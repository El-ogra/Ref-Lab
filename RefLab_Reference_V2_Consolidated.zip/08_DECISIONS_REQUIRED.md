# 08 — Decisions Required
## RefLab Version 2 (V2) — the RealLab **V-CD-2019** line

* **System under documentation:** RefLab Version 2 (V2), the RealLab V-CD-2019 line.
* **Shipped executable:** `real lab system.exe`, **FileVersion 1.605**, `Description: RLS 1.605`, `CompanyName: RealLab`, 76,292,096 bytes, PE32 / linker 6.0, PE build stamp 1595435962 (2020-07-22 16:39:22 UTC).
* **Deployment root:** `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`).
* **Evidence patch markers:** `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`.

**Documentation-only identifiers used in this document.** `DEC-##` (this document), `GAP-##` (gap catalogue in document `07_GAPS_AND_LIMITS.md`), `COR-##` (correction) and `C-##` (conflict) are labels created by the specification. They are **documentation-only** and are not system identifiers: they appear in no product artefact, no configuration file and no runtime component.

---

## 1. What this document is, and how to read it

This document lists the **material unresolved issues that require a decision by the product owner or the replacement project** before the corresponding part of the specification can be finalised. It deliberately does **not** list every undocumented detail: an item belongs here only when the archive holds two or more distinguishable readings, two or more distinguishable behaviours, or an explicit trade-off that only the owner can settle. Every other absence of evidence is a **fact about the evidence**, not a choice, and is carried in the gap catalogue of document `07_GAPS_AND_LIMITS.md`; the last section of this document, **"Not decisions"**, points to those items explicitly so that they are not silently lost.

**Structure of each entry.** Every decision entry has the same six parts:

1. **Question** — the decision, stated as a question that has to be answered.
2. **Evidence** — the archive material that makes the question necessary, with its provenance.
3. **Options** — only options that are *supported by the evidence* or that are *logically distinguishable* from it. No option is invented.
4. **Consequence** — what follows from each option.
5. **Blocked until decided** — the work that cannot start or cannot be completed.
6. **Source references** — the provenance markers and the gap/conflict identifiers.

**Evidence classes** used in this document are the specification-wide set: **VERIFIED** (directly readable in the cited file) · **INFERRED** (derived by deterministic re-computation from cited evidence) · **UNVERIFIED** (asserted but not re-checkable) · **NOT DOCUMENTED** (no artefact describes it) · **NOT RECOVERABLE** (asserted once, supporting artefact absent from the archive).

**Options not listed are not open.** Where only two behaviours are evidenced (for example two documented installation roots), exactly two options are given, even if a third could be imagined; inventing a third option would misrepresent the evidence.

---

## 2. Decision index

| ID | Decision required | Source | Blocked until decided | Priority |
|---|---|---|---|---|
| **DEC-01** | Which database engine(s) the replacement supports | `C-14`, GAP-15, GAP-16 | Schema-version strategy, permission enforcement, install media | **Blocking** |
| **DEC-02** | Which application root and data root are supported | `C-09` (resolved in Stage 2 as a layer separation; the choice remains) | Install script, `SETUP.LST`, media layout, DEC-03 | **Blocking** |
| **DEC-03** | Whether the four PDF output roots stay hard-coded | P11-2, P05-14 | Report writer, print routing, deployment guide | High |
| **DEC-04** | Whether the shipped PDF engine dependency is kept | P11-1, P11-5, P11-8 | Print architecture, install chain, DEC-05 | High |
| **DEC-05** | Third-party licence posture of the print stack | P11-6 | Distribution model, third-party notices | High |
| **DEC-06** | Supported operating-system baseline and runtime payload | P10-5, P11-9, P11-10 | Media build, component inventory, DEC-09 | High |
| **DEC-07** | How the SMS gateway credentials are stored | P07-08-5, GAP-13 (closed in Stage 2) | Security requirement set, schema definition | High |
| **DEC-08** | Whether `VIDAS` is part of the supported data path | P10-7, GAP-14 | Data-model completeness statement, attach step | Medium |
| **DEC-09** | Installation-completeness policy for the five absent Microsoft installers | P10-9, COR-09, GAP-11 | Media build, prerequisite documentation | Medium |
| **DEC-10** | Whether the `English (Canada)` display-language prerequisite stays | P05-4 | Locale policy, date rendering | Medium |
| **DEC-11** | Which documentation layer is the consolidated record | `C-17`, GAP-26 | Citation rules across the specification | Medium |
| **DEC-12** | Installer behaviour: font step, repair path, elevation model | P05-3, P05-8, P10-3 | Installer design, first-install success | Medium |

**Decisions required: 12.**

---

## 3. The decisions

### DEC-01 — Which database engine(s) does the replacement support?

**Question.** Is RefLab V2 replaced with an Access-backed deployment only, a SQL-Server-backed deployment only, or a product that supports both engines with the per-engine DDL dialects implemented as shipped?

**Evidence.**
* The installer offers exactly two engine choices: Access via `Microsoft.JET.OLEDB.4.0` → `D:\real lab system\bin\Patients.mdb`, and SQL Server 2005 → `D:\Lab_data\Patients.mdf`, with the default instance name **`reallabserver`**. `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §4 + §4.1]`
* The embedded DDL is emitted **once per engine dialect**; the effective schema change is **132 distinct (table, column) additions across 29 tables**, **13 type-change statements (12 distinct pairs) across 8 tables**, and **14 distinct created tables** — not 268 statements / 228 columns / 27 tables. `[P04 | ddl-all.txt | all 268 statements, VA offsets]` · `[P11 | analysis/BATCH-04/schema/added-columns.csv | 228 rows → 132 distinct pairs]` — VERIFIED.
* The shipped Access database has **103 tables** and does **not** contain `useraccounts`, `loger` or `win32_processor` (103 tables contain `loggroup`); `win32_processor` is queried as `Select * from Win32_Processor`, an OS-catalogue relation. `[P07-08 | v2019-Patients.mdb.sql | full 103-table parse]` · `[P11 | analysis/BATCH-04/sql_v1605/tables.csv | rows "useraccounts", "loger", "win32_processor"]` — VERIFIED.
* The shipped `Helicobacter` table has **6 columns**; the declared shape has **7** (the `ALTER … ADD hpab/hpbiop/hpiga` statements exist only in the SQL-Server dialect block). `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [Helicobacter]]` · `[P04 | ddl-all.txt | 0x67B442 / 0x67B4A2]` — VERIFIED.
* Access-only DDL idioms appear in the script: `ALTER Table PTC ADD ConstID AUTOINCREMENT(1, 1)`, `ALTER Table payment ADD paymentnum AUTOINCREMENT(1, 1)`, `ALTER Table patienttest ADD COLUMN NatighU YESNO`. `[P04 | ddl-all.txt | 0x67D816 / 0x67D9D2 / 0x67D8F6]` — VERIFIED.
* The vendor's own rule, quoted from the installer: *"If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD."* `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §4 "★ اختيار محرّك قاعدة البيانات"]` — VERIFIED.

**Options.**
* **(a) Access only.** The shipped Access shape (103 tables, 1,682 columns) is the target of record; the SQL-Server-only constructs (`useraccounts`, `loger`, `win32_processor`, the 7-column `Helicobacter`) are outside the data model. The permission model is then the `patients.grant1 … grant17` column set alone, with `useraccounts` absent.
* **(b) SQL Server 2005 only.** The declared DDL shape is the target of record; `useraccounts`, `loger` and `win32_processor` are in the model, `Helicobacter` carries its declared columns, and `SQLEXPR.EXE` becomes a hard installation prerequisite that the supplied media does not carry (see DEC-09).
* **(c) Both engines, as shipped.** The per-engine dialect split is implemented twice; the installer offers the engine choice and the documented rule holds — switching engines does not move the data.

**Consequence.**
* (a) drops three SQL-Server-side constructs that the code addresses, which the archive shows but never explains (GAP-16), and fixes the `Helicobacter` shape to the 6-column shipped table.
* (b) requires the installation media to carry the SQL Server engine (absent — GAP-11) and leaves the permission model's `useraccounts.gtype/hdd1/hdd2` and the `loger` attendance table unevidenced (GAP-16, C-14).
* (c) doubles the schema-version work (the same script, two spellings) and preserves the documented orphaning behaviour of a mid-deployment engine change.
* In all three cases the V2 permission model (`grant1..grant17`, `patientusid`, `patientuscap`, `patientad`, `patientword`, `SecWord Text (10)`, `branche Integer`, `showtip`, `tipnum`, `khasmlimit`, `startwork`/`endwork`/`breakyorn`/`breaktime`) must be carried, because it is the only permission structure the archive evidences. `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [patients]]` — VERIFIED.

**Blocked until decided.** The schema-version strategy (which of the 132 added columns and 14 created tables the replacement versions, and in which dialect); whether `useraccounts`, `loger` and `win32_processor` are in scope; the permission-enforcement design; the installation media content (with DEC-06 and DEC-09); the deployment description of the data store.

**Source references.** `C-14` (PARTIALLY RESOLVED — SQL-Server-side remainder **REQUIRES CONFIRMATION**), `C-06`, `COR-04`, `COR-05`; GAP-11, GAP-15, GAP-16; findings P04-1, P04-4, P05-9, P05-10, P07-08-4, P07-08-7, P07-08-8.

---

### DEC-02 — Which application root and data root are supported?

**Question.** Is the supported deployment `D:\real lab system\` with data at `D:\Lab_data`, `C:\Program Files\real lab system` with data at `D:\Lab_data` or `E:\Lab_data`, or a configurable root?

**Evidence.**
* **Application root, reading A:** `SETUP.LST` carries `DefaultDir=$(ProgramFiles)\real lab system`; this is the only root carried into the final consolidated version card. `[P10 | 12-install-media.md | §2.3]` · `[P11 | reports/Stage-9-V-CD-2019-Final-Comprehensive-Report.md | §2 "مسار التثبيت"]` — VERIFIED.
* **Application root, reading B:** the tree the installer actually copies is rooted at `D:\real lab system\`, with `bin\` (`Patients.mdb`, `RLUTool.exe`, `real lab timer.exe`, `Patient Data Transport.exe`, `RealLab support.exe`, `Branch_Data.mdb`), `Data\` (+ `Data\data_emp\`), `Cache\`, `Images\`, `Fonts\` — 16 extracted `cmd.exe` invocations; the shipped setup manual names the same root for the font step and for launching the program. `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §4 + §5]` · `[P05 | RLS_Setup.txt | fonts step and "تشغيل البرنامج"]` — VERIFIED.
* **Data root, reading A:** `D:\Lab_data` — the shipped manual's attach step and `Setup.bat`. `[P05 | RLS_Setup.txt | "نقوم بالدخول فى المسار الأتى D:\Lab_data"]` — VERIFIED.
* **Data root, reading B:** `E:\Lab_data` — `BASE.ini loca=`. `[P10 | 12-install-media.md | §2.3]` — VERIFIED.
* The four PDF output roots are hard-coded to `D:\PDF\Contracts\`, `D:\PDF\Free\`, `D:\PDF\Individual\`, `D:\PDF\LabToLab\`. `[P11 | pdf-print-stack.md | §2.2]` — VERIFIED.
  * **Stage 2 — the four readings are different artefacts with different roles, not a contradiction.** `SETUP.LST` *declares* the default application root `$(ProgramFiles)\real lab system`; `System\Setup.bat` *executes* against `D:` and `cd\Lab_data` and then runs `OSQL … -i Attaching.sql` and `Attach_database.bat`; the shipped `bin\BASE.ini` *configures* the application data root `loca=E:\Lab_data`; the shipped `bin\SETING.ini` *configures* the backup path `backuppath=D:\lab_data`. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Setup] DefaultDir]` · `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\System\Setup.bat | D: / cd\Lab_data / OSQL / Attach_database.bat]` · `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\BASE.ini | [oledb] loca=E:\Lab_data]` · `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\SETING.ini | [setup] backuppath=D:\lab_data]` — VERIFIED.
  * **The conflict is therefore closed as a documentation defect (COR-13); which root is the supported configuration remains this decision.**

**Options.**
* **(a) `D:\real lab system\` + `D:\Lab_data`.** The root the installer actually writes and the root the shipped manual names; also the only combination consistent with the hard-coded `D:\PDF\…` output roots.
* **(b) `C:\Program Files\real lab system` + `D:\Lab_data` or `E:\Lab_data`.** The root declared in the official install manifest (`SETUP.LST`), with the data root still to be chosen between the two documented values.
* **(c) A configurable installation root** (the `SETUP.LST` mechanism already supports a `DefaultDir` substitution), with one of the two documented roots as the default.

**Consequence.**
* (a) preserves every path that is hard-coded in the product's own material, including the PDF output roots and the SQL-Server data path `D:\Lab_data\Patients.mdf`; it also reproduces a deployment whose data lives on the same volume as the application.
* (b) matches the manifest but leaves the data root ambiguous between `D:\Lab_data` and `E:\Lab_data` — two different volumes for the SQL Server data file and the Access `.mdb`, and two different values for `Attach_database` / `Attach_Patients`.
* (c) resolves the ambiguity for the application root but requires the PDF output roots and the `Attach_*.bat` family to become path-parameterised as well (they are not parameterised in the shipped scripts — see DEC-03).

**Blocked until decided.** The install script and the re-issued `SETUP.LST`; the deployment guide's paths; the media layout; the print routing decision (DEC-03); the attach step described in the manual.

**Source references.** `C-09` — **RESOLVED in Stage 2 as a layer separation (COR-13)**; the *choice* of supported root remains open here. GAP-13 (root/branch information), findings P05-3, P05-5, P05-11, P10-2, P10-4, P11-2, S2-03.

---

### DEC-03 — Do the four PDF output roots stay hard-coded?

**Question.** Does the replacement keep the four fixed PDF destinations `D:\PDF\Contracts\`, `D:\PDF\Free\`, `D:\PDF\Individual\`, `D:\PDF\LabToLab\`, or does it make them configurable?

**Evidence.**
* The four roots are literal in the code, with UI labels `Contracts` / `Free` / `Individual` / `Lab To Lab` and the stored form `LabToLab`. `[P11 | pdf-print-stack.md | §2.2 "شجرة الإخراج — تصنيف PDFs الأربعة"]` — VERIFIED.
* The same four-way commercial classification appears in the data model — `patientinfo.pricemethod Text (10)` and `Gehats.pricemethod Text (20)` with the values `Lab To Lab` / `Individual` / `Free` — `[P07-08 | v2019-Patients.mdb.sql | lines 803 and 1954]` — and in the vendor's own guide, §6:7 "ضبط نوع الحساب الافتراضي (غالبًا Lab To Lab)". `[P05 | learn_toc.jpg | section 6:7]` — VERIFIED.
* The synthesis — one four-way classification driving both the pricing context and the PDF destination — is INFERRED from the three verified elements. `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §4 + §5]` · `[P07-08 | v2019-Patients.mdb.sql | patientinfo.pricemethod]` · `[P11 | pdf-print-stack.md | §2.2]`.

**Options.**
* **(a) Keep the four fixed roots exactly as they are.** Behaviourally identical output placement; the deployment remains tied to a `D:` volume, and the taxonomy stays implicit in the directory names.
* **(b) Make the four roots configurable, keeping the same names and the same four-way taxonomy as the default.** The taxonomy is preserved and becomes visible to configuration and to the deployment guide.
* **(c) Use one configurable output root**, carrying the classification in the file name or in report metadata rather than in the directory path.

**Consequence.**
* (a) preserves operator-visible behaviour exactly, including any scripts or operator habits that depend on the four directories, but hard-codes a drive letter into the product.
* (b) changes no output content and adds only a configuration surface; it also removes the dependency on a specific drive letter, which interacts with DEC-02.
* (c) changes the on-disk contract of every printed artefact, so any downstream consumer of the PDF directories must be re-specified.

**Blocked until decided.** The report writer's output-path logic; the print-routing table; the deployment guide's directory layout; the packaging of the print subsystem.

**Source references.** GAP-20, findings P11-2, P11-4, P07-08-11, P05-14.

---

### DEC-04 — Is the shipped PDF engine dependency kept?

**Question.** Does the replacement keep the hard-coded dependency on the `Bullzip PDF Printer` driver (version **11.1**), substitute a different PDF engine, or replace the print layer with a built-in writer?

**Evidence.**
* The driver name and its version are literals in the binary — `Bullzip PDF Printer` at `0x6A2486` and the default output name `Bullzip PDF Printer 11.1 - Create File` at `0x6A255E` — and the application uses `EnumPrintersA` and `SetDefaultPrinterA`. Upgrading the driver breaks PDF output. `[P11 | pdf-print-stack.md | §2.1 "الاسم مُثبَّت داخل الكود"]` — VERIFIED.
* **Six logical printer roles** exist: `reportprinter`, `reportprinterx`, `zarfprinter`, `barcodeprinter`, `waslprinter`, `IDprinter`. `[P11 | pdf-print-stack.md | §2.4 "أدوار الطابعة الستة"]` — VERIFIED (names).
* The print stack is **100 % third-party and contains zero first-party code**: zero vendor strings (`real lab`/`RL_SETUP`/`Lab_data`/`.mdb`/`Attach_*`) and zero references to `Bullzip`/`BZPDF`/`gslite`/`ghostscript`/`pdftops`/`xpdf`/`pdfpowertool` inside the five stack files ⇒ the print layer is fully replaceable without touching application logic. `[P11 | pdf-print-stack.md | §1 "★★ النتيجة الأهم: لا مراجع Vendor داخل مكدّس PDF"]` — VERIFIED.
* The print audit trail is per-result, with a sequential counter: `SELECT patientid,testcode,resultprint,printuser,printdate,printnum FROM patienttest WHERE testcode in (6,7,8,9,14,15,16,17,18,19,20,21)` — 12 printable test codes — and the quality gate `Not found any Verified selected tests or result to print it`. `[P11 | pdf-print-stack.md | §2.5 "سجلّ الطباعة (أثر تنظيمي)"]` — VERIFIED.
* The installation chain has a proven defect: `RL_SETUP.exe` invokes `System\PDF\SetupP.bat` **before** `System\SetupPZ.bat`; `SetupP.bat` installs Bullzip *before* ‹.NET 4› (which Bullzip 11 requires) ⇒ the first attempt fails and the second succeeds; `System\PDF\SetupFN4.bat` is orphaned and its ‹.NET 4› path is relative-incomplete. `[P11 | pdf-print-stack.md | §5.1 "★★ عيب في سلسلة التثبيت (مُثبت)"]` — VERIFIED.

**Options.**
* **(a) Keep the Bullzip driver dependency, pinned at 11.1.** Print output is byte-compatible with the shipped product; the driver must be installed at that version, and the hard-coded literal keeps that a hard requirement.
* **(b) Substitute another PDF engine** and re-implement the six-role routing and the four-root placement (DEC-03) against it.
* **(c) Replace the print layer with a built-in writer.** The archive shows this touches no application logic (zero first-party code in the stack), but the print audit trail — the 12 printable test codes, the `printnum` sequence and the verified-results gate — must then be re-implemented inside the application, where it did not live before.

**Consequence.**
* (a) preserves behaviour and keeps the install-chain defect (GAP-25) unless the ordering is corrected; it also keeps the signature and licence exposure of DEC-05.
* (b) requires a compatibility assessment of the six roles and of the output naming that the archive cannot supply (GAP-20).
* (c) moves the audit trail into the application, which changes where print history is stored and must be reconciled with the `patienttest` columns `resultprint`, `printuser`, `printdate`, `printnum`.

**Blocked until decided.** The print architecture; the installation chain for the print subsystem; the DEC-05 licence posture; the print audit trail's owner component.

**Source references.** GAP-20, GAP-25, findings P11-1, P11-3, P11-4, P11-5, P11-8, P11-11.

---

### DEC-05 — What third-party licence posture applies to the print stack?

**Question.** Does the replacement keep the shipped third-party stack as it is, substitute the copyleft-licensed components, or keep them under an explicitly documented isolation boundary?

**Evidence.**
* Ghostscript = **AGPL v3** (the `COPYING` file is the full AGPL text, no exception); Xpdf = **GPL v2/v3 dual** (`COPYING` + `COPYING3`); Bullzip = **commercial** (PRO/EXP); PDF Power Tool = **commercial**; ‹.NET 4.0› = Microsoft EULA. **Ghostscript ships twice** — standalone and embedded inside Bullzip. `[P11 | pdf-print-stack.md | §6 "★★★ الامتثال الترخيصي"]` — VERIFIED.
* The installed binaries are signed but with **SHA-1** message digests; Bullzip's certificate chain is `CN=BioPDF ApS … COMODO RSA Code Signing CA`, valid 2015-10-12 → **2020-10-11**; the timestamping signer is valid 2015-12-31 → **2019-07-09**. `osslsigncode verify` reports `Signature verification: failed` and `Timestamp Server Signature verification: failed` while the message digest itself matches. **3 of the 5 installers are entirely unsigned.** `[P11 | pdf-print-stack.md | §4 "★★★ التوقيع الرقمي — نتيجة أمنية مهمة"]` — VERIFIED.

**Options.**
* **(a) Keep the shipped stack** and accept the AGPL v3 obligations for Ghostscript and the GPL v2/v3 obligations for Xpdf, including the notice and source-availability duties that attach to distributing them.
* **(b) Substitute the copyleft components** (keeping the commercial components), which requires re-testing the five-file stack's PDF output behaviour.
* **(c) Keep Ghostscript but isolate it as an unmodified external binary**, shipping the licence text and documenting the boundary between the product and the external process.

**Consequence.**
* (a) constrains the distribution model — a closed distribution of an AGPL component carries obligations that a commercial product owner must accept explicitly.
* (b) directly determines DEC-04's option (b) or (c), and re-opens the PDF-output equivalence testing that the archive cannot perform (no dynamic evidence — GAP-09).
* (c) is a middle position that still requires a documented boundary and a packaging decision; it does not remove the AGPL text from the shipped media.
* In all three cases the SHA-1 digests and expired certificate validity of the shipped installers must be replaced with currently valid signatures, since 3 of the 5 installers are unsigned outright.

**Blocked until decided.** The distribution and licensing plan; the third-party notices file; the final answer to DEC-04.

**Source references.** GAP-09, findings P11-6, P11-7.

---

### DEC-06 — Which operating systems and runtime payload are supported?

**Question.** Does the replacement support both shipped installation targets, a single modern target, or a defined range with one media build per target?

**Evidence.**
* The two targets ship **different builds** of the same runtime components: Jet 4 build `4.0.9756.0` (2009-07-14) on WIN7 against 2008-04-14 on WINXP; `msvbvm60.dll` 1,386,496 against 1,384,479; `MSCOMM32.OCX` 103,744 (6.0.81.69, 1998) against 120,648 (6.1.98.13, 2008); `MSFLXGRD.OCX` 244,024 against 259,912; `msado27.tlb` 98,304 (2010) against 81,920 (2008). **32 of 48 byte-identical.** `[P10 | 12-install-media.md | §4 "★ الحسم الثالث: الفرق بين هدفَي ويندوز"]` · refined by `[P11 | cab-inventory.csv | 96 rows, cross_target column]` — VERIFIED.
* The ‹.NET 4.0› payload is **RTM**, not 4.x and not SP: MSIs dated 2010-03-18, unsupported since **2014-04-29**, not shipped with Windows 8/8.1/10/11 ⇒ not compatible with Windows 10/11; it also replaces `RGB9RAST.dll` (text rasterisation) ⇒ a latent visual-regression surface. `[P11 | pdf-print-stack.md | §3.2 "dotNetFx40_Full_x86_x64.exe — Microsoft Box Stub"]` — VERIFIED.
* Installation is non-deterministic in two respects: `cmd.exe /C start /B WIN7\setup.exe /sc:\setup.log` (and the WINXP twin) writes the install log to **`C:\setup.log`** (root of C:, no backslash after the colon), and `start /B` has **no `/wait`**, so the operator can start the application before the ActiveX/font installation completes. `[P11 | pdf-print-stack.md | §5.2 "★ أثر جانبي: سجل التثبيت على جذر القرص"]` — VERIFIED.
* The training layer is a 2011-era screen recording of the V2 application itself (`RLS_Learn.wmv`, 35:20.20, 1360×768 / 15 fps), showing a Windows 7 desktop. `[P06 | 00_overview.jpg | contact sheet header and frame #1]` · `[P06 | 06_detail_0100s.jpg | frame #16 taskbar]` — VERIFIED.

**Options.**
* **(a) Support both shipped targets**, with their differing runtime builds, as the media does today.
* **(b) Support a single modern target only.** Then the ‹.NET 4.0› RTM payload must be replaced by a supported runtime, the `RGB9RAST.dll` replacement disappears, and the 16 differing members collapse to one build.
* **(c) Support a defined range with a documented runtime matrix** — one media build per supported target, with the runtime differences enumerated rather than incidental.

**Consequence.**
* (a) preserves the 5 lab fonts, the 19 ActiveX controls and the Jet 4 engine as shipped, and preserves the two-target installation media's byte-level differences; the unsupported-runtime exposure remains.
* (b) removes an unsupported-runtime exposure and the `C:\setup.log` side effect can be dropped, but every component must be re-tested on the new target and the 2011-recorded screen behaviour has no observable reference beyond the contact sheets.
* (c) makes the runtime differences a specification input rather than an accident, at the cost of several media builds.

**Blocked until decided.** The installation media build; the runtime component inventory; the visual-regression policy for printed text; DEC-09.

**Source references.** GAP-19, findings P10-5, P10-6, P11-9, P11-10, P06-1, P06-5.

---

### DEC-07 — How are the SMS gateway credentials stored?

**Question.** Does the replacement keep the clear-text `MyLabSetting.accuntID` / `accuntpw` pair for behavioural parity, keep the schema but protect the value at rest, or move the gateway account out of the database entirely?

**Evidence.**
* `MyLabSetting` stores an SMS-gateway account and password in clear text in the shipped V2 database: `LabID Integer`, `sendername Text (15)`, **`accuntID Text (50)`**, **`accuntpw Text (50)`**, `updateflage Byte`, `Hourflag Integer`, `SMSNo Integer`, `totalsms Double`, `SMSSend Double`, `SMSbakey Double`, `phoneNo1..phoneNo6 Text (15)`, `phonenum Integer`, `Timess Text (100)`, `FridaySend Byte`, `shortsms Byte`. `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting], line 709]` — VERIFIED (the clear-text storage); **Stage 2 — the fields ARE populated in the shipped V2 database**: the table holds **5 rows** (one per branch slot, `LabID` 100–500); in the `LabID`=100 row `accuntID` holds an 8-character value and `accuntpw` a 6-character value, both as clear `Text (50)`, with `SMSbakey` (3 characters) and `sendername` = `RealLab`; rows 200–500 carry empty credential columns. The database was opened read-only and no live system was contacted, so this is a statement about the shipped V2 store, not about a running installation. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only via Microsoft.ACE.OLEDB.12.0]` — VERIFIED. GAP-13 is **CLOSED**; GAP-10 (the wider row-count question) remains open.
* The same table is the SMS subsystem's scheduling and quotable control surface: `FridaySend` (weekday gate), `shortsms` (short-message mode), `Hourflag` + `Timess Text (100)` (schedule), `totalsms`/`SMSSend`/`SMSbakey` (counters / balance). `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]]` — VERIFIED (columns) / INFERRED (semantics).
* The table is created by the embedded DDL (`Create Table MyLabSetting (LabID Smallint`, VA `0x674A32`) and is present in the shipped database — it is one of the 14 distinct created tables. `[P04 | ddl-all.txt | VA 0x674A32]` · `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]]` — VERIFIED.
* The capability catalogue includes results delivery and SMS-adjacent reporting, and the statistics module lists "sent samples" among its statistic types. `[P05 | learn_toc.jpg | section 1:9]` · `[P06 | 06_detail_0100s.jpg | frames #6, #7]` — VERIFIED.

**Options.**
* **(a) Preserve the schema and the clear-text storage.** Maximum behavioural parity: any existing installation's data file loads unchanged.
* **(b) Preserve the schema but store the value protected at rest** (encrypted or obfuscated inside `accuntpw`). The column set, widths and all other fields stay identical; only the stored representation changes, and a key must be provisioned at deployment.
* **(c) Move the gateway account out of `MyLabSetting`** into an operating-system credential store or an encrypted configuration file, keeping `MyLabSetting` for the non-secret settings (`FridaySend`, `shortsms`, `Hourflag`, `Timess`, the counters and the phone numbers).

**Consequence.**
* (a) keeps the exposure that the shipped schema demonstrably carries, and the archive places this table outside the consolidated security findings, so the exposure would otherwise be inherited silently.
* (b) keeps every query, report and installer path intact but requires key provisioning and a failure mode for a wrong or missing key.
* (c) removes the secret from the database entirely and matches the storage of other deployment secrets, at the cost of a new provisioning step in the deployment guide.
* All three options must also answer the vendor's own scheduling semantics gap (GAP-21), because the same table carries them.

**Blocked until decided.** The security requirement set; the `MyLabSetting` schema definition in the replacement; the deployment guide's provisioning steps; the SMS subsystem's configuration surface.

**Source references.** GAP-13 (**closed in Stage 2** — the credential is populated in the shipped V2 store), GAP-21 (partly resolved in Stage 2), findings P07-08-5, P07-08-6, P05-12 (licence and hardware binding context), S2-04.

---

### DEC-08 — Is `VIDAS` part of the supported data path?

**Question.** Does the replacement have to interoperate with the `VIDAS` database referenced by `Attach_VIDAS.bat`, and if so, what is its structure?

**Evidence.**
* `Attach_VIDAS.bat` names a database **`VIDAS`** that no artefact describes. `[P10 | 12-install-media.md | §5.1]` — NOT DOCUMENTED.
* The only link is the toolchain manifest `System\datareport_vh\redist.txt` (213 entries), which lists **`vfp6run.exe`, `vfp6t.dll`, `vfp6rrus.dll`** alongside the VB6/VC6 redistributables and `.dbf`/`.fpt` project artefacts — Visual FoxPro 6.0 is inside the product's toolchain. `[P10 | 12-install-media.md | §5.1 "★★ redist.txt — بيان Visual Studio 6.0 SP6 · 213 مدخلًا"]` — VERIFIED (the manifest contents); INFERRED (the link to `VIDAS`, explicitly flagged as a hypothesis by the source).
* The consequence if the hypothesis holds: a FoxPro-backed schema would be **invisible to a schema extraction of `Patients.mdb`**, so the 103-table Access dump would not be a complete description of the product's data. `[P07-08 | v2019-Patients.mdb.sql | full 103-table parse]` — INFERRED.
* **No FoxPro artefact was ever received**, so nothing about `VIDAS` is recoverable from the archive (GAP-14).

**Options.**
* **(a) Confirm that `VIDAS` is a FoxPro-backed schema that the replacement must interoperate with**, and supply its structure and interface.
* **(b) Confirm that `VIDAS` is not part of the supported data path**, and record `Attach_VIDAS.bat` as outside the supported installation flow.
* **(c) Supply a `VIDAS` data dictionary** (table list, keys, column types) so the interface can be specified without a live artefact.

**Consequence.**
* (a) makes the data-model statement of the specification provisional until the second schema is delivered; every "the V2 schema has 103 tables" statement is then incomplete.
* (b) closes the gap cleanly and lets the specification state the schema inventory as complete; it also means the `Attach_*.bat` family in the install flow has one member with no purpose, which must be stated.
* (c) is the minimum input that lets the specification be written without either commitment.

**Blocked until decided.** Whether the data-model section of the specification can state a complete table inventory; the content of the database-attach installation step; the completeness claim attached to the shipped-schema dump.

**Source references.** GAP-14, GAP-10, findings P10-7, P10-9, P07-08-1.

---

### DEC-09 — What is the installation-completeness policy for the five absent Microsoft installers?

**Question.** Must the replacement ship equivalents of the five large Microsoft primary installers the setup scripts reference, may it drop the dependencies they satisfy, or may it require the operator to supply them?

**Evidence.**
* The disc is **partial**: 28 of the 39 CAB files are present in the delivered tree, but the five large Microsoft primary installers referenced by `Setup*.bat` are **absent** — `System\MSSQL_Server_Express_2005\SQLEXPR.EXE`, `System\Microsoft_Windows_Installer_3.1\WI-KB893803-v2-x86.exe`, `System\Microsoft_xml6.0\msxml6_x86.msi`, `System\Microsoft.NET_Framework2.0\dotnetfx.exe`, `System\mysql-connector-odbc-3.51.30-win32.msi`. `[P10 | 12-install-media.md | §7 "★ حالة ISS-33 — ما زال متبقٍّ وأصبح دقيقًا"]` — VERIFIED.
* `D:\Lab_data\Attaching.sql` and `Attach_database.bat` are **created at install time**, not shipped. `[P10 | 12-install-media.md | §7]` — VERIFIED.
* The install-path issue was marked **"✅ VERIFIED"** with a residual note retained: *"بقيت ملاحظة منفصلة: 5 مثبّتات Microsoft الكبرى (SQLEXPR · MSXML · .NET FX2 · MSI 3.1 · MySQL ODBC) غير موجودة في الشجرة المُشحنة"*. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-33]` · earlier statement at `[P10 | 10-Issues/Open-Issues-and-Limitations.md | ISS-33]` — VERIFIED.
* `MDAC_TYP.EXE` (8,124,720 B) at `System\MDAC_TYP\` was the first of the `Setup*.bat`-referenced files to be located, closing part of the question. `[P10 | 12-install-media.md | §6 "MDAC"]` — VERIFIED.

**Options.**
* **(a) Ship equivalents of all five**, so the media is self-contained as the setup scripts assume.
* **(b) Drop the dependencies** those installers satisfy and adjust the install flow — for example if the ‹.NET 4› payload chosen under DEC-06 supersedes the ‹.NET 2.0› installer, or if the MySQL ODBC driver is not used by the supported engine choice under DEC-01.
* **(c) Keep the script references and require the operator to supply the installers** from a separate operator-held bundle, documenting them as external prerequisites.

**Consequence.**
* (a) makes the media self-contained but reintroduces five large redistributables whose exact versions are not recoverable from the archive (GAP-11) — the replacement's choices would have to be documented as its own.
* (b) yields the smallest media but requires a documented argument that each dropped dependency is unnecessary, which depends on DEC-01 and DEC-06.
* (c) keeps the scripts as they are but makes installation two-stage and operator-dependent, and it leaves the archive's own finding (that these files are missing from the supplied tree) as an open operational risk.
* Under every option, the replacement must supply `Attaching.sql` and `Attach_database.bat` (or their equivalent), because the shipped versions are generated at install time and are not in the archive.

**Blocked until decided.** The media build and its manifest; the supported-prerequisites list in the deployment guide; the completeness statement attached to the installation media.

**Source references.** GAP-11, GAP-19, `C-09` (data root), findings P10-8, P10-9, P10-2, COR-09.

---

### DEC-10 — Does the `English (Canada)` display-language prerequisite stay?

**Question.** Must the replacement keep the documented requirement that the client's display language is set to `English (Canada)` for correct date display, or is that dependency removed?

**Evidence.**
* The shipped setup manual requires: `Control Panel → Region and Language → Display language = **English (Canada)**`, described as a hard prerequisite for correct date display; the guide's contents page carries the step "تعديل لغة عرض التاريخ" at p20. `[P05 | RLS_Setup.txt | "تعديل لغة عرض التاريخ"]` · `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §8 contents page]` — VERIFIED.
* The date surface is wide: `requestdate` is `DateTime` in every table that carries it, while `patienttestgroup` stores its date columns as `Text (40)` (`editdate`, `printdate`, `prevdate`, `taslimdate`). `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [patienttestgroup]]` · `[P07-08 | v2019-Patients.mdb.sql | e.g. CREATE TABLE [ABO], [Abuse], [cultures] …]` — VERIFIED.
* The observation screens show dates in an English (Canada)-style rendering on a machine whose clock reads `Thursday, 24-Mar-2011`. `[P06 | 06_detail_0100s.jpg | frames #16 and the report frames]` · `[P06 | 06_detail_0100s.jpg | frames #3, #4]` — VERIFIED (the rendered form); the causal link to the locale setting is INFERRED from the manual.

**Options.**
* **(a) Keep the prerequisite** and carry it into the deployment guide as a hard prerequisite, exactly as the shipped manual does.
* **(b) Remove the dependency** by formatting every date explicitly in the application and in the report templates, so the client's display language no longer affects output.
* **(c) Make the date format an explicit application setting**, with the current rendering as the default, and drop the operating-system prerequisite.

**Consequence.**
* (a) preserves the operator experience and the manual's instructions verbatim, and keeps a deployment-level precondition that is invisible in the code and can break silently on a re-imaged machine.
* (b) removes the precondition but touches every date-bearing surface, including the `Text (40)` date columns in `patienttestgroup` whose encoding is itself undocumented (GAP-22).
* (c) removes the precondition from the operating system while keeping the observable behaviour as the default; it adds one configuration surface.

**Blocked until decided.** The locale and date-rendering requirements; the report templates' date placeholders; the deployment guide's prerequisites list.

**Source references.** GAP-22, findings P05-4, P05-1, P07-08-9, P06-2, P06-5.

---

### DEC-11 — Which documentation layer is the consolidated record?

**Question.** Is the cumulative documentation layer the authoritative consolidated record for the V2 configuration and clinical rules, or do the patch-level analyses and the evidence register remain authoritative?

**Evidence.**
* The cumulative configuration document treats the template layer as "223 `.ini` / 114 categories" and says nothing about `Organism C`, `Check6f` or the signature relocation. `[P11 | analysis/CUMULATIVE/06-configuration.md | §7]` — VERIFIED.
* Those facts exist in the patch-level analyses and in the stage reports, and the evidence register does carry the `Organism C` row. `[P09 | ini-diff-summary.md | §3]` · `[P11 | 11-Evidence/Evidence-Register.md | EV-ANA-045 row text]` — VERIFIED.
* Five V2 facts are present in the archive but in no consolidated document: the dual-dialect DDL; `MyLabSetting.accuntpw` as a clear-text credential in the shipped database; the `Check6f` per-profile 0/1 split; the new `Data\data_emp\R_S.ini` template; and the 13-extractor `patientid` map. `[P04 | ddl-all.txt | all 268 statements]` · `[P07-08 | v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]]` · `[P07-08 | ini-key-delta.csv | 32 rows with key = "form.Check6f"]` · `[P11 | 07-Batch-Ingestion/manifests/BATCH-07-files.csv | rows "…\Data\data_emp\R_S.ini"]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | 58 rows containing "mid(patientid"]` — VERIFIED.

**Options.**
* **(a) Declare the cumulative layer authoritative** and re-issue the documents that omit the three systemic template changes and the five facts listed above.
* **(b) Declare the patch-level artefacts authoritative** and add explicit cross-references from the cumulative layer to them.
* **(c) Create one new consolidated configuration document** — carrying the INI key-level ground truth (3,712 key-level records across 173 `.ini` files: 1,970 ADDED, 897 REMOVED, 845 CHANGED) — and make it the single citation source for the configuration layer.

**Consequence.**
* (a) fixes the omission but requires re-issuing several existing documents, and the re-issue must also resolve the reissuable tables listed in GAP-28.
* (b) leaves the consolidated layer incomplete by construction; a reader who consults only that layer continues to miss the three systemic template changes and the credential finding.
* (c) produces one authoritative source and removes the ambiguity, at the cost of a new document and a re-citation pass across the specification.

**Blocked until decided.** The citation rules of every section of the specification; whether the consolidated documents listed in GAP-28 must be re-issued before or after the choice.

**Source references.** `C-17` — **OPEN, REQUIRES CONFIRMATION**; GAP-26, GAP-28; findings P09-4, P07-08-5, P07-08-13, P07-08-14, P04-1, P04-2.

---

### DEC-12 — What is the installer's behaviour: font step, repair path, elevation model?

**Question.** Does the replacement automate the font installation, keep it as a documented manual prerequisite, or restructure it — and in every case, what elevation and permission model does the installer declare?

**Evidence.**
* Font installation is **manual and outside the installer**: `D:\real lab system\Fonts` → select all → Copy → `Control Panel\Fonts` → Paste, and press OK on the "font already exists, will be reinstalled" prompt. `[P05 | RLS_Setup.txt | "تثبيت برنامج لاير الب سيستم" + "نقوم بفتح مجلد Fonts … Copy … Control Panel … Paste"]` — VERIFIED.
* The installer nevertheless contains a `FontInstaller` (38 procedures) and a `modFonts` (12 procedures), plus a **dedicated repair path** `Frm_repair0..5`, and the full wizard inventory `Frm_rls1..8` + `Frm_rlsAr1..8` (8 install steps), `Frm_rli1..7` + `Frm_rliAr1..7` (7 licence/setup steps), `Frm_mssql1..4` + `Frm_mssqlAr1..4` (4 SQL-Server steps), `Frm_help1..4`, `Form1`(43), `Form2`(10), `frm_start`(2), `RegistryInteraction`(7), `boisais`(16), `Module1`(14), `aaaClass`(15), `BiosData`(8) — 57 objects / 599 procedures in total. `[P05 | Stage-4-V-CD-2019-Deployment-Report.md | §3 + §3.1]` — VERIFIED (form and procedure names) / INFERRED (that a repair path exists and is user-reachable).
* The installer **demands Windows-registry mutation on the client machine** — 24 self-registered ActiveX components and direct writes into `System32`/`SysWOW64` ⇒ any replacement must declare an explicit elevation/permission model. `[P10 | 12-install-media.md | §2.2 "★ الإجراءات التنفيذية عند التثبيت"]` — VERIFIED.
* The install manifest installs **39 files** — 22 `$(WinSysPathSysFile)` + 16 `$(WinSysPath)` + 5 `$(Font)` + 1 `$(MSDAOPath)` — with 24 × `$(DLLSelfRegister)`, 1 × `$(TLBRegister)` and 31 × `$(Shared)`, and the uninstall entry `AppToUninstall=real lab system.exe` with `Uninstal=st6unst.exe`. `[P10 | 12-install-media.md | §2 "★ الحسم الثاني: مواصفة التثبيت الرسمية (SETUP.LST)"]` — VERIFIED.
* The activation procedure is machine-serial based and already requires elevation: `RealLab_Show_Info` is run from the disc (Windows XP: double-click; Windows 7: right-click → *Run as administrator*). `[P05 | RLS_Setup.txt | "كيفية الحصول على سيلاير الجهاز" + "فى حالة ويندوز XP" + "فى حالة ويندوز 7"]` — VERIFIED.

**Options.**
* **(a) Automate the font installation** and keep a repair path (`Frm_repair0..5` in effect), so that a first installation completes the font set without an operator step.
* **(b) Keep the manual font installation as a documented prerequisite** — as the shipped manual does — and keep the repair path.
* **(c) Keep a repair path but rebuild it** around the runtime set and engine chosen under DEC-06 and DEC-01, and around the elevation model declared for the chosen target set.

**Consequence.**
* (a) removes the most common first-install failure mode but changes the installer's effect on the system (it now writes fonts itself) and must still handle the "font already exists" case.
* (b) preserves the shipped operator experience and the manual verbatim, at the cost of a manual step that the archive shows the installer already has code for.
* (c) aligns the repair path with the decisions on runtime and engine, and is the only option that can retire the orphaned, relative-incomplete `SetupFN4.bat` coherently (GAP-25).
* In all three options an explicit elevation/permission model must be declared, because the manifest self-registers 24 ActiveX components and writes into `System32`/`SysWOW64`; the replacement must also state whether `C:\setup.log` and the `start /B` without `/wait` behaviour are retained (DEC-06).

**Blocked until decided.** The installer design; the elevation and permission model; the uninstall path (`st6unst.exe`); the operator documentation of the installation sequence; the print-stack install order that feeds DEC-04.

**Source references.** GAP-25, GAP-11, findings P05-2, P05-3, P05-7, P05-8, P10-2, P10-3, P11-8, P11-10.

---

## 4. Not decisions

The items below are **facts about the evidence**, not choices: no option the owner takes changes what the archive does or does not contain. They are carried in the gap catalogue of document `07_GAPS_AND_LIMITS.md` with their evidence class, their impact on implementation and their provenance, and they must be closed by **new evidence** (a live installation, a vendor answer, an owner-supplied specification) or explicitly accepted as risk.

| Item | Why it is not a decision | Gap / conflict |
|---|---|---|
| Key-level content of the `Data\data_emp\R.ini` change (815 B → 1,824 B) | The changed file was outside the key-level run; only its hashes and sizes survive. No choice recovers it. | GAP-04 (`C-07`, remainder) |
| Provenance of the published "1,617 columns" figure | No artefact in the archive reproduces it; the re-counted 1,682 is the usable figure. | GAP-05 (`C-02`) |
| `RL_Show.pdf` (77 pages) content | No extractable text layer; nothing can be quoted from it. | GAP-06 |
| `RLS_Setup.pdf` pages 2–33 (image-only) | The dialog layouts are not evidenced; only the installer's form inventory covers the wizard. | GAP-07 |
| Body text of `RLS_Learn.pdf` | No `ToUnicode` CMap; only the table of contents was visually corrected. | GAP-08 |
| Any runtime behaviour of the product (report rendering, print routing, licence checks, permission enforcement, reference-range computation, date display) | The archive contains no dynamic evidence of any kind; every finding is static analysis. | GAP-09 |
| Row counts and data of the V2 database; whether `patientinfo` is populated in a real installation | Only the schema dump was ingested; `patientinfo` holds 0 rows in the available evidence. | GAP-10 |
| Contents of the five absent Microsoft primary installers | The files are not in the archive; the *policy* on them is DEC-09, their *contents* are unrecoverable. | GAP-11 (with DEC-09) |
| Contents of the `RL_SETUP.exe` payload | Custom VB6 compression inside `.text`, no standard archive signature; not unpackable without running the installer. | GAP-12 |
| Whether `MyLabSetting.accuntpw` holds a live credential | The schema is known, the data was never ingested; the *handling* decision is DEC-07, the population is unknown. | GAP-13 (with DEC-07) |
| Whether the shipped `Helicobacter` table's absent `hpab`/`hpbiop`/`hpiga` breaks the H. pylori report | Schema proven, runtime behaviour unobservable. | GAP-15 (with DEC-01) |
| Whether `Patient.grant1 … grant17` is enforced at runtime, and how `useraccounts.gtype/hdd1/hdd2` participate | `useraccounts` is absent from the shipped Access database; no deployment was observed. | GAP-16 (with DEC-01) |
| The composition and encoding rule of the 13-character `patientid` | Only the 13 substrings the code extracts are recoverable; the encoding rule is not. | GAP-17 |
| Whether `pregsmok` changes the computed reference range | The column is confirmed `Single` and populated on every row; the rule is not recoverable. | GAP-18 |
| Whether the 96-row CAB inventory was derived from the CAB archives or from the on-disc `OCX\` copies | Not stated in `cab-inventory.csv`; the `cross_target` column implies a per-member extraction. | GAP-19 |
| What `waslprinter` and `IDprinter` produce and to where | The role names are verified; no artefact documents their behaviour. | GAP-20 |
| The semantics of the `MyLabSetting` scheduling and counter fields, including the `Timess` string format | Column names and types are verified; the semantics are not documented. | GAP-21 |
| The rule that populates `patienttestgroup`, and the encoding of its `Text (40)` date columns | Types are verified; the rule and the encoding are not documented. | GAP-22 |
| What writes into `Paste Errors` and how long rows persist | The table shape is verified; its producer and lifecycle are not documented. | GAP-23 |
| The functions of `RLUTool.exe`, `real lab timer.exe`, `Patient Data Transport.exe`, `RealLab support.exe` and the `Natigh` results-delivery service | These are copied by the installer but are absent from the application object inventory; no artefact documents them. | GAP-24 |
| Which script is the intended ‹.NET 4› install entry point | `SetupFN4.bat` is orphaned and its path is relative-incomplete; the shipped order contradicts itself. | GAP-25 (with DEC-04, DEC-06) |
| The 96 extracted CAB runtime binaries; the consolidated PE-envelope table `analysis/BATCH-04/pe-summary.csv` | Their identities and most PE fields are preserved in machine-readable form; the bytes are not. | GAP-02, GAP-03 |
| The three consolidated tables that mix units or universes | Their correct values are known and reissuable; the re-issue is an editorial action, not a decision about the product. | GAP-28 |
| The byte-identical top-level file count (67 against 46) and the ledger totals against the per-patch column sums | Both are internal count discrepancies in the evidence ledger and are settled by recomputation. | GAP-29, GAP-30 |

---

## 5. Counts

| Quantity | Value | Counting method |
|---|---:|---|
| Decisions required | **12** | Entries `DEC-01` … `DEC-12` (§3), matching the index in §2 |
| Decisions marked **blocking** | **2** | `DEC-01`, `DEC-02` — the two that gate the schema strategy and the deployment topology |
| Conflicts routed to a decision | **3** | `C-09` → DEC-02, `C-14` → DEC-01, `C-17` → DEC-11 (the remainder of `C-07` routes to GAP-04 and needs no decision) |
| Options enumerated | **36** | Three options per entry × 12 entries (§3) |
| Non-decision items listed | **24** | Rows of §4 |
| Gaps carried | **30** | Rows `GAP-01` … `GAP-30` of document `07_GAPS_AND_LIMITS.md` |
| Conflicts carried | **16** | Rows `C-01` … `C-17` of document `07_GAPS_AND_LIMITS.md`, minus the withdrawn entry |
| Unresolved conflicts | **2** | `C-14` (remainder), `C-17` — `C-09` was resolved in Stage 2 by layer separation (COR-13) |

---

## 6. Provenance and method

This document was written from the gap-analysis findings file `08_gap_analysis_findings.md` and from the gap catalogue, coverage ledger and conflict register of document `07_GAPS_AND_LIMITS.md`, both of which draw on the seven patch folders of the evidence archive `Reference_V2_Patches_04-11.zip` (patch markers `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`), with the eleventh patch folder's deliverable tree (550 files) as the consolidated reference point. Every entry was raised only where the archive itself offers two or more distinguishable readings or behaviours, or where a documented trade-off requires the owner's judgement; the selection criterion and the separation between a decision and a plain absence of evidence are stated in §1, and the items that failed the criterion are listed in §4 with their gap identifiers rather than being dropped. The evidence classes are the specification-wide set — VERIFIED, INFERRED, UNVERIFIED, NOT DOCUMENTED, NOT RECOVERABLE — and each option set is drawn only from behaviour that is evidenced in the cited material, with the consequence of each option derived from that same material and from the dependencies recorded in the "Blocked until decided" line. The counting method for every figure quoted in §5 is the row that carries it: the decision count is the number of entries in §3, the conflict count is the number of numbered rows `C-01`…`C-17` in document 07, and the gap count is the number of numbered rows `GAP-01`…`GAP-31` in the same document. Every provenance marker is reproduced in the form `[Pxx | path | anchor]` exactly as read; no file name, anchor, line number, page number, table name, column name, INI key, form name, procedure name or printer-role name was invented or normalised.
