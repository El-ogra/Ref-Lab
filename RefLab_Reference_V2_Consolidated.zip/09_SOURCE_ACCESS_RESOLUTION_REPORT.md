# 09 — Source-Access Resolution Report (Stage 2)

**Project:** RefLab V2 · **Target version:** 1.605 · **Stage:** 2 — controlled, read-only source investigation
**Authorized source:** `F:\REAL_LAB_COPY` · **Baseline archive:** `RefLab_Reference_V2_Consolidated.zip` (solution root)
**Execution mode:** continuation of the existing investigation — no reconstruction of Stage 1 findings, no scope expansion beyond the twelve authorised targets.

This report documents what Stage 2 actually did, what it actually found, and what remains open. Every
newly established fact carries an evidence anchor of the form `[SRC | path | anchor]`. Where a fact comes
from the Stage 1 corpus rather than from a newly inspected artefact, the documentation path and locator
are given instead, and the two kinds of evidence are never conflated.

---

## A. Access verification statement

**Access verified at F:\REAL_LAB_COPY.**

The mandatory three-operation gate was executed in order, before any other operation:

| Operation | What was done | Actual result |
|---|---|---|
| **A — directory existence** | `Test-Path -LiteralPath "F:\REAL_LAB_COPY" -PathType Container` | **True** — the directory exists and is a container |
| **B — top-level listing** | `Get-ChildItem -LiteralPath "F:\REAL_LAB_COPY" -Force` (non-recursive, no member opened) | Two entries: `DEMO` (directory) and `real lab system` (directory) |
| **C — actual file read** | Read the first 400 bytes of `F:\REAL_LAB_COPY\real lab system\MCI32.DEP` (2,430 bytes, regular file, immediate child of the authorized directory) with `[System.IO.File]::ReadAllBytes` | **Content read successfully** — a genuine VB6 dependency file (`; Dependency file for setup wizards.`, `[Version] Version=6.1.97.82`, `[MCI32.ocx] Dest=$(WinSysPath) Register=$(DLLSelfRegister) …`) |

* **Access error encountered:** none.
* **Verification timestamp:** 2026-11-14, immediately after the gate; the source tree's newest file
  timestamp is 2026-11-09 13:48:33, which is independent evidence that nothing in the source was
  modified during Stage 2.
* **Source modification status:** none. Every operation against `F:\REAL_LAB_COPY` was a read
  (`Get-ChildItem`, `Get-Content`, `Get-FileHash`, `ReadAllBytes`, a read-only ADO connection, and
  read-only PE/string parsing). All extracted or generated material was written outside the source
  directory, to `…\reflabv2\stage2\`.

### A.1 Version attribution basis

The authorized source contains **two product trees**, distinguished before any substantive inspection:

| Tree | Path | Identity | Eligibility |
|---|---|---|---|
| Earlier build | `F:\REAL_LAB_COPY\real lab system\` | `real lab system.exe` = 59,150,336 B — the size documented for the earlier release | **Out of scope.** Not opened for substantive analysis. |
| **V1.605 payload** | `F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\` | `System\real lab system.exe` = 76,292,096 B, SHA-256 `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0` — the canonical hash already published for the V2 executable in the Stage 1 specification | **Eligible.** All substantive inspection was confined to this tree. |

**Disclosed version-isolation deviation.** While confirming binary identity, one read-only invocation
of the literal scanner was issued against the earlier-build executable. Only its identity header lines
were consumed; the literal-scan output for that binary was never displayed and **no fact derived from
it appears in this report, in any consolidated document, or in any conclusion**. It is recorded here for
completeness rather than because it contributed to a finding.

---

## B. Target-by-target outcome

### B.1 — T1 · SETUP.LST installation manifest — **RESOLVED**

**Investigated:** the V1.605 install manifests of both OS targets.
**Actually inspected:** `RL_CD2019Access\WIN7\SETUP.LST` (6,906 B, SHA-256 `96AFE35E47B9EBE676F1937BF2A0AD3652EC1E28A403083F5C23DD68CB699A65`) and `RL_CD2019Access\WINXP\SETUP.LST` (6,901 B, SHA-256 `F880D254CD337B8969B50C4577458BD2C0EACF2EE8855C31D002AF96DFACDD8A`) — read in full.
**Result:** the manifest has **four** sections and **45** entries: `[Bootstrap]` (6 keys), `[Bootstrap Files]`
(**6** entries), `[Setup]` (4 keys) and `[Setup1 Files]` (**39** entries). The `[Bootstrap]` block is
exactly as previously documented; the `[Bootstrap Files]` section was **never recorded in Stage 1**. The
Setup1 destinations are **12 / 21 / 5 / 1** (`$(WinSysPathSysFile)` / `$(WinSysPath)` / `$(Font)` /
`$(MSDAOPath)`), not the 22 / 16 / 5 / 1 previously published; self-registration is **24** in Setup1 plus
**3** in the bootstrap section (**27** manifest-wide); `$(TLBRegister)` = 1 (`STDOLE2.TLB`, bootstrap
section); `$(Shared)` = **27**, not 31. `DefaultDir=$(ProgramFiles)\real lab system` is a **declaration**,
and the two targets declare the same members with different dates, sizes and versions. The member
`MSCOMCTL.OCX` / `mscomctl.ocx` is declared with the **same size (1,081,616)** and the **same version
string (6.1.97.82)** in both targets — only the casing differs — which independently corroborates C-08.
**Identifiers:** C-09, C-08, COR-12, COR-13, GAP-25.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Bootstrap Files] and [Setup1 Files] sections, 45 entries]` · `[SRC | …\WINXP\SETUP.LST | same structure]`.
**Class:** CONFIRMED FACT. **Residual uncertainty:** the manifest declares what is *installed*; it does not prove what the `RL_SETUP.exe` wizard actually executes.

### B.2 — T2 · BASE.ini configuration and connection logging — **RESOLVED**

**Investigated:** the shipped configuration and its data-root key and connection log.
**Actually inspected:** `RL_CD2019Access\bin\BASE.ini` (381 B, SHA-256 `723EEBD58278C5A9D2C09864FDFE33C60E7110FD3CB07242FED3C71943CCBC90`) — read in full.
**Result:** the file has three sections. `[oledb]` carries `Databasetype=XMSACCESSX`, **`loca=E:\Lab_data`**,
`DataSource=REAL_LAB`, `PersistSecurityInfo=True`, `UserID=sa`, the documented hard-coded password,
`InitialCatalog=Patients`. `[Initial]` carries `Initialw=123`, `nrls=600`, `orls=600`, `drls=0` — **not
recorded in Stage 1**. `[lastlog]` carries the documented `date ## engine ## machine ## labid ## user ##
password` format with **two populated entries** (`20170926##ACCESS##SPRT007-PC##0##sa##…` and
`20170926##MS_SQL##SPRT007-PC##0##sa##…`) and eight empty slots — so the "last ten attempts" ring
holds two real attempts against two engines on the same machine.
**Identifiers:** C-09, F-01, ISS-28, COR-13.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\BASE.ini | [oledb], [Initial], [lastlog] sections]`.
**Class:** CONFIRMED FACT (the values are *static configured* values in the shipped file, not runtime observations).
**Residual uncertainty:** which data root a live deployment uses remains a deployment question (DEC-02).

### B.3 — T3 · CAB members and delivery archives — **PARTIALLY RESOLVED**

**Investigated:** the two delivery archives named by the target list, and the corresponding product cabinets.
**Actually inspected:** `RL_CD2019Access\WIN7\real lab system.CAB` (7,211,180 B, SHA-256 `7CDC7C1FE6CE7B5EA5C1566F6A180D07664F59FA8CD81D126E86B403E63CB7FD`) and
`RL_CD2019Access\WINXP\real lab system.CAB` (7,057,945 B, SHA-256 `EFFF7639BBA8E311501548055277BD048BA38C249EDAF33B2C98941988DB38FB`) — MSCF headers parsed and member
listings obtained by two independent means (`expand.exe -D` and a direct MSCF/CFFILE parse); both list
**48 members**. The source was searched recursively for the two named delivery archives
(`RealLab-Deliverables-B01-B10.zip`, `RealLab-Deliverables-B01-B11.zip`): **neither is present**, and the
authorized source contains **no `.zip` file at all**.
**Result:** the member *bytes* could not be recovered (see §D.1), but **30 of the 37** runtime files
installed under `OCX\` and `Fonts\` were hashed and **matched the canonical cabinet inventory SHA-256
exactly** — including the four `cross_target=DIFFERENT` members (`MSCOMM32.OCX` 120,648 B, `MSFLXGRD.OCX`
259,912 B, `msado27.tlb` 81,920 B and `msvbvm60.dll` 1,384,479 B, the last being the WINXP build), and
including `MSCOMCTL.OCX` (1,081,616 B), whose inventory row is flagged `name_case_differs=YES`. Seven
further installed files are **not** cabinet members (`ChamaleonButton.ocx/.oca`, `MSWINSCK.OCX/.oca/.DEP`,
`vkUserControlsXP.oca`, `unrar.dll`) and two fonts are not either (`Digiface.ttf`, `FREE3OF9.TTF`).
**Identifiers:** GAP-02, GAP-03, GAP-31, C-08.
**Evidence:** `[SRC | …\WIN7\real lab system.CAB | MSCF header, 48 CFFILE entries]` · `[SRC | …\RL_CD2019Access\OCX\ and \Fonts\ | 50 files hashed and joined against cab-inventory.csv]`.
**Class:** CONFIRMED FACT (listings, hashes, superset finding) + NEGATIVE FINDING (delivery archives absent).
**Residual uncertainty:** the cabinet member bytes themselves remain unverified against the inventory.

### B.4 — T4 · `MyLabSetting` row and SMS credential population — **RESOLVED (gap closed)**

**Investigated:** whether the SMS-gateway credential columns are populated in the shipped V2 store.
**Actually inspected:** `RL_CD2019Access\bin\Patients.mdb` (2,682,880 B, SHA-256 `98D51F5294496E03F352FF329F099572915CCB2E670C1F143D6BA368EEE898A3`), opened **read-only** through the
Microsoft ACE OLEDB provider (`Mode=Read`), querying only the `MyLabSetting` table.
**Result:** the table holds **5 rows** — `LabID` 100, 200, 300, 400, 500, i.e. one row per branch slot.
In the `LabID`=100 row, **`accuntID` holds an 8-character value and `accuntpw` a 6-character value**, both
stored as clear `Text (50)`, alongside `SMSbakey` (3 characters) and `sendername`=`RealLab`;
`totalsms`=1000, `SMSSend`=23, `shortsms`=1, `FridaySend`=0, `Hourflag`=0, `phonenum`=1, `SMSNo`=8,
`phoneNo1`=`01144848686`, and a **48-character** `Timess` schedule string. Rows 200–500 carry **empty**
credential columns (row 200 keeps only `phoneNo1`=`201007676559,20` and `totalsms`=1). **Credential values
were not reproduced** in this report or in any consolidated document; only field names, population state
and lengths are recorded.
**Identifiers:** GAP-13 (**closed**), GAP-21 (partly resolved), DEC-07, P07-08-5.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only via Microsoft.ACE.OLEDB.12.0]`.
**Class:** CONFIRMED FACT. **Residual uncertainty:** this is the **shipped static store**, not a live installation; whether a running system holds the same values is not established.

### B.5 — T5 · `Data\data_emp\` five template files — **RESOLVED (gap closed)**

**Investigated:** the five previously identified sub-store templates.
**Actually inspected (all five, read in full):** `PCR.ini` (1,687 B, `77DB6043…`), `PNT.ini` (1,152 B, `6DBF985B…`),
`PNT2.ini` (1,721 B, `B02025B9…`), `R_S.ini` (1,775 B, `3CAE8137…`), `R.ini` (1,824 B, `C0AC220F…`).
**Result:** the file set matches the documented five exactly, and `R.ini`'s hash is the **post-change**
value already recorded in the payload inventory — the artefact inspected is the V2 revision. `R.ini` is a
**reticulocyte-count** profile (`testtype=r`, `formsubtitle=Reticulocyte Count`, `reportmaintitle=HEMATOLOGY
REPORT`, `reportsubtitle1=BLOOD PICTURE`, `main_symb=E`, `sub_symb=E`, `subtitle_symb=B`) with
`statusflag=1`, the switch set `Check1x=1` and `Check1…Check7=1`, geometry `left1=113 … left7=7087`,
`width4=907`, `width7=3118`, `bottomvalue=600`, `leftvalue=600`, `spacevalue=453`, `spacetitle=567`,
`reportstart=2000` and `setupx.reportprinterx=HP LaserJet 1100 (MS)`. `R_S.ini` differs materially:
`statusflag=0`, `Check5x`/`Check6x` present instead of `Check1…Check7`, `Normalbold=0`, different font
sizes. `PNT.ini` is the only one of the five with **no** `[report]` section.
**Identifiers:** GAP-04 (**closed**), C-07.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\Data\data_emp\ | five files, SHA-256 computed]`.
**Class:** CONFIRMED FACT. **Residual uncertainty:** none for these five files.

### B.6 — T6 · SQL Server deployment scripts and relevant DDL — **NEGATIVE FINDING**

**Investigated:** `Attaching.sql`, the user-account and logger DDL, and the deployment scripts that invoke them.
**Actually inspected:** a recursive name search over the whole V1.605 payload for `*.sql`, `*.bat`, `*.cmd`
and for any name matching `attach*`, plus the full text of all nine shipped scripts:
`System\Setup.bat` (1,669 B), `Setup1.bat` (514 B), `Setup2.bat` (449 B), `Setup3.bat` (486 B),
`Setup4.bat` (620 B), `Setup5.bat` (463 B), `SetupPZ.bat` (825 B), `System\PDF\SetupP.bat` (484 B),
`System\PDF\SetupFN4.bat` (456 B).
**Result:** **no SQL script ships in the V1.605 payload.** `Setup.bat` ends with `D:` / `cd\Lab_data` /
`OSQL -S %COMPUTERNAME% -E /i Attaching.sql` / `start /wait Attach_database.bat` — the two scripts are
invoked **by relative name from `D:\Lab_data`** and are therefore created at install time, not shipped.
The SQL-Server provisioning line is itself in the shipped script:
`SQLEXPR.EXE /qb ADDLOCAL=ALL INSTANCENAME=MSSQLSERVER SECURITYMODE=SQL SQLAUTOSTART=1 SQLBROWSERAUTOSTART=1 SAPWD=12345678 DISABLENETWORKPROTOCOLS=0`.
The five prerequisite scripts each install exactly one component (Windows Installer 3.1, MS XML 6.0,
.NET Framework 2, SQL Server Express 2005, MySQL Connector/ODBC 3.51). No `CREATE TABLE useraccounts` or
`loger` statement exists anywhere in the authorized source.
**Identifiers:** C-14, DEC-01, GAP-11, GAP-16, ISS-28, ISS-36, S2-07, S2-08.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\System\Setup.bat | the SQLEXPR.EXE invocation and the OSQL / Attach_database.bat lines]` · `[SRC | …\System\Setup1.bat … Setup5.bat | full scripts]`.
**Class:** CONFIRMED FACT (script contents) + NEGATIVE FINDING (no shipped DDL). **Residual uncertainty:** the `useraccounts` / `loger` definitions remain unavailable; whether they exist in a deployed SQL Server is unestablished — a `CREATE TABLE` statement, had one existed, would still be evidence of a *scripted* definition and not of a deployed object.

### B.7 — T7 · Deployment-tree executables — **PARTIALLY RESOLVED**

**Investigated:** the five executables the Stage 1 gap named.
**Actually inspected (static metadata only — no execution, no disassembly):** `bin\RLUTool.exe` (126,976 B,
SHA-256 `1ABD85277E9C12A827163380FC7DF2A3AE12AA0908A610BC8B8D3DBAFAD63D20`, PE32 GUI, linker 6.0,
timestamp 2016-03-14), `bin\real lab timer.exe` (135,168 B, `37CC4831567F0374697CA5496F77C4FD820F9719AAD9FD2349C297917DFC216D`,
timestamp 2010-11-30), `System\Patient Data Transport.exe` (1,294,336 B,
`4BDFB8FBC5C9DA7EB40C7395802E3FF8A66D8F6692BE2D84165CB24BCB69F024`, timestamp 2011-01-04 — the timestamp
already published in Stage 1). A name-fragment search over every file **and directory** in the payload
found **no** `RealLab support.exe` and **no** `Natigh`.
**Result:** three of the five are present and now have identity and provenance; **two are not part of the
V1.605 payload at all**, which withdraws the earlier statement that the deployment tree copies them.
**Identifiers:** GAP-24.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\ | PE headers of the three executables; name-fragment search — no match for support / natigh]`.
**Class:** CONFIRMED FACT (identity, absence) / NOT DOCUMENTED (function). **Residual uncertainty:** the functions of the three present binaries remain undocumented; no behaviour was inferred from metadata.

### B.8 — T8 · V1.605 administrator literal — **RESOLVED**

**Investigated:** whether the V1.605 executable contains the `admin` literal.
**Actually inspected:** `RL_CD2019Access\System\real lab system.exe` — static PE-header parse plus a
bounded literal scan (ASCII and UTF-16LE) over the whole file. SHA-256
`C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0` — **a canonical match** against the
hash already published for the V2 executable, so the inspected file is the V2 binary.
**Result:** the file carries the PE timestamp `1595435962` = **2020-07-22 16:39:22 UTC** (a second,
independent confirmation of COR-01), entry RVA `0x7142c`, linker 6.0, 3 sections, PE32 GUI, and exactly
**one UTF-16LE occurrence of `admin`** at file offset `0x2DA262`, with **no ASCII occurrence**. Separately,
the shipped configuration `bin\NOTE.ini` (76 B, `C169D6C2C3CE986C37C14F27E80B36B375682056632A6120E92CC20B736EBDA3`)
carries `NIDT=admin` and `NIDL=admin` in its `[NOTICZ]` section.
**Identifiers:** ISS-21, COR-01, S2-04, S2-05, S2-06.
**Evidence:** `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\System\real lab system.exe | PE header TimeDateStamp; UTF-16LE literal scan, offset 0x2DA262]` · `[SRC | …\bin\NOTE.ini | [NOTICZ] section]`.
**Class:** CONFIRMED FACT (the literal is present) / INFERENCE as to its role. **Residual uncertainty:** the literal's *role* — account name, seed, or string — is not established, and no authentication architecture may be inferred from it.

### B.9 — T9 · Re-issuable upstream tables — **NEGATIVE FINDING (no new evidence)**

**Investigated:** `Stage-9-V-CD-2019-Final-Comprehensive-Report.md`, `02-schema.md` and `Evidence-Register.md`.
**Actually inspected:** a recursive search of the authorized source for each of the three names.
**Result:** **none is present** — all three are analysis-stage documents that live only in the patch
folders, not in the source tree. No new evidence exists that would justify re-issuing them, and the
corrected values they carried (1 682 columns; 103 shipped tables; the 132-column / 14-table DDL effect)
are already published in the consolidated specification.
**Identifiers:** GAP-28.
**Evidence:** `[SRC | F:\REAL_LAB_COPY | recursive name search for the three artefacts — no match]`.
**Class:** NEGATIVE FINDING. **Residual uncertainty:** the upstream tables remain as published; GAP-28 stays open as documentation hygiene owned by the corpus maintainer.

### B.10 — T10 · Documentation governance evidence — **OWNER DECISION (unchanged)**

**Investigated:** whether an explicit consolidation rule exists.
**Actually inspected:** the delivered documents `00`–`08` and the three reference index files (read-only);
the Stage 1 §B3 owner-decision analysis retained in session context was consulted.
**Result:** no document in the corpus states a consolidation rule. What exists is a **de facto** practice —
the eleventh patch folder's deliverable tree was treated as the consolidated record, and this
specification now supersedes it as the single V2 reference. That is observed practice, not a written
policy, and it is not converted into one here.
**Identifiers:** GAP-26, C-17, DEC-11.
**Evidence:** `[SRC | source\repos\Ref Lab\ReferenceIndex\RefLab_V2_COMPLETE_INDEX.md | §3 Folder Discovery and §9 the open-item summary]` · `[SRC | 07_GAPS_AND_LIMITS.md | §1 evidence base and method]`.
**Class:** OWNER DECISION. **Residual uncertainty:** the rule remains unwritten; Stage 1's classification stands unchanged.

### B.11 — T11 · C-12 documentation asymmetry — **RESOLVED (documentation-only correction)**

**Investigated:** the residual `C-12` token in document 08.
**Actually inspected:** `08_DECISIONS_REQUIRED.md` — every occurrence of the token.
**Result:** the genuine defect is **one cell**: the §5 counts row still read *"Unresolved conflicts | 5 |
`C-07` (content only), `C-09`, `C-12`, `C-14` (remainder), `C-17`"*, i.e. a stale count and a stale
identifier list left behind by the Stage 1 withdrawal of one conflict. The same table's
"Gaps carried **31**", "Conflicts carried **17**" and "Options enumerated **39**" rows were stale for the
same reason. The three other `C-12` matches in document 08 are the **decision** `DEC-12`, not the
conflict, and need no change.
**Identifiers:** C-12.
**Evidence:** `[SRC | 08_DECISIONS_REQUIRED.md | §5 Counts, the "Unresolved conflicts" row]`.
**Class:** DOCUMENTATION-ONLY CORRECTION. **Residual uncertainty:** none.

### B.12 — T12 · ISS-07 static-copy limitation — **RECORD-ONLY (unchanged)**

**Investigated:** the status of ISS-07 in the light of source availability.
**Actually inspected:** the Stage 1 issue register text as carried in documents 01, 07 and 08.
**Result:** ISS-07 stands. Its Stage 1 wording — that dynamic execution was impossible — is now more
precisely stated by circumstance: the source **was** available for static inspection, and **no dynamic
execution was performed or attempted**. Execution of the application, its installer, or any payload was
not authorised and was not performed; no runtime behaviour was simulated or inferred.
**Identifiers:** ISS-07.
**Evidence:** `[SRC | 07_GAPS_AND_LIMITS.md | §3.2 the ISS-07 entry]` · `[SRC | 08_DECISIONS_REQUIRED.md | the ISS-07 row]`.
**Class:** TOOLING LIMITATION / authority limitation — unchanged and now explicitly re-confirmed.

### B.13 — Central resolution table

| Open item | Target investigated | Found? | Evidence location | Previous documented state | New finding | Evidence class | Residual uncertainty |
|---|---|---|---|---|---|---|---|
| GAP-01 | — | no | `[SRC | F:\REAL_LAB_COPY | recursive search — pdf-print-stack.md absent]` | Analysis-stage document outside the reference tree | Still outside the reference tree; the source does not carry it either | NEGATIVE FINDING | The document's loss from the tree stands |
| GAP-02 | T3 | partly | `[SRC | …\WIN7\real lab system.CAB | MSCF header, 48 CFFILE entries]` | 96 member bytes absent; identities only | Member listings recovered for both targets; 30 of 37 installed runtime copies hash-verified against the canonical inventory; member bytes still unextractable (LZX) | CONFIRMED FACT + TOOLING LIMITATION | Cabinet member bytes remain unverified |
| GAP-03 | T3 | no | `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access | payload binaries present]` | PE-summary table absent and rebuildable only from JSONs | The source now holds the binaries, so the table could be rebuilt — a new target, not performed | CONFIRMED FACT | Table not rebuilt |
| GAP-04 | T5 | **yes** | `[SRC | …\Data\data_emp\R.ini | [reportdata] section, full key set]` | NOT RECOVERABLE | Key-level content of all five sub-store templates recovered; `R.ini` hash = the documented post-change value | CONFIRMED FACT | none for these five files |
| GAP-05 | — | no | — | The 1 617-column figure has no reproducible origin | Unchanged — no artefact in the source can originate it | NEGATIVE FINDING | Figure remains unreproducible |
| GAP-11 | T6 | **yes** | `[SRC | …\System\Setup.bat | prerequisite invocations]` | Five Microsoft installers absent; residual noted | Confirmed absent from the source as well; the five invoking scripts are present and now quoted; print-stack installers present at the documented sizes | CONFIRMED FACT | Policy for the five remains an owner decision (DEC-09) |
| GAP-13 | T4 | **yes** | `[SRC | …\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only]` | NOT RECOVERABLE | Table holds 5 rows (LabID 100–500); `accuntID` (8 chars) and `accuntpw` (6 chars) **populated in clear text** in the LabID=100 row; rows 200–500 empty | CONFIRMED FACT | Shipped static store, not a live installation |
| GAP-16 | T6 | no | `[SRC | F:\REAL_LAB_COPY | no `useraccounts`/`loger` DDL found]` | NOT RECOVERABLE | No SQL DDL ships in the payload; the attach scripts are created at install time | NEGATIVE FINDING | Runtime enforcement of `grant1..grant17` remains unestablished |
| GAP-21 | T4 | partly | `[SRC | …\bin\Patients.mdb | row LabID=100]` | NOT DOCUMENTED | `Timess` is a 48-character schedule string; counters observed (1000 / 23 / 1 / 0 / 0 / 1 / 8) | CONFIRMED FACT | Character-level semantics of the schedule and counters remain inferred |
| GAP-24 | T7 | partly | `[SRC | …\RL_CD2019Access | PE headers; name-fragment search]` | NOT DOCUMENTED | Three executables characterised (hash, size, PE timestamp); `RealLab support.exe` and `Natigh` are **absent from the payload** | CONFIRMED FACT | Functions of the three present binaries remain undocumented |
| GAP-25 | T1/T6 | **yes** | `[SRC | …\System\SetupPZ.bat | full script]` | NOT DOCUMENTED | `SetupPZ.bat` is the correct-order script (.NET 4 → Bullzip); `SetupFN4.bat` is orphaned with a relative-incomplete path, `SetupP.bat` installs Bullzip only | CONFIRMED FACT | `RL_SETUP.exe`'s own step order not re-verified |
| GAP-26 | T10 | no | `[SRC | 07_GAPS_AND_LIMITS.md | §1]` | Not established | Unchanged — no written rule exists; only de facto practice | OWNER DECISION | Rule remains unwritten (DEC-11) |
| GAP-28 | T9 | no | `[SRC | F:\REAL_LAB_COPY | recursive name search — no match]` | OPEN | No new evidence; the three upstream tables are absent from the source | NEGATIVE FINDING | Upstream tables remain as published |
| GAP-31 | T3 | partly | `[SRC | …\WIN7\real lab system.CAB | present in source]` | OPEN | Cabinets are in the source; the three analysis-stage artefacts are not | CONFIRMED FACT | Loss of the analysis artefacts stands |
| C-07 | T5 | **yes** | `[SRC | …\Data\data_emp\ | five files]` | RESOLVED with an open remainder | Remainder closed — the sub-store is now analysed | CONFIRMED FACT | none |
| C-08 | T1/T3 | **yes** | `[SRC | …\WIN7\SETUP.LST | File8 MSCOMCTL.OCX]` | RESOLVED | Third independent corroboration: identical size and version string in both manifests; installed copy hashes to the canonical value | CONFIRMED FACT | none |
| C-09 | T1/T2/T6 | **yes** | `[SRC | …\System\Setup.bat | D: / cd\Lab_data / OSQL / Attach_database.bat]` | OPEN — REQUIRES CONFIRMATION | Resolved by layer separation: manifest declaration, installer execution, application data root, backup path — four artefacts, four roles (COR-13) | CONFIRMED FACT | Which root is *supported* remains DEC-02 |
| C-12 | T11 | **yes** | `[SRC | 08_DECISIONS_REQUIRED.md | §5 counts row]` | Withdrawn from the register but still referenced | One stale cell plus three stale counts in the same table corrected | DOCUMENTATION-ONLY CORRECTION | none |
| C-14 | T6 | no | `[SRC | F:\REAL_LAB_COPY | no shipped DDL]` | PARTIALLY RESOLVED | Unchanged in substance, with the negative finding that the DDL does not ship | NEGATIVE FINDING | SQL-Server-side behaviour remains unestablished |
| C-17 | T10 | no | `[SRC | ReferenceIndex\RefLab_V2_COMPLETE_INDEX.md | §9]` | OPEN | Unchanged — governance question | OWNER DECISION | Rule remains unwritten |
| ISS-21 | T8 | **yes** | `[SRC | …\System\real lab system.exe | UTF-16LE literal at 0x2DA262]` | UNVERIFIED for the V1.605 binary | **Present** — exactly one UTF-16LE occurrence; the shipped configuration also carries `NIDT=admin` / `NIDL=admin` | CONFIRMED FACT | The literal's role is not established |
| ISS-23 / ISS-24 / ISS-06 | — | no | — | Procedure bodies, DataReport designs and control captions not recoverable | Unchanged — the same tooling limitations apply to the source binaries; no re-analysis attempted | TOOLING LIMITATION | unchanged |
| ISS-28 / ISS-36 | T6 | **yes** | `[SRC | …\System\Setup.bat | SQLEXPR.EXE line]` | Documented from the installer analysis | Confirmed in a primary V1.605 artefact: the hard-coded SQL administrator password and `DISABLENETWORKPROTOCOLS=0` are in the shipped script | CONFIRMED FACT | none |
| BR-SETUP-* (manifest rule) | T1 | **yes** | `[SRC | …\WIN7\SETUP.LST | 45 entries]` | Rule stated the 22/16/5/1 and 31-shared breakdown | Rule corrected to the two-section, 45-entry structure with 18/21/5/1, 27 self-registrations and 27 shared | CONFIRMED FACT | none |
| DEC-02 | T1/T2/T6 | partly | `[SRC | …\WIN7\SETUP.LST | [Setup] DefaultDir]` | Blocking; two application roots and two data roots documented | The factual base is now complete and layered (COR-13); the *choice* is still required | CONFIRMED FACT + OWNER DECISION | Owner decision outstanding |
| DEC-07 | T4 | partly | `[SRC | …\bin\Patients.mdb | MyLabSetting]` | Factual basis missing (population unknown) | Factual basis established: a live clear-text credential ships populated | CONFIRMED FACT + OWNER DECISION | Storage policy is the owner's choice |
| DEC-09 | T6 | no | `[SRC | …\System | five installer paths absent]` | Policy open for five absent installers | Confirmed absent from the source as well; no new option appears | CONFIRMED FACT + OWNER DECISION | Policy unchanged |
| DEC-01 / DEC-11 / DEC-03/04/05/06/08/10/12 | T6/T10 | no | — | Open | Unchanged — either factual bases were not in the source, or they are policy choices | OWNER DECISION | unchanged |

---

## C. Negative findings

| # | What was expected | Where it was expected | What was actually examined | What was observed | What was **not** established | Scope of the absence |
|---|---|---|---|---|---|---|
| N-1 | The two delivery archives `RealLab-Deliverables-B01-B10.zip` and `RealLab-Deliverables-B01-B11.zip` | The authorized source tree | A recursive `*.zip` search over the whole of `F:\REAL_LAB_COPY` | **No `.zip` file exists in the source at all** | The delivery-archive contents are not available | The whole authorized source tree |
| N-2 | `Attaching.sql` | The V1.605 payload (expected beside `Attach_database.bat` in the data root) | Recursive `*.sql` / `*.bat` / `*.cmd` enumeration and a name-fragment search for `attach*` over the payload | **No SQL script ships.** `Setup.bat` invokes `Attaching.sql` and `Attach_database.bat` by relative name from `D:\Lab_data` | The attach logic, the `useraccounts` / `loger` DDL, and the database-provisioning steps | The whole V1.605 payload tree |
| N-3 | `RealLab support.exe` | The V2 deployment tree | Name-fragment search over every file and directory | **Absent** | Its function and whether it ever existed in V1.605 | The whole V1.605 payload tree |
| N-4 | `Natigh` (results-delivery service) | The V2 deployment tree | Name-fragment search over every file and directory | **Absent** | Its function and whether it ever existed in V1.605 | The whole V1.605 payload tree |
| N-5 | The five large Microsoft primary installers | `System\…` paths named by `Setup1..Setup5.bat` | Direct existence test of all five paths | **All five absent**, exactly as documented from the patch corpus | Whether they existed on a complete disc | The V1.605 payload tree |
| N-6 | `SETUP.LST` as a *standalone* artefact in the source | Source root or payload | Recursive name search | Not present as a standalone file; the **two manifests themselves** were found and read under `WIN7\` / `WINXP\` | — (the question was answered from those) | The whole source tree |
| N-7 | `BASE.ini` as a standalone artefact | Source root or payload | Recursive name search | Not standalone; the V2 `bin\BASE.ini` was found and read (the earlier-build copy in the same tree was **not** opened) | — (answered from the V2 copy) | The whole source tree |
| N-8 | The three upstream re-issuable tables (`Stage-9-…`, `02-schema.md`, `Evidence-Register.md`) | Source tree | Recursive name search for each | **None present** — analysis-stage documents | Any new basis for re-issuing them | The whole source tree |
| N-9 | `bin\SETTING.ini` (the name used throughout the Stage 1 specification) | `RL_CD2019Access\bin\` | Direct existence test and a listing of the directory | **Does not exist.** The file is `bin\SETING.ini` (4,886 B) and carries the settings content | — (the correct name is now published) | The V1.605 payload tree |
| N-10 | A second `Data\data_emp` template beyond the five | `RL_CD2019Access\Data\data_emp\` | Full directory listing | Exactly **five** files, as documented | — | That directory |
| N-11 | Cabinet member bytes | The two `real lab system.CAB` payloads | Header/CFFILE parse, `expand.exe -D`, FDI via ctypes, shell `CopyHere`, and a hand-written MSZIP decoder | Listings recovered; **bytes not extractable** — the payload is LZX-compressed and no permitted tool decodes it | Byte-level verification of the 96 inventory hashes | The two cabinet payloads |

---

## D. Tooling limitations

| # | Required capability | Actual unavailable capability | Exact limitation | Affected target | Consequence | Outstanding question |
|---|---|---|---|---|---|---|
| D.1 | A cabinet extractor for the V1.605 OS-target payloads | An LZX decoder, or any permitted tool that can decode an LZX-compressed cabinet | `expand.exe` lists a `.cab` but refuses to extract it (`No destination specified`); the FDI API (`cabinet.dll`) invoked through ctypes faults on `FDICreate`; the shell namespace copies the cabinet instead of expanding it; a hand-written MSZIP decoder fails because the payload is LZX, not MSZIP. Installing a decoder is not permitted. | T3 | The 96 cabinet member bytes cannot be recovered or hash-verified directly | Are the cabinet members byte-identical to the installed `OCX\`/`Fonts\` copies? (Partly answered: 30 of 37 installed copies match the canonical inventory exactly.) |
| D.2 | A VB6/COM extraction host | Windows with VB6/OLE property extraction | The analysis host has no COM/OLE property extraction, and no Windows analysis environment was authorised | T7 (control captions), and the standing ISS-06/23/24 items | Per-control captions, procedure signatures/bodies and DataReport designer layouts remain unrecoverable | unchanged from Stage 1 |
| D.3 | An authorised execution environment | A licensed, isolated Windows runtime | Execution of the application, the installer or any payload was not authorised and was not attempted | T12 (ISS-07) | No runtime behaviour is established; nothing was simulated | unchanged from Stage 1 |
| D.4 | A live SQL Server instance for the hosting mode | A running `MSSQLSERVER` instance | No live system was contacted; the `SA` password appears in the shipped script as a literal, but no instance was addressed | T6, C-14, DEC-01 | Whether `useraccounts` / `loger` exist and how `grant1..grant17` is enforced remain unestablished | unchanged from Stage 1 |
| D.5 | A row-level view of the whole V2 store | Nothing beyond what the authorised target requires | The database was opened read-only and queried **only** for the `MyLabSetting` table, because T4 asks only about that table; the row counts of the other 102 tables were deliberately not harvested | T4 | The live-V2 row-count gap (GAP-10 and the wider NOT-RECOVERABLE set) is **not** closed | The row counts of the remaining tables — a candidate for a future authorised target |

---

## E. Items deferred to owner decision

The Stage 1 §B3 analysis was consulted; the following remain owner decisions, and Stage 2 changed only
their factual inputs, never their ownership.

| Decision | What Stage 2 supplied | What still requires an owner |
|---|---|---|
| **DEC-01** (database engine) | Confirmed that no SQL DDL ships in the payload and that the attach scripts are created at install time | Which engine(s) the replacement supports |
| **DEC-02** (application and data roots) | The four readings are now layered and each anchored to a primary artefact (COR-13) | Which root is the *supported* configuration |
| **DEC-03 / DEC-04 / DEC-05** (PDF roots, engine, licence posture) | Nothing — the Stage 1 evidence was already complete | Whether the four roots stay hard-coded, whether the engine is kept, and the licence posture |
| **DEC-06** (OS baseline and runtime payload) | Confirmed that the five Microsoft installers are absent from the source as well | Which Windows baseline and runtime the replacement supports |
| **DEC-07** (SMS credential storage) | **New:** the credential ships **populated in clear text** — the factual basis is now complete | Whether to keep the clear-text pair, protect it at rest, or move it out of the database |
| **DEC-08** (`VIDAS`) | Nothing — no `VIDAS` artefact is in the source | Whether `VIDAS` is part of the supported data path |
| **DEC-09** (five absent installers) | Confirmed absent from the source | The installation-completeness policy |
| **DEC-10** (`English (Canada)`) | `EnLanguage=0` is now visible in the shipped configuration | Whether the locale prerequisite stays |
| **DEC-11** (consolidation rule) | Confirmed that no written rule exists; only de facto practice | Whether to formalise the rule |
| **DEC-12** (installer behaviour) | The script-level install order is now reproducible from `SetupPZ.bat` | The elevation model and the font-step policy |

**No new decision was created by Stage 2**, and no existing decision was closed by it.

---

## F. Baseline versus new archive hashes

**Stage 1 baseline SHA-256 (expected):**

```
735FC05AF545E534880B2E29C04C640641A0BA49D0AB0C461E446774F9ACA0B1
```

**Stage 1 baseline SHA-256 (actually computed during Stage 2, Prompt 3):**

```
735FC05AF545E534880B2E29C04C640641A0BA49D0AB0C461E446774F9ACA0B1
```

**Verification outcome: PASSED.** The hash was computed independently from the file at
`C:\Users\LAP LINK\source\repos\Ref Lab\RefLab_Reference_V2_Consolidated.zip` (354,078 bytes) with
`Get-FileHash -Algorithm SHA256`, and re-computed immediately before the archive update. It matched the
expected value on both occasions, so the archive was eligible for in-place maintenance.

**Stage 2 resulting archive SHA-256:** established after the final archive was constructed and
verified, and reported in the external final engineering disclosure.

**The self-referential hash limitation.** This report is a member of the final archive. Inserting the
final archive's own SHA-256 into the report would change the archive, and therefore change the hash
being reported — an unsatisfiable fixed point. The Stage 1 baseline hash is therefore recorded here,
the final hash is recorded only in the external disclosure, and **no attempt was made to fabricate or
iteratively converge a self-referential value**. This is an intentional integrity safeguard, not an
incomplete calculation.

---

## Provenance and method

Stage 2 executed under the mission authority of Prompt 1 and the binding Stage 1 commitments. The
authorized source was accessed read-only through a verified three-operation gate; all twelve authorised
targets received an outcome; no target was investigated beyond its scope; no Stage 1 finding was
re-derived; no canonical duplicate was re-analysed; and no file in `F:\REAL_LAB_COPY` was modified —
independently corroborated by the source tree's newest timestamp (2026-11-09 13:48:33) preceding the
Stage 2 working window. Evidence classes used throughout are **CONFIRMED FACT**, **PREVIOUSLY
ESTABLISHED FACT**, **INFERENCE**, **NEGATIVE FINDING**, **TOOLING LIMITATION** and **OWNER DECISION**,
as defined in the Stage 2 mission authority. Every newly introduced factual statement carries a
`[SRC | path | anchor]` locator that identifies a real, accessible location; documentation-derived
evidence names the document path and locator instead and is never presented as direct source evidence.
Credential values encountered in `MyLabSetting` were deliberately not reproduced: only field names,
population state and lengths are recorded. Working artefacts (the baseline copy of the nine documents,
the patch scripts, the extraction attempts and the member/hash tables) were kept outside the source
directory and are not part of the deliverable.
