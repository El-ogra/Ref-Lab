# 00 — Index, Scope and Reading Guide

**Subject:** RefLab Version 2 (V2) — the RealLab **V-CD-2019** line
(`real lab system.exe`, **FileVersion 1.605**, `Description: RLS 1.605`, `CompanyName: RealLab`,
76,292,096 bytes, PE32 / linker 6.0, PE build stamp `1595435962` = 2020-07-22 16:39:22 UTC,
SHA-256 `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0`).
`[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info + "pe"."timestamp"]`

---

## 1. Scope

### 1.1 What this specification covers

This document set is a **consolidated engineering specification of one system**: RefLab Version 2
(V2), as established by the evidence archive

```
Reference_V2_Patches_04-11.zip
  SHA-256 67853C14211B1348FD086F3C54D11321D6822E97238DF95ACCBAD627AF9D3796
  90,780,268 bytes · 91 top-level files · 7 patch folders (= patches 04…11; 07 and 08 share one folder)
```

Everything stated in these nine documents is derived from that archive. The specification covers the
product's identity, functionality, business rules, data model, workflows and user interface,
printing and reporting, permissions and security posture, the gaps in the evidence, and the
decisions that remain open.

### 1.2 What it does not cover

* **No implementation.** This document set specifies; it does not build. No application code was
  written, no reference project was modified, and no behaviour was invented to fill a gap.
* **No runtime observation.** No V2 binary was executed on the analysis host; every statement is
  static-analysis derived, and the documents say so wherever it matters.
  `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-07]`
* **One system only.** Every statement in these documents concerns the V2 payload identified in §1.1
  and the evidence derived from it.

### 1.3 Intended reader

A replacement implementer working later against a source repository, who needs to know what V2
does, what its data looks like, which rules must hold, which behaviours are unknown, and which
questions must be answered by the product owner before the corresponding work can start.

---

## 2. Purpose

* **Preservation.** To carry the documented V2 knowledge out of a patch-structured evidence archive
  into a self-contained, navigable form, so that the original patch folders are no longer needed.
* **Traceability.** Every substantive claim is bound to the artefact it came from, with a patch
  marker and a file-level anchor.
* **Honesty about uncertainty.** Every claim is classified, and the gaps and open decisions are
  stated rather than smoothed over.
* **Actionability.** Where the evidence leaves a genuine choice to the product owner, that choice is
  written down as a decision with its consequences, not silently defaulted.

---

## 3. Document navigation

| Document | Read it for |
|---|---|
| `00_INDEX.md` | This page: scope, legend, conventions, coverage, completeness status. |
| `01_EXECUTIVE_UNDERSTANDING.md` | The system in one document: identity, purpose, scope, scale, architecture, components, functional domains, technical overview, known limitations. |
| `02_FUNCTIONAL_SPECIFICATION.md` | The complete function inventory — **136 specifications**: 15 documented capabilities (CAP-01…CAP-15), 41 V2-specific objects (20 code objects + 21 DataReports), 57 vendor-catalogue capability rows, 11 printing functions (PF-01…PF-11), 12 installer functions (IF-01…IF-12) — with purpose, trigger, preconditions, inputs, validation, execution, outputs, side effects, database interactions, permissions, error conditions, exceptions, dependencies, UI entry point and postconditions for each. |
| `03_BUSINESS_RULES.md` | The evidenced business rules — **146 rules across 10 domains** (clinical constants, reference ranges, result lifecycle, catalogue management, branch/identifier rules, billing, reporting and printing, notifications, setup, data integrity) — with conditions, exceptions, affected entities, related functions and per-rule open questions. |
| `04_DATA_MODEL.md` | The data model: **103 tables / 1,682 columns** of the shipped store, the 117 SQL-addressed tables, the 268 embedded DDL statements and their 132-column / 14-table effect, per-table column specifications, 43 relationships (documented / inferred / unverified), identifier semantics, naming traps and schema ambiguities. |
| `05_WORKFLOWS_AND_UI.md` | The **26** end-to-end workflows, the **132**-form screen inventory, UI vocabulary, navigation, the report layout model, field behaviour, the print architecture (six printer roles, four PDF output roots), reporting, document generation, and workflow exception paths. |
| `06_PERMISSIONS_AND_SECURITY.md` | Roles and what "role" can and cannot mean here, the **17** capability flags, the documented authorization gates, **13** protected operations, access boundaries, the security findings, signing and licence-compliance findings, and an explicit list of security assumptions the evidence does not support. |
| `07_GAPS_AND_LIMITS.md` | The coverage ledger, the gap catalogue (**30** gaps), the correction register (**14** corrections), the conflict register (**16** conflicts, 2 unresolved) with both readings and resolution status, and the evidence that exists but is carried only by this specification. |
| `08_DECISIONS_REQUIRED.md` | The **12** material decisions that need an owner's answer (DEC-01…DEC-12), each with the question, the evidence, the options, the consequences and what stays blocked until it is answered; plus an explicit "not decisions" section. |

**Suggested reading paths**

* *Implementing the data layer* → `04` → `03` → `02` §2.
* *Building the UI* → `05` → `02` §2 (CAP-01…CAP-15) → `04` §6 (identifier semantics).
* *Producing reports and PDFs* → `05` §6–§8 → `02` §7 → `08` (DEC-03…DEC-05).
* *Security review* → `06` → `07` (GAP-13, GAP-16) → `08` (DEC-07).
* *Planning the work* → `08` → `07` → `01` §5.2.

---

## 4. Evidence classification legend

Every substantive claim in this document set carries one of five classifications.

| Class | Meaning | What it obliges the author to do |
|---|---|---|
| **VERIFIED** | The cited evidence directly establishes the statement. | Cite the artefact and the anchor that shows it. |
| **INFERRED** | The statement is not literally written in one passage, but multiple pieces of evidence support it. | State the supporting evidence, identify the source locations, and explain why it is an inference rather than a verified fact. Never present it as an established requirement. |
| **UNVERIFIED** | The evidence suggests a possibility but does not establish it. | State it only where it matters for an implementation decision, and say exactly what is missing. |
| **NOT DOCUMENTED** | The supplied evidence does not establish the fact at all. | Say so; do not fill the gap with a conventional design pattern or external knowledge. |
| **NOT RECOVERABLE** | The fact was asserted once, but the artefact that carried it is absent from the archive. | Record the gap explicitly and name the missing artefact. |

A sixth marker appears only in `07_GAPS_AND_LIMITS.md`: **CONFLICT**, used when the archive holds two
disagreeing readings. Such entries always carry both readings, both citations and a resolution
status — **RESOLVED**, **PARTIALLY RESOLVED**, or **OPEN — REQUIRES CONFIRMATION**.

---

## 5. Provenance conventions

### 5.1 Patch markers

| Marker | Patch | Folder in the archive | Folder files |
|---|---|---|---:|
| `[P11]` | patch 11 | بعد الدفعة الحادية عشر | 12 |
| `[P10]` | patch 10 | بعد الدفعة العاشرة | 6 |
| `[P09]` | patch 9 | بعد الدفعة التاسعة | 19 |
| `[P07-08]` | patches 7 and 8 (one folder) | بعد الدفعة السابعة والثامنة | 13 |
| `[P06]` | patch 6 | بعد الدفعة السادسة | 15 |
| `[P05]` | patch 5 | بعد الدفعة الخامسة | 12 |
| `[P04]` | patch 4 | بعد الدفعة الرابعة | 14 |
| | | **Total** | **91** |

### 5.2 Citation form

```
[P11 | analysis/BATCH-04/schema/ddl-all.txt | CREATE TABLE block for MyLabSetting]
[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo]]
[P11 | pdf-print-stack.md | §2.4 printer-role table]
```

* The path is relative to the patch's **deliverable tree**; a bare file name is a file at the
  **root of the patch folder**.
* Anchors are section headings, table rows, or literal statement text that was actually read.
  **No page, line or section number has been invented.** Where a precise location could not be
  established, the verified file name is cited instead.
* A provenance marker identifies the **actual source of the claim**, not merely the newest folder in
  which a similar statement appears. A fact first established at the seventh/eighth patch and
  carried forward is still cited to the seventh/eighth patch when that patch is the origin.

### 5.3 Documentation-only identifiers

`CAP-##`, `BR-##`, `WF-##`, `GAP-##`, `COR-##`, `C-##`, `DEC-##`, `PERM-##`, `PF-##`, `IF-##` and
similar labels exist **only in this specification**. They appear in no product artefact, no
configuration file and no runtime component, and must not be quoted as system identifiers. Where a
label restates something the product itself names, the product's own name is given beside it
(for example, the workflow labelled `WF-14` operates on the product's `workpaper` and `workpaper2`
objects).

### 5.4 Preserved terminology

Original identifiers are reproduced verbatim and never normalised: table and column names
(`patientinfo`, `patienttest`, `normalrange`, `cultures.organism3`, `MyLabSetting.accuntpw`),
configuration keys (`form.Check6f`, `form.LabelX002`), object names (`addpatient`, `resultculutre`,
`frm_money`), printer roles (`reportprinter`, `zarfprinter`, `waslprinter`, `IDprinter`), file names
(`Patients.mdb`, `SETING.ini`, `IDCARD.INI`), and UI labels. Where two source names appear to
describe the same concept, **both** are kept and the ambiguity is documented rather than resolved
by renaming.

---

## 6. Patch coverage summary

The analysis walked the archive in descending order — **P11 → P10 → P09 → P07-08 → P06 → P05 →
P04** — so that each patch was read against the state established by the patches already walked,
and every patch folder received a deliberate uniqueness scan against the eleventh patch folder's
550-file deliverable tree.

| Patch | Files | Unique to this folder | Principal contribution to the specification |
|---|---:|---:|---|
| **P11** | 12 | 2 | The PDF/print-stack analysis (the only source for the print architecture), the PE envelopes of the five print-stack binaries, the CAB member inventory, the 837-row artefact ledger. Its deliverable tree (550 files) is the consolidated reference point. |
| **P10** | 6 | 2 | The installation media: `SETUP.LST` install manifest, the 48-member CAB payloads for the two OS targets, the VB6 SP6 redistributable manifest (the FoxPro indicator), and the batch-11 request manifest. |
| **P09** | 19 | 3 | The INI key-level delta, the schema-application proof, and the per-file classification table; the final patch report. |
| **P07-08** | 13 | 2 | **The richest V2 source**: the shipped Access schema dump (103 tables, 2,105 lines, every column typed and sized), the 3,712-row INI key delta, and the branding comparison (the report header and logo placeholders). |
| **P06** | 15 | 5 | The 2019 training-video frame sheets — the only direct visual evidence of the running application (work-sheet screens, patient identifier format, Excel/Word output). |
| **P05** | 12 | 5 | The shipped setup manual's text (activation procedure, font step, data-root attachment, the `English (Canada)` prerequisite) and the installer-internals report. |
| **P04** | 14 | 2 | The embedded DDL (`ddl-all.txt`), the column-evolution table, the version baseline and the V2 baseline line. |

**Uniqueness test and its correction.** The uniqueness test (MD5 of every one of the 91 top-level
files against an index of the 550 reference-tree files) was re-executed for this specification. It
returns **21 unique** and **70 byte-identical** files — two rows of the source ledger disagreed
with the recomputation and were corrected here, with the MD5 values that settle them. The method
and the corrected figures are stated in `07_GAPS_AND_LIMITS.md` §2.1.

**Nothing was unreadable.** All 91 top-level files opened successfully and every deliverable
archive was a valid archive; no file was corrupt, and none was inaccessible. The gaps documented in
`07_GAPS_AND_LIMITS.md` are therefore gaps in the *content* of the evidence, not in its readability.

---

## 7. Document map

| # | File | Primary evidence root | Size | Character |
|---|---|---|---:|---|
| 00 | `00_INDEX.md` | archive inventory, coverage ledger | ~20 KB | Navigation, legend, conventions, completeness |
| 01 | `01_EXECUTIVE_UNDERSTANDING.md` | P11 tree (baseline, architecture, capabilities, PE reports), P07-08 schema dump | ~29 KB | System-level synthesis; every figure re-counted |
| 02 | `02_FUNCTIONAL_SPECIFICATION.md` | CHM help, vendor capability catalogue, VB6 object tables, print architecture, installer analysis | ~267 KB | The function inventory and per-function specifications |
| 03 | `03_BUSINESS_RULES.md` | V2 SQL pool, schema dump, clinical constants, CHM/guide text, V2 method sheets | ~217 KB | Domain-organised rule catalogue with explicit conditions |
| 04 | `04_DATA_MODEL.md` | schema dump, embedded DDL, SQL table list, branch-data profile | ~149 KB | Tables, columns, types, relationships, naming traps |
| 05 | `05_WORKFLOWS_AND_UI.md` | object model, form blobs, video frames, print stack, template layer | ~226 KB | Workflows, screens, UI vocabulary, printing, reporting |
| 06 | `06_PERMISSIONS_AND_SECURITY.md` | schema dump, SQL pool, CHM/guide text, PE/signature reports | ~79 KB | Flags, gates, protected operations, boundaries, unverified assumptions |
| 07 | `07_GAPS_AND_LIMITS.md` | all seven patch folders; the archive itself | ~107 KB | Coverage ledger, gap catalogue, corrections, conflicts |
| 08 | `08_DECISIONS_REQUIRED.md` | gap and conflict registers; vendor manuals | ~53 KB | The open decisions and their consequences |

---

## 8. Overall completeness status

### 8.1 What is complete

* **Archive verification and inventory** — archive opened, hashed, extracted; all seven expected
  patch folders confirmed present and inventoried (91 files); the consolidated reference tree
  unpacked and enumerated (550 files).
* **Every patch folder examined** — each of the seven received a file inventory, a content read and
  a deliberate uniqueness scan; the 21 patch-root-unique artefacts were identified and their
  findings carried into this specification.
* **The function, rule, data, workflow, UI, printing, permission and security surfaces** are
  specified to the depth the evidence supports, with per-item classifications and provenance.
* **Every material conflict** is registered with both readings and a resolution status; 13 of the
  16 registered conflicts are resolved, 3 remain open and are routed to `08_DECISIONS_REQUIRED.md`
  or recorded as gaps.

### 8.2 What is not complete, and why

| Area | Status | Reason |
|---|---|---|
| Runtime behaviour of the V2 binary | **Not established** | The binary was never executed on the analysis host; all evidence is static. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-07]` |
| Procedure signatures and bodies | **NOT RECOVERABLE** | The object-model extraction recovered procedure counts but no addresses, names or parameters. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-23]` |
| DataReport designer layouts | **NOT RECOVERABLE** | Not extractable from the binary; only identity, type and bound data survive. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-24]` |
| Per-control captions and properties | **NOT RECOVERABLE** | Requires VB6 COM property extraction; control counts and form geometry were recovered instead. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-06]` |
| Row-level data | **NOT RECOVERABLE** | Only the schema of the shipped database was ingested; no table contents exist in the archive. |
| The three unresolved conflicts (the application and data roots; the SQL-Server-side behaviour of `loger` / `useraccounts` / `win32_processor`; the documentation consolidation rule) | **REQUIRES CONFIRMATION** | Both readings are documented in `07_GAPS_AND_LIMITS.md`; each is raised as a decision in `08_DECISIONS_REQUIRED.md`. |

### 8.3 Acceptance-criteria status

| ID | Criterion | Status | Basis |
|---|---|---|---|
| AC-01 | Archive accessed and inspected | **Met** | Opened, hashed (`67853C14…`), extracted, 91 files inventoried. |
| AC-02 | All seven evidence folders examined | **Met** | Coverage ledger, `07_GAPS_AND_LIMITS.md` §2. |
| AC-03 | Patch 11 received primary analysis | **Met** | It is the consolidated reference point (550-file tree), and its patch-root-unique artefacts were read in full. |
| AC-04 | Earlier folders scanned for unique artefacts | **Met** | 21 unique artefacts identified by MD5; findings carried forward. |
| AC-05 | All supported V2 findings consolidated | **Met** | Across the nine documents, with per-item provenance. |
| AC-06 | Evidence classifications applied consistently | **Met** | Five classes defined in §4 and used throughout; a separate **CONFLICT** marker is confined to the gap document. |
| AC-07 | Material claims traceable | **Met** | Every substantive claim carries a `[Pxx | file | anchor]` marker. |
| AC-08 | Conflicts and corrections handled explicitly | **Met** | 14 corrections (COR-01…COR-14) and 16 conflicts (C-01…C-11, C-13…C-17) registered in `07`. |
| AC-09 | No unsupported information invented | **Met** | Unknowns are stated as **NOT DOCUMENTED** / **NOT RECOVERABLE**; no conventional defaults were substituted. |
| AC-10 | Nine core Markdown documents produced | **Met** | `00_` … `08_`. |
| AC-11 | Cross-document consistency checked | **Met** | Counts, terminology and the version identity were reconciled across all nine documents. |
| AC-12 | Scope discipline checked | **Met** | A token scan over every document, heading, filename and table cell was run as part of the verification pass, and every statement was checked against the V2 evidence it cites. |
| AC-13 | ZIP created and tested | **Met** | `RefLab_Reference_V2_Consolidated.zip`, reopened and verified after creation. |
| AC-14 | Gaps and decisions documented honestly | **Met** | 30 gaps (2 closed and 4 partly resolved in Stage 2), 12 decisions, and the "not decisions" boundary in `08`. |
| AC-15 | Original evidence unchanged | **Met** | The archive was opened read-only; all work was done on a copy in a scratch directory. |

---

## 9. Provenance and method

This document set was produced from `Reference_V2_Patches_04-11.zip` alone. The archive was verified
by hash and extracted to a scratch location; the seven patch folders were inventoried; the eleventh
patch folder's deliverable tree was unpacked (550 files) and used as the consolidated reference
point; the remaining folders were walked in descending order and each was tested for artefacts and
facts not carried into the reference tree. Every count published in these documents was re-derived
from a named artefact (object and method counts from the object-model JSON, table and column counts
from the schema dump's `CREATE TABLE` blocks and column lines, control counts by summing the form-blob
control column, INI deltas from the key-level CSV row counts, artefact and CAB-member counts from
the ledger and CAB-inventory row counts, and the patch-level uniqueness test by MD5). Evidence
classes are those defined in §4; provenance markers follow §5; documentation-only identifiers are
labelled as such per §5.3. The specification states what the evidence establishes, marks what it
only supports by inference, and records what it does not establish at all.
