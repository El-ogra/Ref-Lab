# 05 — Workflows, User Interface, Printing & Reporting — RefLab Version 2 (V2)

**System under documentation:** **RefLab Version 2 (V2)**, the **RealLab V-CD-2019** line. Shipped executable `real lab system.exe`, **FileVersion 1.605**, `Description: RLS 1.605`, `CompanyName: RealLab`, 76,292,096 bytes (SHA-256 `C54CE6C8…DF93C0`), PE32 / linker 6.0, PE timestamp **1595435962 = 2020-07-22 16:39:22 UTC**, deployed under `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`). [P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | "relative_path": real lab system\RL_CD2019Access\System\real lab system.exe; "pe"."timestamp"]

**Evidence base and method.** No reference binary was executed. Every claim is derived from static artefacts: the decompiled VB6 object model (`objects.json`, `objects-full.txt`, `forms-blob.txt`), the embedded DDL, the INI and RTF catalogues, the official CHM manual, the vendor Guide Book shipped on the 2019 CD, the screen-recording training video, and the PE envelopes of the print stack. The evidence roots are the patch deliverable trees `analysis/BATCH-04` (VB6 decompilation, schema column census, DDL, CHM manual), `analysis/BATCH-05` (vendor Guide Book and setup texts), `analysis/BATCH-06` (training-video frame sheets), `analysis/BATCH-07` (the shipped V2 schema dumps `v2019-Patients.mdb.sql` and `v2019-data.mdb.sql`, and the template key delta), `analysis/BATCH-09` (shipped RTF and Flash payload ingest), `analysis/BATCH-11` (PE envelopes), `analysis/V-CD-2019` (vendor capability catalogue, PDF print architecture, deployment payload, training video) and `pdf-print-stack.md`. Two further roots are used **for the structure of artefacts that the V2 payload itself ships**: `analysis/BATCH-02/ini/**` (the catalogue of the V2 payload's `Data\*.ini` report-profile and printer-setting templates) and `analysis/BATCH-02/rtf/**` (the catalogue of the 29 `Cache\*.rtf` method sheets the V2 disc carries) — for these, catalogue-level counts are re-based to the V2-primary artefact that states them, and no row-level or cell-level figure from a database extract is used anywhere in this document. The patch markers used in the citations are `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`.

**Evidence classes.** Every claim in this document carries one of the following classes.

| Tag | Meaning |
|---|---|
| **VERIFIED** | Directly readable in a named evidence file; the count/string is reproducible from it. A claim observed in the screen recording is recorded against the named recording file and carries this class. |
| **INFERRED** | Derived by joining two or more verified facts; the derivation is stated. |
| **UNVERIFIED** | Asserted by the vendor in documentation but not corroborated by code/data. |
| **NOT DOCUMENTED** | Not stated in any recovered evidence. |
| **NOT RECOVERABLE** | The artefact that would carry the fact was not present or not extractable. |

**Counting method.** Inventory figures quoted below are counted from the row tables of the source findings file `05_workflows_ui_findings.md`: workflows = the `### WF-xx` headings of §1; forms = the numbered rows of the §2.1 forms table; modules and classes = the rows of the §2.2 table; DataReports = the names listed in §7.1; printer roles = the rows of the §6.3 table; PDF output roots = the rows of the §6.4 table; exception rows = the numbered rows of the §9.1 table.

---

## 1. Workflow catalogue

> **NOTE ON IDs.** The `WF-##` identifiers in this section are **documentation-only** labels invented for cross-reference inside this specification. They are **not** identifiers that exist anywhere in the RealLab binaries, database, or vendor documentation. §1.21 states the verified end-to-end patient-lifecycle workflow that these labels decompose.

### WF-01 — Application start, server resolution and login

| Attribute | V2 fact |
|---|---|
| **Entry point** | Desktop shortcut / program folder icon `real lab system` (green tree-leaf logo). Exact CHM wording: *"بالنقر المزدوج على ايقونة البرنامج الموجودة داخل مجلد البرنامج (real lab system) أو بالنقر المزدوج على ايقونة الاختصار الموجودة على سطح المكتب"* [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1 «كيف يتم تشغيل نظام ريال لاب سيستم ؟» (`001.htm`)]. The same tree-leaf icon is confirmed visually on the Windows 7 desktop in the training recording [P11 \| analysis/V-CD-2019/10-training-video.md \| §2 row 1 "سطح مكتب ويندوز 7 وأيقونة RealLab (ورقة شجر خضراء)"]. |
| **Trigger** | Double-click on the icon. |
| **User actions** | 1) Wait for load; the login screen appears. 2) Pick the user name from the drop-down (first time: `admin`). 3) Type the password (case-sensitive; first time for `admin` the password equals the user name). 4) Press the **«تسجيل دخول»** button. To exit: choose **«خروج»**. [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §2 «كيف يتم تسجيل الدخول لنظام ريال لاب سيستم ؟» (`002.htm`)] |
| **System responses** | Login window renders with the Arabic strings `الدخول للنظام` · `اسم المستخدم` · `كلمة السر` · `نسيت كلمة المرور؟ اضغط هنا` · `شركة ريال لاب لتحاليل المختبرات` · `E-mail: ais_soft_group@yahoo.com` · `Tel: 01144848686 - 01000862074`; these match `IDCARD.INI` literally [P11 \| analysis/V-CD-2019/10-training-video.md \| §5 the login-screen Arabic strings]. |
| **Sequence of operations** | `start` → `server` (server settings window: IP or server machine name, entry permission type, DB user/password, database name) → `login` → `logindete` → main window `labmain`. [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1 the server-settings window; P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects` list] |
| **Validation** | Server name/IP is the only mutable field: *"كل ما سيتم تغيره هو اسم أو أى بي الخاص بالسيرفر"*; entry-permission type, DB user/password and DB name are fixed by the vendor installer and cannot be changed [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1 items 1–4 of the server-settings window]. |
| **Branches / decision points** | **Branch A** — message **«خادم قواعد البيانات غير معرف»**: pressing OK closes the system; then either (1) on the server machine wait until all start-up programs finish and wait a further **five seconds** before pressing OK twice; or (2) on any other workstation, start the SQL server machine (the server need not have RealLab running), and on a machine that is still booting repeat case 1; then check the network switches and sharing effectiveness **without touching system data** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1 branch «خادم قواعد البيانات غير معرف»]. **Branch B** — message **«رجاء تحويل التاريخ الى اللغة الانجليزية»**: the system closes; remedy = `Start menu` → `Control Panel` → `Regional and Language Options` → `Regional Options` tab → `Standards and formats` → `English ( Canada )` → `Ok` [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1 branch «رجاء تحويل التاريخ الى اللغة الانجليزية»]. The same non-obvious locale requirement is repeated in the vendor Guide Book [P11 \| analysis/BATCH-05/manuals/RLS_Setup.txt \| «تعديل لغة عرض التاريخ»]. |
| **Relevant VB6 objects** | `start` (form, 10 methods), `server` (form, 17 methods), `login` (form, 13 methods), `logindete` (form, 6 methods), `users` (form, 57 methods), `userspw` (form, 12 methods), `logindetect` (datareport, 0 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `useraccounts`, `loggroup` (access control); `loger` (attendance in/out log, per the DDL embedded in the shipped executable) [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 «تسجيل الحضور والانصراف» → `loger` (جدول جديد) · `loggroup`]. |
| **Permissions** | The `admin` account is the bootstrap super-user; the manual explicitly instructs the operator to create real users and then **delete `admin`** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §2 step 1]. Access to inner windows is gated by a separate **inner-window password** (`123` by default) in the vendor Guide Book [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «إنشاء مستخدمين… يطلب البرنامج كلمة مرور النوافذ الداخلية»]. |
| **Completion condition** | Main window `labmain` (form, 71 methods, 183 controls) is displayed. |
| **Failure paths** | The two fatal dialogs above; both terminate the process and require an operator action outside the application. |
| **Related screens** | `labmain`, `users`, `userspw`, `server`, `frmTip` (daily-tip form, 5 methods). |

### WF-02 — Patient registration (`addpatient`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main window top bar button **«المرضي»** → patient window → button **«اضافة وتعديل بيانات المرضى»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 «كيف يتم اضافة بيانات مريض جديد ؟» (`003.htm`)]; also reachable directly with **F2** from any main window. Vendor equivalent: `Patient` icon → «إضافة وتعديل بيانات المرضى» [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -1 تشغيل برنامج لاير الب وإضافة مريض جديد»]. |
| **Trigger** | Button click or **F2**. |
| **User actions** | Press **«اضافة مريض»** (the buttons swap to **«إلغاء»** to undo); the caret lands in the patient-name box. Enter the **name**, then the **sex** (the matching surname/title is then shown), then the **age**. Name must be entered *before* age because the age drives the age-appropriate medical normal [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 steps 1–2]. |
| **System responses** | The surname field auto-populates from the chosen sex; the age/sex pair selects the matching normal range; a red-highlighted name cell marks an «مريض مهم» (VIP patient) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 step 2 and §5 point 2]. |
| **Sequence of operations** | `patientmain` → `addpatient` (form, **192 methods**) → `patient` → `patientview` → `patienthistory` / `patienthistory2` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | **Age encoding** — under one month: write days **1–29**; under one year: write months **1–11**; fractions allowed (e.g. `2.5` = two years six months) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 «ملاحظات فى ادخال سن المريض»]. **Name normalisation guidance** — drop hamza (`أحمد`→`احمد`, `إبراهيم`→`ابراهيم`, `علاء`→`علاء`), drop the ta-marbuta (`مروة`→`مروه`, `هبة`→`هبه`, `ساميه`), and use yaa inside the word (`علي` not `على`, `يحي` not `يحى`) so that search and data unification work [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 «ملاحظات عند كتابة الأسماء»]. |
| **Branches / decision points** | **Billing type** (1-1 field) — `Individual` (patient pays the lab's own price even if a referring entity has its own list) / `Lab to Lab` (if the referrer has its own price list the selected tests are priced from it, otherwise the lab's own list applies) / `Free` (total = zero) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 step 3]. **Lab ID** — if the patient has been analysed before, entering the lab code in the lab-code box auto-fills all previously registered personal and clinical data [P11 \| analysis/BATCH-02/db/daytip.csv \| `daytipnum` 6]. **Sample taken outside the lab** — a drop-down of sample type is selected so that a comment is written into the result report [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 step 8]. **Referred entity** — type-ahead autocomplete; clicking the entity name fills the rest of the stored data; a new entity is auto-saved by the system; if no referring entity is typed the system registers one automatically; if the entity carries a discount percentage it is added to the account automatically [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 step 5]. **Suppress referrer name on the report** for Lab-to-Lab work [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 step 6]. |
| **Relevant VB6 objects** | `patientmain` (84 methods), `addpatient` (192), `patient` (58), `patientview` (33), `patienthistory` (22), `patienthistory2` (17), `Patient_samples` (89 methods), `frm_money` (38), `moneypaid` (18) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patientinfo` (carries `PFax varchar(15)`, `SMSMob varchar(15)`, `PatRPW varchar(20)`, `moreinfo2 varchar(30)`) [P11 \| analysis/BATCH-04/schema/added-columns.csv \| `patientinfo,PFax,varchar(15)` / `patientinfo,SMSMob,varchar(15)` / `patientinfo,PatRPW,varchar(20)`]; `patienttest` (**45 columns**, including `natighu`) [P11 \| analysis/BATCH-04/schema/column-evolution.csv \| `patienttest … natighu`]; `payment` (carries `paymentnum bigint IDENTITY(1,1)`) [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table payment ADD paymentnum bigint IDENTITY(1,1) NOT NULL`]. |
| **Permissions** | *"لحذف مريض يجب ان يكون المستخدم الحالى له صلاحية حذف مرضى"* — deleting a patient requires the delete-patient permission on the current user [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 1]. The VIP flag (`important`) is an operational flag, not a permission. |
| **Completion condition** | **F9** saves the new or edited patient; the patient appears in the day's patient list. |
| **Failure paths** | Age entered before name ⇒ no age-appropriate normal is shown. Search misses caused by non-normalised name spelling (see the name-normalisation guidance). |
| **Related screens** | `patientmain`, `patient`, `patientview`, `frm_money`, `moneypaid`, `phone`, `Frm_pic`, `Frm_pic2`. |

### WF-03 — Test ordering / patient order entry

| Attribute | V2 fact |
|---|---|
| **Entry point** | Inside `addpatient`, the test list on the left of the window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «نقوم بإدخال التحاليل الخاصة بالمريض من قائمة التحاليل الموجودة على يسار نافذة البرنامج»]. |
| **Trigger** | Double-click on a test or a group in the list, or press **«اضافة التحليل المحدد»**. |
| **User actions** | The list filter drop-down offers: *routine tests*, *all stored tests*, *test groups*, *the lab's own custom groups* (pre-marriage, pre-anti-HCV, "تشكاب" panels) and a search mode switch (by test name **or** by number) driven by the adjacent text box [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 10]. |
| **System responses** | Double-clicking adds the test (or the whole group) to the patient and prices it under the patient's chosen billing type [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 11]. **F1** with the cursor in the list shows the selected test's details below the list [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 11]. |
| **Sequence of operations** | `addpatient` → test list (populated from `testtable` / `subgrouptable` / `customgrouptable`) → `patienttest` row creation with `arrangnum` ordering. |
| **Validation** | Test ordering can also be done by typing the test number in the search box after choosing the «رقم التحليل» search method, then pressing **Enter** on the keyboard [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 «يمكنك ادخال التحاليل عن طريق كتابة رقم التحليل…»]. |
| **Branches / decision points** | Groups: a group added wholesale brings only its members, and each member's *Add with group* flag decides inclusion — e.g. Gamma-GT is normally not requested together with liver enzymes [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 «Add with group»]. |
| **Relevant VB6 objects** | `addpatient`, `patientmain`, `z_customgroup` (31), `z_group` (14), `testmain` (30), `tools` (1 method but **266 controls**) [P11 \| analysis/BATCH-04/vb6/v1605/forms-blob.txt \| `tools,266,,`]. |
| **Affected entities (exact tables)** | `patienttest` (`testcode`, `subgroupcode`, `arrangnum`, `testprice`, `testpriceout`, `testpriceoutmadfo`), `testtable` (**609** tests as published for V2), `subgrouptable` (**46** rows as published for V2), `customgrouptable` [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patienttest]`] · the catalogue counts at [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 rows 3-1 and §2.7]. |
| **Permissions** | None specific beyond the base "patient data" permission. |
| **Completion condition** | The selected tests appear in the patient's ordered-test list with prices; **F9** persists. |
| **Failure paths** | Removing a test requires a double-click on the entry in the *patient's* list (not the catalogue) — the vendor guide documents the **All** button as the way to delete all tests *only at first registration* [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «لحذف جميع التحاليل الخاصة بالمريض نضغط على زر All … وذلك عند إضافة المريض أول مرة فقط»]. |
| **Related screens** | `addpatient`, `patientmain`, `testmain`, `z_customgroup`. |

### WF-04 — Barcode and label printing (`barcode`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Button **«الباركود»** on the patient window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 «كيف يتم طباعة باركود للمريض؟» (`003A.htm`)]; **F11** jumps to the barcode window for the selected patient [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 keyboard list]. |
| **Trigger** | Button click / F11. |
| **User actions** | The barcode window shows the patient's ordered tests **classified by sample type and drawn material**. Three codes are assigned to every patient: the **case/day code** (sequential, ordering of arrivals, **starts from the first digit**), the **file code** (similar to the case code but **starts from the third digit**; printed at result handover and stuck on the file together with the patient's name, type and age and visit date), and the **lab code** (for easy lookup and printing of the patient's history; **starts from the fifth digit**) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 the three codes]. The code is **13 digits**, exemplar `1 - 4 - 100623 - 1 - 006 - 8` = *a digit not looked at* · *patient's arrival order in the day's work* · *branch number* · *today's date read from the right* · *day-of-week number starting from Sunday* · *case code because the number is 1* [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 «ويتكون رقم الكود من 13 رقم»]. The 13-digit string is a composite of `patientinfo.patientid` (Text(13)) [P11 \| analysis/V-CD-2019/10-training-video.md \| §3 the sample-stamp field table]. |
| **System responses** | Per-material buttons print one label; **«طباعة كل الاكواد»** (orange) prints all file codes; the lab-code button is enabled only when the patient has a lab code; tube/container labels vary in number by the selected tests; an extra free-text barcode can carry a blood-donation or bespoke note written above the arrow button (type and press Enter/arrow to continue, and the label description goes in the box under the arrow) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 points 1–4]. |
| **Sequence of operations** | `barcode` (form, 76 methods, 55 controls) + `barcodeform` (form, 0 methods, 8 controls) → `z_barcodes` (form, 14 methods) → `barcodes` table (in the shipped V2 schema; the number of barcode definitions a live installation holds is **NOT RECOVERABLE**) → printer `barcodeprinter` / `barcodeport` [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 keyboard list; P11 \| analysis/CUMULATIVE/03-capabilities.md \| CAP-03 row]. |
| **Validation** | Horizontal and vertical sliders adjust the print position on the label; after reaching the required dimensions press **«حفظ»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 point 5]. |
| **Branches / decision points** | Drag-and-drop can **move a test from one label to another** (e.g. fasting serum + serum-only viral tests onto one label) and can **delete a test on a label** by dragging it onto the recycle bin [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 the two drag-and-drop paragraphs]. A **«طباعة كود الملف مع الكل»** option decides whether the file code is printed together with all codes [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 point 1]. |
| **Relevant VB6 objects** | `barcode` (76 methods), `barcodeform` (0 methods, 8 controls), `z_barcodes` (14 methods), `CardFrm` (0 methods, 3 controls), `CardFrmSetx` (22 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `barcodes`; `patientinfo.patientid`; `patienttest` (`arrangnum`, `testcode`) [P11 \| analysis/V-CD-2019/10-training-video.md \| §3 «كل حقل له مصدر مُثبَت في البيانات»]. |
| **Permissions** | The barcode printer role (`barcodeprinter`) is separately assignable from the report printer [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 the six printer roles]. |
| **Completion condition** | Labels are printed and the patient file/lab code is stuck on the file. |
| **Failure paths** | If the patient card is lost the vendor's guidance is to **search** for the patient and **re-print** the barcode — **not** to issue a new number [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 14]. |
| **Related screens** | `addpatient`, `barcode`, `barcodeform`, `CardFrm`, `CardFrmSetx`. |

### WF-05 — Result entry per profile (`result*`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main bar → **«المرضي»** → **«ادخال نتائج التحاليل»**, or **F4** from any main window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 «كيف يتم الوصول لنوافذ ادخال نتائج التحاليل ؟» (`004.htm`)]. The result window is opened by **double-clicking a test** of the selected patient, or by selecting with the arrow keys and pressing **Enter** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 3]. |
| **Trigger** | Double-click on the patient's test, or Enter on the highlighted test. |
| **User actions** | Enter the result value in the result cell of the profile grid. The profile grid lists the **whole group** (بروفايل) and **enables only the tests actually ordered for this patient** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 «كيف يتم ادخال نتائج التحاليل (تحاليل الكبد وما شابه مثلاً) ؟» (`004A.htm`)] and shows the patient's header data above the grid. |
| **System responses** | *"وعند ادخال النتيجة يميز البرنامج النتائج الغير طبيعية والحرجة وايضا يكتب تميز لها (عالى او منخفضه او حرجة)"* — on entry the program flags abnormal and critical results and writes a flag («عالى» high / «منخفضه» low / «حرجة» critical) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 2]. Tests that already carry a print mark are shaded **green** and must be reviewed before they can be printed or viewed [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 3]. |
| **Sequence of operations** | `patientmain` → profile form (`Resultliver` 101 methods, `Resulturine` 167, `resultcbc` 172, `resulthepatitis` 187, `resultTrace` 183, `Resultsemen` 222, `resultselectro` 144, `resultanytest` 33, `resultculutre` 115, `resulthpylori` 83, `ResultPCR` 37, `resultIgeAllergy` 231, `resultLBC` 33, `ResultFMF` 48, `ResulturineAuto` 184, `Resultsemen5` 216) → `patienttest` + one profile table per test group [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | **Comparison** — the entered value is compared with `lowlimit` / `highlimit` from `normalrange`; the result is then shown as abnormal (shaded), with an objection text (`nolowexe` / `nohighexe`) and a critical flag (`patienttest` + `normalrange`) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 2 and §10 point 3]. **Unit** — `patienttest.testunit` / `normalrange.testunit` [P11 \| analysis/V-CD-2019/10-training-video.md \| §4 the result-grid column map]. **Normal range text** — the range shown in the grid is a **stored ready-to-print string**, not a value computed at print time (`patienttest.normalrang`, memo) [P11 \| analysis/V-CD-2019/10-training-video.md \| §4 «نصوص النطاق جاهزة للطباعة»]. **Constant override** — a **«Constants»** button on the bottom-right of the window edits the clinical conversion constants (e.g. Hct = Hgb × 3.3; Hgb% = Hgb × 8.25 for under-1-year male/female, × 7.50 for ages 1–12, × 6.25 for males over 12, × 6.75 for females over 12) for a paediatric or adult patient [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 item 1]. |
| **Branches / decision points** | The **patient-history** button's **label changes with the number of stored results for that patient from that profile** (excluding today's result) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 «يتغير اسم زر التاريخ المرضي…»]. Some check boxes (e.g. the comment box) sit in a shaded frame, meaning they are **persistent within this window** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 3]. |
| **Relevant VB6 objects** | All 45 `result*` / `Result*` profile forms; `normal_test` (36 methods); `testrange` (17); `outtest` (11); `converter` (14); `abbrevi` (41); `learntest` (6); `qcfrm` (27); `instrument` (29) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patienttest` (**46** columns in the shipped V2 schema) — `resultt`, `resultt1..resultt4`, `testunit`, `normalrang`, `lowlimit`, `highlimit`, `nolowexe`, `nohighexe`, `commentx`, `resultreview`, `resultfinsh`, `resultprint`, `printuser`, `printdate`, `printnum`, `natighu` — plus one result table per profile (46 profile tables: `cbc`, `urine`, `stool`, `hepatitis`, `lipids`, `kidney`, `semen`, `immun`, `bloodgas`, `cultures`, `cultureanti`, `Helicobacter`, `insulin`, `IgEallergy`, `PCR`, `LBC`, `FMF` …) [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patienttest]`]; the `natighu` column is added by the embedded DDL [P11 \| analysis/BATCH-04/schema/added-columns.csv \| `patienttest,NatighU,Bit`]. |
| **Permissions** | Profile-level form access is permission-driven; the reviewer/auditor buttons on the results window are explicitly restricted: *"هذه الخاصة لا تفعل لغير مدير النظام او المستخدمين اصحاب الصلاحيات المطلقة"* [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 6]. |
| **Completion condition** | **F9** saves results and edits; **F8** marks the selected patient's tests as reviewed. |
| **Failure paths** | A test that cannot be entered or printed electronically (e.g. the blood-picture device, the semen-analysis device) can be force-flagged as done/printed/reviewed via the **«تم»** button in the results window, and un-flagged by pressing it again [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 4]. Review is a **hard prerequisite for printing**, and printing is a **hard prerequisite for handover** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 the closing note and §7 the closing note]. |
| **Related screens** | `patientmain`, `patienthistory`, `patienthistory2`, `patientview`, `anyreport`, `tqrermog`. |

### WF-06 — Result review, print and preview

| Attribute | V2 fact |
|---|---|
| **Entry point** | The action strip at the bottom of the results window (`patientmain`) and the command row of the profile form (`result*`) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 5 and §6 point 5]. |
| **Trigger** | Buttons, or **F11** (preview) / **F12** (print). |
| **User actions** | **Save** — persists the result or the edit made to it. **Print** — prints the results of the requested tests that have been entered *and reviewed*. **Print preview** — shows the same results before printing. **Patient history** — opens the patient's history window and builds a custom history. **Back** — returns to the results window **without saving** the modifications. **Main menu** — exits to the main menu **without saving** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 5]. From the results window the operator may also: print a **combined report** of finished and reviewed results, print a **work sheet** (أمر شغل) for the selected patient only, print an **envelope** (ظرف) for the patient, print the **patient history** in a separate report or as a custom history appended to the tail of the result report, print an **empty report** carrying only the barcode, patient name and lab logo for other purposes, or return to the main menu [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 5]. |
| **System responses** | The print path is **quality-gated**: the literal gate string `Not found any Verified selected tests or result to print it` is emitted when the selection contains no verified/finished result, so **an unverified result is never printed** [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4 «لا تُطبع نتيجة غير مُتحقَّق منها»]. Only **12 printable test types** qualify: `testcode in (6,7,8,9,14,15,16,17,18,19,20,21)` [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4 «12 نوع اختبار فقط قابل للطباعة»]. |
| **Sequence of operations** | `result*` → `reportsetup`-shaped layout loaded from `Data\<category>.ini` → `DataReport` object (66 in V2) → printer role `reportprinter` → Windows print spooler → PDF driver [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`; P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §1 the full path]. |
| **Validation** | The report layout for the selected test category is read from `Data\<category>.ini`; the printable-test whitelist is enforced in the SQL that backs the print query [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4]. |
| **Branches / decision points** | In the results window, per-test markers toggle review status (**F8**), finished status (**F9**) and printed status (**F12**) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 keyboard list]. |
| **Relevant VB6 objects** | `result*` (45 profile forms), `reportsetup` (113 methods), `reportsetup2` (69 methods), `anyreport` (16 methods, 80 controls), `tqrermog` (41 methods), `printerselect` (module, 11 methods), `zarf` (datareport, 1 method) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patienttest` — `resultprint` (Boolean), `printuser` (Text(40)), `printdate` (Text(40)), `printnum` (Double) — the **print audit trail**; `resultreview`; `resultfinsh` [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patienttest]`]. |
| **Permissions** | Printing is an audited act: `printuser` / `printdate` / `printnum` bind every print to an individual user and a **sequential print counter** — the archive's own design note reads *"طباعة مُرقَّمة ⇒ كشف النسخ غير المصرّح به"* [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4 «طباعة مُرقَّمة»]. |
| **Completion condition** | The report is emitted; `patienttest.resultprint` flips to TRUE and `printnum` increments. |
| **Failure paths** | If the printer role is not configured or the hard-coded PDF driver name does not exist on the machine, the PDF path fails — see §6. |
| **Related screens** | `result*`, `anyreport`, `reportsetup`, `reportsetup2`, `tqrermog`, `workpaper`, `workpaper2`. |

### WF-07 — Result delivery / handover and account settlement (`frm_money`, `moneypaid`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main bar → **«المرضي»** → **«تسليم نتائج المرضي»**; also **F6** from any main window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 «كيف يتم تسليم نتائج التحاليل للمريض ؟» (`005.htm`)]. |
| **Trigger** | Button click / F6. On entry the system **automatically lists the day's patients who have not yet collected their results** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 opening paragraph]. |
| **User actions** | With a barcode reader: read the code printed on the **receipt** → the system displays the patient's data → read the code on the patient's **result file** (الفيل) → the system compares the displayed patient data with the file data → on match it asks whether to deliver the results → if a balance remains it warns about it. **If the receipt is lost**, delivery can be done **automatically from the patient's file**. **If the file code was never printed**, delivery can be done by selecting the patient from the list directly [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 the three bullet points]. |
| **System responses** | The window shows the number of **unfinished**, **unprinted** and **un-delivered** tests, plus the **remaining balance** for the lab or for the patient [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 point 4]. A wrong delivery can be corrected by pressing **«مستلمة»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 point 4]. |
| **Sequence of operations** | `patientmain` → `frm_money` (38 methods, 101 controls) → `moneypaid` (18 methods, 23 controls) → `patienttest.give` → `payment` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`; P11 \| analysis/CUMULATIVE/03-capabilities.md \| CAP-05 row]. |
| **Validation** | **Barcode double-read comparison** — the receipt code and the file code must resolve to the same patient, otherwise the system refuses the delivery; this is described as reducing mis-delivery probability because the process passes through more than one confirmation step [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 «فى حالة استخدام قارئ الباركود تقل احتمالية حدوث خطأ…»]. |
| **Branches / decision points** | The lower filter offers **un-delivered results**, sorting by lab-to-lab / individual / important patients, and a period filter per user, plus an **«الكل»** option to show delivered and un-delivered together [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 point 6]. |
| **Relevant VB6 objects** | `frm_money` (38 methods), `moneypaid` (18), `patientmain`, `z_labaccount` (18), `labfunction` (module, 25 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patienttest.give` (Boolean), `patienttest.taslimuser` / `taslimdate` (delivery user + timestamp), `payment` (+ `paymentnum` in V2), `patientinfo.totalprice` / `totalpricedisc` [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patienttest]`; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table payment ADD paymentnum bigint IDENTITY(1,1) NOT NULL`]. |
| **Permissions** | Delivery is an audited act (delivering user + time); the ability to *deliver* is one of the permission-checked actions in the results window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 6]. |
| **Completion condition** | `patienttest.give` set; `printuser`/`printdate` for the delivered result are already present because **printing precedes delivery** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 and §7 closing notes]. |
| **Failure paths** | Delivery attempted on unprinted/unreviewed results is blocked by the review→print→deliver chain; a mis-delivery must be manually reverted with **«مستلمة»**. |
| **Related screens** | `frm_money`, `moneypaid`, `patientmain`, `patientview`. |

### WF-08 — Patient search (`patientview`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main bar → **«المرضي»** → **«بحث عن مرض»**; also **F3** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 «كيف تتم عملية البحث عن مريض فى نظام ريال لاب سيستم ؟» (`006.htm`)]. The daily-tip store repeats this shortcut as a rotating hint [P11 \| analysis/BATCH-02/db/daytip.csv \| `daytipnum` 1]. |
| **Trigger** | Button click / F3. |
| **User actions** | Search **code box**: with a reader, read the code (case code, lab code or file code); without a reader, type the code and press **Enter**. **Name**: enter the first letters to list the first **100** patients whose names begin with them, or search anywhere in the name; both methods can be used together. **Phone / mobile / national ID / any patient code** each have their own dedicated box [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8]. |
| **System responses** | The result list shows **at most 100 patients** — the stated reason is *"لحفاظ على سرية البيانات ام الجرد والفرز فتتم عن طريق الإحصائيات"* (to preserve data confidentiality; stocktaking and sorting are done through the statistics module) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 2]. |
| **Sequence of operations** | `patientmain` → `patientview` (33 methods, 63 controls) → `patienthistory` / `patienthistory2`; SQL uses `mid(patientid,…)` to slice the composite patient id [P11 \| analysis/CUMULATIVE/03-capabilities.md \| CAP-06 row]. |
| **Validation** | The filter block can constrain the search by **period**, **age stage**, **sex**, or **referring entity** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 1]. |
| **Branches / decision points** | From the result grid the operator can view a patient's results, delete the patient from the system, or — via **«نتائج مجمعة»** — print a combined report of several patients sharing selected tests (double-click a patient name in the search result, then move to the combined-results window) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 4]. |
| **Relevant VB6 objects** | `patientview` (33 methods), `patienthistory` (22), `patienthistory2` (17), `anyreport` (16) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patientinfo`, `patienttest`, `history` (dynamic **25**-column table in the shipped V2 `bin\data.mdb`) [P11 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [history]] [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 the `data.mdb` row]. |
| **Permissions** | Deleting a patient from the search window requires the delete permission; the **backup-database** variant of the search (below) is confined to the mini-edition [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 4]. |
| **Completion condition** | A patient (and their visit/test set) is selected. |
| **Failure paths** | The search is **deliberately capped at 100 rows** — an exhaustive search must use the statistics module instead. |
| **Related screens** | `patientview`, `patienthistory`, `patienthistory2`, `anyreport`. |

### WF-09 — Test catalogue maintenance (`setup1`..`setup3`, `tools`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main bar → **«بيانات النظام»** → **«بيانات التحاليل»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 «كيف يتم اضافة أو تعديل بيانات تحليل ؟» (`007.htm`)]; vendor equivalent: `System` icon → «بيانات التحاليل» [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -3 تعديل بيانات أو سعر تحليل»]. |
| **Trigger** | Button click. |
| **User actions** | Browse or search the registered tests (search by test code, group name or test name). Select a test → **«تعديل»** to edit, **«اضافة تحليل»** to create, **«حذف»** to delete, or **«المعدل الطبيعي»** to open its reference-range editor [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 points 1–2 and point 8]. The vendor guide adds **«تراجع»** (undo) as the counterpart of **«حفظ»** (save) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «فى حالة عدم الرغبة فى التعديل نضغط على ( تراجع )»]. |
| **System responses** | The detail panel exposes the full field set: **Test name** (name in the program lists) · **Report name** (name in the report, split into a large-font part and a small-font part, e.g. `SGPT/ALT (Alanine Aminotransferase)`) · **Bill name** (name on the receipt; when the first part repeats the system groups the tests into one line item, e.g. liver and kidney panels) · **History name** (name in the patient history; should be short) · **Arabic name** · **Group name** (used in statistics and when adding a whole group to a patient) · **Branch** (the lab branch responsible) · **Log group** (work-group, e.g. two chemistry analysers — used to split the day's work sheet per instrument) · **Collection** (notes on sample-collection conditions) · **Test time** (turnaround time; **enter 0 for same-day**, and the receipt's result-expected time is computed from it) · **Arrange number** (position in the lists; ties are broken by name) · **Patient price** · **Lab to Lab price** · **Routine test** (show in the routine list) · **See report** (for multi-result tests such as urine, stool and blood picture, no result is displayed in the patient window) · **Print with other** (large tests such as urine/stool cannot be printed inside a combined report) · **Add with group** · **Main test** (main test such as blood gases, haemoglobin, electrophoresis, VDRL — the flag is cancelled in the other members) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 point 3]. |
| **Sequence of operations** | `tools` (1 method / 266 controls) → `setup1` (56 methods), `setup2` (58), `setup3` (42) → `testtable` / `customtesttable` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | The **sample-type / container** block assigns the barcode label material and the test name printed on the label (e.g. urine needs one label; creatinine needs a serum label *and* a 24-hour-urine label) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 point 4]. |
| **Branches / decision points** | **Sent outside the lab** — checking this and choosing the destination lab plus its cost price means that, when such a test is ordered for a patient, it appears automatically in the outbound-samples window and its amount is posted to the lab's accounts [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 point 5]. **Patient question** — a per-test question (e.g. "are you fasting?" for lipids, minimum 12 hours) is shown in the patient window when the test is selected [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 point 6]. **Sub-tests** — for a group such as the CBC differential or VDRL, search by the *third* (test-name) box and the system lists all members; select the member with the mouse [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 the closing note]. |
| **Relevant VB6 objects** | `tools`, `setup`, `setup1`, `setup2`, `setup3`, `instrument` (29), `commentsetup` (5), `abbrevi` (41), `converter` (14), `z_units` (14), `z_pricelists` (27), `z_gehats` (56), `z_customgroup` (31), `antibioticfrm` (29 methods), `normal_test`, `testrange`, `outtest` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `testtable` (609 tests; carries `testcodebill nvarchar(13)`), `customtesttable`, `testunits` (69), `converts` (167), `abbreviations` (650), `instrument`, `normalrange`, `subgrouptable` (46), `customgrouptable`, `pricelist`, `antibiotic` (38 rows / 25 columns), `antibio` (96 rows) [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table testtable ADD testcodebill nvarchar(13)`; P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 the out-of-index capabilities table]. |
| **Permissions** | Editing the catalogue is a system-administration action reachable from the **«بيانات النظام»** ribbon; the vendor guide places it under the `System` icon, i.e. the administrative half of the application [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -1 تعديل بيانات او سعر تحليل»]. |
| **Completion condition** | **«حفظ»** persists; **«تراجع»** abandons. |
| **Failure paths** | The **Urine test number 4** is immutable: *"تحليل البول رقم 4 فى النظام لا يجوز تغيرة الى اى رقم.。甚至 ان كان هذا المكان خالى من التحاليل ولن يمكنك تعديل بياناته واسمائه كما تشاء مثل: Urine or Urine Examination or Urineanalysis"* [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 item 2]. |
| **Related screens** | `tools`, `setup1`, `setup2`, `setup3`, `normal_test`, `instrument`, `abbrevi`, `commentsetup`. |

### WF-10 — Reference-range (normal) management (`normal_test`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | **«بيانات النظام»** → **«بيانات التحاليل»** → select the test → **«المعدل الطبيعي»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 «كيف يتم اضافة أو تعديل المعدلات الطبيعية لتحليل معين ؟» (`008.htm`)]; vendor equivalent: **«القيم المرجعية»** button [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -3 إضافة / تعديل القيم المرجعية الخاصة بالتحاليل (النورمال)»]. |
| **Trigger** | Button click on a selected test. |
| **User actions** | The window shows all ranges registered for that test. **«اضافة مدى»** adds a new range; **«تعديل»** edits the selected range; **«حفظ»** saves; **«تراجع»** undoes the add/edit in progress; **«حذف»** deletes the selected range; **«قائمة التحاليل»** returns to the test list [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 points 1–2]. The vendor guide additionally documents the **«تحديث»** (refresh) button inside the report's reference-range cell, followed by **«موافق»**, to re-apply the *new* range to patients already registered on the old one [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «فى حالة الرغبة فى التعامل معهم على القيم المرجعية الجديدة»]. |
| **System responses** | The system pre-selects the normal matching the patient's sex and age stage; the report shows the range matching sex and age stage [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 opening paragraph]. |
| **Sequence of operations** | `setup1..3` → `normal_test` (36 methods, 25 controls) / `testrange` (17) / `outtest` (11) → `normalrange` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | The 14 documented fields, verbatim: **Test name** · **Test unit** · **Sex** · **Age From : To** · **Age unit** · **Normal range** (text printed in the normal-range cell of the report) · **Low limit / High limit** (values outside the range ⇒ the report text background is shaded) · **Low flag : High flag** (an expression displayed on abnormal results, both while entering results and in the printed report) · **Low comment : High comment : Critical comment** (a comment on the patient's result that appears in the comment cell of the window and of the report when the test name is clicked; it is selected according to whether the patient's result is low, high or critical) · **Critical range** (text printed in the normal-range cell of the report; appears when the option to print critical ranges is chosen in the report-settings window) · **Low limit : High limit (critical)** (the values on which a result is deemed critical and the critical expression is shown) · **Critical flag** (expression shown for critical results) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 points 3–4]. |
| **Branches / decision points** | **By sex and age / by age only** — when the reference value does not differ by sex (e.g. sugar) the range must still be entered **six times**: men 0–120 y and women 0–120 y; men 1–29 d and women 1–29 d; men 1–11 m and women 1–11 m. When it does differ by age: men 0–12 y and men 12–120 y, and likewise for women [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 opening]. **Age-unit granularity** — a range entered for 60 years does not cover a 1-month-old patient even though 30 days ≈ 1 month: a separate range must be added for every new age unit (month / day / year) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «ملاحظة هامة فى الجزء الخاص بالنورمال»]. |
| **Relevant VB6 objects** | `normal_test` (36 methods), `testrange` (17), `outtest` (11) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `normalrange` (852 ranges across 304 tests; 14 fields; `normalrang` is `varchar(MAX)`) [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table normalrange ALTER COLUMN normalrang varchar(MAX)`]; `patienttest` (the range string is **copied** into `patienttest.normalrang` at ordering time, so previously stored results keep the old range) [P11 \| analysis/V-CD-2019/10-training-video.md \| §4 «نصوص النطاق جاهزة للطباعة»]. |
| **Permissions** | Administrative (System menu). |
| **Completion condition** | The range is saved; new patients and — after an explicit refresh — previously registered patients are re-evaluated against it. |
| **Failure paths** | Existing patients are **not** re-evaluated automatically — they continue to be judged against the old range until the operator explicitly refreshes from the report window. Missing age-unit ranges silently yield no range display. |
| **Related screens** | `setup1`, `setup2`, `setup3`, `normal_test`, `testrange`, `outtest`, `reportsetup`. |

### WF-11 — Report design / layout customisation (`reportsetup`, `reportsetup2`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Results window → select a patient and a test → open the profile window → press the **test-group name button "باللون البرتقالى فى أعلى النافذة"** (orange-coloured group-name button at the top of the window) → the **report-settings** window opens [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 «كيف يتم التعديل فى نصوص وأبعاد وألوان التقرير ؟» (`009.htm`)]; confirmed visually in the training recording as the *Preparing Report / Report Template* window [P11 \| analysis/V-CD-2019/10-training-video.md \| §8 the report-setup screen]. |
| **Trigger** | Click on the orange group-name button. |
| **User actions** | Edit the window title and the main report headings (report name, side title, normal-range title, doctor's signature, comment …), the page and item alignment, item colours, and show/hide toggles for report components [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 opening]. The heading panel contains **three signature lines**, any or all of which may be used [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 1]. |
| **System responses** | The layout is stored per **report profile** in `Data\<category>.ini`; the three boxes under each item are colour-coded: a **red-background** box holds the dimension, **green** boxes represent the printed text width on the result page, and **yellow** boxes represent the indent value for sub-titles and their items [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 4]. The visible toggle group is: **Show abnormal result background color** · **Print Status Flag (Low, High, Critical)** · **Make Normal range Font Bold** · **Print Critical Ranges If Found** · **Print Patient History Automatically** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2]. |
| **Sequence of operations** | `reportsetup` (113 methods, 150 controls) / `reportsetup2` (69 methods, 117 controls) → `Data\<category>.ini` → `DataReport` object [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | **Scope of the change is deliberately narrow** — *"عند التعديل فى هذه النافذة لاينطبق التعديل إلا على هذا التقرير فقط وايضا على جهاز الكمبيوتر الذى تم علية التعديل"* for the item-layout part, and *"عند التعديل فى هذه النافذة ينطبق التعديل على جميع التقارير ولكن لا ينطبق إلا على جهاز الكمبيوتر الذى تم علية التعديل فقط"* for the header/footer part [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 the two scope notes]. That is: **changes are per-machine, not per-installation or per-network**. |
| **Branches / decision points** | The **header/footer editor** is reached via **«تعديل ألوان رأس وذيل التقرير»** (edit report head/tail colours) and offers: colour each header/footer element; set the height of the separator lines via a text box; show/hide the lines; and control the thickness of the patient-history line [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 points 6–7]. Its command row is **«حفظ الاعدادات»** · **«أبيض واسود»** (black & white — resets the report to white and black only) · **«عودة»** (return without saving) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 7]. |
| **Relevant VB6 objects** | `reportsetup` (113 methods), `reportsetup2` (69), `static1` (30), `static2` (26), `static3` (15), `static4` (18), `static5` (21), `static6` (24 methods), `BCWFonts` (module, 7 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `Data\*.ini` — 223 report-profile templates (114 catalogue categories); `bin\REPORT.dll` (a plain INI despite the extension, carrying `[reportdata]` and `color1..color19`) [P11 \| analysis/CUMULATIVE/06-configuration.md \| §6 `bin\REPORT.dll` and §7 `Data\*.ini`]. |
| **Permissions** | Per-user; the report-design screen is reachable from the result-entry screen and is not described as administrator-only. |
| **Completion condition** | **«حفظ الاعدادات»** writes the profile back to `Data\<category>.ini`. |
| **Failure paths** | Because the change is machine-local, **two workstations on the same database can print different layouts** — a documented, deliberate property, not a bug. |
| **Related screens** | `reportsetup`, `reportsetup2`, `static1`..`static6`, `BCWFonts`, `result*`. |

### WF-12 — Outbound (referral) sample management (`sarfz`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | **F7**, or main menu → **«حسابات»** → **«العينات المرسلة للخارج»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 «كيف يتم ادارة العينات المرسلة للخارج من داخل النظام ؟» (`010.htm`)]; vendor equivalent: `Accounts` icon → «العينات المرسلة للخارج» [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -6 تصفية حساب العينات المرسلة للخارج»]. |
| **Trigger** | F7 or menu path. |
| **User actions** | The system **automatically detects** tests defined as `Sent outside Lab.` in the test catalogue and places them in this window. Select the period, press **«عرض»**, click a sample to be sent → the system **groups all samples sent to the same destination** and shows the group total; then press the send button, enter the amount that will be paid, press **«موافق»**; if the account is settled press **«خالص»**, which marks the sample as sent and saves it [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 points 2–4; P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -6»]. |
| **System responses** | The two lower buttons show (a) all samples not yet sent and (b) samples whose account is not settled, across all registered patient data [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 point 8]. |
| **Sequence of operations** | `sarfz` (26 methods) → `moenysharekat` (27 methods) → `moenymozafeen` (27 methods) → `patienttest.sentout` / `.send` / `.otherlabname` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | **Changing the destination lab is not persisted as a default for that test**; to make it the default the operator must press **«دائما اليه»** before **«موافق»** or **«خالص»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 point 4]. |
| **Branches / decision points** | The drop-downs allow filtering to a single destination lab, viewing all tests requested in the selected period, and sending tests that are not configured as outbound without changing the system configuration [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 points 5–7]. Two buttons can mark the selected test as outbound / not outbound (the equivalent of editing it in the test catalogue) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 point 6]. |
| **Relevant VB6 objects** | `sarfz`, `moenysharekat`, `moenymozafeen`, `labfunction` (module, 25), `z_gehats` (56), `labtolab` (32) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patienttest.sentout` (Boolean), `patienttest.send` (Boolean), `patienttest.otherlabname` (Text(40)), `patienttest.testpriceout` (Double), `patienttest.testpriceoutmadfo` (Double); `Gehats` (V2 adds `ReferredPW varchar(20)` and `ReferredID int`) [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table Gehats ADD ReferredPW varchar(20)` / `ReferredID int`]. |
| **Permissions** | Accounting-area action (Accounts icon). |
| **Completion condition** | `sentout` = TRUE, `send` = TRUE and the settlement amount recorded. |
| **Failure paths** | Without **«دائما اليه»** the changed destination is silently discarded. Un-sent and un-settled samples are only reachable through the two dedicated filter buttons. |
| **Related screens** | `sarfz`, `moenysharekat`, `moenymozafeen`, `labtolab`, `z_gehats`. |

### WF-13 — Stocktaking, accounting and grading (`labfunction`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main menu → **«حسابات»** → **«الجرد وحساب الدرج»**, or **F7** from any main window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §13 «كيف يتم معرفة حساب الدرج وعمل جرد لفترة محددة ؟» (`011.htm`)]; vendor equivalent: `Accounts` icon → «الجرد وحساب الدرج» [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «6 -1 الجرد وحساب المعمل»]. |
| **Trigger** | Menu path or F7. |
| **User actions** | Select the period (default = today) and press **«عرض»**. Seven report blocks are then available: 1) the patients' accounts (each button prints a report of the patients' names, data and itemised breakdown; the **«ماتم تحصيلة»** button asks *"هل تريد عرض الفلوس المحصلة من مرضى الفترة المحددة فقط ام اي مريض سدد فى هذه الفترة"*), 2) the outbound-sample account (with a **«العينات المرسلة للخارج»** button to see them either **itemised per sample** or **aggregated per destination**), 3) the expenses and deposits registered through the accounts window (cash withdrawal and deposit), 4) patients with a remaining balance and the commissions of referring entities, 5) the workload of each user and the amounts collected with them, 6) claims on / turnover with the other entities (aggregated or itemised) and 7) the ability to **print a claim** for a given entity [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §13 points 1–7]. |
| **System responses** | The vendor guide names the aggregate outputs explicitly: total patient-sample value, total discounts, what was collected and what was not, the cash on hand, and **net profit after collection and settlement** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 –6 الجرد وحساب المعمل»]. The **inner-window password `123`** is requested on entry [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «يطلب البرنامج كلمة مرور النوافذ الداخلية»]. |
| **Sequence of operations** | `labfunction` (module, 25 methods) → `payment`, `patientinfo.totalprice` / `totalpricedisc`, `Gehats.omola` (referring-entity commission) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`; P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5]. |
| **Validation** | The report granularity selector offers four modes: **مفصل بالنتائج** (itemised by results) · **مفصل بالأسعار** (itemised by prices) · **مفصل** · **مجمع** (aggregated) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «نوع التقرير المطلوب»]. |
| **Branches / decision points** | **Single-site vs multi-branch** — with several machines on one database and all users on the same branch, pick `All`; with a branch-lab system, pick the branch number from the top of the window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «2 -6» and «3 -6»]. Stocktaking can be scoped to a **specific user** (doctor / referring entity / requesting doctor) or to the **outbound samples / account type** [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 the Accounting unit table]. |
| **Relevant VB6 objects** | `labfunction` (module, 25), `z_labaccount` (18), `moenysharekat` (27), `moenymozafeen` (27), `printerselect` (module, 11) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `payment` (+ `paymentnum` in V2), `patientinfo.totalprice`, `patientinfo.totalpricedisc`, `Gehats.omola`, `Labbranch`, `Patient.branche` [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table payment ADD paymentnum bigint IDENTITY(1,1) NOT NULL`; P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-2]. |
| **Permissions** | Inner-window password; branch scoping implies the multi-branch permission set (`Patient.branche`, `SUBSTRING(patientid,9,1)` as the branch index inside the composite patient id) [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §5 the branch model]. |
| **Completion condition** | The period report renders; an entity claim may be printed. |
| **Failure paths** | Cash in/out is registered in a separate accounts window (صرف وإيداع نقدية) and appears in block 3 only after registration [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §13 point 4]. |
| **Related screens** | `labmain`, `z_labaccount`, `moenysharekat`, `moenymozafeen`, `sarfz`. |

### WF-14 — Work-sheet generation (`workpaper`, `workpaper2`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Vendor guide: work-sheet capability group `Work Sheet` (2:1–2:2) [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.2 the Work Sheet unit]. |
| **Trigger** | Requesting a work sheet for a group of patients in a period, or for a specific test / test group in a period. |
| **User actions** | Two variants exist — **work sheet for a group of patients** and **work sheet for a specific test or group of tests**, plus **classification of a period's tests to count how often each test was performed** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «2 -1 / 2 -2 / عمل ورقة عمل»]. |
| **System responses** | The printed work sheet is headed **WORKPAPER BY PATIENT NAME** or **WORKPAPER BY TEST NAME**, carries `No. of Patients: 3  \|  Printed by: Administrator  \|  Thursday, 24-Mar-2011  11:34 AM`, and lists `Test Name \| Gender \| Male \| Age \| Years \| (barcode)` grouped by **Group**, **Total**, and the **log group** (work group) with the sample type and a per-test volume and a `Reprinted` marker [P11 \| analysis/V-CD-2019/10-training-video.md \| §7.1 the WORKPAPER BY PATIENT NAME facsimile]. The BY TEST NAME variant is headed `No. of types of tests: 17  \|  Printed by: Administrator` and lists `Test Code 1 → F.B.C.    (Patient Name \| Result \| ID)` etc. [P11 \| analysis/V-CD-2019/10-training-video.md \| §7.2]. |
| **Sequence of operations** | `workpaper` (17 methods) / `workpaper2` (18 methods) + `wasl` table + `testtable` [P11 \| analysis/V-CD-2019/10-training-video.md \| §7 the "source in the code" note]. |
| **Validation** | The work sheet is a **profile/subgroup listing printed as a distribution map** — "which tests of this group were requested and by whom they passed" — which is exactly what the `wasl` table (`subgroupcode`, `testcode`, `waslname`, `testprice`, `testno`) models; `wasl` carries `resultt`, `testunit`, `RESULTCASEPRINT`, `normalrang`, `testcodex`, `subgroupname` [P11 \| analysis/V-CD-2019/10-training-video.md \| §7 the interpretation note; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table wasl ADD resultt varchar(50)` etc.]. |
| **Branches / decision points** | Work sheets split the day's work **per instrument**, because each test is assigned a **Log group** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9 the Log group field]. |
| **Relevant VB6 objects** | `workpaper` (17 methods), `workpaper2` (18 methods), `sarfz` (26) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `wasl`, `patienttest` (`loggroup`, `subgroupcode`, `testcode`), `testtable` [P11 \| analysis/V-CD-2019/10-training-video.md \| §7]. |
| **Permissions** | Work-sheet printing uses the **work-sheet printer role** `waslprinter` [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 the six printer roles]. |
| **Completion condition** | The work sheet is printed and filed. |
| **Failure paths** | A `Reprinted` marker appears on reprinted lines — reprinting is flagged, not blocked [P11 \| analysis/V-CD-2019/10-training-video.md \| §7.1]. |
| **Related screens** | `workpaper`, `workpaper2`, `patientmain`. |
| **Document-generation dependency** | **VERIFIED — the work sheet has both a print/document output and an Excel output.** The work-sheet window carries the controls **Print**, **Excel Report**, **Print New Sheet** and **Save as Excel File**; the produced document is headed **WORKPAPER BY PATIENT NAME** (carrying `No. of Patients: 3`, `Printed by: Administrator`, the print timestamp) or **WORKPAPER BY TEST NAME** (carrying `No. of types of tests: 17`), and the same screen shows a **spreadsheet window with a bar chart and a statistics table** (name, age, unit, level, values, count, average) [P11 \| analysis/BATCH-06/video/sheets/06_detail_0100s.jpg \| frame #1 (t=1800s), frame #4 (t=1860s), frame #15 (t=1980s)] · [P06 \| 06_detail_0100s.jpg \| frames #1, #4, #15]. The application objects are `workpaper` (17 methods) / `workpaper2` (18 methods) and the DataReports `Reportworkp` · `Reportwp` · `Reportwpm` · `Reportwpot` · `Reportwpt` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. **The mechanism that produces the Word-format document and the Excel file (COM automation, template export, or an intermediate file) is NOT DOCUMENTED** — the frames show the controls and the outputs, not the implementation. |

### WF-15 — Statistics and performance monitoring (`statisReport`, `static1`..`static6`, `anyreport`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Vendor guide: **«Statistics»** icon [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -5 الإحصائيات ومتابعة أداء المعمل»]; capability unit `Server` 4:1–4:5 [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4]. |
| **Trigger** | Click the Statistics icon and choose the statistic type. |
| **User actions** | Two statistic families: on **patients** and on **tests** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -5 الإحصائيات ومتابعة أداء المعملStatistics»]. |
| **System responses** | The screen (Arabic) exposes: number of patients (from date / to date); patients by type; patients (critical cases); number of reviews; number of tests by type; number of tests (critical cases); number of tests per branch; number of tests per representative; number of tests (unfinished); number of outbound samples, per branch, per referring entity, and unfinished; and **branch accounting** (tests per branch, outbound samples per branch). Observed values in the recording: patients **216**, tests **50**, outbound samples **118**, representatives **120**, branch account **400**. A **bar chart titled «عدد التحاليل»** is exported to Word with a table of test name / count / percentage [P11 \| analysis/V-CD-2019/10-training-video.md \| §6 «وحدة الإحصائيات — مسرود بصريًا»]. |
| **Sequence of operations** | `statisReport` (datareport) + `static1` (30 methods) · `static2` (26) · `static3` (15) · `static4` (18) · `static5` (21) · `static6` (24 methods) + `anyreport` (16 methods, 80 controls) → `loger` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`; P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-1]. |
| **Validation** | Period filtering (a year, a month) and sex/class breakdowns are the documented axes [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «2 -5 / 3 -5 / 4 -5»]. |
| **Branches / decision points** | The user-workload statistic is what the stocktaking screen's "workload of each user" block also reports; the two views overlap [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §13 point 6]. |
| **Relevant VB6 objects** | `statisReport` (datareport, 0 methods), `reportstatic1` (datareport), `static1`..`static6`, `anyreport`, `labfunction` (module, 25), `z_logs` (14), `loggroup` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patientinfo.requestdate` / `patientsex`, `patienttest.subgroupcode`, `loger` (attendance/out), `loggroup` [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4]. |
| **Permissions** | The guide states that **only the system administrator** can see users' in/out times and the overtime/lateness figures [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -4 تسجيل الحضور والانصراف… يمكن لمدير النظام فقط الاطلاع»]. |
| **Completion condition** | The statistic renders; optionally exported to Word. |
| **Failure paths** | The statistics module is the sanctioned substitute for the search window's 100-row cap [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 2]. |
| **Related screens** | `static1`..`static6`, `anyreport`, `labfunction`, `z_logs`. |

### WF-16 — User and permission management (`users`, `userspw`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Vendor guide: **«User»** icon → **«إنشاء مستخدمين»** (create users) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -4 إنشاء مستخدمين وتحديد صلاحياتهم»]; capability unit `Server` §4 [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7]. |
| **Trigger** | Click the User icon, then **«إنشاء مستخدمين»**. |
| **User actions** | The **inner-window password `123`** (or the operator's own password if they changed it) is requested. Then **«إضافة»**: type the user's name, the **main password** and the **branch password**, then tick the permissions and press **«حفظ»**; the user then appears in the user list on the left of the window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -4 إنشاء مستخدمين»]. To edit: select the user in the list → **«تعديل»** → edit → **«حفظ»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «2 -4 تعديل بيانات وصلاحيات المستخدمين»]. |
| **System responses** | On login the new user's permissions apply; attempting an unauthorised action shows the message **«أنت ال تملك الصالحية لهذا العمل راجع مدير النظام»** (you do not have the permission for this work — see the system administrator) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -4»]. |
| **Sequence of operations** | `users` (57 methods — up from 29) → `userspw` (12 methods) → `useraccounts` (carries `HDD1 varchar(20)`, `HDD2 varchar(20)`, `Gtype Smallint`) [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table useraccounts ADD HDD1 varchar(20)` / `HDD2 varchar(20)` / `Gtype Smallint`]. |
| **Validation** | The **attendance / sign-out** sub-flow: the user records **check-in** at the start of work, records a **break** if any, and records **sign-out** at the end of the shift; the administrator can then see in/out times, overtime and lateness per user [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -4 تسجيل الحضور والانصراف»]. |
| **Branches / decision points** | The V2 `useraccounts` model adds a **permission tier** (`gtype`), plus **hardware binding** fields (`HDD1`, `HDD2`) that align with the hardware-locked licensing scheme [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §2.2 «Patients (SQL Server): branche · SecWord · grant13..grant17»]. |
| **Relevant VB6 objects** | `users` (57 methods), `userspw` (12), `login` (13), `logindete` (6), `logindetect` (datareport) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `useraccounts` (carries `HDD1`, `HDD2`, `Gtype`; the SQL-Server `Patients` table carries `branche`, `SecWord`, `grant13..grant17`), `loggroup`, `loger` [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §2.2]. |
| **Permissions** | This workflow *is* the permission workflow. The explicit denial string is `أنت ال تملك الصالحية لهذا العمل راجع مدير النظام`. |
| **Completion condition** | The user is saved and appears in the login drop-down. |
| **Failure paths** | The `admin` bootstrap account must be deleted after real users exist [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §2 step 1]. The inner-window password `123` is a hard-coded default in the vendor documentation — a known credential exposure [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «كلمة المرور ( 123 )»]. |
| **Related screens** | `users`, `userspw`, `login`, `logindete`, `logindetect`. |

### WF-17 — Price-list management and printing (`z_pricelists`, `pricelistsN`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Vendor guide: **«System»** icon → **«قوائم أسعار التعاقدات»** (contract price lists) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -3 إضافة / تسجيل قائمة أسعار جديدة فى البرنامج»]. |
| **Trigger** | Menu path. |
| **User actions** | **«اضافة»** → type the new price-list name → **«Ok»**; the list appears in the program's price lists. Add a test: select it → **«إضافة»** → choose the test → enter its price → **«موافق»**. Edit a price: select the test → **«تعديل»** → new price → **«حفظ»**. Delete a test: select → **«حذف»**. Rename a list: **«تعديل»** at the bottom of the list → rename → **«حفظ»**. Delete a whole list: select → **«حذف»** → **«موافق»**. Print a list: select → **«طباعة القائمة»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -3»]. |
| **System responses** | The list becomes selectable for referring entities; the printed list is emitted by the DataReport `pricelistsN` [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 the DataReport table: `pricelistsN`]. |
| **Sequence of operations** | `z_pricelists` (27 methods) / `shoppingfrm` (15) → `pricelist` → `pricelistsN` (datareport) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | A lab-to-lab entity may be bound to any list, including the **Lab-to-Lab** list [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «7 -3 إضافة طبيب معالج / جهة إحالة»]. |
| **Branches / decision points** | Three entity kinds exist with different price behaviour: **doctor (طبيب معالج)** — billed at `Patient Price`; **outbound samples (عينات مرسلة)**; **referring/contract entity (جهة إحالة أو تعاقد)** — billed from its own list, with an address/phone/fax/manager block and an optional **discount or commission (خصم أو عمولة)** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «7 -3»]. |
| **Relevant VB6 objects** | `z_pricelists` (27 methods), `shoppingfrm` (15), `z_gehats` (56), `labtolab` (32) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `pricelist`, `pricelists`, `Gehats` (+ `ReferredPW`, `ReferredID` in V2), `testtable.testprice` / `testpriceout` [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table Gehats ADD ReferredPW varchar(20)`]. |
| **Permissions** | Administrative (System menu). |
| **Completion condition** | The list exists and is bound to at least one entity. |
| **Failure paths** | Deleting a list that entities still reference leaves those entities without a price list; the manual's delete path requires **«موافق»** confirmation only, with no reference check documented [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -3»]. |
| **Related screens** | `z_pricelists`, `shoppingfrm`, `z_gehats`, `labtolab`. |

### WF-18 — Culture / sensitivity entry and culture-antibiotic catalogue (`resultculutre`, `antibioticfrm`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Results window → select the culture test → the culture entry form opens. The antibiotic catalogue is at **«System»** → **«Culture Antibiotics»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «9 -3 إضافة مضاد حيوى للمزرعة»]. |
| **Trigger** | Double-click the culture test (result entry) / menu path (catalogue). |
| **User actions** | Culture entry fields: **Sample – Organism A – Organism B – Organism C – Culture Condition – Colony Count**, then press **«Sensitivity»** to enter the antibiotics; pick **Highly For / Moderate For / Low For / Resistant For** by double-clicking the antibiotic on the right of the window, or select it and press **«Add»**; the display of **Sensitivity / Reference / Commercial Name** in the report is toggled per element [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «8 -1 إدخال التقارير فى حالة المزارع»]. For the catalogue: **«إضافة»** → choose the culture → double-click the antibiotic → **«حفظ»**; if the antibiotic is not in the list, type its data manually in the antibiotic fields → **«حفظ»**; delete: select → **«حذف»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «9 -3»]. |
| **System responses** | The antibiotic set is filtered by patient context: an antibiotic tagged for **Pregnant** appears in the culture only when the patient is pregnant; an antibiotic tagged for **Children** appears only when the patient is a child, and the program recognises a child as **under 12 years** (male or female) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «9 -3»]. |
| **Sequence of operations** | `resultculutre` (115 methods) → `antibioticfrm` (29 methods) → `cultures` / `cultureanti` / `antibiotic` / `antibio` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | **Organism C** — the `Data\*.ini` profiles carry `LabelX002=Organism C`, `ITEMXV002`, `ITEMXD2=Gram Positive Cocci##Gram Negative bacilli##Gram Negative Dilococci##No Organism##` and `Check6f=1` in **32 files**; the shipped schema carries `cultures.organism3 Text(80)` and `organism`/`organism2` as `Text(80)`; and the embedded DDL in the 1.605 executable carries `ALTER TABLE cultures ALTER COLUMN organism3` — the same feature implemented across template, schema and embedded DDL [P11 \| analysis/BATCH-07/ini-diff-summary.md \| §3 «★ تأكيد متقاطع من طبقة SQL»; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table cultures ALTER COLUMN organism3 varchar(80)`]. |
| **Branches / decision points** | Adding a **new culture to the program** requires an **ID number between 118 and 139**, searching by that ID, pressing **«تعديل»**, filling the culture data and selecting **Group Name = CULTURE AND SENSITIVITY**, then **«حفظ»**; afterwards the operator must **copy `D:\real lab system\Data\100.ini` and rename the copy to the new culture's ID number**, then edit the culture's own report and add the required antibiotics [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «8 -3 إضافة مزرعة جديدة للبرنامج»]. This is a **file-level template derivation performed outside the application** — a design-critical fact for any re-implementation. |
| **Relevant VB6 objects** | `resultculutre`, `antibioticfrm`, `sharekat` / `sharekathesab` (referenced by the vendor guide for the culture catalogue) [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-8]. |
| **Affected entities (exact tables)** | `cultures` (+ `organism3 Text(80)`, + `condition2 Text(50)`, `organism`/`organism2` widened to `Text(80)`), `cultureanti` (`Sensitivityvalue` changed from `Double` to `Text(10)` in V2 — i.e. sensitivity became **textual**), `antibiotic` (38 rows / 25 columns), `antibio` (96 rows) [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §2.2 the column-change table; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table cultureanti ALTER COLUMN Sensitivityvalue varchar(10)`]. |
| **Permissions** | Result entry permission; the culture/antibiotic catalogue is a System-menu (administrative) action. |
| **Completion condition** | The culture result is saved; the sensitivity grid is populated. |
| **Failure paths** | A new culture without the corresponding `Data\<ID>.ini` template has **no report layout** — the template must be cloned manually. |
| **Related screens** | `resultculutre`, `antibioticfrm`, `setup1`, `setup2`, `setup3`. |

### WF-19 — Fixed comment (test comment) library (`commentsetup`, `Frmcomment`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | **«System»** → **«Test Comments»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «5 -3 إضافة / تسجيل كومنت ثابت فى تحليل معين»]; in the report, the **«Comment»** button at the bottom of the report opens a drop-down of the comments registered for that test [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «5 -3» tail]. |
| **Trigger** | Menu path (catalogue) / **«تعليق (البرتقالى)»** button (in the result window) [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 4]. |
| **User actions** | Catalogue: **«إضافة»** → choose the test → type the comment → **«حفظ»**; the comment appears at the top after saving and **more than one comment can be registered for the same test**. In the report: click the **Comment** icon at the bottom → a drop-down lists the comments registered for that test → click one and it is inserted into the patient's result report [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «5 -3»]. |
| **System responses** | Three comment sources are available in the result-entry window: **typing** directly, **picking from the saved comments** via the orange **«تعليق (البرتقالى)»** button, and **picking the comment stored in the normal-range list** by clicking the test name; there is also **an undo button for the last comment added** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 4]. |
| **Sequence of operations** | `commentsetup` (5 methods, 47 controls) → `Frmcomment` (17 methods, 23 controls) → `patienttest.commentx` (memo) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`; P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[commentx] Memo/Hyperlink (255)`]. |
| **Validation** | Comments registered in the catalogue are **per test** — a comment offered for test A is not offered for test B [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «5 -3»]. |
| **Branches / decision points** | The **low/high/critical comment** route (§5, WF-10) is a *different* mechanism from the *fixed comment* route: the former is driven by `normalrange.lowcomment` / `highcomment` and appears automatically according to the result; the latter is an explicitly picked text. Both land in the same report comment cell [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 point 3 and §6 point 4]. |
| **Relevant VB6 objects** | `commentsetup`, `Frmcomment`, `noteic` (10 methods), `result*` forms [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `comments` (12 rows), `patienttest.commentx`, `normalrange.lowcomment` / `highcomment` [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 «إضافة كومنت ثابت في تحليل معين» → `comments` (12)]. |
| **Permissions** | The comment catalogue is a System-menu action. |
| **Completion condition** | The comment is inserted into the result and saved with it. |
| **Failure paths** | Comments left in some check boxes persist in the window (the shaded-frame behaviour) — a stale comment can be carried into the next patient unless removed [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 3]. |
| **Related screens** | `commentsetup`, `Frmcomment`, `noteic`, `result*`. |

### WF-20 — Patient history (`patienthistory`, `patienthistory2`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | The **«Patient History»** button on the result profile form and on the results window; also from the search window [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 5 and §8 point 4]. |
| **Trigger** | Button click. |
| **User actions** | The history window lists the patient's tests from **previous visits**. To insert a previous result into the current result report, **double-click the test**; to produce a **separate** patient-history report, double-click the test in the history window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «13 -1 التاريخ المرضى للمريض / عمل تقرير بالتاريخ المرضى»]. |
| **System responses** | The history is inserted **automatically** into the result report when the same test was performed on a previous visit. The **sorting and grouping method of the history** is configured from the **report-settings** window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «13 -1»]. A custom history can be built for the selected patient and appended to the **tail** of the result report [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 5]. |
| **Sequence of operations** | `patienthistory` (22 methods, 50 controls) / `patienthistory2` (17 methods, 25 controls) → `history` table (dynamic, **25** columns, in the shipped V2 `bin\data.mdb`) → `patienttest.historyname` [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6 the `data.mdb` row] · [P11 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| `CREATE TABLE [history]`] · [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[historyname] Text (50)`]. |
| **Validation** | The patient is identified by **name or by lab code** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «13 -1»]. |
| **Branches / decision points** | The report-design toggle **«Print Patient History Automatically»** switches the automatic insertion on and off [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2]. A **separate** history report is an alternative to the in-report history [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 5]. |
| **Relevant VB6 objects** | `patienthistory`, `patienthistory2`, `reportsetup`, `reportsetup2`, `Reporthistory` (datareport, 1 method), `Reporthistory2` (datareport, 1 method) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `history` (25 columns in the shipped V2 `data.mdb`), `patienttest.historyname` (`Text (50)`), `patientinfo.patientid` / `labid` [P11 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| `CREATE TABLE [history]`] · [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[historyname] Text (50)`]. |
| **Permissions** | Result-report permission. |
| **Completion condition** | The history is rendered, either inside the result report or as a separate report. |
| **Failure paths** | A history report can be produced for a test group that mixes a profile with tests from another group — the vendor guide flags this explicitly as the reason for the separate-history route [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «13 -1» tail]. |
| **Related screens** | `patienthistory`, `patienthistory2`, `reportsetup`, `result*`. |

### WF-21 — Database backup, restore, zeroing and the branch data tool (`labdb`, `labdb1`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Main bar → **«اعدادات»** → **«Database Maintenance»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14 «كيف يتم عمل نسخ احتياطي لقاعدة بيانات النظام ؟» (`backup.htm`)]; vendor equivalent: `RLS ACCESS Database Tools.exe` / `RLS SQL Database Tools.exe` in `bin\` [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3 the deployment tree]. |
| **Trigger** | Button click. |
| **User actions** | **The system closes and a password dialog opens**; the base password is **`123`** and the manual recommends changing it afterwards to protect the system [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]. Large-lab edition: part 1 changes the maintenance password and exits; part 2 **zeroes all or part of the system data** by selecting the buttons in sequence; part 3 selects the database path; part 4 lists previous backups with their size (part 6) and count (part 5), each deletable by selecting it and pressing **«حذف»**; part 7 auto-fills a backup file name with **today's date**, and pressing the backup button runs the backup until the message **«Press any key to continue»** appears; press **«تحديث»** next to part 4 to make the new file appear in the list; to restore, select the backup file and press **«استرجاع»** in part 8 and wait for the restore to finish [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]. Small-lab edition: part 3 additionally allows **restoring a single patient's data by his work code** (obtained or copied from the search window when searching the backup database), and allows **cancelling patients' results and data from the main database after backing them up** (for performance) or **deleting patients permanently** by removing the selected period from both the main and the backup database [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14 second half]. |
| **System responses** | The backup file is named **`Patient_yyyymmdd.bak`** and is created **inside the same database path**; the manual recommends copying it to another medium or machine to protect against disk failure [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14 the closing notes]. |
| **Sequence of operations** | `labdb` (module, 24 methods) / `labdb1` (module, 20 methods) → `Patients.mdb`, `Patients_backup.mdb`, `Branch_Data.mdb` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | *"اخر ملف نسخ احتياطى به جميع البيانات الموجودة فى الملفات التى تحمل تاريخ سابق إلا فى حالة تصفير قاعدة البيانات ومسح بعض المعلومات من النظام"* — the latest backup holds all data except what has been explicitly zeroed [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]. |
| **Branches / decision points** | The **backup-database search** variant of the patient search can query the **main** or the **backup** database; a patient found only in the backup is copied back via the database-maintenance tools so their results can be worked on and printed [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 4]. |
| **Relevant VB6 objects** | `labdb`, `labdb1` (modules), `server`, `setup` (16 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `Patients.mdb`, `Patients_backup.mdb`, `Branch_Data.mdb`, `data.mdb` [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6 the `bin\` comparison table]. |
| **Permissions** | Maintenance password (default `123`). |
| **Completion condition** | The new `.bak` appears in the list after **«تحديث»**. |
| **Failure paths** | **The zeroing operation is destructive and irreversible with respect to the shipped backup** — the last backup contains everything *except* data zeroed after it. Growing the backup database does not slow the system, except when adding patients to it or searching inside it [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14 closing notes]. The shipped `Patients_backup.mdb` does **not** carry the additions held in the shipped `Patients.mdb`; restoring it therefore loses them [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6 the `Patients_backup.mdb` row]. |
| **Related screens** | `labdb`, `labdb1`, `server`, `setup`, `patientview`. |

### WF-22 — System settings (`setup`, `setup1`..`setup3`, report/receipt/envelope/card settings)

| Attribute | V2 fact |
|---|---|
| **Entry point** | **«اعدادات»** → **«اعدادات النظام»**; vendor equivalent: **«Setting»** icon → **«إعدادات النظام»** [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14 opening and §11 opening; P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «7 -1 تعديل إعدادات النظام الأساسية»]. |
| **Trigger** | Menu path. |
| **User actions** | Nine setting groups are documented: **1-7 report settings** · **2-7 report margins** · **3-7 paper size** · **4-7 report head/tail print options** · **5-7 edit report head/tail colours** · **6-7 dedicated printers** · **7-7 default account type** · **8-7 receipt settings (head/tail and margins)** · **9-7 envelope settings** — plus the **database-server settings** and the **barcode visibility / default account type** switches [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «7 -1…9 -7»; P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 and §14]. |
| **System responses** | **Paper size** — choose **A4** or **A5** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -7 التعدّل فى حجم الورق المستخدم فى طباعة التقرير»]; **margins** — `Page Margin` and `Report top space`, with the top margin editable up to a maximum of **8 cm** so that pre-printed paper with the lab's logo can be used [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «2 -7 ضبط هوامش التقرير»]; **head/tail** — either do not print head/tail at all (for pre-printed stationery), or print them as separate text lines with editable lab data, font size, colour and type, or print them from the **image files bundled with the program** (head and tail images chosen from the local machine), then **«حفظ الإعدادات»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «4 -7»]; **printers** — one printer can be selected for each of **report, barcode, receipt, envelope, card** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «6 -7 ضبط الطابعات المخصصة للطباعة»]; **default account type** — the account type the system applies by default for prices, discounts, commissions and out-of-lab samples [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «7 -7»]; **receipt settings** — top margin for pre-printed paper, currency type, result-expected time, print-once-only control, and whether NATIGH-site data is shown on the receipt [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «8 -7 إعدادات الإيصال»]. |
| **Sequence of operations** | `setup` (16 methods) → `setup1` (56) · `setup2` (58) · `setup3` (42) → `bin\SETING.ini` · `bin\IDCARD.INI` · `bin\BASE.ini` · `bin\NOTE.ini` [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Validation** | The settings window is where the **per-profile printer** is chosen from `Data\*.ini` (`setupx.reportprinterx`), while the **global printer roles** live in `SETING.ini` (`[selectprinter] reportprinter / barcodeprinter / zarfprinter / waslprinter / IDprinter`) [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 the six printer roles; P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 rows 6-3…6-7]. |
| **Branches / decision points** | The **per-report** design window (§11) and the **global** settings window are two different scopes: the former changes one report on one machine, the latter changes the system on one machine [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 the two scope notes]. |
| **Relevant VB6 objects** | `setup`, `setup1`, `setup2`, `setup3`, `reportsetup`, `reportsetup2`, `server`, `CardFrmSetx` (22 methods), `Frmac` (26 methods), `z_titles` (15), `z_units` (14) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `bin\SETING.ini` (**4,886 bytes**), `bin\IDCARD.INI`, `bin\BASE.ini` (381 bytes), `bin\NOTE.ini` (76 bytes) [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §3, §4 and §5]. |
| **Permissions** | Administrative. |
| **Completion condition** | **«حفظ الإعدادات»** / **«حفظ الاعدادات»**. |
| **Failure paths** | The V2 `bin\BASE.ini` **[lastlog]** section records the last **ten** connection attempts as `date##engine##machine##lab-id##user##password` with the password in **clear text** (`12345678`) and the real machine name (`SPRT007-PC`) — so a settings change can leak credentials into a shipped configuration file [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §3 «F-09 — سجلّ محاولات الاتصال يكتب كلمة المرور نصًّا»]. |
| **Related screens** | `setup`, `setup1`, `setup2`, `setup3`, `server`, `CardFrmSetx`, `Frmac`. |

### WF-23 — Result delivery through NATIGH.COM (electronic result portal)

| Attribute | V2 fact |
|---|---|
| **Entry point** | The **NATIGH.COM** icon in the patient window (phone field → NATIGH icon), or the customer-account creation route **«System»** → **«الجهات الخارجية والمعامل»** → **«إضافة»** → entity type → **«ID»** button [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1 تسليم نتائج المريض عن طريق موقع نتتيجة ( NATIGH.COM )»]. |
| **Trigger** | Icon click / menu path. |
| **User actions** | Register the patient, **enter the mobile/phone number** in its dedicated field (or press the NATIGH icon), enter the tests and the results as usual, then open the upload tool, select the patient and press **«Upload»**. The patient (or the doctor / the lab) then visits `WWW.NATIGH.COM`, signs in — account type **Patient**, **Doctor** or **Laboratory**; a patient may enter the lab code plus phone number, or the password directly; a doctor or a lab enters **lab code + ID + password** — and presses **«Sign In»** to reach the lab's reception page, then the **«Result»** icon to view the result, which can be printed or exported as **Word / PDF** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1»]. The administrator side counts uploaded patients for a period and can **«Block»** a patient's result [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1» tail]. |
| **System responses** | Pressing **«ID»** in the external-entity window makes the program **generate a unique ID** for the doctor or the lab; the same number is written into the password field, then **«حفظ»** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «11 -3»]. The **patient-history** feature has a V2 flag `patienttest.natighu` (Bit / YESNO) added by the embedded DDL — the per-test record of whether the result has been pushed to the portal [P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table patienttest ADD NatighU Bit`; P11 \| analysis/BATCH-04/schema/column-evolution.csv \| `patienttest … added_in_v2019: natighu`]. |
| **Sequence of operations** | Patient data → `patientinfo.SMSMob` / `PatRPW` (V2 columns) → `SMSSender` / `SMStemplate` / `smsgroups` / `smslist` (four tables shipped with the 2019 payload) → portal [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §2.1 the ten tables]. |
| **Validation** | The mobile number is mandatory for the upload route; the account type determines which credentials are required [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1»]. |
| **Branches / decision points** | Three account kinds — Patient / Doctor / Laboratory — with three different authentication flows; a **Contract** patient type is used when a lab-to-lab referrer is set, so that the referring lab sees the results of the samples it sent [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «11 -3»]. |
| **Relevant VB6 objects** | `SMSfrmsenderos` (form, **139 methods**, 186 controls), `patientmain`, `addpatient`, `z_gehats` (56), `phone` (33), `Frmac` (26 methods) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `SMSSender` (carries `username varchar(50)`), `SMStemplate`, `smsgroups`, `smslist` (carries `send Smallint`), `patienttest.natighu`, `patientinfo.SMSMob`, `patientinfo.PatRPW`, `useraccounts` (carries `HDD1`, `HDD2`, `Gtype`) [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §2.1; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt]. |
| **Permissions** | The SMS sender is a separate form with its own 139 procedures; the `smsgroups`/`smslist` tables define recipient groups and recipients. |
| **Completion condition** | `patienttest.natighu` set for the uploaded test; the result is visible on the portal. |
| **Failure paths** | The portal is a **third-party service** (`NATIGH.COM`, with an Android app `com.natighweb.app`) — the workflow's completion depends on an external system that is **outside the archive** [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1»]. The portal's own publication URL and privacy handling are therefore **NOT RECOVERABLE** from this evidence set. |
| **Related screens** | `SMSfrmsenderos`, `phone`, `Frmac`, `patientmain`, `addpatient`. |

### WF-24 — Sample separation and pulling (`Patient_samples`)

| Attribute | V2 fact |
|---|---|
| **Entry point** | Vendor guide: **«Laboratory»** icon → **«سحب وفصل العينات»** (pull and separate samples) [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «فصل وسحب العينات»]. |
| **Trigger** | Icon → button. |
| **User actions** | Choose the patient from the patient list on the right of the window → the samples to be pulled for that patient appear → **click the sample** to record it as a drawn sample → it is listed at the bottom of the window [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «فصل وسحب العينات»]. |
| **System responses** | The screen lets the person responsible for sample drawing know which samples have already been drawn for each patient [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «فصل وسحب العينات» tail]. |
| **Sequence of operations** | `Patient_samples` (form, **89 methods**, 101 controls) → `cultures` / `sample` entities [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 the out-of-index row «فصل وسحب العينات (أيقونة Laboratory)» → `cultures` · `cultureanti` · `sample`]. |
| **Validation** | **NOT RECOVERABLE** — the exact meaning of `Patient_samples` is an open question in the archive's open-question register (`V-04`, a **documentation-only** archive label: *"ما Patient_samples بالضبط — تتبّع عينات أم مستودع عينات؟"*) [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-04]. The vendor guide's behaviour above is the best available constraint. |
| **Branches / decision points** | Not documented beyond the click-to-record flow. |
| **Relevant VB6 objects** | `Patient_samples`, `cultures`-related forms (`resultculutre`), `barcode` (label material per sample) [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | **NOT RECOVERABLE** — the table backing `Patient_samples` is not identified in the schema evidence. |
| **Permissions** | Laboratory-area action. |
| **Completion condition** | The sample is recorded as drawn. |
| **Failure paths** | Not documented. |
| **Related screens** | `Patient_samples`, `barcode`, `resultculutre`. |

### WF-25 — PDF output via the external print driver

| Attribute | V2 fact |
|---|---|
| **Entry point** | Any print action in the application. The PDF route is not a separate menu — it is the **Windows printer driver** behind the report printer role. |
| **Trigger** | Print / print-preview on a report. |
| **User actions** | *(none inside the application — the application does not generate the PDF)*. |
| **System responses** | The application hands its report to the Windows print spooler; the driver named **`Bullzip PDF Printer`** produces the file; the driver writes into one of four category folders. |
| **Sequence of operations** | `real lab system.exe` (FileVersion 1.605) → literal `Bullzip PDF Printer` (DeviceName) → `EnumPrintersA` / `SetDefaultPrinterA` → Bullzip port driver `cf/Bullzip/PDF Printer/Ports/BULLZIP/bzpdf.dll` → embedded Ghostscript (`app/gs/`) → `D:\PDF\<category>\` [P11 \| pdf-print-stack.md \| §2.1 the hard-coded printer name; P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §1 the full path]. |
| **Validation** | The device name is **hard-coded as a literal** at offset `0x6A2486`, and the default output name is hard-coded at `0x6A255E` as **`Bullzip PDF Printer 11.1 - Create File`** [P11 \| pdf-print-stack.md \| §2.1 the offset table]. |
| **Branches / decision points** | Four output categories: `Contracts` → `D:\PDF\Contracts\`, `Free` → `D:\PDF\Free\`, `Individual` → `D:\PDF\Individual\`, `Lab To Lab` (stored `LabToLab`) → `D:\PDF\LabToLab\` [P11 \| pdf-print-stack.md \| §2.2 the output tree]. |
| **Relevant VB6 objects** | `printerselect` (module, **11 methods**), with the functions `selectprinter` and `check_onePrinter` [P11 \| pdf-print-stack.md \| §2.4 the six printer roles; P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| `# 210 objects`]. |
| **Affected entities (exact tables)** | `patienttest.resultprint` · `printuser` · `printdate` · `printnum` (print audit) — **no SQL is involved in the PDF path** [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §5 transition 6]. |
| **Permissions** | The print audit binds every printed result to an individual user and a sequential counter [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4 «سجلّ تدقيق طباعة»]. |
| **Completion condition** | The PDF file exists under `D:\PDF\<category>\`. |
| **Failure paths** | If `Bullzip PDF Printer` is not installed **under that exact name**, the PDF path fails; if Bullzip is re-installed at version 12/13/… the hard-coded default output name `… 11.1 - Create File` no longer matches [P11 \| pdf-print-stack.md \| §2.1 the four VERIFIED FACT bullets]. |
| **Related screens** | `printerselect`, `setup`, `reportsetup`, `result*`. |

### WF-26 — Installation, licensing and deployment from the 2019 CD

| Attribute | V2 fact |
|---|---|
| **Entry point** | CD root → `RL_SETUP.exe` (**FileVersion 19.00**, `ProductName: RealLab CD`, built 2020-09-01) [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1 the installer identity]. |
| **Trigger** | Double-click `RL_SETUP` (or the vendor guide's `RL_SETUP` on the CD) [P11 \| analysis/BATCH-05/manuals/RLS_Setup.txt \| «تثبيت برنامج لاير الب سيستم»]. |
| **User actions** | The installer shows the EULA and the licence, then the operator chooses: **option 1** = the application, **option 3** = Microsoft SQL Server [P11 \| analysis/BATCH-05/manuals/RLS_Setup.txt \| «نقوم بالضغط على الاختيار الأول» / «نقوم بالضغط على العنصر الثالث ( ميكروسوفت سيكول سيرفر )»]; the database type is then chosen between **Microsoft Access database** (`Microsoft.JET.OLEDB.4.0`, `D:\real lab system\bin\Patients.mdb`) and **Microsoft SQL server database** (`MS SQL Server 2005`, `D:\Lab_data\Patients.mdf`), plus **MySQL** via `Setup5.bat` [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2 the database choice; P11 \| analysis/V-CD-2019/05-deployment.md \| §2 the three engines]. |
| **System responses** | The installer copies the deployment payload to `D:\real lab system\`, then runs `System\Setup1..5.bat` + `SetupPZ.bat` + `System\PDF\SetupP.bat` + `XCOPY` + the two target-specific `setup.exe` bootstraps, and finally `D:\Lab_data\Attach_Patients.bat`, `Attach_Interface.bat` and `Attach_VIDAS.bat` [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3.1 the extracted commands]. |
| **Sequence of operations** | `RL_SETUP.exe` (57 objects / 599 procedures) → `System\Setup1.bat` (Windows Installer 3.1) → `Setup2.bat` (MSXML 6.0) → `Setup3.bat` (.NET Framework 2.0) → `Setup4.bat` (SQL Server Express 2005, `SAPWD=12345678`, `DISABLENETWORKPROTOCOLS=0`) → `Setup5.bat` (MySQL Connector ODBC 3.51) → `SetupPZ.bat` (.NET 4 **then** Bullzip) → `System\PDF\SetupP.bat` (Bullzip only) → `XCOPY` → `WIN7\setup.exe` / `WINXP\setup.exe` → `Attach_*.bat` [P11 \| analysis/V-CD-2019/05-deployment.md \| §1 the script table; P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3.1]. |
| **Validation** | **Licensing is hardware-bound** — `Hardware\Description\System` (WMI fingerprint), `Choose your systems (licensed only)`, and the clause *"If the computer hard disk, Mother board and CPU damage or lost the RealLab not responsible and you will purchased the other license for the SOFTWARE."* The application itself reads `Select * from Win32_Processor` [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 the licensing section]. The machine fingerprint is read with `RealLab_Show_Info.exe` (on Windows 7: *Run as administrator*) [P11 \| analysis/BATCH-05/manuals/RLS_Setup.txt \| «كيفية الحصول على سيلاير الجهاز»]. |
| **Branches / decision points** | **Database-conversion warning** — the installer states: *"If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD."* — converting does **not** move the data [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2 the conversion note]. |
| **Relevant VB6 objects** | The installer's own object model: `Form1` (43 methods) · `Form2` (10) · `frm_start` (2) · `Frm_rls1`…`Frm_rls8` (5–17 methods, **8 steps**) · `Frm_rlsAr1`…`Frm_rlsAr8` (the same steps in Arabic) · `Frm_rli1`…`Frm_rli7` + `Frm_rliAr1`…`Frm_rliAr7` (7 licence/setup steps) · `Frm_mssql1`…`Frm_mssql4` + Arabic variants (4 steps) · `Frm_repair0`…`Frm_repair5` (the **Repair Installed Software** path) · `Frm_help1`…`Frm_help4` · `FontInstaller` (38) · `RegistryInteraction` (7) · `Module1` (14) · `modFonts` (12) · `boisais` (16) · `aaaClass` (15) · `BiosData` (8) [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1.1 the object-structure table]. |
| **Affected entities (exact tables)** | `Patients.mdb` (Access) / `Patients.mdf` + `Interface.mdf` + `VIDAS` (SQL Server); `Branch_Data.mdb` as the per-branch schema template; `SYSTEM`/`Interface` as a **separate database from the patient data** [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1 the two SQL-Server databases]. |
| **Permissions** | The install writes to `System32`/`SysWOW64` and **self-registers the components declared `$(DLLSelfRegister)` in the manifest** — 24 in the `[Setup1 Files]` phase and 3 more in the `[Bootstrap Files]` phase, **27 declared manifest-wide** — plus `$(TLBRegister)` on `STDOLE2.TLB` → 1; this requires administrator rights and is not declared by the product [P11 | analysis/V-CD-2019/12-install-media.md | §2.2 the executable actions]. [SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Bootstrap Files] and [Setup1 Files] sections] |
| **Completion condition** | The application is installed at `C:\Program Files\real lab system` (`SETUP.LST` `DefaultDir=$(ProgramFiles)\real lab system`) with the data at `D:\real lab system\` / `D:\Lab_data\` [P11 \| analysis/V-CD-2019/12-install-media.md \| §2.3 the install path]. |
| **Failure paths** | **(a) Install-chain defect** — `RL_SETUP.exe` invokes `System\PDF\SetupP.bat` **before** `System\SetupPZ.bat`; `SetupP.bat` installs Bullzip **before** .NET 4 exists, but Bullzip 11 requires .NET 4 ⇒ **a first failing attempt followed by a successful retry**. `System\PDF\SetupFN4.bat` is referenced by nobody and carries a **broken relative path** (`dotNetFx40_…exe` without `System/PDF/`) [P11 \| pdf-print-stack.md \| §5.1 the install-chain defect]. **(b) No waiting on the Microsoft bootstraps** — `cmd.exe /C start /B WIN7\setup.exe /sc:\setup.log` and the same for WINXP use `start /B` **without `/wait`**, so the operator may start the application before the ActiveX and font installation has finished; the setup log is also written to the **root of the disk** as `C:\setup.log` (no `\` after `C:`) [P11 \| pdf-print-stack.md \| §5.2 the setup-log side effect]. **(c) Two conflicting runtime builds** — the CAB and the `OCX\` folder ship *different* builds of the same components (16 of 48 files differ), so the final installed state depends on the copy order [P11 \| analysis/V-CD-2019/12-install-media.md \| §4.1 the CAB-vs-OCX mismatch]. |
| **Related screens** | `RL_SETUP.exe` wizard forms; `real lab system.exe`; `real lab system help.chm`. |

### 1.21 — The verified patient-lifecycle workflow (documentation-only label `WF-LIFECYCLE`)

The end-to-end patient lifecycle of **RefLab Version 2 (V2)** is **VERIFIED** as an eight-step sequence; each step is the subject of a dedicated workflow section above.

| # | Step | Workflow section | Principal screen(s) |
|---:|---|---|---|
| 1 | log in | WF-01 | `login` → `labmain` |
| 2 | add / edit the patient | WF-02 | `patientmain` → `addpatient` |
| 3 | print barcode and labels | WF-04 | `barcode` → `barcodeform` |
| 4 | order the tests | WF-03 | `addpatient` (test list) |
| 5 | enter the result | WF-05 | `result*` profile forms |
| 6 | review the result | WF-05 / WF-06 | `patientmain` / `result*` |
| 7 | print the report | WF-06 | `reportsetup` → printer role → spooler |
| 8 | deliver the result and settle the account | WF-07 | `frm_money` → `moneypaid` |

Three further branches attach to the same lifecycle: **sample separation and pulling** (WF-24, `Patient_samples`), the **electronic result portal** upload (WF-23, with the per-test flag `patienttest.natighu`) and the **patient-history** route (WF-20).

---
## 2. Screen inventory (V2 — `real lab system.exe` FileVersion 1.605)

**Object-model totals (VERIFIED).** `Real_lab_system` declares **210 objects** with **8,026 methods**: **132 forms**, **66 DataReports**, **9 modules**, **3 classes** [P11 | analysis/BATCH-04/vb6/v1605/objects.json | `stats`: objects 210 / methods 8026, and the `objects` array]. Control counts are recovered for **131 of the 132 forms** — `forms-blob.txt` lists **11,622 controls** in total; the single form without a control blob is `labxxyyzz` (3 methods) [P11 | analysis/BATCH-04/vb6/v1605/forms-blob.txt | `# 131 forms from form-data blobs` and the `name,controls,width,height` table].

**Provenance column.** Every row of the forms, modules and classes tables is taken from the decompilation of `real lab system.exe` (FileVersion 1.605) in patch BATCH-04: the object name and the method count from `objects.json` / `objects-full.txt`, the control count from `forms-blob.txt`.

**Capability column.** `CAP-01`…`CAP-15` are **documentation-only** labels for the 15 documented capabilities of the embedded CHM manual [P11 | analysis/V-CD-2019/03-capabilities.md | §1 the documented-capability table]. The `1-x`…`9-x` codes are the section numbers of the vendor Guide Book's 7 functional units [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2 the seven units]. The `Domain` column is an editorial classification of this document.

### 2.1 Forms — complete table (132 rows)

| # | VB6 form name | Methods | Controls | Domain | Entry capability | Provenance |
| 1 | `resultIgeAllergy` | 231 | 178 | Result entry | CAP-04 · IgE allergy | BATCH-04 decompilation |
| 2 | `Resultsemen` | 222 | 266 | Result entry | CAP-04 · semen profile | BATCH-04 decompilation |
| 3 | `Resultsemen5` | 216 | 231 | Result entry | CAP-04 · semen profile v5 | BATCH-04 decompilation |
| 4 | `addpatient` | 192 | 230 | Patient domain | CAP-02 · add / edit patient | BATCH-04 decompilation |
| 5 | `resulthepatitis` | 187 | 199 | Result entry | CAP-04 · hepatitis profile | BATCH-04 decompilation |
| 6 | `ResulturineAuto` | 184 | 195 | Result entry | CAP-04 · automated urine | BATCH-04 decompilation |
| 7 | `resultTrace` | 183 | 213 | Result entry | CAP-04 · trace elements | BATCH-04 decompilation |
| 8 | `resultcbc` | 172 | 245 | Result entry | CAP-04 · CBC profile | BATCH-04 decompilation |
| 9 | `Resulturine` | 167 | 154 | Result entry | CAP-04 · urine profile | BATCH-04 decompilation |
| 10 | `resultselectro` | 144 | 181 | Result entry | CAP-04 · selected profile | BATCH-04 decompilation |
| 11 | `resultcrossm` | 140 | 142 | Result entry | CAP-04 · crossmatch | BATCH-04 decompilation |
| 12 | `Resultstool` | 139 | 144 | Result entry | CAP-04 · stool profile | BATCH-04 decompilation |
| 13 | `SMSfrmsenderos` | 139 | 186 | Patient domain | 1-12 · NATIGH/SMS result delivery | BATCH-04 decompilation |
| 14 | `resultimmun` | 138 | 171 | Result entry | CAP-04 · immunology profile | BATCH-04 decompilation |
| 15 | `ResultFertlity` | 125 | 157 | Result entry | CAP-04 · fertility profile | BATCH-04 decompilation |
| 16 | `ResultTORCH` | 123 | 122 | Result entry | CAP-04 · TORCH profile | BATCH-04 decompilation |
| 17 | `ResultSuprarenal` | 117 | 150 | Result entry | CAP-04 · suprarenal profile | BATCH-04 decompilation |
| 18 | `Resultkidney` | 117 | 155 | Result entry | CAP-04 · kidney profile | BATCH-04 decompilation |
| 19 | `resulthormon` | 116 | 151 | Result entry | CAP-04 · hormones | BATCH-04 decompilation |
| 20 | `resultculutre` | 115 | 149 | Result entry | CAP-04 · culture & sensitivity | BATCH-04 decompilation |
| 21 | `reportsetup` | 113 | 150 | Report & layout design | CAP-09 · report design (item layout) | BATCH-04 decompilation |
| 22 | `resultprostata` | 113 | 148 | Result entry | CAP-04 · prostate profile | BATCH-04 decompilation |
| 23 | `resultVitamins` | 110 | 143 | Result entry | CAP-04 · vitamins | BATCH-04 decompilation |
| 24 | `resultpt` | 110 | 153 | Result entry | CAP-04 · prothrombin time | BATCH-04 decompilation |
| 25 | `Resultliver` | 101 | 138 | Result entry | CAP-04 · liver profile | BATCH-04 decompilation |
| 26 | `resultTumors` | 100 | 131 | Result entry | CAP-04 · tumour markers | BATCH-04 decompilation |
| 27 | `resultdrugs` | 98 | 131 | Result entry | CAP-04 · drugs/toxicology | BATCH-04 decompilation |
| 28 | `resultcrp` | 97 | 116 | Result entry | CAP-04 · CRP profile | BATCH-04 decompilation |
| 29 | `resultretios` | 97 | 129 | Result entry | CAP-04 · reticulocytes | BATCH-04 decompilation |
| 30 | `resultabuse` | 95 | 106 | Result entry | CAP-04 · abuse/toxicology | BATCH-04 decompilation |
| 31 | `ResultInsulin` | 92 | 124 | Result entry | CAP-04 · insulin profile | BATCH-04 decompilation |
| 32 | `Patient_samples` | 89 | 101 | Patient domain | 6-x · sample separation & pulling | BATCH-04 decompilation |
| 33 | `patientmain` | 84 | 163 | Patient domain | CAP-02 / CAP-04 / CAP-05 · patient hub | BATCH-04 decompilation |
| 34 | `resultcsf` | 83 | 121 | Result entry | CAP-04 · CSF profile | BATCH-04 decompilation |
| 35 | `resulthpylori` | 83 | 94 | Result entry | CAP-04 · H. pylori | BATCH-04 decompilation |
| 36 | `Resultlipids` | 81 | 117 | Result entry | CAP-04 · lipids profile | BATCH-04 decompilation |
| 37 | `resultbloodgas` | 81 | 134 | Result entry | CAP-04 · blood gases | BATCH-04 decompilation |
| 38 | `resultrenal` | 80 | 110 | Result entry | CAP-04 · renal profile | BATCH-04 decompilation |
| 39 | `resultcoagfactor` | 79 | 112 | Result entry | CAP-04 · coagulation factors | BATCH-04 decompilation |
| 40 | `resultsugacurve` | 78 | 133 | Result entry | CAP-04 · glucose curve | BATCH-04 decompilation |
| 41 | `barcode` | 76 | 55 | Patient domain | CAP-03 · barcode & labels | BATCH-04 decompilation |
| 42 | `resultImmunoglob` | 72 | 103 | Result entry | CAP-04 · immunoglobulins | BATCH-04 decompilation |
| 43 | `resultstone` | 72 | 100 | Result entry | CAP-04 · stone profile | BATCH-04 decompilation |
| 44 | `labmain` | 71 | 183 | Shell / session hub | CAP-01 · main window | BATCH-04 decompilation |
| 45 | `reportsetup2` | 69 | 117 | Report & layout design | CAP-09 · report design (head/tail) | BATCH-04 decompilation |
| 46 | `resultcardiac` | 66 | 96 | Result entry | CAP-04 · cardiac profile | BATCH-04 decompilation |
| 47 | `Resultbilharzias` | 64 | 92 | Result entry | CAP-04 · bilharzia profile | BATCH-04 decompilation |
| 48 | `resultmarrow` | 64 | 110 | Result entry | CAP-04 · bone marrow | BATCH-04 decompilation |
| 49 | `resultiron` | 62 | 96 | Result entry | CAP-04 · iron profile | BATCH-04 decompilation |
| 50 | `Resultsugar` | 61 | 99 | Result entry | CAP-04 · sugar profile | BATCH-04 decompilation |
| 51 | `resultprotelec` | 61 | 98 | Result entry | CAP-04 · protein electrophoresis | BATCH-04 decompilation |
| 52 | `resultpostcoital` | 60 | 86 | Result entry | CAP-04 · post-coital test | BATCH-04 decompilation |
| 53 | `patient` | 58 | 73 | Patient domain | CAP-02 · patient data | BATCH-04 decompilation |
| 54 | `setup2` | 58 | 98 | Settings | CAP-07 · test data | BATCH-04 decompilation |
| 55 | `users` | 57 | 83 | Shell / session hub | CAP-01 · user & permission admin | BATCH-04 decompilation |
| 56 | `setup1` | 56 | 99 | Settings | CAP-07 · test data | BATCH-04 decompilation |
| 57 | `z_gehats` | 56 | 67 | Reference data | CAP-07 · referring entities / labs | BATCH-04 decompilation |
| 58 | `Frm_pic` | 55 | 49 | Patient domain | CAP-02 · patient pictures | BATCH-04 decompilation |
| 59 | `resulthgbelec` | 51 | 85 | Result entry | CAP-04 · Hb electrophoresis | BATCH-04 decompilation |
| 60 | `resultwidal2` | 51 | 105 | Result entry | CAP-04 · Widal profile (secondary) | BATCH-04 decompilation |
| 61 | `ResultFMF` | 48 | 105 | Result entry | CAP-04 · familial Mediterranean fever | BATCH-04 decompilation |
| 62 | `resultABO` | 47 | 77 | Result entry | CAP-04 · ABO profile | BATCH-04 decompilation |
| 63 | `Resultpregnancy` | 44 | 70 | Result entry | CAP-04 · pregnancy profile | BATCH-04 decompilation |
| 64 | `setup3` | 42 | 142 | Settings | CAP-07 · test data | BATCH-04 decompilation |
| 65 | `abbrevi` | 41 | 50 | Reference & clinical rules | CAP-07 · abbreviations | BATCH-04 decompilation |
| 66 | `resultwidal` | 41 | 85 | Result entry | CAP-04 · Widal profile | BATCH-04 decompilation |
| 67 | `tqrermog` | 41 | 58 | Result entry | CAP-04 · mixed profile | BATCH-04 decompilation |
| 68 | `resultha1c` | 39 | 68 | Result entry | CAP-04 · HbA1c | BATCH-04 decompilation |
| 69 | `frm_money` | 38 | 101 | Accounting & outbound | CAP-05 · handover & settlement | BATCH-04 decompilation |
| 70 | `ResultPCR` | 37 | 94 | Result entry | CAP-04 · PCR profile | BATCH-04 decompilation |
| 71 | `normal_test` | 36 | 25 | Reference & clinical rules | CAP-08 · normal ranges | BATCH-04 decompilation |
| 72 | `resultzn` | 36 | 79 | Result entry | CAP-04 · zinc profile | BATCH-04 decompilation |
| 73 | `patientview` | 33 | 63 | Patient domain | CAP-06 · patient search | BATCH-04 decompilation |
| 74 | `phone` | 33 | 59 | Patient domain | CAP-06 · phone / mobile search | BATCH-04 decompilation |
| 75 | `resultLBC` | 33 | 52 | Result entry | CAP-04 · LBC profile | BATCH-04 decompilation |
| 76 | `resultanytest` | 33 | 72 | Result entry | CAP-04 · generic profile | BATCH-04 decompilation |
| 77 | `ResultESR` | 32 | 66 | Result entry | CAP-04 · ESR profile | BATCH-04 decompilation |
| 78 | `labtolab` | 32 | 56 | Accounting & outbound | CAP-10 · lab-to-lab | BATCH-04 decompilation |
| 79 | `resultTUBERCULIN` | 32 | 56 | Result entry | CAP-04 · tuberculin | BATCH-04 decompilation |
| 80 | `Frm_pic2` | 31 | 38 | Patient domain | CAP-02 · patient pictures (secondary) | BATCH-04 decompilation |
| 81 | `z_customgroup` | 31 | 37 | Reference data | CAP-07 · custom test groups | BATCH-04 decompilation |
| 82 | `static1` | 30 | 92 | Report & layout design | CAP-09 · static layout editor 1 | BATCH-04 decompilation |
| 83 | `testmain` | 30 | 75 | Report & layout design | CAP-07 · test list window | BATCH-04 decompilation |
| 84 | `antibioticfrm` | 29 | 52 | Reference & clinical rules | CAP-07 · culture antibiotics | BATCH-04 decompilation |
| 85 | `instrument` | 29 | 83 | Reference & clinical rules | CAP-07 · instruments | BATCH-04 decompilation |
| 86 | `moenymozafeen` | 27 | 58 | Accounting & outbound | CAP-11 · referring-doctor account | BATCH-04 decompilation |
| 87 | `moenysharekat` | 27 | 58 | Accounting & outbound | CAP-10 · outbound settlement | BATCH-04 decompilation |
| 88 | `qcfrm` | 27 | 38 | Reference & clinical rules | CAP-13 · QC / constants | BATCH-04 decompilation |
| 89 | `z_pricelists` | 27 | 28 | Reference data | CAP-07 · price lists | BATCH-04 decompilation |
| 90 | `Frmac` | 26 | 46 | Patient domain | CAP-02 · account card | BATCH-04 decompilation |
| 91 | `sarfz` | 26 | 35 | Accounting & outbound | CAP-10 · outbound samples | BATCH-04 decompilation |
| 92 | `static2` | 26 | 87 | Report & layout design | CAP-09 · static layout editor 2 | BATCH-04 decompilation |
| 93 | `static6` | 24 | 87 | Report & layout design | CAP-09 · static layout editor 6 | BATCH-04 decompilation |
| 94 | `CardFrmSetx` | 22 | 29 | Patient domain | CAP-03 · card setup | BATCH-04 decompilation |
| 95 | `patienthistory` | 22 | 50 | Patient domain | CAP-02 · patient history | BATCH-04 decompilation |
| 96 | `static5` | 21 | 60 | Report & layout design | CAP-09 · static layout editor 5 | BATCH-04 decompilation |
| 97 | `moneypaid` | 18 | 23 | Accounting & outbound | CAP-05 · payment entry | BATCH-04 decompilation |
| 98 | `static4` | 18 | 77 | Report & layout design | CAP-09 · static layout editor 4 | BATCH-04 decompilation |
| 99 | `workpaper2` | 18 | 40 | Print & documents | 2-2 · work sheet (tests) | BATCH-04 decompilation |
| 100 | `z_labaccount` | 18 | 32 | Accounting & outbound | CAP-11 · lab account | BATCH-04 decompilation |
| 101 | `Frmcomment` | 17 | 23 | Reference & clinical rules | CAP-07 · comment picker | BATCH-04 decompilation |
| 102 | `patienthistory2` | 17 | 25 | Patient domain | CAP-02 · patient history (secondary) | BATCH-04 decompilation |
| 103 | `server` | 17 | 27 | Shell / session hub | CAP-01 · server settings | BATCH-04 decompilation |
| 104 | `testrange` | 17 | 50 | Reference & clinical rules | CAP-08 · range browser | BATCH-04 decompilation |
| 105 | `workpaper` | 17 | 36 | Print & documents | 2-1 · work sheet (patients) | BATCH-04 decompilation |
| 106 | `anyreport` | 16 | 80 | Report & layout design | CAP-09 · combined / empty report | BATCH-04 decompilation |
| 107 | `setup` | 16 | 63 | Settings | CAP-01 · system settings | BATCH-04 decompilation |
| 108 | `shoppingfrm` | 15 | 27 | Reference data | CAP-07 · price-list shopping | BATCH-04 decompilation |
| 109 | `static3` | 15 | 72 | Report & layout design | CAP-09 · static layout editor 3 | BATCH-04 decompilation |
| 110 | `z_titles` | 15 | 27 | Reference data | CAP-07 · titles | BATCH-04 decompilation |
| 111 | `converter` | 14 | 24 | Reference & clinical rules | CAP-07 · unit conversion | BATCH-04 decompilation |
| 112 | `z_barcodes` | 14 | 22 | Reference data | CAP-03 · barcode reference data | BATCH-04 decompilation |
| 113 | `z_branchs` | 14 | 21 | Reference data | CAP-07 · branches | BATCH-04 decompilation |
| 114 | `z_group` | 14 | 21 | Reference data | CAP-07 · test groups | BATCH-04 decompilation |
| 115 | `z_logs` | 14 | 21 | Reference data | CAP-07 · log groups | BATCH-04 decompilation |
| 116 | `z_units` | 14 | 21 | Reference data | CAP-07 · unit dictionary | BATCH-04 decompilation |
| 117 | `login` | 13 | 8 | Shell / session hub | CAP-01 | BATCH-04 decompilation |
| 118 | `userspw` | 12 | 15 | Shell / session hub | CAP-01 · user password | BATCH-04 decompilation |
| 119 | `outtest` | 11 | 39 | Reference & clinical rules | CAP-08 · range export | BATCH-04 decompilation |
| 120 | `noteic` | 10 | 21 | Patient domain | CAP-02 · patient notes | BATCH-04 decompilation |
| 121 | `start` | 10 | 14 | Shell / session hub | CAP-01 | BATCH-04 decompilation |
| 122 | `labmainTools` | 6 | 13 | Shell / session hub | CAP-01 · main-window tools | BATCH-04 decompilation |
| 123 | `learntest` | 6 | 19 | Reference & clinical rules | CAP-07 · test learning sheet | BATCH-04 decompilation |
| 124 | `logindete` | 6 | 12 | Shell / session hub | CAP-01 | BATCH-04 decompilation |
| 125 | `commentsetup` | 5 | 47 | Reference & clinical rules | CAP-07 · fixed test comments | BATCH-04 decompilation |
| 126 | `frmTip` | 5 | 10 | Shell / session hub | CAP-15 · daily tip | BATCH-04 decompilation |
| 127 | `labxxyyzz` | 3 | — | Shell / session hub | — (no CHM counterpart) | BATCH-04 decompilation |
| 128 | `calctest` | 2 | 6 | Reference & clinical rules | CAP-13 · calculation helper | BATCH-04 decompilation |
| 129 | `tools` | 1 | 266 | Master data | CAP-07 · test catalogue shell | BATCH-04 decompilation |
| 130 | `CardFrm` | 0 | 3 | Patient domain | CAP-03 · patient card | BATCH-04 decompilation |
| 131 | `ais` | 0 | 11 | Shell / session hub | — (no CHM counterpart) | BATCH-04 decompilation |
| 132 | `barcodeform` | 0 | 8 | Patient domain | CAP-03 · barcode shell | BATCH-04 decompilation |

### 2.2 Modules (9) and classes (3)

| Object | Type | Methods | Role | Provenance |
|---|---|---:|---|---|
| `labfunction` | module | 25 | Accounting / stocktaking engine; drives the F7 monthly accounts-and-grading window | BATCH-04 decompilation |
| `labdb` | module | 24 | Database maintenance: backup / restore / zeroing of the patient database | BATCH-04 decompilation |
| `labdb1` | module | 20 | Secondary database-maintenance library (backup-DB search, per-patient restore) | BATCH-04 decompilation |
| `boisais` | module | 16 | Vendor sub-module (shared with the installer) | BATCH-04 decompilation |
| `mInputbox` | module | 12 | Custom input box used by dialogs | BATCH-04 decompilation |
| `printerselect` | module | 11 | Printer selection: `selectprinter`, `check_onePrinter`; backs the six printer roles | BATCH-04 decompilation |
| `saveIOtemp` | module | 10 | Temporary persistence of in-progress inputs | BATCH-04 decompilation |
| `BCWFonts` | module | 7 | Black-and-white conversion of report fonts (the «أبيض واسود» button) | BATCH-04 decompilation |
| `otherfun` | module | 2 | Small helper functions | BATCH-04 decompilation |
| `CRect` | class | 20 | Rectangle / geometry helper (used by the layout editors) | BATCH-04 decompilation |
| `aaaClass` | class | 15 | General helper class (also present in `RL_SETUP.exe`) | BATCH-04 decompilation |
| `BiosData` | class | 8 | Biometrics carrier (used by the hardware-bound licensing check) | BATCH-04 decompilation |

[All module/class rows: P11 | analysis/BATCH-04/vb6/v1605/objects-full.txt | `# 210 objects`.]

### 2.3 DataReports (66)

The **66 DataReports** are inventoried in §7.3 because they are the *output* side of the reporting system rather than screens; each has **0 methods except three** — `Reporthistory` (1), `Reporthistory2` (1) and `zarf` (1) [P11 | analysis/BATCH-04/vb6/v1605/objects-full.txt | `# 210 objects`].

### 2.4 Forms with no obvious CHM counterpart

`analysis/BATCH-04/help_v1605/capability-crossref.md` lists the objects that the 15-topic CHM manual does not explain — including `labmain` (71 methods), `labfunction` (25), `printerselect` (11), `reportsetup` (113), `reportsetup2` (69), `users` (57), `userspw` (12), `server` (17), `z_gehats` (56), `z_pricelists` (27), `instrument` (29), `abbrevi` (41), `learntest` (6), `converter` (14), `antibioticfrm` (29), `Frm_pic` (55), `Frm_pic2` (31), `CardFrm` (0), `CardFrmSetx` (22), `SMSfrmsenderos` (139), `mInputbox` (12), `saveIOtemp` (10), `static6` (24), `labmainTools` (6), `otherfun` (2), `ais` (0) and `z_labaccount` (18) [P11 | analysis/BATCH-04/help_v1605/capability-crossref.md | the "VB6 objects with no obvious CHM counterpart" list]. **INFERRED:** the CHM documents 15 capabilities; the V2 vendor Guide Book documents ~60 across 7 units — the documentation gap is a real coverage gap, not an absence of function [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §3 the coverage-verification table].

---

## 3. UI vocabulary

> Arabic strings are reproduced **verbatim** as they appear in the evidence, including the typographic inconsistencies of the source (e.g. `النتايج` for `النتائج`). Provenance is given for every group.

### 3.1 Login and session (screen: `login`, `logindete`, `start`)

| Label / string | Context | Provenance |
|---|---|---|
| `تسجيل دخول` | Login button | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §2 step 3] |
| `خروج` | Exit button | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §2 step 4] |
| `الدخول للنظام` | Login window caption | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5 the login-screen Arabic strings] |
| `اسم المستخدم` | Login field | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| `كلمة السر` | Login field | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| `نسيت كلمة المرور؟ اضغط هنا` | Forgot-password link | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| `شركة ريال لاب لتحاليل المختبرات` | Vendor identity on login | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| `E-mail: ais_soft_group@yahoo.com` · `Tel: 01144848686 - 01000862074` | Vendor contact on login | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| `خادم قواعد البيانات غير معرف` | Fatal dialog: database server undefined | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1] |
| `رجاء تحويل التاريخ الى اللغة الانجليزية` | Fatal dialog: date locale | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1] |

### 3.2 Main ribbon and top-level commands

| Label | Screen | Provenance |
|---|---|---|
| `المرضي` | main window top bar | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3, §5, §7, §8] |
| `حسابات` | main menu (Accounts) | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12, §13] |
| `بيانات النظام` | main window top bar (System data) | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9, §10] |
| `اعدادات` | main window top bar (Settings) | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14] |
| `اضافة وتعديل بيانات المرضى` | patient window | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3] |
| `ادخال نتائج التحاليل` | patient window | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5] |
| `تسليم نتائج المرضي` | patient window | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7] |
| `بحث عن مرض` | patient window | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8] |
| `العينات المرسلة للخارج` | accounts menu | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12] |
| `الجرد وحساب الدرج` | accounts menu | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §13] |
| `بيانات التحاليل` | system-data menu | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9, §10] |
| `Database Maintenance` | settings menu | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14] |
| `اضافة مريض` · `تعديل` · `حذف` · `إلغاء` · `حفظ` · `مستلمة` · `تم` · `خالص` · `موافق` · `تراجع` | common command buttons | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 1, §7 point 4, §5 point 4, §12 point 4, §10 point 2, §5 - manuals] |
| `اضافة التحليل المحدد` · `حذف الكل` · `اضافة (انتر)` · `لاب اي دى` · `مرضي اليوم` · `ايصال` · `الباركود` | patient window buttons | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 points 11, 12, 13, 14, 15 and the closing note] |
| `طباعة كود الملف مع الكل` · `طباعة كل الاكواد` | barcode window check-box / orange button | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §4 points 1–2] |

### 3.3 Patient-status icon legend (results window and delivery window)

Seven glyphs, with their exact documented meaning [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §5 point 1 and §7 point 1]:

| Glyph | Documented meaning (verbatim) |
|---|---|
| `نيو` (red circle) | `مريض جديد تم تسجيلة للنظام ولم تدخل له اى نتائج` |
| `ورقة الملاحظات` | `مريض له نتائج لم تكتب بعد` |
| green + blue arrows | `مريض له نتائج لم تراجع بعد` |
| `الطابعة` | `مريض له نتائج لم تطبع بعد` |
| `عربة التسوق` | `مريض لم يستلم النتائج او له نتائج لم تسلم بعد` |
| `الجنية` | `مريض استلام جميع النتائج الخاصة به ويوجد مشكلة فى حسابه (باقى حساب للمعمل أو المريض)` |
| `الوسام` | `مريض تم ادخال نتائجه وطباعتها وحسابه خالص واستلم نتائجه` |

### 3.4 Result-entry window and profile grid

| Label | Context | Provenance |
|---|---|---|
| `حفظ` · `طباعة` · `معاينة الطباعة` · `Patient history` · `رجوع` · `القائمة الرئيسية` | profile form command row, in that documented order | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 5] |
| `تعليق (البرتقالى)` | orange comment button | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 4] |
| `Constants` | constants button, bottom-right of the result window | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 item 1] |
| `ملاحظات` | add/edit a note for the doctors or the reception staff | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 4] |
| `بي` · `تي` | two audit buttons on the results window (patient record audit / test-result audit) | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §5 point 6] |
| Column headers `Test Name \| Result \| Unit \| L or H \| Normal Range \| Verified \| Print` | result grid (English) | [P11 \| analysis/V-CD-2019/10-training-video.md \| §4 the observed columns] |
| Flags `عالٍ` / `منخفضة` / `حرجة` (`High` shown in red) | abnormal / critical result flags | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 2; P11 \| analysis/V-CD-2019/10-training-video.md \| §4 «القيمة High باللون الأحمر»] |

### 3.5 Report-design window (`reportsetup`)

| Label | Context | Provenance |
|---|---|---|
| `Show abnormal result background color` | toggle | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2] |
| `Print Status Flag (Low, High, Critical)` | toggle | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2] |
| `Make Normal range Font Bold` | toggle | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2] |
| `Print Critical Ranges If Found` | toggle | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2] |
| `Print Patient History Automatically` | toggle | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 2] |
| `Vertical Space After Sub Title` | margin | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 5] |
| `Vertical Space Between Tests` | margin | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 5] |
| `Additional V. Space To Ref. Range` | margin | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 5] |
| `Printing printer` | per-report printer override | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 5] |
| `حفظ الاعدادات` · `أبيض واسود` · `عودة` | report-design command row | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 6] |
| `تعديل ألوان رأس وذيل التقرير` | button opening the header/footer colour editor | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 point 6] |
| `Preparing Report` · `Report Template` · `Dr. Doctor's Name` · `Thank You` · `Title` · `Report Text` · `Print All Reports` · `Preview` · `Print` · `Close` | report-setup screen, observed in the training recording | [P11 \| analysis/V-CD-2019/10-training-video.md \| §8 the report-setup screen] |

### 3.6 Normal-range window (`normal_test`)

`Test name` · `Test unit` · `Sex` · `Age From : To` · `Age unit` · `Normal range` · `Low limit` · `High limit` · `Low flag : High flag` · `Low comment : High comment` · `Critical comment` · `Critical range` · `Critical flag`; buttons `اضافة مدى` · `تعديل` · `حفظ` · `تراجع` · `حذف` · `قائمة التحاليل` [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 points 2–3].

### 3.7 Test-catalogue window (`setup1`..`setup3`)

`Test name` · `Report name` · `Bill name` · `History name` · `Arabic name` · `Group name` · `Branch` · `Log group` · `Collection` · `Test time` · `Arrange number` · `Patient price` · `Lab to Lab price` · `Routine test` · `See report` · `Print with other` · `Add with group` · `Main test`; buttons `اضافة تحليل` · `تعديل` · `حذف` · `المعدل الطبيعي` [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 point 3 and point 8].

### 3.8 Outbound-sample window (`sarfz`)

Buttons `عرض` (show) · `ترسل إلى` (send to) · `موافق` · `خالص` · `دائما اليه` (always to) — the last being an explicit "make this the default destination" action [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §12 points 2–4; P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «4 -6 تصفية حساب العينات المرسلة للخارج»].

### 3.9 Accounting / stocktaking window

`عرض` · `إجمالى عينات المرضى` · `العينات المرسلة للخارج` · `ماتم تحصيلة` · `الكل` · `Branch no` [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §13 points 1–3; P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «6 -1 / 6 -2»].

### 3.10 Backup / maintenance dialog

`Database Maintenance` · base password `123` · `حذف` (delete a backup) · `تحديث` (refresh the list) · `استرجاع` (restore) · `Press any key to continue` · backup file name pattern `Patient_yyyymmdd.bak` [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §14].

### 3.11 System settings window (`setup1`..`setup3`)

`إعدادات النظام` (System settings) · `إعدادات التقرير` (report settings) · `إعدادات الإيصال` (receipt settings) · `إعدادات الظرف` (envelope settings) · `إعدادات الخلفية` (background settings) · `إعدادات هوامش التقرير` (report margins) · `ضبط الطابعات المخصصة للطباعة` (dedicated printers) · `ضبط نوع الحساب الافتراضي للنظام` (default account type) · `التعدّل فى حجم الورق` (paper size) · `تعديل ألوان رأس وذيل التقرير` · `سحب وفصل العينات` (pull & separate samples) [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «7 -1…9 -7» and «فصل وسحب العينات»; P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.6 rows 6-1…9-7].

### 3.12 Culture / sensitivity

`Sample` · `Organism A` · `Organism B` · `Organism C` · `Culture Condition` · `Colony Count` · `Sensitivity` · `Highly For` · `Moderate For` · `Low For` · `Resistant For` · `Add` · `Group Name = CULTURE AND SENSITIVITY` · `Pregnant` · `Children` · `Sent outside Lab.` · `Cost Price` · `Patient Price` [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «8 -1 إدخال التقارير فى حالة المزارع», «8 -3 إضافة مزرعة جديدة للبرنامج», «9 -3 إضافة مضاد حيوى للمزرعة», «11 -3 العينات المرسلة للخارج»].

### 3.13 Statistics

`Statistics` · `عدد التحاليل` (bar-chart title) · `عدد المرضى` (admin counter) · `Block` [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «1 -5», «12 -1»; P11 | analysis/V-CD-2019/10-training-video.md | §6].

### 3.14 NATIGH.COM portal

`Upload` · `Sign In` · `Result` · `Admin` · `Block` · `Patient` · `Doctor` · `Laboratory` · `NATIGH.COM` · `WWW.NATIGH.COM` · `http://play.google.com/store/apps/details?id=com.natighweb.app` [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «12 -1»].

### 3.15 Daily-tip strings (`daytip` table)

The `daytip` table is the application's rotating-hint store: `daytipnum Integer NOT NULL` is the hint ordinal and `daytip2 Text (255)` the hint text, in the shipped V2 schema [P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [daytip]]. The hints are Arabic and carry the keyboard-shortcut reminders for the main windows (patient search **F2**, patient entry **F3**, result entry **F4**, result delivery **F6**, out-referred samples **F7**), and the same shortcut set is documented independently in the CHM manual [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §8 the navigation keys]. **The exact hint strings a live V2 installation carries, and how many it holds, are NOT RECOVERABLE** — the shipped schema was ingested as a schema dump, so the table's rows are not part of the evidence.

[The tip-text catalogue the archive holds: P11 | analysis/BATCH-02/db/daytip.csv | the `daytipnum,daytip2` table.] — **VERIFIED** for the table's shape in the shipped V2 schema: `daytipnum Integer NOT NULL`, `daytip2 Text (255)` [P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [daytip]]. **The number of tip texts a live V2 installation carries is NOT RECOVERABLE** — the shipped schema was ingested as a schema dump and no row-level extract of the live store exists in the evidence.

### 3.16 Bill / card texts (`bin\IDCARD.INI`)

- `[IDdata]` — for each of the three fields (name · barcode · password) a **position** (`L` / `T`), a **font** (`F`), a **bold** flag (`B`) and a **size** (`S`) [P11 | analysis/CUMULATIVE/06-configuration.md | §5 `bin\IDCARD.INI`].
- `[Billdata]` — the receipt texts: **`Welcome To RealLab`** · **`Thank you for visiting RealLab!`** · opening hours · address · phone · website · e-mail · Facebook page [P11 | analysis/CUMULATIVE/06-configuration.md | §5]. **VERIFIED** as present in the `bin\IDCARD.INI` of the shipped deployment payload [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 the `bin\` payload table, `IDCARD.INI` row].

### 3.17 Report header strings (`bin\SETING.ini`)

- Arabic titles: **`Textr1txt=المنظومة البرمجية`** · **`Textr2txt=ريال لاب سيستم`** [P11 | analysis/CUMULATIVE/06-configuration.md | §4]. **VERIFIED** as the Arabic `*txt` title family carried by `bin\SETING.ini`; the exact values shipped in the V2 copy of that file were not separately extracted — see G-1 in §9.2.
- Twelve positioned font slots: **`Textr1..4`** (report text) · **`Textl1..4`** (left/label) · **`Textc1..4`** (centre), each with font-name / size / bold attributes, plus the paper margins [P11 | analysis/CUMULATIVE/06-configuration.md | §4]. The shipped file unifies the fonts of all three families to **Times New Roman 11.25** and sets `reporthead`/`zarfhead` to **0** (head/tail printing disabled) [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4 the printing-layer table]. **VERIFIED**.
- The three **signature texts** are confirmed in the **V2** `SETING.ini` as `signature1txt` / `signature2txt` / `signature3txt`: the report-setup screen visibly shows `Dr. Doctor's Name` and `Thank You`, and the training recording maps them to those exact keys [P11 | analysis/V-CD-2019/10-training-video.md | §8 the "matching table" between the UI elements and the extracted files: `Dr. Doctor's Name` → `SETING.ini` → `signature2txt`; `Thank You` → `SETING.ini` → `signature3txt`; `Font / Style / Size / Alignment` → `SETING.ini` → `Textr1fn/fs/fb` + `Data\*.ini`]. **VERIFIED**.

### 3.18 Per-profile report strings (`Data\*.ini`)

Exact label strings recovered from the profile catalogue (representative, reproducible in `analysis/BATCH-02/ini/test-catalogue.csv`):

| Slot | Values observed |
|---|---|
| `formsubtitle` | `Urine Culture` · `Stool Culture` · `Blood Culture` · … |
| `reportmaintitle` | `MICROBIOLOGY  REPORT` (note the double space) · `HEMATOLOGY REPORT` · … |
| `reportsubtitle1` | `Culture and Sensitivity:` · `Culture and Sensitivity :` (both spellings occur) |
| `normal_label` | `Reference Range:` · `Reference Range :` |
| `comment_label` | `Comment:` · `Comment :` |
| `main_symb` / `sub_symb` / `subtitle_symb` | single-letter glyph keys (`E`, `K`, …) used as the item markers |
| `signature` / `signature2` / `signature3` | `Doctor's signature:` · `Dr. Doctor's Name` · `Thanks` — not carried by the V2 profiles; centralised in `SETING.ini` / `IDCARD.INI` [P11 \| analysis/BATCH-07/ini-diff-summary.md \| §2 the key-level difference table] |

[P11 | analysis/BATCH-02/ini/test-catalogue.csv | the profile catalogue of the V2 payload's `Data\*.ini` templates; P11 | analysis/BATCH-02/ini/parsed.csv | `formsubtitle`, `reportmaintitle`, `reportsubtitle1`, `normal_label`, `comment_label` columns.] The V2 payload ships **223** `Data\*.ini` report-profile templates [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1, the `Data\*.ini` row].

### 3.19 Work-sheet and report English headers

`WORKPAPER BY PATIENT NAME` · `WORKPAPER BY TEST NAME` · `No. of Patients:` · `No. of types of tests:` · `Printed by:` · `Test Name | Gender | Male | Age | Years` · `Test Code 1 → F.B.C.` · `Patient tests in our lab` · `Available tests in report` · `Reprinted` [P11 | analysis/V-CD-2019/10-training-video.md | §7 the work-sheet facsimiles; P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «6 -1 عمل تقرير مجمع»].

### 3.20 Bilingual behaviour (VERIFIED)

| Screen | Language | Evidence |
|---|---|---|
| Login | Arabic | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| Patient registration | Arabic | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| Main menu | Arabic | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| **Test-definition engine** | **English** | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| **Result grid** | **English** (column headers) | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| **Printed work sheet** | **English** | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| Statistics | Arabic | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |
| Report setup | Arabic | [P11 \| analysis/V-CD-2019/10-training-video.md \| §5] |

> **INFERRED (strong):** localisation is **per-form, not per-file** — there is no single translation layer, so any re-implementation must budget localisation per screen [P11 | analysis/V-CD-2019/10-training-video.md | §5 the "partial, not comprehensive" design note].

### 3.21 Other shipped configuration values (VERIFIED)

| File / object | Shipped value | Provenance |
|---|---|---|
| `bin\BASE.ini` | `DataSource=REAL_LAB`; `[Initial] nrls=600` with a companion `orls=600` | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §3 the `bin\BASE.ini` row] |
| `bin\data_connection.udl` | connects to `patients` + `Interface` + `VIDAS` with `Data Source=<servername>` | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1] |
| `Patients.mdb` | **103 tables / 1,617 columns** | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §1] |
| `bin\SETING.ini` | `reporthead` = **0** and `zarfhead` = **0** (head/tail printing disabled) | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §4 the printing-layer table] |

---
## 4. Layout constraints — the report layout model

### 4.1 The `Data\*.ini` profile model

**VERIFIED.** `Data\*.ini` holds **223 files** — the V2 payload's report-profile template set [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1, the `Data\*.ini` row]. The template catalogue groups them into **114 clinical categories** — **114 primary** profiles plus **109 `_S` (secondary)** variants; that split is derived from the template catalogue and is not stated by a V2-primary artefact [P11 | analysis/BATCH-02/ini/parsed.csv | 223 rows, `category` + `variant` columns; P11 | analysis/BATCH-07/ini-diff-summary.md | §4]. Each file is one **report template** for one clinical category, plus a per-profile printer binding.

**Section inventory (VERIFIED, reproducible from the template catalogue's `sections.csv`):**

| Section | Files containing it | Role |
|---|---:|---|
| `reportdata` | **222** | the report body: column geometry, colours, fonts, print flags, titles |
| `setupx` | **221** | the per-profile printer binding (`reportprinterx`) |
| `form` | **137** | the input-form overlay for profiles that carry their own entry form (labels, item templates, check-boxes) |
| `report` | **49** | the printed-report overlay (title bold/italic/size/colour, 12 separator lines with independent bold and size) |
| `setup` | **1** | (`REPORT.ini`) |
| `sentence` | **1** | (`data.ini`) |

[P11 | analysis/BATCH-02/ini/sections.csv | the `section,files` table.]

### 4.2 The seven column positions

**VERIFIED.** Seven positional keys `left1` … `left7` define the horizontal geometry of the result table; they occur in **221–222 of the 223** profile files (`left1` 222, the rest 221) [P11 | analysis/BATCH-02/ini/keys-frequency.csv | `left1` 222 / `left2..left7` 221].

**Unit: twips — INFERRED (strongly supported, not directly declared).** The archive's own methodology note states *"مواضع الأعمدة بالـtwips في .ini"* and the observed magnitudes are consistent with 1440 twips = 1 inch on A4 (11906 twips wide): e.g. `left1=710`, `left3=3600`, `left7=6000`, `width4=1600`, `width7=2700` [P11 | analysis/BATCH-02/ini/keys-frequency.csv | the `left*`/`width*` rows; P11 | analysis/BATCH-02/rtf/report-structure.md | §3 the note "**مصدر الأبعاد:** كل موضع عمود في القالب يأتي من ملف `.ini` المقابل في `Data\` (المفاتيح `left1..left7`, `width4`, `width7`, `topvalue`, `bottomvalue`, `leftvalue`, `rightvalue`, `spacevalue`)"].

**Widths.** `width4` and `width7` are the two width slots present in essentially every profile (221 each); `width1` appears in 69 profiles and `width8` in 9 — i.e. most profiles only parameterise the widths of two of the seven columns and leave the rest at a default [P11 | analysis/BATCH-02/ini/keys-frequency.csv | `width4` 221, `width7` 221, `width1` 69, `width8` 9].

**Spacing keys (VERIFIED).** `spacetitle` (221), `spacevalue` (221), `spacenormal` (208) — the vertical gaps above the title, above a result value, and above the normal-range line respectively [P11 | analysis/BATCH-02/ini/keys-frequency.csv].

### 4.3 Colour slots and per-position fonts

**VERIFIED — and a correction to the archive's own label.** The archive describes the palette as *"24 لونًا"* / *"24 colours"* [P11 | analysis/CUMULATIVE/06-configuration.md | §7 «Data\*.ini — 223 ملفًا / 114 فئة … (عناوين، 7 مواضع أعمدة، 7 عروض، 24 لونًا، خط لكل موضع، أعلام طباعة)»; P11 | 11-Evidence/Evidence-Register.md | EV-ANA-016 «7 مواضع أعمدة + 24 لونًا + خط لكل موضع»]. The reproducible key census is **20 lettered colour slots**, `colora` … `colort`, each present in **221** profiles (`colorr` in 217) [P11 | analysis/BATCH-02/ini/keys-frequency.csv | the 20 `color<letter>` rows]. The per-profile tally confirms it: `colors_configured` = **20** in 110 of the 114 categories, **19** in 2, and **0** in the two files that carry no `[reportdata]` colours (`REPORT.ini`, `data.ini`) [P11 | analysis/BATCH-02/ini/test-catalogue.csv | the `colors_configured` column]. **The "24 colours" figure is therefore NOT reproducible from the evidence; the reproducible figure is 20.**

**Per-position font metadata.** Four attributes per position: **`fn`** (font name) · **`fs`** (font size) · **`fb`** (bold flag) · **`ul`** (underline flag) — e.g. `colorafn` / `colorafs` / `colorafb` / `coloraul`. Across all 223 files these exist for **17 positions** (`a b c d e f g i j k l m o p q s t` — `h` and `n` are absent) and **65 distinct keys**; per profile, **16 quadruples** are configured in **78 of the 114** categories and **none** in 36 [P11 | analysis/BATCH-02/ini/keys-frequency.csv | the `color<letter>(fn|fs|fb|ul)` rows; P11 | analysis/BATCH-02/ini/test-catalogue.csv | the `fonts_configured` column]. Observed font values in V2 profiles: **`Times New Roman`**, **`Arial`**, **`Tahoma`** [P11 | analysis/BATCH-07/ini-key-delta.csv | e.g. `reportdata.colorbfn,Times New Roman,Times New Roman`, `reportdata.colorefn,,Arial`, `reportdata.colortfn,Times New Roman,Tahoma`].

**Secondary palette file.** `bin\REPORT.dll` — despite the `.dll` extension it is a **562-byte plain INI** carrying `[reportdata]` and `color1` … `color19` (BGR values such as `14737632` = `0xE0E0E0`, `12632256` = `0xC0C0C0`, `16777215` = `0xFFFFFF`, `46444020` = `0x2C4C64`, `4210752` = `0x404040`); it is the shared report colour palette written by VB6 under a DLL-looking name [P11 | analysis/CUMULATIVE/06-configuration.md | §6 `bin\REPORT.dll`]. It is shipped in the V2 `bin\` payload [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 the `bin\` payload table, `REPORT.dll` row].

### 4.4 Print flags (VERIFIED)

| Flag | Occurrences | Meaning |
|---|---:|---|
| `printcritical` | 217 | print the critical range in the normal-range cell |
| `printhistory` | 217 | print the patient history in the report |
| `statusflag` | 217 | print the Low / High / Critical status word |
| `backcolor` | 217 | shade the background of an abnormal result |
| `normal` | 208 | print the normal range line |
| `normalbold` | 135 | print the normal-range text in bold |
| `check1x` | 106 | (a profile-specific visibility flag) |
| `check2x` / `check3x` | 217 | (a profile-specific visibility flag) |
| `printsen` / `printcommer` | 36 | print the sensitivity / commercial-name column (microbiology) |
| `printxo<n>` | 35 / 14 / 10 … | per-item print override for numbered items |
| `comment` | 219 | print the comment column |
| `reportstart` | 129 | the profile's own report start offset |

[P11 | analysis/BATCH-02/ini/keys-frequency.csv | the named key rows.] The CHM-level semantics of the first five are the report-design toggles **Show abnormal result background color**, **Print Status Flag (Low, High, Critical)**, **Print Critical Ranges If Found**, **Print Patient History Automatically** and **Make Normal range Font Bold** [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §11 point 2].

### 4.5 Header / footer and page positions

**Page margins (VERIFIED).** `topvalue`, `bottomvalue`, `leftvalue`, `rightvalue` — each present in **217** profiles [P11 | analysis/BATCH-02/ini/keys-frequency.csv]. The page template carried by `bin\SETING.ini` is `topvalue=0 bottomvalue=567 leftvalue=567 rightvalue=0` [P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §3.3 the "configuration precedes the code" evidence list, item 2]. **NOT RECOVERABLE for V2:** the exact values of these four keys in the shipped `bin\SETING.ini` were not separately extracted — only the printer names, `reporthead`/`zarfhead` = 0 and the font unification are on record [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4 the printing-layer table].

**Patient-history block positions (VERIFIED).** A dedicated family of top/left coordinate pairs, all with an occurrence count of **1** (present in a single profile, the history profile): `hidtop` · `hidleft` · `hnametop` · `hnameleft` · `hreqtop` · `hreqleft` · `hinfotop` · `hinfoleft` · `hprnttop` · `hprntleft` · `hrefftop` · `hreffleft` · `hlinetop` · `addwidthlin`; together with the visibility switches `shownamex` · `showinfox` · `showreferx` · `showidx` · `showreqdx` · `showprtdx` · `showtimex` · `showlongdx` and the style keys `patienthistbold` · `historycaptionbold` · `historydatebold` · `historyresult` [P11 | analysis/BATCH-02/ini/keys-frequency.csv | the `h*` and `show*` rows].

**Title / indent offsets (VERIFIED).** `titleleft` (70 profiles) · `leftshift` (14) · `leftsubtitshift` (10) · `secondshift` (1) [P11 | analysis/BATCH-02/ini/keys-frequency.csv].

**Separator lines (VERIFIED).** Each profile with a `[report]` section defines **12 separator lines** with independent **bold** (`linebold_1` … `linebold_12`) and **size** (`linesize_1` … `linesize_12`) [P11 | analysis/BATCH-02/ini/keys-frequency.csv | the `linebold_*`/`linesize_*` rows]. The header/footer editor exposes the separator-line height, the show/hide state of the lines and the thickness of the patient-history line (§3.5).

### 4.6 Paper size and report start offset

**Paper size (VERIFIED).** `bin\SETING.ini` `[setup]` carries **`papersize=A4`** [P11 | analysis/CUMULATIVE/06-configuration.md | §4 `bin\SETING.ini`]; the vendor Guide Book exposes the choice as **A4** or **A5** in *«3 -7 التعدّل فى حجم الورق المستخدم فى طباعة التقرير»* [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «3 -7 التعدّل فى حجم الورق المستخدم فى طباعة التقرير»]. The CHM also documents the top-margin ceiling of **8 cm** used to accommodate pre-printed logo stationery [P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «2 -7 ضبط هوامش التقرير»].

**Report start offset (VERIFIED, two distinct values).**
1. **Global** — `bin\SETING.ini` `[setup]` **`reportstart=1984`** [P11 | analysis/CUMULATIVE/06-configuration.md | §4].
2. **Per-profile** — `Data\*.ini` `[reportdata]` **`reportstart`**, present in **129** profiles; the value recorded in the profile catalogue is **`2000`** [P11 | analysis/BATCH-02/ini/keys-frequency.csv | `reportstart` 129].

### 4.7 The three signature strings (VERIFIED)

The three report signature strings are **not** carried by the V2 report profiles; they are centralised in the configuration files of the deployment:

| Key | Text | V2 location |
|---|---|---|
| `reportdata.signature` | `Doctor's signature:` | `bin\SETING.ini` / `bin\IDCARD.INI` |
| `reportdata.signature2` | `Dr. Doctor's Name` | `bin\SETING.ini` (`signature2txt`) |
| `reportdata.signature3` | `Thanks` | `bin\SETING.ini` (`signature3txt`) |

The report-setup screen visibly shows `Dr. Doctor's Name` and `Thank You`, and the training recording maps them to those exact keys [P11 | analysis/V-CD-2019/10-training-video.md | §8 the "matching table" between the UI elements and the extracted files: `Dr. Doctor's Name` → `SETING.ini` → `signature2txt`; `Thank You` → `SETING.ini` → `signature3txt`; `Font / Style / Size / Alignment` → `SETING.ini` → `Textr1fn/fs/fb` + `Data\*.ini`]. The shipped `bin\SETING.ini` is **4,886 bytes** [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4].

### 4.8 The third-organism extension (VERIFIED, three layers)

One feature implemented consistently in three independent layers:

```
Data\*.ini  (32 files)   LabelX002 = Organism C
                          ITEMXV002
                          ITEMXD2   = Gram Positive Cocci##Gram Negative bacilli##
                                     Gram Negative Dilococci##No Organism##
                          Check6f   = 1
Patients.mdb             cultures.organism3   Text(80)
                          cultures.organism    Text(80)
                          cultures.organism2   Text(80)
                          cultures.condition2  Text(50)
real lab system.exe DDL   ALTER TABLE cultures ALTER COLUMN organism3 -> varchar(80)
```

[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §9 the three-layer intersection; P11 | analysis/BATCH-07/ini-diff-summary.md | §3 the cross-check from the SQL layer; P11 | analysis/BATCH-04/sql_v1605/ddl-evidence.txt | the `cultures` ALTER statements.] Each of the 32 affected profiles carries roughly **+53 bytes** of additional content [P11 | analysis/BATCH-07/ini-diff-summary.md | §4 «الحجم: نمو ثابت ~+53 بايت لكل ملف»].

---

## 5. Field behaviour

### 5.1 The result-entry contract (VERIFIED)

| Aspect | Behaviour | Provenance |
|---|---|---|
| **Abnormal shading** | A result outside `lowlimit`/`highlimit` is displayed with a **shaded background**; the shading can be switched off per profile with the toggle **Show abnormal result background color** (`backcolor`, 217 profiles) | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 point 3 «خارج المدى سيتم تظليل خلفية النص فى التقرير»; §11 point 2] |
| **Abnormal flag (objection text)** | `nolowexe` (Text(20)) and `nohighexe` (Text(20)) carry the **low / high expression**; the on-screen column is headed **`L or H`** and the word `High` is rendered **in red** | [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[nolowexe] Text (20)` / `[nohighexe] Text (20)`; P11 \| analysis/V-CD-2019/10-training-video.md \| §4 the column map and «القيمة High باللون الأحمر = nohighexe»] |
| **Critical flag** | A **critical** expression is written when the value crosses the *critical* low/high limits; the critical range is printed in the normal-range cell only when the profile sets `printcritical` | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10 point 3 (Low/High limit (critical) + Critical flag); §11 point 2 «Print Critical Ranges If Found»] |
| **Normal range** | `patienttest.normalrang` (Memo) is a **stored ready-to-print string** — e.g. `Male 7-45`, `Female 13-17`, `Non 1-2`, `Male 6-18` — copied from `normalrange.normalrang` at ordering time, **not computed at print time** | [P11 \| analysis/V-CD-2019/10-training-video.md \| §4 «نصوص النطاق جاهزة للطباعة»; P11 \| analysis/BATCH-04/sql_v1605/ddl-evidence.txt \| `ALTER Table normalrange ALTER COLUMN normalrang varchar(MAX)`] |
| **Result values** | `resultt` (Text(50)) plus `resultt1` … `resultt4` — five result cells per ordered test | [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[RESULTT] … [resultt1] … [resultt4]`] |
| **Unit** | `testunit` Text(15) on the order, mirrored from `normalrange.testunit` | [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql; P11 \| analysis/V-CD-2019/10-training-video.md \| §4] |
| **Print marking** | Tests that carry a print mark are **shaded green** in the profile grid and must be reviewed before they can be printed or viewed | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 3] |
| **Per-item comment** | `commentx` Memo(255) | [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `[commentx] Memo/Hyperlink (255)`] |
| **Group enablement** | Only the tests actually **ordered for this patient** are enabled inside the profile grid; the rest of the group is shown but inactive | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 2] |

### 5.2 The three comment mechanisms (VERIFIED)

| Mechanism | Trigger | Source of the text | Landing place |
|---|---|---|---|
| **Free typing** | type directly into the comment cell | the operator | `patienttest.commentx` |
| **Saved fixed comments** | the orange **«تعليق (البرتقالى)»** button → a list of the comments registered for that test | `comments` catalogue (12 rows), maintained under **System → «Test Comments»** | `patienttest.commentx` |
| **Range-driven objection** | automatic, on entering a low / high / critical result | `normalrange.lowcomment` / `highcomment` / the critical comment | the comment cell of the window **and** of the report, shown when the test name is clicked |

An **undo button** removes the last comment added [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 point 4]. A fourth route — the comment **stored in the normal-range list** — is selected by clicking the test name [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 point 4].

### 5.3 Keyboard shortcuts — exact keys (VERIFIED)

**Patient window (`addpatient`)** [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §3 the keyboard list]:

| Key | Action |
|---|---|
| `F1` | with the cursor in the test list — show the data of the selected test |
| `F2` | add a new patient |
| `F3` | go to the search window |
| `F4` | go to the result-entry window |
| `F5` | refresh the test list / prepare a new test search |
| `F6` | go to the result-delivery window |
| `F7` | go to the outbound-samples window |
| `F8` | edit the selected patient's data |
| `F9` | save the new patient or the edit |
| `F10` | delete the selected patient |
| `F11` | go to the barcode-printing window of the selected patient |
| `F12` | print a receipt for the selected patient |
| `Enter` | move between boxes · collect the test price from the patient · add the selected test or group |
| `Up` / `Down` | move between boxes · navigate the test list · choose the search method when the cursor is in the test search box |
| `Ctrl` | move between the test/group search box and the test/group list |
| `Esc` | cancel the new-patient / patient-edit operation; return to the main list |

**Results window and delivery window** [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §5 and §7 keyboard lists]:

| Key | Action |
|---|---|
| `F2` | go to the patient-data window |
| `F3` | go to the search window |
| `F4` | go to the result-entry window |
| `F5` | refresh the patient list (re-display today's patients) |
| `F6` | go to the result-delivery window |
| `F7` | go to the outbound-samples window |
| `F8` | mark the result reviewed / not reviewed |
| `F9` | mark the result finished / not finished |
| `F12` | mark the result printed / not printed |
| `Enter` | show the selected patient's tests, or open the result-entry window for the selected test |
| `Up` / `Down` | move between patients · navigate the patient's tests |
| `Ctrl` | move between the patient list and the patient's tests (delivery window: also the search box) |
| `Esc` | return to the main menu |

**Profile result-entry window** [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 keyboard list]:

| Key | Action |
|---|---|
| `F8` | mark the patient's selected tests as reviewed |
| `F9` | save the results and edits |
| `F11` | print-preview the report of the entered results |
| `F12` | print the result report (the tests to be printed that have results entered and have been reviewed) |
| `Enter` | move to the next result cell; in the last available cell it **saves and returns to the results window** |
| `Up` / `Down` | move between the available result cells |
| `Esc` | return to the results window **without saving** |

**Search window** [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §8 keyboard list]: `F2` patient data · `F4` result entry · `F5` refresh for a new search · `F6` delivery · `F7` outbound samples · `F10` delete the selected patient · `Esc` back to the main menu.

**Windows with no shortcuts:** the barcode window, the test-catalogue window, the normal-range window, the report-design window, the outbound-samples window and the stocktaking window all state **«لا توجد اختصارات بعد»** (no shortcuts yet) [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §4, §9, §10, §11, §12, §13 keyboard lists].

### 5.4 Constants / clinical conversion factors (VERIFIED)

Editable per-patient from the **«Constants»** button on the result window [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 item 1]:

| Formula | Condition |
|---|---|
| `Hct = Hgb × 3.3` | used when no haematocrit result is entered |
| `Hgb% = Hgb × 8.25` | male **or** female under one year |
| `Hgb% = Hgb × 7.50` | age 1 – 12 years |
| `Hgb% = Hgb × 6.25` | male over 12 years |
| `Hgb% = Hgb × 6.75` | female over 12 years |

The constants are held in the `constanttable` table (`constantdiscrp` naming the group, `constant1..constant7` the slots) in the shipped V2 schema [P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [constanttable]]. The **values** the V2 CHM manual documents for the CBC group are 3.3 / 8.25 / 7.50 / 6.25 / 6.75 [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 item 1 — the five formulas above]; the PT group is documented by name (*ISI, Control Time and Concentration table*) but **the numbers stored in the V2 `constanttable` rows are NOT RECOVERABLE** — no row-level extract of the live store exists in the evidence. The shipped schema carries a **seventh** constant slot (`constant7`) [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.2 the column-change table]. To change the constant for a paediatric case the paediatric constant is edited; for an adult, the adult constant is edited.

### 5.5 The audit trail (VERIFIED)

Every result row carries the full chain of custody in `patienttest` [P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | `CREATE TABLE [patienttest]`]:

| Field | Meaning |
|---|---|
| `edituser` / `editdate` | who entered/edited the result and when |
| `resultreview` | reviewed flag |
| `resultfinsh` | finished flag |
| `printuser` / `printdate` / `printnum` | who printed, when, and the **sequential print counter** |
| `prevuser` / `prevdate` | the previous editor and the previous edit time |
| `taslimuser` / `taslimdate` | who delivered the result to the patient and when |
| `give` | delivered flag |
| `loggroup` | the work group that performed the test |
| `sentout` / `send` / `otherlabname` | outbound flags and destination |
| `natighu` | **V2 only** — the NATIGH portal upload flag |

The two audit buttons on the results window (**«بي»** for the patient record, **«تي»** for the test result) expose: who registered the patient, how many times the data was edited, who edited it last, the payment system, who collected the money, who entered the result, who reviewed it, who is responsible for the printing, how many times the result was printed, who delivered the result — each with date and time [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §5 point 6]. These buttons are restricted to the system administrator and users with absolute permissions.

---

## 6. Printing architecture

### 6.1 The headline finding (VERIFIED)

> **RealLab owns no PDF engine.** It sends its report to an **external Windows printer driver** — `Bullzip PDF Printer` — and both the **device name** and the **driver version** are **hard-coded as string literals inside the application**. Pathology ⇒ PDF goes through the **operating-system print layer**, not through an application library. [P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | the one-line summary at the head of the document]

### 6.2 The exact PDF generation mechanism (VERIFIED)

| Offset in `real lab system.exe` (FileVersion 1.605) | Literal | Role |
|---|---|---|
| `0x6A2486` | **`Bullzip PDF Printer`** | the hard-coded printer **DeviceName** |
| `0x6A255E` | **`Bullzip PDF Printer 11.1 - Create File`** | the hard-coded default **output file name** |

[P11 | pdf-print-stack.md | §2.1 the offset table.]

**Consequences (all VERIFIED):**
1. The application **does not generate the PDF** — Bullzip's port driver does.
2. If `Bullzip PDF Printer` is not installed **under that exact name**, the PDF path **fails**.
3. The **version is pinned too** (`11.1`) — installing Bullzip 12/13/… breaks the default output-file name.
4. ⇒ RealLab is bound to a third-party print program at a specific version — a **fragile coupling**.

[P11 | pdf-print-stack.md | §2.1 the four VERIFIED FACT bullets.]

**The full path (VERIFIED):**

```
real lab system.exe (FileVersion 1.605)
   • literal «Bullzip PDF Printer»            ← device name
   • literal «Bullzip PDF Printer 11.1 - Create File» ← output name
   • EnumPrintersA / SetDefaultPrinterA       ← Win32 API
   • 6 printer roles · 5 selection lists (cboPrinters..5) · 6 imlPrinters
        │  hands the report to the printer port
        ▼
Bullzip PDF Printer 11.1.0.2600  (BioPDF ApS · Inno Setup 5.5.7)
   cf/Bullzip/PDF Printer/Ports/BULLZIP/bzpdf.dll   ← port driver
   app/gs/                                          ← embedded Ghostscript
   app/DocumentCollector.exe · app/Notify.exe · labels.txt × ~50 languages
        │  produces
        ▼
D:\PDF\Contracts\  ·  D:\PDF\Free\  ·  D:\PDF\Individual\  ·  D:\PDF\LabToLab\
```

[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §1 the full path diagram.]

**Third-party tools that the application never calls (VERIFIED):** `gslite.exe` (GPL Ghostscript Lite 9.14.17) · `xpdfsetup.exe` (Xpdf Lite 3.3.4, ships `bin/pdftops.exe`) · `pdfpowertool_setup.exe` (PDF Power Tool 4.0.0.11). The literal scan of `real lab system.exe` (FileVersion 1.605) returns **0** occurrences for `gslite`, `ghostscript`, `pdftops`, `xpdf` and `pdfpowertool` — they are **operator tools** installed in `System\PDF\` for manual conversions, not part of the application path [P11 | pdf-print-stack.md | §5 the toolchain table].

### 6.3 The six printer roles (VERIFIED)

**The shipped global bindings (Stage 2, VERIFIED).** `bin\SETING.ini` `[selectprinter]` declares the six printer roles and binds them: `reportprinter`, `barcodeprinter`, `zarfprinter` and `waslprinter` are all set to `HP Officejet 6000 E609a Series`, while **`IDprinter` is left empty**; the two legacy ports `reportport` and `barcodeport` are set to `LPT1:`. The per-profile binding `setupx.reportprinterx` is a separate layer and is set to `HP LaserJet 1100 (MS)` in the shipped profiles (`[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\SETING.ini | [selectprinter] section]`).


| Symbol | Meaning | Note |
|---|---|---|
| `reportprinter` | report printer | the primary path |
| `reportprinterx` | alternative report printer | secondary path; also the key `setupx.reportprinterx` in every `Data\*.ini` profile |
| `zarfprinter` | **ZARF** | integration with an external system |
| `barcodeprinter` | barcode printer | tubes and sample labels |
| `waslprinter` | **WASL** | external integration — the work-sheet printer |
| `IDprinter` | **ID / identity printer** | the patient identity card |

[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3 the six-printer-roles table; P11 | pdf-print-stack.md | §2.4 the same table with the module note "مع وحدة `printerselect` (11 إجراء) ودالة `selectprinter` و`check_onePrinter`"].

**Global role bindings in `bin\SETING.ini` `[selectprinter]`** — shipped values: `reportprinter` = `HP Officejet 6000 E609a Series` · `barcodeprinter` = `HP Officejet 6000 E609a Series` · `zarfprinter` = `HP Officejet 6000 E609a Series` · **`waslprinter` = `HP Officejet 6000 E609a Series`** · **`IDprinter` = *(empty)*** [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4 the printing-layer table].

### 6.4 The output tree — all four PDF categories (VERIFIED)


| UI label | Hard-coded path |
|---|---|
| `Contracts` | `D:\PDF\Contracts\` |
| `Free` | `D:\PDF\Free\` |
| `Individual` | `D:\PDF\Individual\` |
| `Lab To Lab` (stored as `LabToLab`) | `D:\PDF\LabToLab\` |

[P11 | pdf-print-stack.md | §2.2 the output-tree table.] These four categories map onto the four **account types** used by the application (`Individual` / `Lab to Lab` / `Free` / contract) — the archive's reading is that they express a **commercial/operational classification** of lab paperwork: contracts · free · individual · lab-to-lab [P11 | pdf-print-stack.md | §2.2 the OBSERVED note].

### 6.5 The print registry and quality gates (VERIFIED)

```sql
SELECT patientid,testcode,resultprint,printuser,printdate,printnum
FROM patienttest
WHERE testcode in (6,7,8,9,14,15,16,17,18,19,20,21) AND patientid='…'
```

[P11 | pdf-print-stack.md | §2.5 the print-audit SQL.]

| Control | Fact | Provenance |
|---|---|---|
| **Verified-only gate** | the literal `Not found any Verified selected tests or result to print it` — **an unverified result is never printed** | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| **Printable test types** | **12** only: `testcode in (6,7,8,9,14,15,16,17,18,19,20,21)` | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| **Print audit** | `resultprint` · `printuser` · `printdate` · `printnum` | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| **Numbered printing** | `printnum` is a **sequential counter** ⇒ detectable unauthorised copying | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| **Output separation** | 5 classified output paths ⇒ complete segregation of the four data classes | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |

### 6.6 Layer transitions (VERIFIED)

| # | Transition | Status |
|---|---|---|
| 1 | Application → print driver (`Bullzip PDF Printer` literal + `EnumPrintersA`/`SetDefaultPrinterA`) | **established** |
| 2 | Print driver → Ghostscript (`app/gs/` inside the Bullzip package) | **established** |
| 3 | ‹.NET 4› ← Bullzip (`SetupPZ.bat` installs .NET 4 then Bullzip) | **established** |
| 4 | Application → Ghostscript / Xpdf / PDF Power Tool | **does not exist — 0 calls** |
| 5 | ‹.NET 4› → application | absolute independence (the application is VB6) |
| 6 | Application → database (PDF path) | no SQL in the PDF path |

[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §5 the transitions table.] The strategic consequence is that **the PDF path can be re-implemented without touching application logic**.

### 6.7 The install-chain defect (VERIFIED)

| Script | Referenced by | What it does | Status |
|---|---|---|---|
| `System\SetupPZ.bat` | ✔ `RL_SETUP.exe` | ‹.NET 4› **then** Bullzip — two correct paths | ✅ the **effective** script |
| `System\PDF\SetupP.bat` | ✔ `RL_SETUP.exe` | Bullzip only — **before** ‹.NET 4› | ⚠️ **duplicated and mis-ordered** |
| `System\PDF\SetupFN4.bat` | ✘ **nobody** | ‹.NET 4› with a **broken relative path** (`dotNetFx40_…exe` without `System/PDF/`) | ⚠️ **orphaned + broken path** |

**Defect statement (VERIFIED):** `RL_SETUP.exe` invokes `System\PDF\SetupP.bat` **before** `System\SetupPZ.bat`. The later script installs .NET 4 first and then Bullzip, but the earlier invocation installs Bullzip **before .NET 4 exists**, and Bullzip 11 **requires** .NET 4 ⇒ **a first failing attempt followed by a successful retry**. `SetupFN4.bat` will only succeed if the working directory happens to be `System\PDF\`. [P11 | pdf-print-stack.md | §5.1 the install-chain defect.]

**Side effect (VERIFIED):** the setup log is written to the **root of the disk** as `C:\setup.log` (no `\` after `C:`), and the `start /B` invocations of the two `setup.exe` bootstraps have **no `/wait`**, so the operator may start the application before the ActiveX and font installation has finished [P11 | pdf-print-stack.md | §5.2].

### 6.8 Licensing and signing compliance (VERIFIED)

| File | Signature | Algorithm | Signer | Status |
|---|---|---|---|---|
| `Setup_BullzipPDFPrinter…exe` | ✔ | **SHA1** | BioPDF ApS (DK) via COMODO RSA Code Signing CA | **verification fails** |
| `dotNetFx40_Full_x86_x64.exe` | ✔ | **SHA1** | Microsoft Corporation | **verification fails** |
| `gslite.exe` | ✘ | — | — | **unsigned** |
| `pdfpowertool_setup.exe` | ✘ | — | — | **unsigned** |
| `xpdfsetup.exe` | ✘ | — | — | **unsigned** |

[P11 | pdf-print-stack.md | §4 the digital-signature table.] Bullzip's certificate chain: primary `CN=BioPDF ApS, O=BioPDF ApS, L=Alsager, postalCode=3140, ST=DK`, issued by `COMODO RSA Code Signing CA`, valid 2015-10-12 → 2020-10-11; timestamp signer `COMODO SHA-1 Time Stamping Signer` valid 2015-12-31 → 2019-07-09; recorded signing time `2017-03-10 16:27:29 UTC`. `osslsigncode verify` returns `Signature verification: failed` and `Timestamp Server Signature verification: failed`, but the message digest **matches** (`Current == Calculated`) ⇒ the file is unmodified; only the chain/timestamp has expired [P11 | pdf-print-stack.md | §4 the Bullzip detail].

**Licence obligations (VERIFIED):**

| Component | Shipped licence | Obligation |
|---|---|---|
| Ghostscript 9.14.17 Lite | **GNU AGPL v3** | the strongest: the shipped `COPYING` is the full AGPL v3 text with no exception; network use triggers §13 |
| Xpdf 3.3.4 | **GPL v2 or v3** (dual) | the `README` requires unmodified copies to ship `README` + `COPYING` + `COPYING3` + the documentation — the installer **does** include them |
| Bullzip PDF Printer 11.1 | commercial (BioPDF ApS) | PRO/EXP editions are **paid** — a licence per copy |
| PDF Power Tool 4.0 | commercial (pdfpowertool.com) | licence verification required |
| .NET Framework 4.0 | Microsoft EULA | out of support |

[P11 | pdf-print-stack.md | §6 the licensing-compliance table.] The archive's own, carefully hedged reading: Ghostscript is **not linked into RealLab's code** but is invoked as a separate process or shipped inside Bullzip, so this is most likely **mere aggregation** and the GPL obligation does not attach to RealLab itself — **but** (1) licence disclosure is mandatory, (2) any network use of Ghostscript reopens the §13 question, and (3) the disc distributes an AGPL tool through commercial intermediaries [P11 | pdf-print-stack.md | §6 the precise note].

**Other compliance facts (VERIFIED):** the Bullzip installer replaces Windows system files (`sys/oleaut32.dll`, `sys/msxml6.dll`) — the same "write over `System32`" pattern found in `SETUP.LST` [P11 | pdf-print-stack.md | §3.1 note 3]; the install media CAB self-registers **24** OCX/DLLs into the Windows registry and writes into `System32`/`SysWOW64` without declaring the administrator requirement [P11 | analysis/V-CD-2019/12-install-media.md | §2.2]; and the CAB ships **two conflicting builds** of the runtime — 16 of the 48 files differ between `WIN7` and `WINXP`, and the CAB and the `OCX\` folder ship *different* builds of `msvbvm60.dll`, `msado27.tlb`, `MSCOMM32.OCX` and `MSFLXGRD.OCX`, so the installed state depends on copy order [P11 | analysis/V-CD-2019/12-install-media.md | §4 and §4.1].

### 6.9 PE envelopes of the five PDF-stack binaries (VERIFIED)

| File | Bytes | Version | Company | Product | Authenticode |
|---|---:|---|---|---|---|
| `dotNetFx40_Full_x86_x64.exe` | 50,449,456 | 10.0.21009.0 | Microsoft Corporation | Microsoft® .NET Framework (Box Stub) | YES |
| `gslite.exe` | 15,499,441 | 9.14.17.0.17 | Free Distribution | GPL Ghostscript Lite | NO |
| `pdfpowertool_setup.exe` | 2,287,977 | 4.0.0.11 | pdfpowertool.com | PDF Power Tool | NO |
| `Setup_BullzipPDFPrinter_11_1_0_2600_PRO_EXP.exe` | 11,075,872 | 11.1.0.2600 | Bullzip | Bullzip PDF Printer Professional and Expert Setup | YES |
| `xpdfsetup.exe` | 1,081,385 | 3.3.4.0.4 | Free Distributions | Xpdf Lite | NO |

[P11 | analysis/BATCH-11/pe-envelope.md | §1 the envelope table.] All five are PE32 / x86 / `WINDOWS_GUI`; the four Inno-Setup-based ones carry an overlay of 90–99 % and import the same ten DLLs [P11 | analysis/BATCH-11/pe-envelope.md | §1 and §2]. **No RealLab vendor code exists anywhere in this layer** — the scan for `real lab` / `RL_SETUP` / `Lab_data` / `.mdb` / `Attach_*` / `Bullzip` / `BZPDF` / `PDF Printer` / `gslite` / `ghostscript` / `pdftops` / `xpdf` / `pdfpowertool` inside the five files returns **0 hits for every pattern** [P11 | pdf-print-stack.md | §1 the "no vendor references" table].

---

## 7. Reporting

### 7.1 DataReport inventory for V2 — 66 objects (VERIFIED)

The V2 executable declares **66 DataReport objects** [P11 | analysis/BATCH-04/vb6/v1605/objects.json | the 66 `datareport` entries in the `objects` array]. Every DataReport has **0 methods except three** — `Reporthistory` (1), `Reporthistory2` (1) and `zarf` (1) [P11 | analysis/BATCH-04/vb6/v1605/objects-full.txt | `# 210 objects`].

**DataReports with a documented business meaning (VERIFIED, one-for-one — 21 of the 66):**

| # | DataReport | Documented meaning |
|---:|---|---|
| 1 | `RPTPatientVisit` | patient-visit report |
| 2 | `ReportFatoraC` | coagulation-factors report |
| 3 | `ReportFatorareset` | coagulation-factors reset report |
| 4 | `ReportFatorareset8` | coagulation-factors reset (copy 8) |
| 5 | `ReportIGE1` | IgE allergy report (1) |
| 6 | `ReportIGE1s` | IgE allergy report (short) |
| 7 | `ReportLBC` | LBC report |
| 8 | `ReportLBCs` | LBC report (short) |
| 9 | `ReportPCR` | PCR report |
| 10 | `ReportPCRs` | PCR report (short) |
| 11 | `ReportPatPhone` | patient-phone report |
| 12 | `ReportSMS` | SMS message report |
| 13 | `ReportTestTime` | test-duration report |
| 14 | `ReportZN` | zinc report |
| 15 | `ReportZNs` | zinc report (short) |
| 16 | `Reportliver7his` | liver history report (7) |
| 17 | `Reportlivers7his` | liver history report (7, short) |
| 18 | `Reportmony01` | financial report 01 |
| 19 | `Reportmony11` | financial report 11 |
| 20 | `Reportmony5` | financial report 5 |
| 21 | `pricelistsN` | price list |

[P11 | analysis/V-CD-2019/03-capabilities.md | §3 the DataReport table.] The naming convention is regular: the `s` suffix denotes the **short** variant of its partner (`ReportIGE1`/`ReportIGE1s`, `ReportLBC`/`ReportLBCs`, `ReportPCR`/`ReportPCRs`, `ReportZN`/`ReportZNs`, `Reportliver7his`/`Reportlivers7his`, `Reportanyreport`/`Reportanyreports`, `Reporturine`/`Reporturines`, `Reportcross`/`Reportcrosss`, `Reportsemen1`/`Reportsemen1s`, `Reportsemen2`/`Reportsemen2s`, `Reporttotals`/`Reporttotal`, `Reportliver`/`Reportlivers`, `Reportliver7his`/`Reportlivers7his`) — **INFERRED** from the 66-name list.

**Complete V2 DataReport list (66) — VERIFIED:**

`logindetect` · `pricelists` · `pricelistsN` · `reportculutre` · `reportculutres` · `reportstatic1` · `repotrwidal` · `repotrwidals` · `rpttotaliss` · `rpttotalisss` · `statisReport` · `zarf` · `ReportFatora` · `ReportFatoraC` · `ReportFatoraS` · `ReportFatorareset` · `ReportFatorareset8` · `ReportIGE1` · `ReportIGE1s` · `ReportLBC` · `ReportLBCs` · `ReportPCR` · `ReportPCRs` · `ReportPatPhone` · `ReportSMS` · `ReportSugar` · `ReportSugars` · `ReportTestTime` · `ReportZN` · `ReportZNs` · `Reportanyreport` · `Reportanyreports` · `Reportcross` · `Reportcrosss` · `Reporthistory` · `Reporthistory2` · `Reportinstrument` · `Reportliver` · `Reportliver7his` · `Reportlivers` · `Reportlivers7his` · `Reportlog` · `Reportmony01` · `Reportmony1` · `Reportmony11` · `Reportmony2` · `Reportmony3` · `Reportmony4` · `Reportmony5` · `Reportqc` · `Reportsemen` · `Reportsemen1` · `Reportsemen1s` · `Reportsemen2` · `Reportsemen2s` · `Reportshareka` · `Reporttotal` · `Reporttotals` · `Reporturine` · `Reporturines` · `Reportworkp` · `Reportwp` · `Reportwpm` · `Reportwpot` · `Reportwpt` · `RPTPatientVisit` [P11 | analysis/BATCH-04/vb6/v1605/objects-full.txt | `# 210 objects`].

### 7.2 The `Data\*.ini` template model

**VERIFIED.** 223 files / 114 categories; each file is one report template for one clinical category, plus the `_S` secondary variant for 109 of them (§4.1 above). The architectural precedence is:

```
Data\*.ini  +  Cache\*.rtf  +  normalrange  +  testtable  +  converts
                    ↓
        real lab system.exe  (VB6)  ← reads them at run time
                    ↓
      DataReport object (66) → printer role → Windows spooler → PDF driver
```

[P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §3.3 the precedence diagram.]

**Two consequences that matter for re-implementation (VERIFIED):**
1. The `.ini` files carry **measurement units that no language would use** (twips) ⇒ the system is reading them to place the columns [P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §3.3 evidence item 1].
2. `normalrange` carries **14 fields with exactly the same names as the manual's normal-range window** (`normalrang`, `testunit`, `lowlimit`, `highlimit`, `nolowexe`, `nohighexe`, `lowcomment`, `highcomment`, `sex`, `firstold`, `secondold`, `ageunit`, `REFRANGE`) ⇒ the manual documents the schema, not a paraphrase of it [P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §3.3 evidence item 3].

### 7.3 The 223 report-profile templates, the 114 catalogue categories and the three printers in use

**VERIFIED — V2 profile census.** `Data\*.ini` = **223 files** — the V2 payload's report-profile template set [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1, the `Data\*.ini` row]. The template catalogue groups them into **114** distinct categories with a **114 primary + 109 `_S` (secondary)** variant split; that split is derived from the catalogue of the shipped templates and is not stated by a V2-primary artefact [P11 | analysis/BATCH-02/ini/parsed.csv | 223 rows; P11 | analysis/BATCH-02/ini/test-catalogue.csv | 114 rows].

**Per-category totals (reproducible from the template catalogue — a catalogue-level aggregate, not a V2-published figure):** `columns_configured` sums to **1,180** across the 114 categories (10 in 69 categories, 11 in 36, 12 in 4, 13 in 2, 20 in 1, 0 in 2); `colors_configured` sums to **2,238** (20 × 110, 19 × 2, 0 × 2); `fonts_configured` sums to **1,248** (16 × 78, 0 × 36) [P11 | analysis/BATCH-02/ini/test-catalogue.csv | the three columns].

**Printers bound per profile — the shipped values (VERIFIED, computed from `parsed.csv`):**

| `setupx.reportprinterx` | Profiles (files) | Categories |
|---|---:|---:|
| `HP LaserJet 1100 (MS)` | **212** | **108** |
| `HP LaserJet 1100` | **8** | **4** |
| `HP LaserJet P1005` | **1** | **1** |
| *(no printer key)* | **2** | **2** (`REPORT.ini`, `data.ini`) |
| `Send To OneNote 2007` | **0** | **0** |
| `HP LaserJet 1018` | **0** | **0** |

[P11 | analysis/BATCH-02/ini/parsed.csv | the `printer` column; P11 | analysis/BATCH-07/ini-key-delta.csv | the `setupx.reportprinterx` rows; P11 | analysis/BATCH-02/ini/printer-settings.csv | the per-printer category list]. **The V2 profile set uses three real printer models** — `HP LaserJet 1100 (MS)`, `HP LaserJet 1100` and `HP LaserJet P1005` — while the **global** roles in `bin\SETING.ini` point at a fourth, different device, `HP Officejet 6000 E609a Series` [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4].

### 7.4 The report-design surface (V2)

The `reportsetup` / `reportsetup2` windows expose, per report profile: the window title, the main headings (report name, side title, normal-range title, doctor's signature, comment), page and item alignment, item colours, the five print toggles of §5.4, the three margin values, a per-report printer override, and the header/footer colour editor with the 12 separator lines and the patient-history line thickness [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §11 points 1–7; P11 | analysis/BATCH-05/manuals/RLS_Learn.txt | «6 -1…6 -5»].

---

## 8. Document generation

### 8.1 The RTF method-sheet library (29 documents)

**VERIFIED.** The library is `Cache\*.rtf` — **29 documents**, all created by **Microsoft Word 2002 (`Microsoft Word 10.0.2627`)**, company `ais group`, encoding **1256** (Arabic Windows) with `\adeflang3073`, creation dates **2010-07-15 → 2010-07-16** [P11 | analysis/BATCH-02/rtf/test-library.md | the header line and §2 the content census]. **These 29 sheets ship inside the V2 payload** (`real lab system\RL_CD2019Access\Cache\`), so their content is V2-shipped content [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 the `Cache\` payload table].

**These are test *descriptions*, not report templates** — they carry sample type, measurement principle, reference interval, clinical significance and critical thresholds [P11 | analysis/BATCH-02/rtf/test-library.md | §1 the catalogue table and §4 the three-layer knowledge model].

**The 29 files (VERIFIED):** `006.rtf` · `007.rtf` · `008.rtf` · `009.rtf` · `013.rtf` · `015.rtf` · `020.rtf` · `023.rtf` · `030.rtf` · `038.rtf` · `039.rtf` · `056.rtf` · `057.rtf` · `070.rtf` · `077.rtf` · `079.rtf` · `102.rtf` · `175.rtf` · `176.rtf` · `180.rtf` · `295.rtf` · `310.rtf` · `311.rtf` · `315.rtf` · `316.rtf` · `317.rtf` · `420.rtf` · `495.rtf` · `500.rtf` [P11 | analysis/BATCH-02/rtf/report-structure.md | §1 the 29-row table; P11 | analysis/BATCH-02/rtf/test-library.md | §1 the 29-row catalogue].

**Content census (VERIFIED):** `sample_type` in **26 of 29** · `clinical_significance` in **17** · `reference_intervals` in **9** · `method_note` in **8** · `interpretation` in **2**; **2** documents carry embedded images; the generating application is `Microsoft Word 10.0.2627` in **20** of them; creation range 2010-07-15 → 2010-07-16 [P11 | analysis/BATCH-02/rtf/test-library.md | §2 the content census].

**The six critical-threshold sheets (VERIFIED):**

| Test | Thresholds | File |
|---|---|---|
| CBC | `Hgb < 5 or > 20 g/dL` · `Hct < 15% or > 60%` · `WBC < 500 or > 50,000/mm3` · `Platelets < 50,000 or > 999,000/mm3` | `056.rtf` |
| BUN / Urea | `> 40 mg/dL` (no dehydration / no renal-disease history) · `> 100 mg/dL` (renal-disease history) · `> 20 mg/dL` rise in 24 h (acute renal failure) | `013.rtf` |
| Bilirubin | newborn `> 15 mg/dL` · SI `> 257 µmol/L` | `015.rtf` |
| Ionised calcium | `> 6.29 mg/dL` (SI `> 1.57`) · `< 3.1 mg/dL` (SI `< 0.78`) | `175.rtf` |
| Total calcium | `> 12 mg/dL` (SI `> 2.99` — coma/death) · `< 7 mg/dL` (SI `< 1.75` — seizure/death) | `176.rtf` |
| Sodium | `< 80 mEq/L` · `> 115 mEq/L` | `180.rtf` |

[P11 | analysis/CUMULATIVE/04-clinical-rules.md | §4 the critical-threshold table; P11 | analysis/BATCH-02/rtf/test-library.md | §1b the extracted thresholds.]

**Shipped payload (VERIFIED).** BATCH-08 delivered the **2019 copies** of `Cache\*.rtf` — 29 entries, **29/29 verified MATCH** by SHA-256 and size, verdict `DRAFT_ACCEPTED` [P11 | batches/BATCH-08/ingest-report.md | the header table: "Archive entries 29 · Verified (SHA-256 + size) 29 · Verdict DRAFT_ACCEPTED"]. ⇒ **The 29 method sheets shipped on the 2019 disc are the library described above**, with the same creation dates (2010-07-15 → 2010-07-16) and the same generating application [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §7 "طبقة التوثيق — Cache\*.rtf"].

**One anomaly (VERIFIED, unexplained).** `056.rtf` is **16,953,057 bytes** while the other 28 total **3,802,324 bytes** — it carries 4 `\pict` blocks and 1,720 text characters; the archive labels this a **HYPOTHESIS** ("a printed template for a single test containing a large results table, or embedded data") and states it needs a separate extraction [P11 | analysis/BATCH-02/rtf/report-structure.md | §4 the 056.rtf exception].

### 8.2 The Flash presentation library (13 presentations)

**VERIFIED.** `Cache\*.exe` is **not** an interactive report host — it is a library of **13 animated clinical-training presentations** about laboratory science and quality, in Arabic and English [P11 | analysis/CUMULATIVE/09-presentation-library.md | §1 the correction].

**Technical structure (VERIFIED):** the player is **Macromedia Flash Player 8.0 r22** — identical in all 13; the SWF overlay always begins at byte **1,687,552**; the SWF format is uncompressed `FWS`, version 5; the stage is **640×480** at **15 fps**; playback is a **slide show** — a `DefineVideo` tag per frame carrying an independent **baseline JPEG**; control is 4 `DefineButton2` buttons plus one `DefineSprite` (the player chrome); **379** frames were extracted [P11 | analysis/CUMULATIVE/09-presentation-library.md | §2 the technical table].

**The 13 presentations (VERIFIED — titles, language and frame counts):**

| # | File | Title | Lang | Frames |
|---:|---|---|---|---:|
| 1 | `001.exe` | **الأخطاء الشائعة في المعامل** | ar | 28 |
| 2 | `002.exe` | **Laboratory Safety** | en | 20 |
| 3 | `003.exe` | **التحليل الطبية** | ar | 23 |
| 4 | `004.exe` | **Liver Function Tests** | en | 12 |
| 5 | `005.exe` | **Lipids & Glucose** | en | 22 |
| 6 | `006.exe` | **Cardiac Enzymes** | en | 18 |
| 7 | `007.exe` | **C.B.C (BLOOD FILM)** | en | 43 |
| 8 | `007a.exe` | **C.B.C and Anemia** | en | 30 |
| 9 | `008.exe` | **Microbiology** | en | 51 |
| 10 | `009.exe` | **1-URINE ANALYSIS** | en | 34 |
| 11 | `010.exe` | **ELISA & PCR** | en | 16 |
| 12 | `011.exe` | **IMMUNE System — Ag ~ Ab Reaction Application in Serology** | en | 58 |
| 13 | `012.exe` | **IMMUNOHISTOCHEMISTRY & IMMUNOSTAINING** | en | 24 |

[P11 | analysis/CUMULATIVE/09-presentation-library.md | §3 the 13-presentation table.] Language split: **2 Arabic**, **11 English** [P11 | analysis/CUMULATIVE/09-presentation-library.md | §3 the `Lang` column].

**Shipped payload (VERIFIED).** BATCH-09 delivered the **2019** copies of `Cache\*.exe` — 13 entries under `real lab system\RL_CD2019Access\Cache\`, archive SHA-256 `94E773F3DD5A3122C297BCEF5339C00A9ABFED631636D121B7553132E7C35AA9`, **13/13 verified MATCH**, verdict `DRAFT_ACCEPTED` [P11 | batches/BATCH-09/ingest-report.md | the header table and the 13-row per-file table]. ⇒ **The 13 presentations are shipped with the V2 disc as the library described above** (`SAFlashPlayer` 8.0 r22 + SWF 640×480) [P11 | reports/Stage-7-V-CD-2019-Final-Report.md | §2 the decisive BATCH-09 result].

**Clinical content note (VERIFIED for `001.exe`):** the 28-frame Arabic presentation constitutes a compressed specification of standard laboratory practice — errors before / during / after analysis, HBV and EBV interpretation, Levey-Jennings rules, critical-value reporting (2 of 3 samples), infection-control rules (1–15), and patient confidentiality [P11 | analysis/CUMULATIVE/09-presentation-library.md | §4 note 3].

**The training layer (VERIFIED).** The documentation and training layer of the shipped disc comprises **57 items** — 13 Flash presentations + 29 RTF method sheets + 15 CHM help topics — and is frozen in that state [P11 | reports/Stage-7-V-CD-2019-Final-Report.md | the ISS-43 closure note].

### 8.3 The training video (V2 payload)

**VERIFIED.** `RL_CD2019Access\RLS_Learn.wmv` — 85,279,236 bytes, ASF/WMV container, **2120.199 s = 35:20.20**, video `wmv3` (Main profile, **1360×768**, **15 fps**, 262 kbps), audio `wmav2` (44,100 Hz, **mono**, 48 kbps, `language=eng`), VBR, creation date **2011-03-24**, encoder WMFSDK 12.0.7601.17514 (Windows 7 era), 5,000 ms precroll; container title `real lab learn` [P11 | analysis/V-CD-2019/10-training-video.md | §1 the technical table]. The archive states it is a **live screen recording of RealLab running**, not a slide deck [P11 | analysis/V-CD-2019/10-training-video.md | §2].

**Screen events observed (VERIFIED, with timestamps):** desktop + RealLab icon 0 s · main window 20–440 s · **sample stamp** 360 s · patient-registration form 380 s · test-definition engine 400–580 s · **login screen** 600 s · **report preview** 620 s · result grid 640–720 s · result grid + doctor's comment 700–740 s · Explorer + Excel grids 740–840 s · patient-card form 860 s · "patient information" report 880 s · `real lab system` definition window 1000 s · the same window with an Arabic message 1180 s · report with an Arabic form 1420 s · company report + tables 1640 s · **report-settings window** 1740 s · **printed work sheet + statistics module** 1800–2080 s · "ريال لاب" document + result report 2100 s. **106 frames** extracted every 20 s into `analysis/BATCH-06/video/frames/` plus **7 contact sheets** in `…/sheets/` [P11 | analysis/V-CD-2019/10-training-video.md | §2 the observation table and the closing note].

**Privacy note (VERIFIED, carried forward as a constraint):** the video contains **real patient data** (anonymised names, barcode numbers, dates, results, a referring-entity name) in the frames at 360 s, 620 s and 2200 s. The archive's decision is that **none of these values are copied into any document or deliverable** — this document therefore reproduces only the *structure* of those fields. The archive also flags the product-level consequence: **the barcode itself is personal identifying data** (it embeds the patient index), so any replacement must treat the barcode as sensitive (masking / access rights / audit log) [P11 | analysis/V-CD-2019/10-training-video.md | §11 the privacy note].

### 8.4 Office-document dependencies

| Dependency | Fact | Class | Provenance |
|---|---|---|---|
| **Microsoft Word (authoring)** | the 29 `Cache\*.rtf` method sheets were authored in **Microsoft Word 2002 (`Microsoft Word 10.0.2627`)**, company `ais group`, encoding **1256** (Arabic Windows), creation dates **2010-07-15 → 2010-07-16** | **VERIFIED** | [P11 \| analysis/BATCH-02/rtf/test-library.md \| the header line and §2 the content census] |
| **Word export (statistics)** | the statistics module exports the bar chart **«عدد التحاليل»** **to Word** together with a table of test name / count / percentage | **VERIFIED** | [P11 \| analysis/V-CD-2019/10-training-video.md \| §6 «وحدة الإحصائيات — مسرود بصريًا»] |
| **Word / PDF export (portal)** | a result retrieved from the NATIGH.COM portal can be printed or exported as **Word / PDF** | **VERIFIED** | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1»] |
| **Excel in the training recording** | the screen recording shows **Explorer + Excel grids** at 740–840 s | **VERIFIED** | [P11 \| analysis/V-CD-2019/10-training-video.md \| §2 the observation table] |
| **Excel / Word output of the work sheet** | **VERIFIED.** The work-sheet window offers **Print**, **Excel Report**, **Print New Sheet** and **Save as Excel File**; the printed document is headed **WORKPAPER BY PATIENT NAME** (`No. of Patients: 3 \| Printed by: Administrator \| Thursday, 24-Mar-2011 11:34 AM`) or **WORKPAPER BY TEST NAME** (`No. of types of tests: 17`), and the recording shows a spreadsheet window with a bar chart and a statistics table | **VERIFIED** | [P11 \| analysis/BATCH-06/video/sheets/06_detail_0100s.jpg \| frames #1, #4, #15] · [P06 \| 06_detail_0100s.jpg \| frames #1, #4, #15] · [P11 \| analysis/V-CD-2019/10-training-video.md \| §7.1–§7.2 the work-sheet facsimiles] |
| **Automation mechanism behind the work-sheet output** | **NOT DOCUMENTED** — the recording shows the controls and the resulting documents, but not whether the Word-format document and the Excel file are produced by COM automation, by a template export, or by writing an intermediate file | **NOT DOCUMENTED** | [P11 \| analysis/BATCH-06/video/sheets/06_detail_0100s.jpg \| frames #1, #4] |

---

## 9. Workflow exceptions, edge cases and gaps

### 9.1 Documented failure paths and negative conditions

| # | Condition | Behaviour | Provenance |
|---:|---|---|---|
| 1 | DB server undefined at start-up | dialog «خادم قواعد البيانات غير معرف» → OK → the application closes | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1] |
| 2 | Date locale not English | dialog «رجاء تحويل التاريخ الى اللغة الانجليزية» → OK → the application closes | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §1] |
| 3 | Patient delete without permission | refused; the current user must hold the delete-patient permission | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §3 point 1] |
| 4 | Unauthorised menu action | message «أنت ال تملك الصالحية لهذا العمل راجع مدير النظام» | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «1 -4»] |
| 5 | Printing an unverified / unfinished result | gate string `Not found any Verified selected tests or result to print it` | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| 6 | Printing a test outside the whitelist | only `testcode in (6,7,8,9,14,15,16,17,18,19,20,21)` is printable (12 types) | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4] |
| 7 | Delivering a result that was never printed | blocked — printing precedes delivery; a mistaken delivery is reverted with «مستلمة» | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 point 4] |
| 8 | Barcode delivery mismatch (receipt code ≠ file code) | the system compares the two and refuses to deliver | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7] |
| 9 | Receipt lost | delivery proceeds automatically from the patient's file | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7] |
| 10 | File code never printed | delivery by direct selection from the patient list | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7] |
| 11 | Changing the outbound destination without «دائما اليه» | the new destination is **not** saved as the default and is silently discarded | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 point 4] |
| 12 | Editing the reference range for existing patients | old registrations keep the **old** range until the operator refreshes explicitly from the report window («تحديث» then «موافق») | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «3 -3»] |
| 13 | Missing age-unit range (e.g. a month range absent) | no normal is displayed for that patient even though the numeric age is equivalent | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «ملاحظة هامة فى الجزء الخاص بالنورمال»] |
| 14 | A culture added without a matching `Data\<ID>.ini` | no report layout exists for it; the template must be cloned by hand from `100.ini` | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «8 -3»] |
| 15 | A culture/antibiotic added without an ID (118–139) | the catalogue cannot be addressed by ID and the report template cannot be derived | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «8 -3»] |
| 16 | Child patient (< 12 y) without a Children-specific antibiotic | the general antibiotic list applies; the Children-specific filtering is only effective when explicitly assigned | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «9 -3»] |
| 17 | Pregnant patient | the Pregnancy-specific antibiotic appears only when the patient's pregnancy flag is set | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «9 -3»] |
| 18 | Patient search exceeding 100 rows | the list is truncated at 100 by design (data-confidentiality rule); exhaustive work must use the statistics module | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 2] |
| 19 | Attempting to change urine test number 4 | refused — its number, name and data are immutable | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 item 2] |
| 20 | Deleting the whole system data (Database Maintenance) | the operation zeroes data that the latest backup no longer contains — irreversible with respect to the shipped backup | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14] |
| 21 | Restoring a patient found only in the backup DB | the patient's code must be copied from the backup-database search and re-imported via the maintenance tools before results can be worked on or printed | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §8 point 4] |
| 22 | Installing the PDF stack | Bullzip is attempted **before** .NET 4 → the first attempt fails, the second succeeds | [P11 \| pdf-print-stack.md \| §5.1] |
| 23 | `Bullzip PDF Printer` absent or renamed | the PDF output path fails outright | [P11 \| pdf-print-stack.md \| §2.1] |
| 24 | Bullzip re-installed at a version past 11.1 | the hard-coded default output name no longer matches | [P11 \| pdf-print-stack.md \| §2.1] |
| 25 | Converting the database type in the installer | the data stays in the first database and is invisible in the second — the installer says so explicitly | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2] |
| 26 | A machine whose disk / motherboard / CPU is damaged | the licence is void and a new licence must be purchased | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4] |
| 27 | Two workstations sharing one database | report-layout edits on one machine do **not** propagate — each workstation prints its own layout | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §11 the two scope notes] |
| 28 | A stale comment left in a shaded-frame check box | the comment persists in the window and can leak into the next patient's record | [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §6 point 3] |
| 29 | Setup bootstraps launched with `start /B` and no `/wait` | the operator may start the application before ActiveX and fonts are installed; the log lands at `C:\setup.log` in the disk root | [P11 \| pdf-print-stack.md \| §5.2] |
| 30 | Installing with the shipped `Patients_backup.mdb` | the shipped backup does not carry the additions held in `Patients.mdb`; restoring it loses them | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6 the `Patients_backup.mdb` row] |

### 9.2 Open questions carried forward (NOT RECOVERABLE from this archive)

| # | Question | Archive reference |
|---|---|---|
| V-04 | What exactly is `Patient_samples` — sample **tracking** or a sample **repository**? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-04] |
| V-05 | How are `grant13..grant17` plus `useraccounts.gtype/hdd1/hdd2` actually used? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-05] |
| V-07 | What does `LBC` stand for? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-07] |
| V-09 | What is the difference between the SQL-Server `Patients` table and the Jet `patientinfo` table? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-09] |
| V-03 / V-08 | What is the `loger` table and does it log HIPAA / session events? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-03 and V-08] |
| V-01 | What are `Attaching.sql` and `Attach_database.bat`? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-01] |
| V-02 | Why is a `win32_processor` table created? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-02] |
| V-10 | What are the new `Insulin` and `antibio` structures? | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-10] |

**NOTE ON IDs.** The `V-##` identifiers in the table above are **documentation-only** labels of the archive's open-question register; they are not identifiers in the RefLab binaries or database. The `G-##` identifiers used from the next table onwards are **documentation-only** labels of this specification.

**Additional gaps identified by this extraction (NOT RECOVERABLE):**

| # | Gap | Why it matters | Evidence of the gap |
|---:|---|---|---|
| G-1 | The exact shipped values of `bin\SETING.ini` `[setup]` keys `papersize` and `reportstart`, and of `topvalue`/`bottomvalue`/`leftvalue`/`rightvalue` | the layout constants of the shipped configuration were not separately extracted | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §4 lists only the printer / `reporthead` / font rows for `SETING.ini`] |
| G-2 | The **exact** `Data\*.ini` key count per file in V2 | the per-file profile size is recorded in `ini-diff-summary.json` (`size_delta` and its two size fields) but the V2 key census was not recomputed | [P11 \| analysis/BATCH-07/ini-diff-summary.json \| the per-file size fields] |
| G-3 | Whether `Data\*.ini` is copied by the installer from `bin\` or shipped in place on the 2019 disc | the installer copies the deployment payload, and `Data\` is part of it, but the copy order relative to `bin\Data\` was not traced | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3.1 the copy commands] |
| G-4 | The **control-level** identities (control names, captions, positions) of every form | only the aggregate control **counts** survive the decompilation; `ISS-23`/`ISS-24` remain open | [P11 \| analysis/BATCH-04/vb6/v1605/forms-blob.txt \| the count-only table] |
| G-5 | The internal layout of the **66 DataReports** | the report *designs* were never extracted; only the `Data\*.ini` layout model was recovered | [P11 \| analysis/BATCH-04/vb6/v1605/objects-full.txt \| the 66 `datareport` entries] |
| G-6 | The **`056.rtf`** anomaly (16.95 MB vs 3.8 MB for the other 28) | a single sheet holds more than the entire library; its content is still a HYPOTHESIS | [P11 \| analysis/BATCH-02/rtf/report-structure.md \| §4] |
| G-7 | The behaviour of the **NATIGH.COM portal** itself | it is a third-party service outside the archive | [P11 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| «12 -1»] |
| G-8 | The **`RL_Show.pdf`** (77 pages) | it has no extractable text (only 77 characters); it was printed via Bullzip and is image-only | [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §4 the extraction limitations] |

### 9.3 Design-relevant constraints implied by the evidence (INFERRED)

1. **The knowledge layer is text and can be imported as-is** — `testtable` (609 tests), `normalrange` (852 ranges), `constanttable`, the **223** report-profile templates (114 catalogue categories), the 29 RTF sheets, the 13 presentations. Adding a new test requires **no code change** [P11 | analysis/BATCH-02/rtf/test-library.md | §4 the closing design note] · the catalogue counts at [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 rows 3-1 and 3-3].
2. **Report layout is data-driven, not code-driven** — 7 column positions, 20 colour slots, 16 per-position font quadruples, print flags, 12 separator lines; the application reads them at run time [P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §3.3].
3. **The PDF layer is fully replaceable** — 0 vendor references inside the five print-stack binaries; the path is a Windows driver integration [P11 | pdf-print-stack.md | §1 and §5].
4. **Localisation is per-form** — no central translation layer exists [P11 | analysis/V-CD-2019/10-training-video.md | §5].
5. **Every clinical write is auditable** — `edituser`/`editdate`/`printuser`/`printdate`/`printnum`/`taslimuser`/`taslimdate`/`natighu`; the audit fields are the strongest inherited accountability control and must survive any re-implementation [P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §4 and §6 requirement 4].
6. **The barcode is personal data** — it embeds the patient index in a 13-digit composite, so it must be treated as sensitive [P11 | analysis/V-CD-2019/10-training-video.md | §11].

---

## Provenance and method

This document was compiled from the source findings file `05_workflows_ui_findings.md`, which had already been extracted from the RefLab V2 evidence archive, and was then reconciled against the archive itself: every data-derived figure was re-checked against a V2-primary artefact, and the training-video frame sheet `analysis/BATCH-06/video/sheets/06_detail_0100s.jpg` was re-read directly to establish the work-sheet's Excel/Word output controls and the spreadsheet frame cited in WF-14 and §8.4. The evidence roots are the patch deliverable trees named in the *Evidence base and method* section above, and every factual statement carries a `[Pxx | file.ext | anchor]` marker naming the file and the anchor it was read from. Claims are classified **VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED** or **NOT RECOVERABLE** as defined in the legend at the head of this document; where a figure quoted by the archive could not be reproduced from the underlying file, the discrepancy is flagged in place (the colour-slot count in §4.3 is the one such correction), and where a figure could be supported only by a catalogue of the shipped payload's own files, it is re-based to the V2-primary artefact that states it or marked **NOT RECOVERABLE**. All inventory figures quoted here — 26 workflows, 132 forms, 9 modules, 3 classes, 66 DataReports, 6 printer roles and 4 PDF output roots — are counted from the row tables of the source findings file by the method stated at the head of this document. The `WF-##`, `CAP-##`, `V-##` and `G-##` identifiers are **documentation-only** labels; they do not exist as identifiers in the RefLab binaries, database or vendor documentation.
