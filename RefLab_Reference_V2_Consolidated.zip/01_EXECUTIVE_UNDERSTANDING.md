# 01 — Executive Understanding: RefLab Version 2 (V2)

> **Document 1 of 9.** Scope, purpose, navigation, evidence legend and coverage status are in
> `00_INDEX.md`. This document states what the supplied evidence establishes about the system as a
> whole. Detailed specifications live in `02_…`–`08_…`.

---

## 1. System identity

| Attribute | Evidenced value | Source |
|---|---|---|
| Product name (as declared in the binary) | `real lab system` | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info.ProductName]` |
| Vendor / company | `RealLab` | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info.CompanyName]` |
| File description | `RLS 1.605` | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info.FileDescription]` |
| File / product version | **1.605** (FileVersion and ProductVersion) | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info]` |
| Internal / original filename | `real lab system` / `real lab system.exe` | same |
| Copyright / trademark holder | `RealLab` | same |
| Author comment embedded in the binary | `ais_soft_group@yahoo` | same |
| Specification line | **RealLab V-CD-2019** — the "second edition" | `[P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 1]` |
| Executable size | 76,292,096 bytes | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | size_bytes]` |
| Executable SHA-256 | `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0` | same |
| Recorded PE build stamp | `1595435962` = **2020-07-22 16:39:22 UTC** | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | pe.timestamp]` |
| Implementation technology | Visual Basic 6 (native code; `MSVBVM60.DLL`, 231 imported functions) | `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | vb6 + pe.imports]` |
| Linker / subsystem / entry | linker 6.0, `IMAGE_SUBSYSTEM_WINDOWS_GUI`, entry RVA `0x7142c`, 3 sections, no overlay | same |
| Deployment root of the V2 payload | `real lab system\RL_CD2019Access\` | `[P11 | 02-Versions/Version-Identification.md | §2 classification table]` |

**Reading the version number.** `1.605` is the file version of the V2 executable; the analysis
corpus names the same payload "V-CD-2019" because it is the payload that ships on the 2019
deployment disc. Both tokens denote the same artefact, and this specification uses them
interchangeably, always for V2 only. `[P11 | analysis/V-CD-2019/00-baseline-summary.md | §1]`

**Note on the build stamp.** The PE timestamp is attacker-editable in principle; it is therefore
*the recorded build stamp of the V2 file*, not proof of authorship. `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | pe.timestamp]`

---

## 2. Evidenced purpose

The evidence establishes RefLab V2 as a **clinical laboratory information system** for a medical
diagnostic laboratory: it registers patients and referring entities, records test orders, captures
per-profile analytical results against reference ranges and critical thresholds, produces printed
and PDF reports and worksheets, settles accounts, manages stock, and distributes results to
patients and to third parties.

This purpose is evidenced from several independent directions:

* The in-application help (CHM `real lab system help.chm`, 15 topics) documents 15 capabilities
  spanning exactly these activities: run and log in, manage patient data, print the patient
  barcode, enter test results, deliver results, search for a patient, add/modify test data, manage
  reference ranges, customise reports, manage out-referred samples, accounts/stocktaking/lab
  accounting, back up the system database, clinical constants and calculation factors, the fixed
  test-numbering constraint, and the keyboard shortcuts and results UI.
  `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic index]`
  `[P11 | analysis/V-CD-2019/03-capabilities.md | §1 capability table]`
* The vendor's own capability catalogue (`RLS_Learn.pdf`, 7 functional modules) enumerates **57
  numbered capability rows** — patient registration, patient amendment, result entry, combined and
  blank reporting, farm result entry, patient search, visit and medical history, electronic
  delivery, user and permission administration, server configuration, accounting, and general
  settings — which collapse into **21 functional groups**.
  `[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.1–§2.7]`
* The shipped data model is a clinical data model: `patientinfo` (patient master), `patienttest`
  (order/result index), per-profile result tables, `normalrange` (reference intervals),
  `constanttable` (clinical constants and calculation factors), `cultures` (microbiology),
  `antibio` (antibiotic catalogue), `history` (audit), `payment`, `smslist`, `MyLabSetting`.
  `[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE blocks]`

**Deployment model.** V2 is a **single-workstation, Windows desktop application** with a local
database, offering an optional Microsoft SQL Server hosting mode for multi-branch operation.
Branch scoping is implemented per installation (`branche`, `Labbranch`, `labid`).
`[P11 | analysis/V-CD-2019/00-baseline-summary.md | §3]`
`[P04 | analysis/BATCH-04/schema/ddl-all.txt | ALTER Table Patients ADD branche smallint]`

---

## 3. System scope

### 3.1 In scope

| Layer | What it comprises |
|---|---|
| Presentation | 132 VB6 forms, 66 VB6 DataReports, 9 modules, 3 classes; 11,622 controls recovered across 131 form blobs |
| Business logic | 8,026 VB6 procedures across the 210 objects |
| Configuration / template | 228 `.ini` template files (`Data\*.ini` per profile, `SETING.ini`, `IDCARD.INI`, `BASE.ini`), plus a 29-file RTF method-sheet library and a 13-file Flash clinical-teaching library |
| Data | Jet 4 (Microsoft Access) `Patients.mdb` as the shipped store, with a Microsoft SQL Server hosting option; an embedded startup schema DDL that adds 132 distinct columns across 29 tables and creates 14 tables |
| Printing / documents | An external PDF printer driver plus Ghostscript Lite, Xpdf and PDF Power Tool; six logical printer roles; four PDF output roots; Word and Excel automation for worksheets |
| Platform | Windows 7 / Windows XP x86, Visual Basic 6 SP6 runtime, Jet 4 engine, MDAC, .NET Framework 4.0 |
| Deployment | `RL_SETUP.exe` plus 7 `Setup*.bat` scripts and two OS-specific CAB payloads (WIN7, WINXP) |

### 3.2 Explicitly outside the evidenced system boundary

* **No web front end, no cloud service, no mobile client.** The only electronic delivery channel
  evidenced is a third-party portal integration (NATIGH.COM) plus an SMS gateway.
  `[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.1 row 1-12/1-12a/1-12b]`
* **No instrument interface (HL7/AST/LOINC).** No evidence of bidirectional analyzer
  communication exists in the archive; result entry is manual or by paste.
* **No billing/ERP integration.** Accounting is internal to the application (`payment`,
  `frm_money`, `moneypaid`, price lists, stocktaking).

---

## 4. Scale — evidenced figures

Every figure below is reproducible from a named artefact; the counting method is stated.

| Measure | Count | Counting method | Source |
|---|---:|---|---|
| VB6 objects in the V2 binary | **210** | one row per entry of the `objects` array; 132 forms + 66 DataReports + 9 modules + 3 classes | `[P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats + objects]` |
| VB6 procedures | **8,026** | sum of the `methods` field across all 210 objects (the object-model `stats` block). *Counting note:* the per-object method column reproduced in `02_FUNCTIONAL_SPECIFICATION.md` §1.3 sums to 8,038 — 12 more than the `stats` figure; both figures are carried there with the discrepancy stated | same |
| Form control blobs recovered | **131 of 132** forms, **11,622** controls in total | data rows of `forms-blob.txt` (the form without a blob is `labxxyyzz`, 3 methods) | `[P11 | analysis/BATCH-04/vb6/v1605/forms-blob.txt | header + table]` |
| Documented in-application capabilities | **15** (CAP-01…CAP-15) | one per CHM topic group | `[P11 | analysis/V-CD-2019/03-capabilities.md | §1 table]` |
| Vendor catalogue capability rows / groups | **57** rows in 7 modules → **21** groups | one row per numbered catalogue entry; groups per §9.4 of `02_FUNCTIONAL_SPECIFICATION.md` | `[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.1–§2.7]` |
| V2-specific objects | **41** = 20 code objects + 21 DataReports | one per entry of the `added[]` list in the object-model diff (`analysis/BATCH-04/vb6/v1605/`, the object-diff JSON), split by the `type` field | `[P11 | analysis/BATCH-04/vb6/v1605/ | object-diff JSON, "added" array]` |
| Function specifications in `02_FUNCTIONAL_SPECIFICATION.md` | **136** | 15 (A) + 20 (B1) + 21 (B2) + 57 (C) + 11 printing (D) + 12 installer (E); layers are disjoint by construction | `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3–§5]`, `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §1–§6]` |
| Tables in the shipped V2 database | **103** | distinct `CREATE TABLE` names in the `mdbtools` dump of the shipped `Patients.mdb` | `[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | 103 CREATE TABLE blocks]` |
| Columns in the shipped V2 database | **1,682** | column definition lines in the same dump | same |
| Tables addressed by V2 SQL | **117** | distinct table names in the 1,797 SQL statements extracted from the binary | `[P11 | analysis/BATCH-04/sql_v1605/tables.csv | 117 data rows]` |
| Embedded startup DDL statements | **268** = 27 `CREATE TABLE` + 241 `ALTER TABLE` | literal count in the binary's string pool | `[P04 | analysis/BATCH-04/schema/ddl-all.txt | full file]` |
| Effective startup schema change | **132** distinct (table, column) pairs added across **29** tables; **13** type-change statements (12 distinct pairs); **14** distinct tables created | deduplicated by target; the DDL is dual-dialect (T-SQL and Jet), so statement count ≠ effect count | `[P04 | analysis/BATCH-04/schema/ddl-all.txt | full file]` |
| Configuration template files | **228** `.ini` files in the V2 `Data\` template store — the **223** direct `Data\*.ini` profile templates plus **5** in the `Data\data_emp\` sub-store | file inventory of the V2 payload (`Data\*.ini` + `Data\data_emp\*`) | `[P11 | 07-Batch-Ingestion/manifests/BATCH-07-files.csv | Data\ rows]`, `[P11 | analysis/CUMULATIVE/06-configuration.md | §7]` |
| Configuration key deltas | **3,712** = 1,970 ADDED + 897 REMOVED + 845 CHANGED | one row per key in the key-level delta table | `[P07-08 | analysis/BATCH-07/ini-key-delta.csv | 3,712 data rows]` |
| Logical printer roles | **6** (`reportprinter`, `reportprinterx`, `zarfprinter`, `barcodeprinter`, `waslprinter`, `IDprinter`) | one per printer-role record | `[P11 | pdf-print-stack.md | §2.4]` |
| PDF output roots | **4** (`D:\PDF\Contracts\`, `D:\PDF\Free\`, `D:\PDF\Individual\`, `D:\PDF\LabToLab\`) | one per output-root record | `[P11 | pdf-print-stack.md | §2.2]` |
| Printable test codes | **12** (`6,7,8,9,14,15,16,17,18,19,20,21`) | literal list in the print query | `[P11 | pdf-print-stack.md | §2.5]` |
| Installer payload members | **48 per OS target** (WIN7, WINXP); 32 byte-identical, 16 differing | member-level inventory with SHA-256 per member | `[P11 | cab-inventory.csv | 96 data rows]` |
| Inventoried deployment artefacts | **837** | one row per artefact in the full-file SHA-256 ledger | `[P11 | ledger.csv | rows RLC-0001…RLC-0837]` |
| Documented end-to-end workflows | **26** (WF-01…WF-26) | one per workflow block in `05_WORKFLOWS_AND_UI.md` | `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3–§5]` and the CHM/UI artefacts |

> **Counting note.** The 131-vs-132 form figures are not a conflict: the object model declares 132
> forms, and control blobs were recovered for 131 of them.

---

## 5. Architecture

The evidence establishes the following component structure. It is a *layered* system with a
hard-coded external print stack and a self-updating schema.

```
┌───────────────────────────────────────────────────────────────────────────┐
│ PRESENTATION (VB6, 210 objects / 8,026 procedures)                        │
│   132 forms · 66 DataReports · 9 modules · 3 classes · 11,622 controls    │
└───────────────┬───────────────────────────────────┬───────────────────────┘
                │                                   │
┌───────────────▼──────────────┐   ┌────────────────▼──────────────────────┐
│ CONFIGURATION / TEMPLATE     │   │ BUSINESS-RULE LAYER (embedded SQL +   │
│ 228 .ini templates            │   │ DDL in the binary's string pool)     │
│ SETING.ini · IDCARD.INI     │   │ 1,797 SQL statements · 268 DDL stmts  │
│ BASE.ini · 29 RTF · 13 Flash │   │ clinical constants · reference ranges  │
└───────────────┬──────────────┘   └────────────────┬──────────────────────┘
                │                                   │
┌───────────────▼───────────────────────────────────▼──────────────────────┐
│ DATA LAYER — 4 database roles over 2 engine choices                      │
│  Patients.mdb (Jet 4, 103 tables / 1,682 columns) · Branch_Data.mdb (49)  │
│  + optional SQL Server hosting (useraccounts, loger) · history · wasl    │
└───────────────┬───────────────────────────────────────────────────────────┘
                │
┌───────────────▼───────────────────────────────────────────────────────────┐
│ PRINT / DOCUMENT LAYER — fully third-party, zero first-party code        │
│  Bullzip PDF Printer (driver) → Ghostscript Lite 9.14.17 → Xpdf Lite     │
│  PDF Power Tool · Word/Excel automation (work sheets)                     │
│  6 printer roles · 4 PDF output roots · per-result print audit trail     │
└───────────────────────────────────────────────────────────────────────────┘
```

### 5.1 Component table

| # | Component | What the evidence establishes | Class |
|---|---|---|---|
| C1 | **VB6 application core** | Native Win32 GUI executable, VB6 runtime dependency, 210 objects / 8,026 procedures, no overlay, entry RVA `0x7142c` | VERIFIED |
| C2 | **Configuration / template layer** | 228 `.ini` files; per-profile report layout templates (`Data\*.ini`) with 7 column positions, colour slots, print flags, titles; `SETING.ini` and `IDCARD.INI` carry report/bill/card text; `BASE.ini` carries data-root configuration | VERIFIED |
| C3 | **Clinical constants & formulas** | `constanttable` (8 columns) with `CBCCONS`, `PTCONS` and `RATIOS` groups; unit-conversion tables `converts` (167 rows) and `testunits` (69 rows) | VERIFIED |
| C4 | **Reference-range engine** | `normalrange` (18 columns) incl. `REFRANGE Text (1)`, `pregsmok Single`, `lowcomment`/`highcomment` Memo, `sex`, `ageunit`; per-test, per-sex, per-age-unit intervals | VERIFIED |
| C5 | **Embedded SQL layer** | 1,797 SQL statements extracted from the binary, addressing 117 table names | VERIFIED |
| C6 | **Startup schema DDL** | 268 embedded DDL statements (27 `CREATE TABLE` + 241 `ALTER TABLE`), dual-dialect (T-SQL / Jet); they resolve to **132 distinct (table, column) additions across 29 tables**, **13 type-change statements (12 distinct pairs)**, and **14 distinct created tables** | VERIFIED |
| C7 | **Jet 4 Access store** | `Patients.mdb` — 103 tables / 1,682 columns; `Branch_Data.mdb` template with 49 tables | VERIFIED |
| C8 | **SQL Server hosting option** | `useraccounts` (account types, `HDD1`/`HDD2`), `loger` attendance table, `win32_processor` catalogue — SQL-Server-resident only, absent from the shipped Access store | VERIFIED |
| C9 | **Print stack** | Five third-party binaries (Bullzip setup, `gslite.exe`, `xpdfsetup.exe`, `pdfpowertool_setup.exe`, `dotNetFx40_Full_x86_x64.exe`) plus two `Setup*.bat`; the application drives the print path through `Bullzip PDF Printer` (literal at `0x6A2486`) with `EnumPrintersA`/`SetDefaultPrinterA` | VERIFIED |
| C10 | **Installer** | `RL_SETUP.exe` + 7 `Setup*.bat`; 16 `cmd.exe` invocations; two OS payloads (WIN7 / WINXP CAB, 48 members each); install manifest `SETUP.LST` | VERIFIED |
| C11 | **Documentation & learning layer** | CHM help (15 topics), `RLS_Learn.pdf` (7 modules, ~60 capabilities), training video `RLS_Learn.wmv` (35:20.20, 1360×768), setup manual `RLS_Setup.txt`, 29 RTF method sheets, 13 Flash clinical shows | VERIFIED |
| C12 | **Notifications / external channels** | SMS gateway credentials and scheduling in `MyLabSetting` (20 columns) incl. `accuntID`, `accuntpw`, `FridaySend`, `shortsms`, `Hourflag`, `Timess`, `totalsms`, `SMSSend`, `SMSbakey`, `phoneNo1..6`; NATIGH.COM result-delivery portal; `wasl` external-system interface with a `waslprinter` role | VERIFIED (schema) / INFERRED (runtime behaviour) |

### 5.2 Architectural facts that constrain a re-implementation

1. **The print layer contains no first-party code.** A scan of the five PDF-stack binaries yields
   zero occurrences of the application's own identifiers (`real lab`, `RL_SETUP`, `Lab_data`,
   `.mdb`, `Attach_*`) and zero references to the third-party tools by name inside the application
   binary — the application drives the stack purely through the Windows printing API and the
   `Bullzip PDF Printer` device name. The print layer is therefore replaceable without touching
   application logic, but it is also a **hard-coded external dependency**: the driver name *and
   its version* are literals, so a different driver version changes the application's behaviour.
   `[P11 | pdf-print-stack.md | §1 and §2.1]`
2. **The schema changes itself at startup.** The application carries its own DDL, so a replacement
   must decide whether to reproduce that behaviour, and the DDL is written in **two dialects**
   (T-SQL and Jet) whose statements are counted differently — a naive statement count overstates
   the effective change. `[P04 | analysis/BATCH-04/schema/ddl-all.txt | full file]`
3. **The UI is template-driven, not code-driven.** Report layout (column positions, colours,
   fonts, print flags, titles) lives in `.ini` files, so a re-implementation must reproduce the
   template model to reproduce report output. `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3–§5]`
4. **The installer mutates the machine beyond the application folder** — 24 self-registering
   ActiveX components and direct writes into `System32`/`SysWOW64` — so any replacement needs an
   explicit elevation and permission model. `[P10 | 12-install-media.md | §2.2]`
5. **The shipped install chain has a known ordering defect**: Bullzip is installed before the
   .NET runtime it requires, and the orphaned `SetupFN4.bat` carries a relative-incomplete .NET
   path, so the first installation attempt fails and the second succeeds.
   `[P11 | pdf-print-stack.md | §5.1]`

---

## 6. Functional domains

| Domain | Scope in V2 | Primary artefacts |
|---|---|---|
| **D1 Patient administration** | Registration, amendment, search, visit and medical history, barcode identification | forms `addpatient`, `patientview`, `patienthistory`, `patienthistory2`, `barcode`; tables `patientinfo`, `patienttest`, `patients` |
| **D2 Order entry & test catalogue** | Ordering tests, profiles, groups, analytes, units, abbreviations | forms `setup1`–`setup3`; tables `testtable`, `subgrouptable`, `testunits`, `abbreviations` |
| **D3 Result entry** | Per-profile result capture, delta checks, culture/sensitivity entry, semen and IgE-allergy profiles, sample separation | forms `result*`, `resultculutre`, `Patient_samples`, `antibioticfrm`; tables `patienttest`, `cultures`, `PTC` |
| **D4 Clinical decision support** | Reference ranges, critical thresholds, calculation constants, unit conversion, sex/age-dependent intervals | tables `normalrange`, `constanttable`, `converts` |
| **D5 Reporting & printing** | Report design, result printing, PDF output, worksheets, combined/blank reports, receipts, ID cards | forms `reportsetup`, `reportsetup2`; `Data\*.ini` templates; 66 DataReports |
| **D6 Result delivery** | Patient handover, electronic delivery through the NATIGH.COM portal, SMS notification | forms `frm_money`, `moneypaid`; tables `smslist`, `smsgroups`, `SMStemplate`, `SMSSender`, `MyLabSetting` |
| **D7 Accounts & stock** | Pricing, invoicing, settlement, price lists, stocktaking, laboratory accounting | forms `labfunction`, `z_pricelists`, `pricelistsN`; tables `payment`, `Gehats` |
| **D8 Referral samples** | Out-referred sample management | form `sarfz` |
| **D9 Administration & users** | User accounts, permission flags, attendance, branch scoping, setup | forms `users`, `userspw`, `setup`; tables `patients`, `useraccounts`, `loger`, `loggroup` |
| **D10 Maintenance & reporting** | Backup/restore/zeroing, branch-data tool, statistics, day tips | forms `labdb`, `labdb1`, `statisReport`, `static1`–`static6`; table `daytip` (20 rows) |
| **D11 Documentation & learning** | In-app help, learning catalogue, training video, method sheets, clinical animations | CHM, `RLS_Learn.pdf`, `RLS_Learn.wmv`, 29 RTF, 13 Flash |
| **D12 Deployment** | Installation, activation, OS-specific payloads, licensing | `RL_SETUP.exe`, `Setup*.bat`, `SETUP.LST`, WIN7/WINXP CABs |

---

## 7. Technical overview

### 7.1 Evidence basis (important limitation)

**Every statement in this specification is derived from static evidence.** No dynamic execution of
the V2 binary was possible on the analysis host (no Windows / Wine environment), so no runtime
behaviour was observed. The largest single limitation of the whole corpus is recorded as ISS-07 in
the issue register and is unchanged across all analysed patches.
`[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-07]`

Evidence types actually used: PE envelope analysis (per-file JSON reports), VB6 object-model
extraction (`objects.json`, the object-model diff file in `analysis/BATCH-04/vb6/v1605/`,
`forms-blob.txt`), embedded string-pool
extraction (1,797 SQL statements, 268 DDL statements), database schema dumps (`mdbtools`), INI
template key-level diffing, CHM/manual text extraction, screen-recording frame analysis, and
installer/CAB payload inspection. `[P11 | ledger.csv | rows RLC-0001…RLC-0837]`

### 7.2 Notable technical dependencies

| Dependency | Why V2 needs it | Class |
|---|---|---|
| Visual Basic 6 SP6 runtime (`MSVBVM60.DLL`) | the application itself | VERIFIED |
| Jet 4 (Access) engine — 12 engine files | the shipped local database | VERIFIED |
| 19 ActiveX controls (e.g. `MSCOMCTL.OCX`, `MSCOMM32.OCX`, `MSFLXGRD.OCX`) | the UI | VERIFIED |
| 5 laboratory fonts | report output | VERIFIED |
| MDAC / `MDAC_TYP.EXE` | OLE DB / ODBC data access | VERIFIED |
| .NET Framework 4.0 (RTM build, MSIs dated 2010-03-18) | required by the Bullzip PDF stack | VERIFIED |
| Bullzip PDF Printer 11.1 | the PDF output device | VERIFIED |
| Ghostscript Lite 9.14.17 | raster/post-processing in the PDF path (AGPL v3) | VERIFIED |
| Xpdf Lite | PDF utilities (GPL v2/v3) | VERIFIED |
| PDF Power Tool | PDF operations (commercial) | VERIFIED |
| Microsoft Word and Microsoft Excel | work-sheet and Excel-report generation (COM automation) | VERIFIED |
| Optional Microsoft SQL Server 2005 Express | multi-branch / SQL-Server hosting mode | VERIFIED |
| Visual FoxPro 6.0 runtime (`vfp6run.exe`, `vfp6t.dll`, `vfp6rrus.dll`) | listed in the redistributable manifest; most plausible explanation for the otherwise unexplained database name `VIDAS` | INFERRED |

### 7.3 Known limitations of the system as evidenced

1. **No patient data is in the evidence base.** Only the schema of the shipped database was
   ingested; row-level counts for the V2 tables are unavailable, and no real patient record appears
   anywhere in the archive. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-09 and neighbouring entries]`
2. **Procedure signatures and bodies are not recoverable.** The object-model extraction reports
   `method_entries_read: 1268`, `unique_entries: 0`, `methods_without_address: 1268` — procedure
   counts are reliable, names/parameters/bodies are not. `[P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats]`, `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-23]`
3. **DataReport designer layouts are not extractable** from the binary; only object identity, type
   and bound data are evidenced. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-24]`
4. **Control-level properties (per-control caption/text) are not recoverable** without VB6 COM
   property extraction; control counts and form geometry are recovered instead.
   `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-06]`
5. **The print-stack installers carry SHA-1 Authenticode digests and three of the five are
   unsigned**; signature verification fails although the message digests match the file contents.
   `[P11 | pdf-print-stack.md | §4]`
6. **The shipped .NET payload is an RTM 4.0 build** (MSIs dated 2010-03-18), out of support since
   2014-04-29 and not shipped with current Windows releases; it also replaces `RGB9RAST.dll`,
   a latent text-rasterisation regression surface. `[P11 | pdf-print-stack.md | §3.2]`
7. **Two application roots and three data roots are documented for the same product** — the
   supported configuration is not settled by the evidence (see `07_GAPS_AND_LIMITS.md`, conflict
   C-09). `[P10 | 12-install-media.md | §2.3]`, `[P05 | RLS_Setup.txt | fonts step]`

---

## 8. How to use this specification

| If you are… | Read |
|---|---|
| a replacement implementer sizing the data model | `04_DATA_MODEL.md`, then `03_BUSINESS_RULES.md` |
| a replacement implementer building the UI | `05_WORKFLOWS_AND_UI.md`, then `02_FUNCTIONAL_SPECIFICATION.md` §2 (CAP-01…CAP-15) |
| responsible for security review | `06_PERMISSIONS_AND_SECURITY.md` |
| responsible for print/report output | `05_WORKFLOWS_AND_UI.md` §6–§8 |
| deciding what to build first | `08_DECISIONS_REQUIRED.md`, then `07_GAPS_AND_LIMITS.md` |
| auditing the evidence itself | `07_GAPS_AND_LIMITS.md` §1 (coverage ledger) and §conflict register |

---

## 9. Provenance and method

This document was produced from the seven patch folders of the evidence archive
`Reference_V2_Patches_04-11.zip` (91 top-level files; patch folders for patches 04 through 11,
with patches 07 and 08 sharing one folder), analysed in the descending order
P11 → P10 → P09 → P07-08 → P06 → P05 → P04. The P11 deliverable tree (550 files) is the
consolidated reference point; earlier folders were scanned for artefacts and facts not carried
into it, and 24 patch-root-unique artefacts were identified and preserved. All figures quoted in
this document were re-counted directly from the cited artefacts (object counts from
`objects.json`, column counts from the schema dump's column definition lines, control counts by
summing the `forms-blob.txt` control column, INI deltas from the key-level CSV row count, artefact
counts from the ledger and CAB inventory row counts). Evidence classes used throughout are
**VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED** and **NOT RECOVERABLE**, as defined
in `00_INDEX.md`. Where this document summarises a topic that is specified in full elsewhere, the
detail lives in the document named in the row, and the topic is not repeated with a different
number.
