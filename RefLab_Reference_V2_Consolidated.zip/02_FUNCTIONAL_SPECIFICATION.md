# RefLab V2 — Functional Specification (Functions & Capabilities Inventory)

**Target version:** RefLab **V2** = RealLab **V-CD-2019**, the `real lab system\RL_CD2019Access\System\real lab system.exe` executable — **FileVersion 1.605** (`Description: RLS 1.605`, `CompanyName: RealLab`, 76,292,096 bytes, SHA-256 `C54CE6C8…DF93C0`, PE32 / linker 6.0, PE timestamp `1595435962` = 2020-07-22 16:39:22 UTC) — the "second edition" / الإصدار الثاني. **Deployment root:** `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`). [P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | "pe"."timestamp"]
**Evidence roots:** the patch deliverable trees P04..P11 — principally the P11 tree (`analysis/BATCH-04/`, `analysis/BATCH-02/` — the catalogue of the shipped payload's own `Data\*.ini` report profiles and printer settings and its `Cache\*.rtf` method sheets, `analysis/V-CD-2019/`, `reports/`) and the seven patch extracts. Every citation below names the patch marker and the path of the file relative to that patch's deliverable tree. Where a figure is a catalogue-level count, the **V2-primary** artefact that states it is cited in place of the catalogue.
**Output language:** English. All Arabic identifiers / literal strings are preserved verbatim.

---

## 0. Evidence base and method

### 0.1 Artefacts parsed and how the inventory was derived

1. Every file listed in the primary-source manifest was read in full (or parsed programmatically where tabular).
2. `analysis/BATCH-04/vb6/v1605/objects.json` was parsed to enumerate the complete V2 VB6 object table (210 objects / 8,026 procedures) — this is the authoritative object-level inventory for V2.
3. `analysis/V-CD-2019/03-capabilities.md` (§2 table and §3 table) was parsed to isolate the **41 objects introduced by this build** — 20 code objects (forms, modules, classes) plus 21 DataReports — and `analysis/BATCH-04/vb6/v1605/objects.json` supplied each object's type and procedure count.
4. `analysis/BATCH-04/vb6/v1605/forms-blob.txt` was parsed (131 forms, control counts + form geometry) to attach control-level detail to each new form.
5. `analysis/BATCH-04/schema/created-tables.csv`, `schema/added-columns.csv`, `schema/column-evolution.csv`, `sql_v1605/tables.csv` were parsed to bind every function to its exact tables/columns.
6. The official CHM manual bundled with this build was read in full (`help-manual-ar.md`, `help-topics.csv` — 15 topics, 5,193,985 bytes, SHA-256 `624308649E523400F6672389FC877543DB9D286F27E743C1581B1CF507902A39`), so the *documented* behaviour of CAP-01..CAP-15 in V2 is exactly that manual's text, while the *implementation* is evidenced separately from the binary analysis. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | header + topic index] [P11 | analysis/V-CD-2019/03-capabilities.md | §1 preamble]

### 0.2 Evidence classification tags used in this document

| Tag | Meaning |
|---|---|
| **VERIFIED** | Directly observed in a V2 artefact (literal string, table/column, object name, method count, INI key, script line, or an explicitly quoted manual passage). |
| **INFERRED** | A conclusion drawn from V2 evidence by reasoning; the underlying evidence is cited but the conclusion itself is not literally stated. |
| **UNVERIFIED** | Asserted by an upstream P11 document but not independently re-derivable from the primary artefacts; carried forward with that caveat. |
| **NOT DOCUMENTED** | The evidence base does not establish this field. Used liberally — no field is filled by guesswork. |
| **NOT RECOVERABLE** | The evidence was destroyed/absent in the artefact and cannot be reconstructed (e.g. DataReport designer layouts are not extractable from the binary). |

---

## 1. Master function / capability inventory

### 1.1 Layer A — 15 documented CHM capabilities (CAP-01..CAP-15)

| Function ID | Name | Domain | Documented in | V2 implementation anchors (object / method count) | Evidence |
|---|---|---|---|---|---|
| CAP-01 | Run & login | Session / authentication | `001.htm`, `002.htm` | `start`(10) `server`(17) `users`(57) `login`(13) `userspw`(12) `logindete`(6) `logindetect`(0) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-01] |
| CAP-02 | Manage patient data | Patient registration | `003.htm` | `patientmain`(84) `addpatient`(192) `patient`(58) `patientview`(33) `patienthistory`(22) `patienthistory2`(17) `Patient_samples`(89) `RPTPatientVisit`(0) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-02] |
| CAP-03 | Print patient barcode | Barcode / labels | `003A.htm` | `barcode`(76) `barcodeform`(0) `z_barcodes`(14) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-03] |
| CAP-04 | Enter test results (per profile) | Result entry | `004.htm`, `004A.htm` | 30+ `result*`/`Result*` forms incl. `resultcbc`(172) `resultbloodgas`(81) `resultTrace`(183) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-04] |
| CAP-05 | Deliver results to patient | Result delivery | `005.htm` | `frm_money`(38) `moneypaid`(18) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-05] |
| CAP-06 | Search for a patient | Patient search | `006.htm` | `patientview`(33) `patientmain`(84) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-06] |
| CAP-07 | Add / edit test data | Test master data | `007.htm` | `tools`(1) `setup`(16) `setup1`(56) `setup2`(58) `setup3`(42) `testmain`(30) `instrument`(29) `abbrevi`(41) `converter`(14) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-07] |
| CAP-08 | Manage reference ranges | Reference ranges | `008.htm` | `normal_test`(36) `testrange`(17) `outtest`(11) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-08] |
| CAP-09 | Customise reports | Report design | `009.htm` | `reportsetup`(113) `reportsetup2`(69) `static1`(30) `static2`(26) `static3`(15) `static4`(18) `static5`(21) `static6`(24) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-09] |
| CAP-10 | Manage out-referred samples | Referral-out samples | `010.htm` | `sarfz`(26) `moenysharekat`(27) `moenymozafeen`(27) `labtolab`(32) `z_gehats`(56) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-10] |
| CAP-11 | Accounts & stocktaking | Billing / accounting | `011.htm` | `labfunction`(25) `frm_money`(38) `moneypaid`(18) `z_labaccount`(18) `z_pricelists`(27) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-11] |
| CAP-12 | Back up the database | Database maintenance | `backup.htm` | `labdb`(24) `labdb1`(20) `tools`(1) `labmainTools`(6) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-12] |
| CAP-13 | Clinical constants & factors | Clinical calculation rules | `nots.htm` | `normal_test`(36) `testrange`(17) `resultcbc`(172) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-13] |
| CAP-14 | Fixed test-numbering constraint | Test master data | `nots.htm` | `testtable` (609 rows) `subgrouptable`(46 rows) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-14] (capability) · row counts [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 table row 3-1] |
| CAP-15 | Keyboard shortcuts & results UI | UI behaviour | `004A.htm`, `010.htm`, `011.htm` | `daytip` (2 SQL statements) — the number of tip texts a live V2 installation carries is **NOT RECOVERABLE** | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table row CAP-15] (capability) · [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| `daytip` row] |

### 1.2 Layer B — the 41 VB6 objects introduced by this build

Method counts are the V2 values from `objects.json`. "Controls" is the V2 control count from `forms-blob.txt` (131 forms parsed); classes and modules have no control record. The 41 objects of this layer are the union of the 20 code objects of §1.2 B.1 and the 21 DataReports of §1.2 B.2; every one of them also appears in the complete 210-object table of §1.3.

#### B.1 New forms / modules / classes (20)

| Function ID (exact VB6 name) | Type | Methods | Controls | Domain | Signification | Evidence |
|---|---|---:|---:|---|---|---|
| `BiosData` | class | 8 | — | Infrastructure / clinical data model | Biological-data (bios) helper class | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row BiosData] |
| `CardFrm` | form | 0 | 3 | Patient identity card | ID-card form | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row CardFrm] |
| `CardFrmSetx` | form | 22 | 29 | Patient identity card | Patient-card setup | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row CardFrmSetx] |
| `Frmac` | form | 26 | 46 | Laboratory forms | AC form | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row Frmac] |
| `Patient_samples` | form | 89 | 101 | Sample tracking | Patient sample tracking | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row Patient_samples] |
| `ResultFMF` | form | 48 | 105 | Result entry — new profile | Familial Mediterranean Fever result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row ResultFMF] |
| `ResultPCR` | form | 37 | 94 | Result entry — new profile | PCR result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row ResultPCR] |
| `Resultsemen5` | form | 216 | 231 | Result entry — new profile | Semen analysis v5 result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row Resultsemen5] |
| `ResulturineAuto` | form | 184 | 195 | Result entry — new profile | Automated urine analysis result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row ResulturineAuto] |
| `SMSfrmsenderos` | form | 139 | 186 | SMS / notifications | SMS message sender | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row SMSfrmsenderos] |
| `aaaClass` | class | 15 | — | Infrastructure | Helper class | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row aaaClass] |
| `boisais` | module | 16 | — | Infrastructure | Vendor sub-module | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row boisais] |
| `labmainTools` | form | 6 | 13 | Main shell | Main-screen tools | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row labmainTools] |
| `mInputbox` | module | 12 | — | UI infrastructure | Custom input box | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row mInputbox] |
| `otherfun` | module | 2 | — | UI infrastructure | Helper functions | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row otherfun] |
| `resultIgeAllergy` | form | 231 | 178 | Result entry — new profile | IgE allergy result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row resultIgeAllergy] |
| `resultLBC` | form | 33 | 52 | Result entry — new profile | LBC result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row resultLBC] |
| `resulthpylori` | form | 83 | 94 | Result entry — new profile | *H. pylori* result entry | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row resulthpylori] |
| `saveIOtemp` | module | 10 | — | Infrastructure | Temporary persistence of inputs | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row saveIOtemp] |
| `static6` | form | 24 | 87 | Report design — static screen | New static screen | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table row static6] |

#### B.2 New DataReports (21)

All 21 are `datareport` type with `methods=0` in V2 (DataReport designers carry no VB6 procedures). [P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats + object records]

| Function ID (exact VB6 name) | Methods | Domain | Signification | Evidence |
|---|---:|---|---|---|
| `RPTPatientVisit` | 0 | Patient visit log | Patient-visit report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row RPTPatientVisit] |
| `ReportFatoraC` | 0 | Coagulation factors | Coagulation-factors report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatoraC] |
| `ReportFatorareset` | 0 | Coagulation factors | Coagulation-factors reset report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatorareset] |
| `ReportFatorareset8` | 0 | Coagulation factors | Coagulation-factors reset (copy 8) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatorareset8] |
| `ReportIGE1` | 0 | IgE allergy | IgE allergy report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportIGE1] |
| `ReportIGE1s` | 0 | IgE allergy | IgE allergy report (short) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportIGE1s] |
| `ReportLBC` | 0 | LBC | LBC report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportLBC] |
| `ReportLBCs` | 0 | LBC | LBC report (short) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportLBCs] |
| `ReportPCR` | 0 | PCR | PCR report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportPCR] |
| `ReportPCRs` | 0 | PCR | PCR report (short) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportPCRs] |
| `ReportPatPhone` | 0 | Patient contacts | Patient-phone report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportPatPhone] |
| `ReportSMS` | 0 | SMS / notifications | SMS message report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportSMS] |
| `ReportTestTime` | 0 | Lab performance | Test-time report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportTestTime] |
| `ReportZN` | 0 | Trace elements | Zinc report | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportZN] |
| `ReportZNs` | 0 | Trace elements | Zinc report (short) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportZNs] |
| `Reportliver7his` | 0 | Clinical history | Liver history report (7) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportliver7his] |
| `Reportlivers7his` | 0 | Clinical history | Liver history report (7, short) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportlivers7his] |
| `Reportmony01` | 0 | Billing | Financial report 01 | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportmony01] |
| `Reportmony11` | 1 | Billing | Financial report 11 | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportmony11] |
| `Reportmony5` | 0 | Billing | Financial report 5 | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportmony5] |
| `pricelistsN` | 0 | Billing | Price list (N) | VERIFIED [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row pricelistsN] |

### 1.3 Layer C — complete V2 VB6 object table (210 objects / 8,026 procedures)

Complete enumeration from `objects.json` (V2). "Methods" is the V2 procedure count for the object.

| # | Object | Type | Methods | Domain |
|---:|---|---|---:|---|
| 0 | `labmain` | form | 71 | Main shell / menu |
| 1 | `labxxyyzz` | form | 3 | Main shell helper |
| 2 | `patientmain` | form | 84 | Patient registration |
| 3 | `labdb` | module | 24 | Database / backup infrastructure |
| 4 | `frm_money` | form | 38 | Billing & accounting |
| 5 | `tools` | form | 1 | Reference data / test setup |
| 6 | `Resultliver` | form | 101 | Result entry — liver |
| 7 | `moneypaid` | form | 18 | Billing & accounting |
| 8 | `addpatient` | form | 192 | Patient registration |
| 9 | `Resulturine` | form | 167 | Result entry — urine |
| 10 | `Reporturine` | datareport | 0 | Report template |
| 11 | `Reportliver` | datareport | 0 | Report template |
| 12 | `tqrermog` | form | 41 | Reference data (titration / reagents) |
| 13 | `ReportFatora` | datareport | 0 | Report template — coagulation factors |
| 14 | `Reporttotal` | datareport | 0 | Report template — totals |
| 15 | `Reporthistory` | datareport | 1 | Report template — medical history |
| 16 | `barcode` | form | 76 | Barcode & labels |
| 17 | `phone` | form | 33 | Patient contacts |
| 18 | `testmain` | form | 30 | Test & reference-range setup |
| 19 | `Resultsugar` | form | 61 | Result entry — sugar |
| 20 | `labdb1` | module | 20 | Database / backup infrastructure |
| 21 | `Reportworkp` | datareport | 0 | Report template — work paper |
| 22 | `workpaper` | form | 17 | Statistics & work sheet |
| 23 | `Reportwp` | datareport | 0 | Report template — work paper |
| 24 | `Resultstool` | form | 139 | Result entry — stool |
| 25 | `testrange` | form | 17 | Test & reference-range setup |
| 26 | `ReportSugar` | datareport | 0 | Report template |
| 27 | `Resultkidney` | form | 117 | Result entry — kidney |
| 28 | `resultculutre` | form | 115 | Result entry — culture & sensitivity |
| 29 | `Resultlipids` | form | 81 | Result entry — lipids |
| 30 | `ais` | form | 0 | Reference data (AIS placeholder) |
| 31 | `reportculutre` | datareport | 0 | Report template — culture |
| 32 | `Resultsemen` | form | 222 | Result entry — semen |
| 33 | `resultABO` | form | 47 | Result entry — ABO |
| 34 | `resultwidal` | form | 41 | Result entry — Widal |
| 35 | `resulthepatitis` | form | 187 | Result entry — hepatitis |
| 36 | `ReportFatoraS` | datareport | 0 | Report template — coagulation factors (short) |
| 37 | `ResultESR` | form | 32 | Result entry — ESR |
| 38 | `resultcbc` | form | 172 | Result entry — CBC |
| 39 | `repotrwidal` | datareport | 0 | Report template — Widal |
| 40 | `Reporthistory2` | datareport | 1 | Report template — medical history (2) |
| 41 | `ResultTORCH` | form | 123 | Result entry — TORCH |
| 42 | `resultcrp` | form | 97 | Result entry — CRP |
| 43 | `resultpt` | form | 110 | Result entry — prothrombin time |
| 44 | `resulthormon` | form | 116 | Result entry — hormones |
| 45 | `Reportinstrument` | datareport | 0 | Report template — instruments |
| 46 | `patient` | form | 58 | Patient registration |
| 47 | `Reportshareka` | datareport | 0 | Report template — farms |
| 48 | `patientview` | form | 33 | Patient search |
| 49 | `outtest` | form | 11 | Test & reference-range setup |
| 50 | `setup` | form | 16 | Test & reference-range setup |
| 51 | `anyreport` | form | 16 | Report — blank/combined report |
| 52 | `calctest` | form | 2 | Test setup — calculator |
| 53 | `statisReport` | datareport | 0 | Statistics |
| 54 | `Reportwpm` | datareport | 0 | Report template — work paper (by patient) |
| 55 | `Reportwpt` | datareport | 0 | Report template — work paper (by test) |
| 56 | `Reportwpot` | datareport | 0 | Report template — work paper (other) |
| 57 | `barcodeform` | form | 0 | Barcode & labels |
| 58 | `ResultInsulin` | form | 92 | Result entry — insulin |
| 59 | `start` | form | 10 | Session / startup |
| 60 | `Resultbilharzias` | form | 64 | Result entry — bilharzia |
| 61 | `Reportcross` | datareport | 0 | Report template — cross match |
| 62 | `Reportmony1` | datareport | 0 | Report template — money |
| 63 | `Reportsemen` | datareport | 0 | Report template — semen |
| 64 | `Reportanyreport` | datareport | 0 | Report template — combined report |
| 65 | `BCWFonts` | module | 7 | Infrastructure — fonts |
| 66 | `reportsetup` | form | 113 | Report design & printing |
| 67 | `patienthistory` | form | 22 | Patient medical history |
| 68 | `resultselectro` | form | 144 | Result entry — selective / RO |
| 69 | `resultcardiac` | form | 66 | Result entry — cardiac |
| 70 | `resultTumors` | form | 100 | Result entry — tumour markers |
| 71 | `resultVitamins` | form | 110 | Result entry — vitamins |
| 72 | `resultTrace` | form | 183 | Result entry — trace elements |
| 73 | `resultanytest` | form | 33 | Result entry — generic |
| 74 | `Resultpregnancy` | form | 44 | Result entry — pregnancy |
| 75 | `pricelists` | datareport | 0 | Report template — price list |
| 76 | `resultiron` | form | 62 | Result entry — iron |
| 77 | `reportsetup2` | form | 69 | Report design & printing |
| 78 | `labfunction` | module | 25 | Billing & accounting — stocktaking |
| 79 | `ResultFertlity` | form | 125 | Result entry — fertility |
| 80 | `ResultSuprarenal` | form | 117 | Result entry — suprarenal |
| 81 | `server` | form | 17 | Server / deployment / branches |
| 82 | `users` | form | 57 | Security — users & permissions |
| 83 | `login` | form | 13 | Security — login |
| 84 | `userspw` | form | 12 | Security — user password |
| 85 | `Reportlog` | datareport | 0 | Report template — log |
| 86 | `z_units` | form | 14 | Reference data — units |
| 87 | `z_barcodes` | form | 14 | Reference data — barcode types |
| 88 | `z_branchs` | form | 14 | Branches |
| 89 | `z_logs` | form | 14 | Reference data — log groups |
| 90 | `z_gehats` | form | 56 | Referral entities (جهة إحالة / treating doctor) |
| 91 | `z_pricelists` | form | 27 | Billing — price lists |
| 92 | `z_titles` | form | 15 | Reference data — titles |
| 93 | `labtolab` | form | 32 | Billing — lab-to-lab |
| 94 | `sarfz` | form | 26 | Out-referred samples |
| 95 | `instrument` | form | 29 | Reference data — instruments |
| 96 | `Reportmony2` | datareport | 0 | Report template — money |
| 97 | `Reportmony3` | datareport | 0 | Report template — money |
| 98 | `zarf` | datareport | 1 | External integration — ZARF |
| 99 | `aaaClass` | class | 15 | Infrastructure — helper class |
| 100 | `static1` | form | 30 | Report design — static screen |
| 101 | `reportstatic1` | datareport | 0 | Report template — static 1 |
| 102 | `static2` | form | 26 | Report design — static screen |
| 103 | `static3` | form | 15 | Report design — static screen |
| 104 | `noteic` | form | 10 | Result entry — internal comments |
| 105 | `z_group` | form | 14 | Reference data — groups |
| 106 | `antibioticfrm` | form | 29 | Reference data — farm antibiotics |
| 107 | `Frmcomment` | form | 17 | Reference data — saved comments |
| 108 | `static4` | form | 18 | Report design — static screen |
| 109 | `z_customgroup` | form | 31 | Reference data — custom test groups |
| 110 | `Reportsemen1` | datareport | 0 | Report template — semen 1 |
| 111 | `commentsetup` | form | 5 | Reference data — comment setup |
| 112 | `abbrevi` | form | 41 | Reference data — abbreviations |
| 113 | `learntest` | form | 6 | Reference data — learning tests |
| 114 | `converter` | form | 14 | Test setup — unit converter |
| 115 | `shoppingfrm` | form | 15 | Billing — shopping list |
| 116 | `frmTip` | form | 5 | Session — tip-of-the-day |
| 117 | `workpaper2` | form | 18 | Statistics & work sheet |
| 118 | `Reportsemen2` | datareport | 0 | Report template — semen 2 |
| 119 | `resultabuse` | form | 95 | Result entry — abuse/drugs |
| 120 | `resultdrugs` | form | 98 | Result entry — drugs |
| 121 | `resultcoagfactor` | form | 79 | Result entry — coagulation factors |
| 122 | `resultImmunoglob` | form | 72 | Result entry — immunoglobulin |
| 123 | `resultimmun` | form | 138 | Result entry — immunology |
| 124 | `resulthgbelec` | form | 51 | Result entry — Hb electrophoresis |
| 125 | `resultprotelec` | form | 61 | Result entry — protein electrophoresis |
| 126 | `resultbloodgas` | form | 81 | Result entry — blood gases |
| 127 | `resultcrossm` | form | 140 | Result entry — cross match |
| 128 | `resultsugacurve` | form | 78 | Result entry — glucose curve |
| 129 | `resultstone` | form | 72 | Result entry — stone |
| 130 | `resultprostata` | form | 113 | Result entry — prostatic secretion |
| 131 | `resultcsf` | form | 83 | Result entry — CSF |
| 132 | `resultzn` | form | 36 | Result entry — zinc |
| 133 | `resultTUBERCULIN` | form | 32 | Result entry — tuberculin |
| 134 | `resultmarrow` | form | 64 | Result entry — bone marrow |
| 135 | `resultpostcoital` | form | 60 | Result entry — post-coital |
| 136 | `moenysharekat` | form | 27 | Billing — farm money |
| 137 | `resultrenal` | form | 80 | Result entry — renal failure |
| 138 | `patienthistory2` | form | 17 | Patient medical history (2) |
| 139 | `qcfrm` | form | 27 | Quality control |
| 140 | `printerselect` | module | 11 | Report design & printing (module) |
| 141 | `z_labaccount` | form | 18 | Billing — lab accounts |
| 142 | `static5` | form | 21 | Report design — static screen |
| 143 | `logindetect` | datareport | 0 | Login detection report |
| 144 | `logindete` | form | 6 | Security — login detection |
| 145 | `Reportqc` | datareport | 0 | Report template — QC |
| 146 | `Reportlivers` | datareport | 0 | Report template — liver (short) |
| 147 | `setup1` | form | 56 | Test & reference-range setup |
| 148 | `setup2` | form | 58 | Test & reference-range setup |
| 149 | `setup3` | form | 42 | Test & reference-range setup |
| 150 | `normal_test` | form | 36 | Test & reference-range setup |
| 151 | `Reporturines` | datareport | 0 | Report template — urine (short) |
| 152 | `ReportSugars` | datareport | 0 | Report template — sugar (short) |
| 153 | `Reporttotals` | datareport | 0 | Report template — totals (short) |
| 154 | `Reportanyreports` | datareport | 0 | Report template — combined (short) |
| 155 | `repotrwidal` | datareport | 0 | Report template — Widal (short) |
| 156 | `Reportcrosss` | datareport | 0 | Report template — cross match (short) |
| 157 | `reportculutres` | datareport | 0 | Report template — culture (short) |
| 158 | `Reportsemen1s` | datareport | 0 | Report template — semen 1 (short) |
| 159 | `Reportsemen2s` | datareport | 0 | Report template — semen 2 (short) |
| 160 | `Reportmony4` | datareport | 0 | Report template — money |
| 161 | `moenymozafeen` | form | 27 | Billing — treating-doctor money |
| 162 | `resultha1c` | form | 51 | Result entry — HbA1c |
| 163 | `resultwidal2` | form | 51 | Result entry — Widal (2nd version) |
| 164 | `Frm_pic` | form | 55 | Patient pictures |
| 165 | `CRect` | class | 20 | Infrastructure — rectangle class |
| 166 | `rpttotaliss` | datareport | 0 | Report template — total issues |
| 167 | `rpttotalisss` | datareport | 0 | Report template — total issues (short) |
| 168 | `Frm_pic2` | form | 31 | Patient pictures |
| 169 | `resultretios` | form | 97 | Result entry — reticulocytes |
| 170 | `ReportFatoraC` | datareport | 0 | Report template — coagulation factors |
| 171 | `resulthpylori` | form | 83 | Result entry — *H. pylori* |
| 172 | `Frmac` | form | 26 | Laboratory forms |
| 173 | `Reportmony5` | datareport | 0 | Report template — money |
| 174 | `saveIOtemp` | module | 10 | Infrastructure — temporary persistence |
| 175 | `CardFrm` | form | 0 | Patient identity card |
| 176 | `CardFrmSetx` | form | 22 | Patient identity card setup |
| 177 | `Resultsemen5` | form | 216 | Result entry — semen v5 |
| 178 | `Patient_samples` | form | 89 | Sample tracking |
| 179 | `ReportFatorareset` | datareport | 0 | Report template — coagulation reset |
| 180 | `ReportPatPhone` | datareport | 0 | Report template — patient phone |
| 181 | `pricelistsN` | datareport | 0 | Report template — price list (N) |
| 182 | `SMSfrmsenderos` | form | 139 | SMS sender |
| 183 | `BiosData` | class | 8 | Infrastructure — bios data class |
| 184 | `boisais` | module | 16 | Infrastructure — vendor module |
| 185 | `ReportSMS` | datareport | 0 | Report template — SMS |
| 186 | `Reportmony11` | datareport | 1 | Report template — money 11 |
| 187 | `Reportliver7his` | datareport | 0 | Report template — liver history 7 |
| 188 | `Reportlivers7his` | datareport | 0 | Report template — liver history 7 (short) |
| 189 | `mInputbox` | module | 12 | UI infrastructure — input box |
| 190 | `ReportTestTime` | datareport | 0 | Report template — test time |
| 191 | `RPTPatientVisit` | datareport | 0 | Report template — patient visit |
| 192 | `static6` | form | 24 | Report design — static screen |
| 193 | `ReportPCR` | datareport | 0 | Report template — PCR |
| 194 | `ReportFatorareset8` | datareport | 0 | Report template — coagulation reset (8) |
| 195 | `ResultPCR` | form | 37 | Result entry — PCR |
| 196 | `labmainTools` | form | 6 | Main shell — tools |
| 197 | `ReportPCRs` | datareport | 0 | Report template — PCR (short) |
| 198 | `ResultFMF` | form | 48 | Result entry — FMF |
| 199 | `resultLBC` | form | 33 | Result entry — LBC |
| 200 | `ReportLBC` | datareport | 0 | Report template — LBC |
| 201 | `ReportLBCs` | datareport | 0 | Report template — LBC (short) |
| 202 | `ReportZN` | datareport | 0 | Report template — zinc |
| 203 | `ReportZNs` | datareport | 0 | Report template — zinc (short) |
| 204 | `Reportmony01` | datareport | 0 | Report template — money 01 |
| 205 | `resultIgeAllergy` | form | 231 | Result entry — IgE allergy |
| 206 | `ReportIGE1` | datareport | 0 | Report template — IgE allergy |
| 207 | `ReportIGE1s` | datareport | 0 | Report template — IgE allergy (short) |
| 208 | `otherfun` | module | 2 | UI infrastructure — helpers |
| 209 | `ResulturineAuto` | form | 184 | Result entry — automated urine |

Totals: 132 forms · 66 datareports · 9 modules · 3 classes = **210**; procedures = **8,026**. [P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats block + 210 object records]

> **Two counting notes on this table.**
>
> 1. **Procedure total.** The `objects.json` stats block reports **8,026** procedures for the 210 objects. Adding the `Methods` column of the 210 rows above yields **8,038** — 12 more than the reported total. The difference is not explained by the source evidence and is reproduced here as found; both figures are stated so that neither is presented as verified beyond its own artefact. The row counts (132 / 66 / 9 / 3 = 210) do reconcile exactly.
> 2. **Duplicate object name.** The exact name `repotrwidal` occurs twice in this table — at row 39 (*Report template — Widal*) and at row 155 (*Report template — Widal (short)*). Both entries are reproduced verbatim; the two rows are distinct objects, and the source evidence does not state which of the two is the short-form Widal report. [P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats block + object records]

---

## 2. Detailed per-function specifications — CAP-01..CAP-15

> Each spec below uses the full field set. Fields the evidence does not establish are written **NOT DOCUMENTED**. Multi-condition rules are reproduced in full, not compressed.

### CAP-01 — Run the system and log in

- **Function ID:** CAP-01
- **Name:** تشغيل وتسجيل الدخول — Run system & log in
- **Purpose:** Start the application, establish the database-server context, and authenticate a user before any operational screen becomes reachable.
- **Functional domain:** Session / authentication
- **Description:** The application is launched by double-clicking the program icon inside the `real lab system` folder, or the desktop shortcut icon. After the loading screen the login screen appears. A "server and database settings" window holds the server IP / machine name, the (fixed) login-permission type, the DB user name and password, and the database name.
- **Trigger:** Double-click on the application icon (folder) or desktop shortcut.
- **Preconditions:** (1) The database server must be reachable; (2) the OS date display language must be English (Canada); (3) on a PC that has just booted, the user must wait for all startup programs next to the clock in the taskbar to finish loading and then wait a further five seconds so that the server can work.
- **Inputs:**
  - Server IP address or server machine name (text; "the server machine name is preferred on the server itself"). A "احضار" (retrieve) button fetches it so the system keeps working if the network card, cable or switch fails.
  - Login-permission type — *fixed and unchangeable when the vendor's installer is used*.
  - DB user name and password — *change is prohibited*; they are the database-connection credentials.
  - Database name — *change is prohibited*, it is a system constant.
  - Login form: user name selected from a drop-down list; password typed into a dedicated field, **case-sensitive**.
- **Validation rules:**
  1. On first use select `"admin"`; then create the real users and delete that account.
  2. On first use, for the user name `"admin"`, the **same word is entered as the password** (`admin` / `admin`).
  3. Only the server IP/machine name may vary across the laboratory's machines; everything else in that window is a system constant.
  4. The region/date-format must be set to **English (Canada)**: `Start menu → Control Panel → Regional and Language Options (Icon) → Regional Options (Tab) → Standards and formats (Option) → Select English (Canada) → Ok (key)`.
- **Execution sequence:** Launch icon → wait for load → (on error: acknowledge the dialog) → login screen → choose user name → type password → press "تسجيل دخول" → main window. To exit, choose "خروج".
- **Business logic:** The only field intended to vary per installation is the server address; the DB credential and DB name are immutable so that all laboratory machines share one data source. Where the machine is not the SQL Server host, the operator must start ("تشغيل") the server machine — the program need not be opened on the server for the other machines to work.
- **Outputs:** An authenticated session; access to the main window.
- **Side effects:** Session establishment is recorded in the log tables `loger` / `loggroup` / `tasgel` / `patients` (attendance/work-window columns `startwork`, `endwork`, `breakyorn`, `breaktime`). The `patients` table name here is the **staff/work-log table**, not the patient master.
- **Database interactions:** `useraccounts` (6 SQL statements; columns added in V2: `Gtype` Smallint, `HDD1` varchar(20), `HDD2` varchar(20)), `patients` (14 statements), `loggroup` (7 statements), `loger` (5 statements — `SELECT * FROM loger where lognum=…`), `tasgel` (6 statements — `select * from tasgel where username='…'`), `useraccounts` sample: `select * from useraccounts where usersnum=`.
- **Permissions:** Users are classified as *administrator* or *users with absolute rights*; several result-window functions (the "بي" / "تي" audit buttons) explicitly refuse to act for anyone other than the administrator or users holding absolute rights.
- **Error conditions:**
  - Message `"خادم قواعد البيانات غير معرف"` (database server not defined) → after pressing OK the system closes; then the operator must (1) wait five seconds after OS startup on the server machine and press OK on both dialogs, or (2) on a non-server machine, start the SQL Server machine, or (3) if the server is still booting, repeat case (1); and check the network switches and sharing between machines before touching any system data.
  - Message `"رجاء تحويل التاريخ الى اللغة الانجليزية"` (please convert the date to English) → after OK the system closes; the region must be changed to English (Canada).
- **Exception handling:** NOT DOCUMENTED beyond the two dialog paths above; the manual prescribes manual operator recovery, not programmatic retry.
- **Related entities:** `useraccounts`, `loggroup`, `loger`, `tasgel`, `patients` (staff work log).
- **Dependencies:** `MSVBVM60.DLL` runtime; SQL Server / Access data source; `start`, `login`, `users`, `userspw`, `server`, `logindete` forms.
- **UI entry point (exact form name):** `start` → `login` (the manual's "شاشة التسجيل" / login screen); server settings are exposed via the `server` form.
- **Postconditions:** The user is logged in; the session is logged; the main window is reachable.
- **Evidence classification:** **VERIFIED** for the manual behaviour (the CHM manual bundled with this build) and for the object/table inventory; the `loger` table's *purpose* remains open (see §7 open points V-03 / V-08). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topics 001.htm, 002.htm] [P11 | analysis/V-CD-2019/02-schema.md | §5 tables referenced in SQL] [P11 | analysis/BATCH-04/schema/added-columns.csv | useraccounts rows]

### CAP-02 — Manage patient data

- **Function ID:** CAP-02
- **Name:** إدارة بيانات المرضى — Add / edit patient data
- **Purpose:** Register a patient, maintain their demographics and clinical flags, attach the requested tests with pricing, and print the receipt and barcode.
- **Functional domain:** Patient registration & demographics
- **Description:** Reached from the main window top bar → "المرضي" → "اضافة وتعديل بيانات المرضى", or by pressing **F2** from any of the main program windows. Inside the window the operator can add a patient, edit a previous patient, choose the required tests for the patient, delete a patient, collect the amount due, apply a discount, and print the receipt and the patient's barcode.
- **Trigger:** Menu `المرضي` → `اضافة وتعديل بيانات المرضى`; or keyboard **F2** from any main window.
- **Preconditions:** Logged in. To delete a patient the current user must hold the *delete-patient* right. To use the barcode/lab-ID workflow the laboratory must be running the barcode + lab-ID (لاب اي دي) scheme.
- **Inputs (types + constraints):**
  - Patient name (free text) — recommended normalisation for searchability: **omit any hamza** (أحمد = احمد, إبراهيم = ابراهيم, علاء = علاء); **replace taa marbuta with haa** (بهاء = مروه-style pairs: مروة = مروه, هبة = هبه, سامية = ساميه); **use yaa in the middle of the word** (علي not على, يحي not يحى).
  - Sex — selecting it auto-fills the matching **title** (لقب).
  - Age — **must be entered before the patient's natural/normal rate and age stage can be shown**. If the patient is **under one month**, write the age in **days from 1 to 29**. If **under one year**, write it in **months from 1 to 11**. A **fraction may be written** in the age field, e.g. `2.5` years meaning two years and six months.
  - Account method — one of **Individual**, **Lab to Lab**, **Free**; must also be compatible with the referral entity.
    - *Individual*: the patient is priced on the laboratory's own patient price list, **even if a referral entity with its own price list has been selected**.
    - *Lab to Lab*: two cases — if the referral entity has its own price list (previously entered from the "قائمة اسعار التحاليل للجهات" window), the selected tests are priced with that entity's prices; if the referral entity has **no** price list, the patient is priced on the lab-to-lab price selected in the test-data window.
    - *Free*: the tests are performed free and the **total account is zero**.
  - "Important patient" flag — for important patients or whose results interest the laboratory management; recommended to ease access to such results.
  - Referral entity name — typing activates **auto-complete**; clicking the name shows the remaining stored data about that entity. A **newly typed entity is saved automatically** for later recall. If **no** referral entity is entered for the patient, the system registers it automatically **from himself**. If the chosen entity has a discount percentage, that percentage is added automatically to the accounts (from the "الجهات الخارجية والمعامل" window).
  - Print flag — for lab-to-lab dealings where the referral entity's name must **not** appear on the result.
  - Extra information block — e.g. fasting hours, anticoagulant / liver / antiviral therapy, antibiotics or none, pregnancy for women, whether the patient is a smoker.
  - Out-of-lab withdrawn sample — when the sample is sent to another lab or withdrawn outside the lab, the **type of the out-withdrawn sample** is chosen so that a comment is written into the result report.
  - Note field — a note about the patient or about samples not yet arrived, so the doctor can see it while running the tests (reception ⇄ laboratory comment).
  - Test list drop-down — one of: routine tests / all tests stored in the system / test groups / the laboratory's own custom groups (pre-marriage, pre-HCV-treatment, work-up groups). Search **by test name or by number** using the adjacent text box.
  - Discount — either an **integer amount** or a **percentage**; then the **amount paid** is entered.
- **Validation rules:**
  1. Pressing "add patient" or "edit" replaces those buttons with a **Cancel** button so the operation can be undone.
  2. On "add patient" the write cursor is placed in the **patient name** field.
  3. Age must be entered before the patient's normal medical rate and age stage appear.
  4. A patient's account method must be compatible with the referral entity (see the three rules above).
  5. If no referral entity is entered, the system registers one "from himself".
  6. **A patient may only be deleted by a user who holds the delete-patient right.**
  7. In the barcode/lab-ID scheme: on first registration press "لاب اي دي" and print the barcode, which is handed to the patient; on a later visit press "اضافة مريض", put the cursor in the **Lab ID** field and read the barcode from the card, which restores all the registered data. If the card is lost, search for the patient in the search window and print the barcode again — **do not issue a new number**.
  8. Tests can also be entered by typing the test number in the search box after selecting the search mode "رقم التحليل" with the up/down arrows, then pressing **Enter**.
  9. Test entries are removed from the patient's selected-test list by **double-clicking** the test, or all removed with the "حذف الكل" button.
- **Execution sequence:** Main menu → `المرضي` → `اضافة وتعديل بيانات المرضى` → (a) add/edit patient → (b) fill name/sex/age → (c) choose account method → (d) flag as important → (e) pick referral entity → (f) fill extra info / out-sample type / notes → (g) select tests from the drop-down (double-click or "إضافة التحليل المحدد") → (h) apply discount and enter the paid amount → double-click "إدخال (انتر)" → (i) press "خالص" then "موافق" to settle the account → (j) print receipt and/or barcode → (k) save (F9). To reach today's patients press "مرضى اليوم" and pick the patient from the drop-down.
- **Business logic:** The 13-digit patient code is composite: position 1 = a not-looked-at digit, position 2 = the patient's order of arrival in the day's work, position 3 = **branch number**, positions 4–9 = the day's date read from the right, position 10 = the day-of-week number starting from Sunday, position 11 = "case code" (1 because the number is one). The **lab code** is what makes the patient reachable across visits and drives printing of the medical history. The account total is the sum of the selected tests' prices under the chosen account method, minus the discount, minus the amount paid.
- **Outputs:** A patient record; a priced test list; a settled or open account; a printable receipt and barcode; a printed receipt optionally showing the test breakdown and prices.
- **Side effects:** Writes to `patientinfo` and `patienttest`; writes the discount/paid amount to the payment tables; prints the barcode and receipt; the receipt may be **printed automatically after saving the patient** or on pressing the "ايصال" button (the behaviour is chosen under `اعدادات` → `اعدادات النظام`).
- **Database interactions:** `patientinfo` (428 SQL statements — the most referenced table in V2; columns `patientnamear`, `patientphone`, `patienttel`, `pricemethod`, `patientsex`, `patientage`, `patientsefa`, `patientid` Text(13), `barcode`, `requestdate`, `referredbyname`, `totalprice`, `totalpricedisc`, `patientageunit`; V2 additions `PFax`, `PatRPW`, `SMSMob`, `gehaname`, `moreinfo2`, and `patientinfo.moreinfo` widened from Text(22) to Memo/Hyperlink(255)), `patienttest` (343 statements; `patientid`, `testcode`, `subgroupcode`, `testsimp`, `resultt`…`resultt4`, `resultfinsh`, `resultreview`, `resultprint`, `give`, `sentout`, `send`, `otherlabname`, `printwith`, `resultreview`), `patienttotal`, `payment`, `phone`, `barcodes`, `titless`, `gehats`, `pricelist`, `pricemenu`, `samples`.
- **Permissions:** Delete-patient right required for deletion; discount/collection actions require an authenticated user; receipt/printing behaviour is configurable per lab.
- **Error conditions:** If a duplicate Lab ID is read, the system restores the existing patient's data instead of creating a new record (documented behaviour for re-visits). Loss of the barcode card must not produce a new number (search-and-reprint prescribed). NOT DOCUMENTED for genuine validation failures (e.g. non-numeric age) — no error-message inventory exists in the evidence.
- **Exception handling:** The undo affordance (Cancel button replacing Add/Edit) is the documented recovery for a mistyped or cancelled registration.
- **Related entities:** `patientinfo`, `patienttest`, `patienttotal`, `payment`, `phone`, `barcodes`, `titless`, `gehats`, `pricelist`, `pricemenu`, `samples`, `Patient_samples`, `RPTPatientVisit`.
- **Dependencies:** `patientmain`, `addpatient`, `patient`, `patientview`, `patienthistory`, `patienthistory2`, `Patient_samples`, `frm_money`, `moneypaid`, `barcode`, `phone`.
- **UI entry point (exact form name):** `patientmain` → `addpatient`.
- **Postconditions:** Patient stored with a unique `patientid`; selected tests priced and attached; account state recorded; barcode/receipt printable.
- **Evidence classification:** **VERIFIED** (manual text + V2 object/table inventory). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 003.htm] [P11 | analysis/V-CD-2019/03-capabilities.md | §1 table row CAP-02] [P11 | analysis/BATCH-04/sql_v1605/tables.csv | patientinfo, patienttest rows]

### CAP-03 — Print the patient barcode

- **Function ID:** CAP-03
- **Name:** طباعة الباركود للمريض — Print patient barcode
- **Purpose:** Produce and label the physical barcode/sleeve/tube labels that carry the patient's identity into the laboratory.
- **Functional domain:** Barcode & labels
- **Description:** After the patient's data has been entered and saved, press the "الباركود" button in the patient-data window (the barcode can be printed for the currently displayed patient, whether new or old). The barcode window shows the patient's required tests **classified by sample type and the material drawn**.
- **Trigger:** `الباركود` button in the patient-data window.
- **Preconditions:** Patient data saved (the manual says "بعد تسجيل بيانات المريض وحفظها").
- **Inputs:** Selection of which code(s) to print; per-label test selection by drag-and-drop; free-text label descriptions; barcode position offsets via sliders; a "طباعة كود الملف مع الكل" checkbox.
- **Validation rules / documented rules:**
  1. **Every patient receives three codes:**
     - **Case/day code** — a sequential code that orders arrival in the day's work; **it begins at digit 1 from the left**.
     - **File code (كود الملف)** — similar to the case code but **begins at digit 3 from the left**; it is printed when results are delivered by barcode and stuck on the **file/folder (الفيل)** along with the patient's name, type, age and visit date.
     - **Lab code (كود المعمل)** — given to the patient for easy access to their data and for printing their medical history; **it begins at digit 5 from the left**.
  2. The code number consists of **13 digits**, e.g. `1 - 4 - 100623 - 1 - 006 - 8`:
     - a digit that is **not looked at**,
     - the patient's order of arrival in today's work,
     - the **branch number**,
     - the day's date read from the right,
     - the day-of-week number, **starting from Sunday**,
     - the case code — 1 because the number is one.
  3. Any single label may be printed on its own by pressing the button **named after the material**, any number of times (e.g. when part of the sample is sent out).
  4. The **lab-code button is enabled only when the patient has a lab code**.
  5. The number of tube and container labels **varies from patient to patient according to the selected tests**.
  6. A label can be deleted by **dragging the element over the trash and releasing it**.
  7. A test can be **moved from one label to another** by drag-and-drop (e.g. fasting-serum and serum-only virus tests can be combined on one label as desired).
- **Execution sequence:** Save patient → open `barcode` → choose code(s) → (optional) adjust position sliders → print a single label → adjust until the required dimensions are reached → press "حفظ" → print again / print all codes.
- **Business logic:** Label content is derived from the patient's ordered test list (ordered by `arrangnum`) and from the sample type per test; the three-code scheme supports both barcode-reader hand-off (receipt code → file code) and direct lab-code retrieval.
- **Outputs:** Printed file code, lab code, tube/container labels, and optional extra (free-text) barcodes.
- **Side effects:** Print jobs on the **barcode printer role** (`barcodeprinter`); barcode records in `barcodes`; label-position settings are saved by the "حفظ" button.
- **Database interactions:** `barcodes` (7 statements — `SELECT * FROM barcodes`), `patientinfo` (`barcode`, `patientid`, `patientnamear`, `patientsex`, `patientage`, `patientsefa`, `requestdate`), `patienttest` (`testsimp`, `testcode`, `printwith`).
- **Permissions:** NOT DOCUMENTED for the barcode window specifically; printing is generally subject to the authenticated session.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** The drag-to-trash affordance is the documented removal path.
- **Related entities:** `barcodes`, `patientinfo`, `patienttest`, `z_barcodes` (barcode-type master).
- **Dependencies:** `barcode`(76), `barcodeform`(0), `z_barcodes`(14), `printerselect`, printer role `barcodeprinter`.
- **UI entry point (exact form name):** `barcode`.
- **Postconditions:** Physical labels produced and (for the file code) the delivery identifier is available for the result-delivery step.
- **Evidence classification:** **VERIFIED** for the manual rules; the geometry of the label is operator-adjustable (verified from the manual). **NOT DOCUMENTED:** the label template dimensions. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 003A.htm] [P11 | analysis/BATCH-04/vb6/v1605/objects.json | object 16 barcode]

### CAP-04 — Enter test results (per profile)

- **Function ID:** CAP-04
- **Name:** إدخال النتائج — Enter results (by profile)
- **Purpose:** Enter, review, verify and print the analytical result of each test, including the per-profile result grids that V2 extended with new clinical profiles.
- **Functional domain:** Result entry
- **Description:** Reached from the main window → "المرضي" → "ادخال نتائج التحاليل", or by pressing **F4** from any main program window. From the results window the operator enters patient results, reviews and prints them, and prints a work sheet and an envelope for the patient.
- **Trigger:** Menu `المرضي` → `ادخال نتائج التحاليل`; or **F4**.
- **Preconditions:** A patient must exist with at least one ordered test; the patient's profile determines which result form opens.
- **Inputs (types + constraints):** result values per analyte (`patienttest.resultt`, `resultt1`…`resultt4`), unit, comment, and — for the profile result form — per-analyte result entries with automatic abnormal/critical flagging.
- **Validation rules (documented, in full):**
  1. The patient panel shows **today's patients only**; clicking the patient's name shows the rest of their data and tests. A **status glyph** next to each name:
     - **new (red circle)** — patient registered, no results entered;
     - **paper (notes)** — patient has results not yet written;
     - **green and blue arrows** — patient has results not yet reviewed;
     - **printer** — patient has results not yet printed;
     - **shopping cart** — patient has not received the results, or has results not yet delivered;
     - **genie** — patient received all their results **but there is a problem in their account** (a balance remains for the lab or the patient);
     - **badge** — the patient's results were entered, printed, the account settled and the results delivered.
  2. The patient panel shows a **small green box** carrying the **number of visits** the patient has made to the laboratory (via Lab ID); an important patient's **name field is coloured red**.
  3. The patient's **code or Lab ID can be copied** with a single mouse click on the code / Lab ID field, for use elsewhere in the system.
  4. The test panel shows the patient's tests, each with a mark indicating whether it was written, reviewed, printed or delivered. To open a specific test's result form: **double-click** it, or select it with the arrow keys and press **Enter (دخول)**.
  5. For a test whose result is **not entered in the system** (e.g. a blood-image device or a semen analyser device), select the test and press **تم** so the system considers it done / printed / reviewed; press "تمت" again if the test is to be considered not yet complete. **ملاحظات** adds or edits a note for other doctors or for reception staff about this patient.
  6. **Results must be reviewed before they can be printed, and must be printed before they can be delivered to the patient.** If that did not actually happen, the same mechanism as item 5 is used to record it.
  7. In the profile result form (topic `004A.htm`): if the test belongs to a **group (profile)**, the form shows **all tests of the group**, with the tests selected for this patient **enabled**. On entering a result the program **marks abnormal and critical results and also writes a flag for them (high / low / critical)**. Tests that have **not** been ticked are shown, while **printed tests are shaded green**, and the results must be reviewed before printing or viewing.
  8. Some check boxes (e.g. the comment) have a **shaded frame**, meaning that value **stays fixed (saved) in this window**.
  9. Comment area: type it, or pick a **saved comment** via the orange "تعليق" button (a list opens; clicking a comment inserts it). The comment stored in the **normal-ranges list** can also be inserted by pressing the **test name**. A button **undoes the last inserted comment**.
  10. The **patient-history button's label changes with the number of results stored for the patient from this profile, ignoring today's result**.
- **Execution sequence (result-entry form buttons, in order):** `زر حفظ` (save the entered or amended result) → `زر طباعة` (print the results of the chosen tests that have been entered **and reviewed**) → `زر معاينة الطباعة` (preview those same results before printing) → `Patient history` (go to the patient's history window and build a custom history) → `زر رجوع` (return to the results window **without saving** the amendments and results) → `زر القائمة الرئيسية` (exit to the main menu **without saving**).
  Results-window action bar, in order: go to the patient-data window → print a **combined report** of the finished and reviewed results → print a **work sheet (order of work)** for the selected patient only → print an **envelope (ظرف)** for the selected patient → print the **medical history** if found, in a separate report or as a custom history printed in the tail of the result report → print a **blank report** carrying the barcode and the laboratory name/logo for other purposes → return to the system main menu.
- **Business logic:** Two independent audit buttons exist: **"بي"** reveals who registered the patient's data, how many modifications were made to it, who made the last modification, the account-payment method, and the users who collected the money; **"تي"** reveals for a selected test who entered the result, who reviewed it, who is responsible for printing, how many times the result was printed, and who delivered it — **all with date and time**. Both are restricted to the administrator or users with absolute rights.
- **Outputs:** Stored, flagged, reviewed results; printed reports; a print/review audit trail.
- **Side effects:** Result flags and review/print markers written to `patienttest`; a **print audit** record (`resultprint`, `printuser`, `printdate`, `printnum`) is created when printing; the print job goes to the configured report printer role.
- **Database interactions:** `patienttest` (343 statements; `resultt`…`resultt4`, `resultreview`, `resultprint`, `resultfinsh`, `printwith`, `printnum`, `printuser`, `printdate`, `testcode`, `testsimp`, `testunit`, `normalrang`, `nolowexe`, `nohighexe`), plus one profile table per test family (`cbc`, `liver`, `urine`, `stool`, `semen`, `hormones`, `helicobacter`, `igeallergy`, `lbc`, `fmf`, `pcr` — the last five being V2-new), `normalrange` (95 statements), `constanttable`, `comments`.
- **Permissions:** "بي"/"تي" audit buttons: administrator / absolute-rights users only.
- **Error conditions:** NOT DOCUMENTED for invalid numeric entry; the only documented refusal is the *unverified-result print gate* (see CAP-09 / printing section): `"Not found any Verified selected tests or result to print it"`.
- **Exception handling:** "رجوع" and "القائمة الرئيسية" deliberately discard unsaved amendments; the "تم"/"تمت" toggle is the documented correction path for results entered on external devices.
- **Related entities:** `patienttest`, `patientinfo`, `normalrange`, `constanttable`, `comments`, `daytip`, `noteic`.
- **Dependencies:** 30+ `result*` / `Result*` forms; `patientmain`; `anyreport`; `workpaper`; `patienthistory`; `patienthistory2`.
- **UI entry point (exact form name):** `patientmain` → results grid → per-profile form (e.g. `resultcbc`, `resultIgeAllergy`, `ResultPCR`).
- **Postconditions:** Result stored with abnormal/critical flags, review state and print state; combined/report output available.
- **Evidence classification:** **VERIFIED** for the documented behaviour and the result-grid ↔ `patienttest` field mapping (confirmed by the training video frame-by-frame). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topics 004.htm, 004A.htm] [P11 | analysis/V-CD-2019/10-training-video.md | §4 result grid field mapping] [P11 | analysis/BATCH-04/vb6/v1605/objects.json | result* objects]

### CAP-05 — Deliver results to the patient

- **Function ID:** CAP-05
- **Name:** تسليم نتائج التحاليل للمريض — Deliver results to patient
- **Purpose:** Hand over finished, reviewed, printed results to the patient and settle the patient's account in the same transaction.
- **Functional domain:** Result delivery
- **Description:** Reached from the main window → "المرضي" → "تسليم نتائج المرضي", or by pressing **F6** from any main program window. On entering the window the system **automatically displays today's patients who have not received their results**.
- **Trigger:** Menu `المرضي` → `تسليم نتائج المرضي`; or **F6**.
- **Preconditions:** Results must have been **reviewed** and **printed** before they can be delivered; the same "تم" mechanism used in CAP-04 is the documented fallback if that did not happen in reality.
- **Inputs:** patient selection (from the list or by barcode), delivery action, settlement amount / account clearance.
- **Validation rules (documented, in full):**
  1. **Barcode-reader hand-off** (multi-step confirmation): on the patient's arrival, the code printed on the **receipt** is read → the system displays the patient's data in the window; then the code on the patient's **result file (الفيل)** is read → the system **compares** the patient's displayed data with the data of the file about to be delivered → **if the data match**, the system asks whether to deliver the results → and **if a balance remains, the system warns about it**.
  2. **If the receipt is lost**, delivery can be performed **automatically from the patient's file**.
  3. **If the file code was not printed**, delivery can be done by **choosing the patient from the list (1) directly**.
  4. Section 4 shows the **number of unfinished results**, the **number of unprinted results**, and the **remaining balance for the laboratory or for the patient**. If a delivery was made by mistake, or a result should be considered already delivered, press **"مستلمة"**.
  5. Section 6 allows showing the **undelivered results** and sorting them by **lab-to-lab / independent patient / important persons**; it also allows showing the undelivered results **for any period determined by the user**, and showing **all delivered and undelivered results** by selecting the "الكل" property.
  6. Section 7's text box reaches any patient **by their code, or by the lab code, or by the file code** (the last is used in barcode-reader delivery).
- **Execution sequence:** Open the delivery window → (optionally scan receipt code then file code, or pick from the list) → confirm delivery → settle or clear the account → return to the main menu.
- **Business logic:** Delivery is gated on the review→print→deliver chain, and the file-code/receipt-code double scan is an anti-mis-delivery control that reduces substitution error. The "مستلمة" flag is the manual correction mechanism for a mistaken delivery.
- **Outputs:** `give` marker on the delivered tests; account settlement record; delivery audit (who delivered, when).
- **Side effects:** Marks results delivered; records payment/settlement; prints nothing by itself (printing is a separate step) but can trigger the delivery receipt.
- **Database interactions:** `patienttest` (`give`, `resultprint`, `resultreview`, `resultfinsh`), `patientinfo` (`totalprice`, `totalpricedisc`), `patienttotal`, `payment` (32 statements; `paymentnum` added in V2), `pricelist`.
- **Permissions:** Settlement/collection actions require an authenticated user; the "مستلمة" override is a user-initiated correction (no separate permission documented).
- **Error conditions:** On a barcode data mismatch the system does **not** proceed silently — it compares and asks. NOT DOCUMENTED for the mismatch refusal message text.
- **Exception handling:** "مستلمة" button; receipt-loss path; direct list selection path.
- **Related entities:** `patienttest`, `patientinfo`, `patienttotal`, `payment`, `frm_money`, `moneypaid`.
- **Dependencies:** `frm_money`(38), `moneypaid`(18), `patientmain`, `patientview`.
- **UI entry point (exact form name):** `patientmain` → `frm_money`.
- **Postconditions:** Results marked delivered; balance settled or explicitly left open and visible.
- **Evidence classification:** **VERIFIED**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 005.htm]

### CAP-06 — Search for a patient

- **Function ID:** CAP-06
- **Name:** البحث عن مريض — Search for a patient
- **Purpose:** Locate a patient by any of the laboratory's identifiers or by name, then inspect or act on their history, tests, results and account.
- **Functional domain:** Patient search
- **Description:** Reached from the main window → "المرضي" → "بحث عن مرض", or by pressing **F3** from any main program window. From this window the operator finds a specific patient, sees their history and number of visits to the laboratory, the tests of each visit, the unfinished / unprinted / undelivered results, and the open accounts; the patient can also be deleted from the system here.
- **Trigger:** Menu `المرضي` → `بحث عن مرض`; or **F3**.
- **Preconditions:** Logged in. For the backup-database search, the "mini version" of the system must be in use.
- **Inputs (types + constraints):**
  - **Code field** — accepts the **case code, the lab code or the file code**; a barcode reader may be used (put the cursor in the dedicated code field and read the code); without a reader, type the code and press **Enter**.
  - **Name search** — type the **first letters of the name** to list the **first 100 patients** whose names begin with those letters, **or** search **anywhere in the name**; **both methods can be used together** (example given: names beginning with (اح) and containing (خال) → "احمد خالد ، احمد خالد علي ، احمد محمد خالد").
  - **Phone number / mobile / national ID / any patient code** — each in **its own dedicated field**.
  - **Search constraints** — the result may be constrained to a **time period**, an **age stage**, a **specific sex**, or a **specific referral entity**.
- **Validation rules:**
  1. **At most 100 patients are displayed** — explicitly "to preserve data confidentiality"; stock-taking and sorting are done **through the statistics module instead**.
  2. Deletion of the selected patient is possible from this window (F10).
  3. In the mini-version there is an option to search **either the primary database or the backup database**. If the patient is found in the backup database, **copy the patient's code** and, from the "أدوات وصيانة قاعدة البيانات" (database tools & maintenance) window, copy that patient's data **back into the primary database** so it can be worked with and printed.
- **Execution sequence:** Open search window → enter search term / scan code → Enter → result list (≤100) → double-click a patient name to open the combined-results route → or act on the selected patient.
- **Business logic:** The 100-row cap is a deliberate confidentiality control that pushes bulk work (stock-taking, sorting) into the statistics module. The backup-database search plus "copy back" procedure is the mini-version's data-recovery path.
- **Outputs:** A filtered patient list; the selected patient's tests, counts (unfinished / unprinted / undelivered; patients with unclosed accounts), patient data, and the combined-results print path.
- **Side effects:** Reads only, except for the delete action (F10) and the backup→primary copy-back.
- **Database interactions:** `patientinfo` (428 statements — name/phone/ID/sex/age/date filters), `patienttest` (343 statements), `history` (13 statements — `SELECT * FROM History WHERE selector = 1 and labid= '…'`), `barcodes`, `phone`, `patienttotal`, `payment`.
- **Permissions:** Deleting a patient requires the delete-patient right (see CAP-02). NOT DOCUMENTED for search itself.
- **Error conditions:** NOT DOCUMENTED for empty searches.
- **Exception handling:** The backup-database path + copy-back is the documented recovery procedure.
- **Related entities:** `patientinfo`, `patienttest`, `history`, `phone`, `barcodes`, `patienttotal`.
- **Dependencies:** `patientview`(33), `patientmain`(84), `patienthistory`, `patienthistory2`, `labdb`/`labdb1` (database maintenance).
- **UI entry point (exact form name):** `patientmain` → `patientview`.
- **Postconditions:** Selected patient identified; search window refreshed (F5) for a new search.
- **Evidence classification:** **VERIFIED**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 006.htm]

### CAP-07 — Add / modify test (analyte) data

- **Function ID:** CAP-07
- **Name:** إضافة أو تعديل بيانات تحليل — Add or edit test data
- **Purpose:** Maintain the master definition of every test: naming in all contexts, grouping, sample material, prices, print behaviour and patient questions.
- **Functional domain:** Test master data
- **Description:** Reached from the main window → "بيانات النظام" → "بيانات التحاليل". Through the test-data window the operator can add a new test or modify a stored test's data (its name in the report, its name on the receipt, the group it belongs to, the time needed to complete the result, the type of material drawn (for the barcode), the test's prices, whether it is sent outside the laboratory, and so on).
- **Trigger:** Main menu → `بيانات النظام` → `بيانات التحاليل`.
- **Preconditions:** Logged in; the account must be authorised for system data (implied by the menu placement — the right is not named explicitly in the manual).
- **Inputs — the full documented field list of a test:**
  - **Test name** — the test's name in the program lists (the name customary inside the laboratory).
  - **Report name** — the test's name in the report, split into **two parts**: the first in a large font, the second in a small font; either part may be used alone, e.g. `SGPT/ALT (Alanine Aminotransferase)`.
  - **Bill name** — the test's name on the receipt; it too has two parts, and **when the first part is identical the system groups the tests into one line** (e.g. liver tests and kidney tests).
  - **History name** — the test's name in the medical history; preferably short, to save space in the report.
  - **Arabic name** — the test's Arabic name.
  - **Group name** — the group the test belongs to; useful **for statistics** and when adding a whole group of tests to a patient.
  - **Branch** — the laboratory branch responsible for this test.
  - **Log group** — the work-group the test belongs to; e.g. with two chemistry devices (a large and a small one) the sugar test runs on one or the other, so that when a work order (work sheet) for today's samples is requested using the work-group system, the program prints each device's tests separately.
  - **Collection** — notes on the conditions for drawing the sample.
  - **Test time** — the time needed to finish the test; **if the result is on the same day enter zero** (the receipt's result-pickup time depends on this number and is computed in days).
  - **Arrange number** — the ordering of the test in the test lists; **if several tests share the number, ordering is by name**.
  - **Patient price** — the price for the ordinary (independent) patient.
  - **Lab to Lab price** — the price for other laboratories and entities (used when the entity has no dedicated price list).
  - **Routine test** — makes the test appear in the routine (most-requested) test list in the patient-data window.
  - **See report** — a test with more than one result (urine, stool, blood picture) **cannot show its result** in the patient-data view.
  - **Print with other** — for large tests such as urine and stool, they **cannot be printed in a combined report**.
  - **Add with group** — when a test group is selected for a patient, whether this test is added with the group (e.g. Gamma-GT is not often requested together with liver enzymes).
  - **Main test** — a main test such as blood gases, haemoglobin, electrophoresis or FVD has more than one element; in the other elements this mark is cancelled.
  - **Material / container** — the type of material or container the sample is drawn in, for printing a dedicated barcode label, plus the test's name on that label (e.g. urine needs one "urine" label; creatinine-clearance needs a serum label and a 24-hour urine label).
  - **Sent-out flag** — for tests sent outside the laboratory, choose this, then choose the **destination entity** and the **cost price**; when such a test is entered for a patient it appears in the out-referred samples window, and when sent it is **entered into the laboratory's accounts**.
  - **Patient question** — a question posed to the patient when this test is selected (e.g. for lipid tests "are you fasting? must be fasting at least 12 hours"); it is shown in the patient-data window.
- **Validation rules:**
  1. Latin letters appearing in some test names can be entered by **clicking the desired letter** while typing the name; copy/paste works in the other text fields.
  2. A new test is added with the **"اضافة تحليل"** button, a stored test is modified with **"تعديل"**, or deleted; a button jumps to the **normal values/ranges** window for the selected test.
  3. To modify the data or the normal ranges of a **sub-group of tests** (e.g. the elements of the blood-picture test or FVD), type letters of the test name into the **third search field (search by test name)**; the system then displays **all elements** of that test, and the element is picked with the mouse.
- **Execution sequence:** Main menu → `بيانات النظام` → `بيانات التحاليل` → pick a test from list (1) or from the search result (2) → read/edit the field panel (3) → set material (4) → set sent-out destination & cost (5) → set patient question (6) → add/edit/delete (8) → optionally jump to normal ranges.
- **Business logic:** The same test has up to five distinct names (program list, report, receipt, history, Arabic) plus pricing per account class, a group for statistics, a branch, and a work-group for device routing. The bill-name grouping rule means two different tests can print as one receipt line.
- **Outputs:** Persisted test master record; updated test lists; receipt/report/medical-history naming for the test; barcode material assignment; out-referral routing with cost.
- **Side effects:** `testtable`/`customtesttable` writes; `subgrouptable`/`customgrouptable` grouping; `barcodes` material assignment; `instrument`/`loggroup`/`labbranch` references; downstream changes affect every patient's pricing, printing and statistics.
- **Database interactions:** `testtable` (74 statements; 609 rows; V2 added columns `REFRANGE`, `testcodebill`), `customtesttable` (9 statements), `subgrouptable` (14; 46 rows), `customgrouptable` (6), `testunits` (7), `testname` (7), `abbreviations` (6), `instrument` (5), `barcodes` (7), `loggroup` (7), `labbranch` (7), `comments` (28), `pricelist` (11), `pricemenu` (2), `gehats` (27; V2 added `ReferredPW` varchar(20), `ReferredID` int). The **609-test** and **46-profile** figures are the vendor catalogue's own counts for V2. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-1]
- **Permissions:** NOT DOCUMENTED as an explicit named right; the function sits behind the system-data menu.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `testtable`, `customtesttable`, `subgrouptable`, `customgrouptable`, `testunits`, `testname`, `abbreviations`, `instrument`, `barcodes`, `loggroup`, `labbranch`, `comments`, `pricelist`, `pricemenu`.
- **Dependencies:** `tools`, `setup`, `setup1`, `setup2`, `setup3`, `testmain`, `instrument`, `commentsetup`, `abbrevi`, `converter`, `z_units`, `z_barcodes`, `z_branchs`, `z_logs`, `z_group`, `z_titles`, `z_customgroup`, `z_gehats`, `z_pricelists`, `z_labaccount`, `normal_test`, `testrange`.
- **UI entry point (exact form name):** `setup1` / `setup2` / `setup3` (test data window reached from the system-data menu).
- **Postconditions:** Test master record updated and immediately effective for registration, pricing, printing and statistics.
- **Evidence classification:** **VERIFIED** (manual field list + V2 schema). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 007.htm] [P11 | analysis/V-CD-2019/02-schema.md | §3 added columns]

### CAP-08 — Manage reference (normal) ranges

- **Function ID:** CAP-08
- **Name:** إدارة النطاقات المرجعية — Manage reference ranges
- **Purpose:** Define, per test, the normal range and the abnormal/critical thresholds by sex and age band.
- **Functional domain:** Reference ranges / clinical rules
- **Description:** Main menu → "بيانات النظام" → "بيانات التحاليل" → select the test → press the "المعدل الطبيعي" button. Through this window a new range can be added or an existing one edited; the system shows the natural rate that matches the patient's sex and age stage.
- **Trigger:** Test-data window → select test → "المعدل الطبيعي" button.
- **Preconditions:** The test must exist in the test master. For a test whose natural rate does **not** differ by sex (e.g. sugar for men, women and children), the range must be entered **six times** — three sex × age-unit combinations for each sex.
- **Inputs (types + constraints):** the six mandatory bands are:
  - Men from 0 to 120 years **and** women from 0 to 120 years;
  - Men from 1 to 29 days **and** women from 1 to 29 days;
  - Men from 1 to 11 months **and** women from 1 to 11 months.
  Where the rate differs by age, e.g. men 0→12 years and men 12→120 years, and likewise for women.
- **Validation rules / documented field semantics:**
  - **Low limit / High limit** — the values on whose basis a result is considered **abnormal**; **outside the range the text background is shaded in the report**.
  - **Low flag / High flag** — an expression displayed for abnormal results, **both during result entry in the window and during printing in the report**.
  - **Low comment / High comment / Critical comment** — a comment about the patient's entered result, shown in the comment field of the window and of the report **when the test name is pressed**, and it is chosen according to whether the patient's result is low, high or critical.
  - **Critical range** — the text printed in the normal-range field of the report; it is shown **when "print critical ranges" is selected in the report-settings window**.
  - **Critical Low limit / Critical High limit** — the values on whose basis a patient's result is considered **critical**, and the critical-result expression is then displayed.
  - **Critical flag** — the expression shown for critical results.
  - **Test unit** — the unit of the test in this range (it appears next to the result in the report).
  - **Sex**, **Age From / To**, **Age unit**, **Normal range** (the printed text of the range).
- **Execution sequence:** Open test data → select test → "المعدل الطبيعي" → (1) list of all ranges recorded for the test → (2) command buttons → (3) selected range detail → save.
  Command buttons, in order: **اضافة مدى** (add a range for the selected test) · **تعديل** (modify the range selected in the list and shown) · **حفظ** (save either the new or the modified range) · **تراجع** (undo the current operation, whether adding or modifying a range) · **حذف** (delete the selected range) · **قائمة التحاليل** (return to the list of tests registered in the system).
- **Business logic:** A range is keyed by (test, sex, age band, age unit); the system auto-selects the range matching the patient's sex and age stage when a result is entered. Flags and comments are dual-purpose: they surface at entry time and at print time.
- **Outputs:** Persisted reference ranges with thresholds, flags and comments; automatic abnormal/critical marking at entry; shaded abnormal results in the report; optional critical-range printing.
- **Side effects:** Directly changes which results are flagged abnormal/critical across the whole database, and what the report prints.
- **Database interactions:** `normalrange` (95 SQL statements; **852 ranges**; V2 added column `REFRANGE`; V2 type changes `normalrang` → `varchar(MAX)` and `→ Memo`), `testtable`, `testunits`. The **852** figure is the vendor catalogue's count for V2 and is repeated in the Stage-9 report. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-3] [P11 | reports/Stage-9-V-CD-2019-Final-Comprehensive-Report.md | §1.3 ③]
- **Permissions:** NOT DOCUMENTED as a named right.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** "تراجع" (undo) for the in-flight add/edit; "حذف" for a committed range.
- **Related entities:** `normalrange`, `testtable`, `testunits`, `normal_test`, `testrange`, `outtest`.
- **Dependencies:** `normal_test`(36), `testrange`(17), `outtest`(11).
- **UI entry point (exact form name):** `setup1` → `normal_test`.
- **Postconditions:** Range list updated and effective for the next result entry.
- **Evidence classification:** **VERIFIED** for the manual rules and for the 14 documented field names; the **852-range** count is **VERIFIED** from the V2 vendor catalogue and Stage-9 (the V2 SQL extraction independently confirms the table's 95 SQL statements and the two V2 type changes). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 008.htm] [P11 | analysis/V-CD-2019/02-schema.md | §3 and §4]

### CAP-09 — Customise reports (text, dimensions, colours)

- **Function ID:** CAP-09
- **Name:** تخصيص التقارير — Customise reports
- **Purpose:** Edit report headings, layout, colours, margins and per-element print toggles.
- **Functional domain:** Report design & printing
- **Description:** Main menu → "المرضي" → "ادخال نتائج التحاليل" → pick a patient → double-click a test → in the result-entry form press the **orange group-name button at the top of the window** → the report-settings window opens.
- **Trigger:** Orange test-group-name button in the result-entry form.
- **Preconditions:** A test that belongs to a profile must be open, so that the report of that group is selected.
- **Inputs:**
  - The report name, the main headings (report name, side/sub title, normal-range title, doctor's signature, comment) and the page and inner-element alignment, colours, and show/hide of report components.
  - The **doctor-signature field consists of three lines**; any one of them or all of them may be used.
  - Toggles (in order): **Show abnormal result background color** (colour shading behind an abnormal result) · **Print Status Flag (Low, High, Critical)** (print the word high/low per the patient's result) · **Make Normal range Font Bold** · **Print Critical Ranges If Found** · **Print Patient History Automatically**.
  - Symbols and shapes used to mark elements and side headings.
  - Element placement: measured **from the start of the page from the left**; to pick a colour, click the element, the pointer changes, a colour-picker box opens, choose the colour and press OK.
  - Dimension boxes under each element: a **red-background box** holds the appropriate dimension; **green-background boxes** represent the display width of the text in the result page; **yellow-background boxes** represent the wrap value of the sub-headings and their elements.
  - Margins (part 5): **Vertical Space After Sub Title** (space after side headings and before the first of their elements) · **Vertical Space Between Tests** (space between each test and the next) · **Additional V. Space To Ref. Range** (push the normal ranges off the result's baseline — down when the ranges or test names are large) · **Printing printer** (the printer used for this report, where a colour printer is used for some reports).
- **Validation rules / documented scope of change:**
  1. **Changes made in this window apply only to this report** and **only to the computer on which the change was made**.
  2. Changes made in the header/footer colour window **apply to all reports**, but still **only to that computer**.
  3. The header/footer window allows: colouring parts of the header and footer; entering the **height of the separator lines**; **showing or hiding** the separators; and controlling the **thickness of the medical-history line**.
- **Execution sequence:** Open report settings → edit panel (1) → set toggles (2) → pick symbols (3) → colour and position elements (4) → set margins (5) → command buttons (6).
  Command buttons, in order: **زر حفظ الاعدادات** (save the changes and amendments made to the report) · **تعديل ألوان رأس وذيل التقرير** (opens the header/footer colour window) · **زر أبيض واسود** (reset the report colours to black-and-white only) · **زر عودة** (return to the window through which this one was reached, **discarding** the changes).
  Header/footer window buttons, in order: **زر حفظ الاعدادات** · **زر أبيض وأسود** · **زر عودة** (back to the report-settings window, discarding the changes).
- **Business logic:** The report layout is data-driven from per-profile INI files, not hard-coded in the report designer: `formsubtitle`, `reportmaintitle`, `reportsubtitle1`, `main_symb`, `sub_symb`, `subtitle_symb`, `normal_label`, `comment_label`, `signature`, `signature2`, `signature3`, `printer`, `printcritical`, `printhistory`, `statusflag`, plus the geometry keys `left1..left7`, `width4`, `width7`, `topvalue`, `bottomvalue`, `leftvalue`, `rightvalue`, `spacevalue` and the colour keys `colora..colort` (24 colours) and `colorafn..colortfn` (name/size/bold/underline per position).
- **Outputs:** Per-report INI configuration; the colour palette file (`REPORT.dll`, an INI with `[reportdata]` and `color1..color19`); the rendered report layout.
- **Side effects:** Configuration is local to the machine — a laboratory with several machines can therefore print **different-looking reports from the same data** unless the INIs are copied.
- **Database interactions:** `reportview` (2 statements — `SELECT stripnum,stripdiscrp,strip1 FROM reportview where stripdiscrp='MAIN'`) is the only report-configuration table in SQL; the bulk of the configuration lives in `Data\*.ini` — **223** report-profile INI files on the 2019 payload — and `SETING.ini`/`IDCARD.INI`. [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §1 `Data\*.ini` row]
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** The "عودة" button returns without saving; the "أبيض وأسود" button provides a global colour reset.
- **Related entities:** `reportview`, `Data\*.ini`, `SETING.ini`, `IDCARD.INI`, `bin\REPORT.dll`.
- **Dependencies:** `reportsetup`(113), `reportsetup2`(69), `static1`…`static6`, `printerselect`(11 module), `anyreport`(16).
- **UI entry point (exact form name):** `reportsetup` (reached from the result-entry form's orange group-name button); global report settings in `reportsetup2`.
- **Postconditions:** Report rendering configuration updated on the local machine only.
- **Evidence classification:** **VERIFIED** for the manual rules and the INI key inventory; **NOT RECOVERABLE** for the DataReport designer layouts themselves. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 009.htm] [P11 | analysis/BATCH-02/ini/test-catalogue.csv | header row — the report-profile key set] [P11 | analysis/BATCH-07/ini-key-delta.csv | the V2 template key delta] [P11 | analysis/V-CD-2019/10-training-video.md | §8 report-settings window]

### CAP-10 — Manage out-referred samples

- **Function ID:** CAP-10
- **Name:** إدارة العينات المرسلة للخارج — Manage samples referred out
- **Purpose:** Dispatch tests that are performed by an external laboratory, settle the resulting accounts, and keep the sent/not-sent status of each test consistent.
- **Functional domain:** Out-referred samples
- **Description:** After entering patient data and the tests required for each patient, if some of the patient's tests are to be sent out (previously defined in the system from the test-data window), the system recognises them and places them **automatically** in the out-referred samples window.
- **Trigger:** Press **F7** on the keyboard, or main menu → "حسابات" → "العينات المرسلة للخارج".
- **Preconditions:** The test must already be marked as sent-out in the test-data window with its destination entity and cost price.
- **Inputs:** the destination laboratory/entity; the amount that will be paid now; the period used for the search; the sample/test selection.
- **Validation rules / documented rules:**
  1. Section (2) can show **only the samples not yet sent**, or **all samples sent within a period determined by the user**.
  2. Clicking a sample in section (1) **collects all samples sent to the same destination** and shows the **total account**.
  3. The buttons in section (4) **send the selected sample** to the desired destination and **enter the value that will be paid now**; if the account is settled **and the courier will collect it**, press **"خالص"**, which makes the system **set the "sent" mark and save it**.
  4. **Changing the name of the laboratory or destination is not saved as a default value for that test.** If the destination is to become the default, press **"دائما اليه" before "موافق" or "خالص"**.
  5. The drop-down in section (5) filters the display to a **single destination or laboratory**, to reduce the search result.
  6. The two buttons in section (6) make the selected test **sent out** or **no longer sent out** (mirroring the test-data window).
  7. The drop-down in section (7) lists **all tests requested in the selected period**; from it, tests that are not sent can be displayed and sent **without changing the system data**, or made always-sent as in rule 6.
  8. The two buttons in section (8) show **all unsent samples** and **samples whose account has not been settled**, across **all registered patient data**.
- **Execution sequence:** Open the out-referred samples window → filter (2)/(5) → select a sample (3) → send + enter amount (4) → settle ("خالص") → optionally make the destination the default ("دائما اليه" then "موافق"/"خالص").
- **Business logic:** Out-referral is a two-level concept: a *test-level* flag (destination + cost price, maintained in CAP-07) and a *sample-level* dispatch record. The "دائما اليه" mechanic deliberately separates "this one-off dispatch" from "change the test's default destination", and refuses to silently rewrite the default.
- **Outputs:** Dispatch records with settlement state; amounts entered into the laboratory's accounts; a "sent" mark per sample.
- **Side effects:** Financial entries against the destination entity; patient test rows flagged as sent-out; default-destination changes when explicitly requested.
- **Database interactions:** `patienttest` (`sentout`, `send`, `otherlabname`), `sharekat` (5 statements — farm entities), `sharekathesab` (19 statements — farm test details), `antibiotic` (13 statements — `SELECT * From antibiotic WHERE (antiid NOT IN (SELECT antiid AS sdsdsd From cultureanti WHERE patientid=…))`), `antibio` (2 statements), `cultures` (3), `cultureanti` (7), `gehats` (27), `pricelist` (11).
- **Permissions:** NOT DOCUMENTED as a named right for this window.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** The "no longer sent out" toggle (rule 6) is the documented correction path.
- **Related entities:** `patienttest`, `sharekat`, `sharekathesab`, `antibiotic`, `antibio`, `cultures`, `cultureanti`, `gehats`.
- **Dependencies:** `sarfz`(26), `moenysharekat`(27), `moenymozafeen`(27), `labtolab`(32), `z_gehats`(56), `antibioticfrm`(29).
- **UI entry point (exact form name):** `sarfz`.
- **Postconditions:** Sample dispatch status and settlement recorded; test default destination changed only on explicit request.
- **Evidence classification:** **VERIFIED**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 010.htm]

### CAP-11 — Accounts, stocktaking and lab accounting

- **Function ID:** CAP-11
- **Name:** الحسابات والجرد — Accounts and stocktaking
- **Purpose:** Produce period-scoped financial and workload reports for patients, out-referred samples, referring entities, cash movements and individual users.
- **Functional domain:** Billing & accounting
- **Description:** From the main menu choose "حسابات" then press "الجرد وحساب الدرج" (or press **F7** from any main window). The **monthly accounts and stocktaking window** appears.
- **Trigger:** Main menu → `حسابات` → `الجرد وحساب الدرج`; or **F7** (note: F7 is shared with CAP-10's out-referred samples window — the manual documents both routes).
- **Preconditions:** Logged in; a period must be selected (default = today).
- **Inputs:** the accounting period (default today's date) and the "عرض" button.
- **Validation rules / documented content (all seven sections, in order):**
  1. The **period** to be stock-taken is chosen (default = the current date), then the "**عرض**" button is pressed.
  2. **Patient accounts** are displayed; pressing each button shows a report of the **patients' names and data** and their **detailed breakdown**. The button **"ماتم تحصيلة"** asks the system whether to show **only the money collected from the patients of the selected period**, or **every patient who paid during that period**.
  3. The account of the **out-referred samples** in the selected period is displayed; the button **"العينات المرسلة للخارج"** shows the samples sent in that period and their accounting — **either each sample in detail, or all samples of each destination grouped**.
  4. **Expenses and revenues** recorded in the system through the accounts window (cash withdrawal / cash deposit) are displayed.
  5. **Patients with a remaining balance at the laboratory**, and the **commissions of the referral entities** if any, are displayed.
  6. For **each user** who worked in the period, the amounts they collected and the transactions they made are shown.
  7. A **statement (مطالبة)** can be produced for an entity, and the **volume of dealings with other entities** can be measured, **aggregated or detailed**.
- **Execution sequence:** Open accounts & stocktaking → set period → "عرض" → read/reports per section → print a statement for a specific entity.
- **Business logic:** This window is the single aggregation point where four dimensions of the laboratory's money are reconciled: patient balances, out-referral cost, referral commissions and per-user collection performance. The two different meanings of "money collected in the period" (money taken *in* the period vs. money belonging to *patients of* the period) are explicitly offered as a choice because they answer different questions.
- **Outputs:** Period-scoped account reports, per-user workload reports, referral statements, cash-movement listings.
- **Side effects:** Read-only reporting plus the printing of statements.
- **Database interactions:** `payment` (32 statements; V2 added `paymentnum`), `patientinfo` (`totalprice`, `totalpricedisc`), `patienttotal` (12), `gehats` (27 — referral entities), `pricelist` (11), `pricemenu` (2), `shopping` (6 — `select * from shopping where matlobid=`), `sarfeda3` (2), `patienttest` (343).
- **Permissions:** NOT DOCUMENTED as a named right; the window is under the "حسابات" menu.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `payment`, `patientinfo`, `patienttotal`, `gehats`, `pricelist`, `pricemenu`, `shopping`, `sarfeda3`.
- **Dependencies:** `labfunction`(25 module), `frm_money`(38), `moneypaid`(18), `z_labaccount`(18), `z_pricelists`(27), `labtolab`(32), `printerselect`(11).
- **UI entry point (exact form name):** `labfunction` (module) driving `frm_money` / `z_labaccount`.
- **Postconditions:** Period accounts presented and printable.
- **Evidence classification:** **VERIFIED**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 011.htm]

### CAP-12 — Back up the system database

- **Function ID:** CAP-12
- **Name:** النسخ الاحتياطي — Database backup & maintenance
- **Purpose:** Create, restore, list, delete and purge database backups; and, in the large-lab configuration, reset the system's data.
- **Functional domain:** Database maintenance
- **Description:** Main menu → "اعدادات" → press the "**Database Maintenance**" button. **The system closes** and a password dialog opens; enter the base password `123` and press OK. The vendor advises changing the password afterwards to protect the system from tampering.
- **Trigger:** Main menu → `اعدادات` → `Database Maintenance`.
- **Preconditions:** The **base password `123`** (documented default) must be entered; for the large-lab variant the window differs from the small-lab variant.
- **Inputs:** the maintenance password; the database path (part 3); the selected period (small-lab variant); the backup file name (auto-filled with today's date); the buttons to zero data.
- **Validation rules / documented behaviour:**
  - **Large-laboratory window:**
    - part 1 — change the database-repair/maintenance password and leave the window;
    - part 2 — **zero all the system's data** by selecting **all the buttons in order**, or a subset of them, to clear only some data;
    - part 3 — select the database path, for backup or restore;
    - part 4 — all previous backups are listed; part 5 — their **count**; part 6 — their **size**; any of them can be **deleted** by selecting it and pressing "حذف";
    - part 7 — the system **automatically names the backup file with today's date** when the window opens; pressing the backup button performs the backup, and the operator waits for the message **"Press any key to continue"**; after the backup the **"تحديث" (refresh)** button next to part 4 must be pressed so the new file appears in the list;
    - part 8 — to restore, select the backup file and press "استرجاع", then wait for the restore to finish.
  - **Small-laboratory window (after the same password):**
    - part 1 — change the maintenance password and leave;
    - part 2 — zero the system's data, all buttons or a subset;
    - part 3 — **restore a single patient's data via that patient's work code (the work/shift code, not the lab code)**, obtained from or copied out of the patient-search window when searching in the backup database;
    - backup/restore is performed by **choosing the period** and then the operation;
    - the operator may **cancel patients' results and data from the primary database** after backing them up — for speed of performance and system response — or **keep them** so that their medical history can still be printed; or **delete the patients permanently** by deleting the selected period from **both the primary and the backup database**.
  - **Backup file naming/location:** the file is named **`Patient_yyyymmdd.bak`** and lives **inside the same database path**. The vendor advises moving the backup file to another disc or device to protect against hard-disk failure.
  - The **most recent backup file** contains all the data present in the earlier-dated files, **except** where the database was zeroed and some information was deleted from the system.
  - **Enlarging the backup database does not affect system performance**, except when patients are added to the backup database or when searching inside the system **in** the backup database.
- **Execution sequence:** `اعدادات` → `Database Maintenance` → system closes → password `123` → (large-lab or small-lab window) → select path → backup / restore / delete / zero as required → refresh the list.
- **Business logic:** Two deployment shapes are supported: a single-site "large laboratory" that uses whole-database backups with a full data-zero facility, and a "small laboratory" mini-version that works on a **period-scoped** basis with **per-patient restore by work code**. The trade-off is explicit: archiving to the backup database buys speed but forfeits the patient's medical history.
- **Outputs:** `.bak` backup files in the database folder; restored data; refreshed backup list; cleared data subsets.
- **Side effects:** The application **closes** to enter this function; data may be zeroed; the backup database grows; the maintenance password may be changed.
- **Database interactions:** the whole database (`Patients.mdb`, `data.mdb`, `Branch_Data.mdb`); the backup file itself (`Patient_yyyymmdd.bak`); `Branch_Data.mdb` is the **branch schema template** (49 tables, 0 rows, modified schema).
- **Permissions:** The **base password `123`** guards the whole maintenance window; it is a documented, shipped default and is explicitly recommended for change — this is the only access control on this window.
- **Error conditions:** NOT DOCUMENTED for a failed backup or restore beyond the "Press any key to continue" handshake.
- **Exception handling:** The "تحديث" (refresh) step after a backup; per-patient restore in the small-lab variant; the operator-advised off-host copy of the `.bak` file.
- **Related entities:** `Patients.mdb`, `data.mdb`, `Branch_Data.mdb`.
- **Dependencies:** `labdb`(24 module), `labdb1`(20 module), `tools`(1), `labmainTools`(6), `Patient Data Transport.exe` (separate tool).
- **UI entry point (exact form name):** `tools` / `labmainTools` (Database Maintenance dialog), with `labdb`/`labdb1` performing the work.
- **Postconditions:** Backup file written and listed; restore applied; or selected data zeroed.
- **Evidence classification:** **VERIFIED** for the manual procedure; the *internal* backup implementation (which engine / file format) is **NOT DOCUMENTED**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic backup.htm] [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 10 Branch_Data.mdb]

### CAP-13 — Clinical constants and calculation factors

- **Function ID:** CAP-13
- **Name:** الثوابت السريرية — Clinical constants and factors
- **Purpose:** Maintain the numeric coefficients and control values that the system applies when deriving or interpreting results.
- **Functional domain:** Clinical calculation rules
- **Description:** "Constants and system parameters must be verified first before working for the first time." The constants listed are: **Prothrombin Time (PT): ISI, Control Time and Concentration table**; **Partial Thromboplastin Time (PTT): Control Time**; **COMPLETE BLOOD COUNT (CBC):** **Hct (Hematocrit) = Hgb × 3.3**, used **when a haematocrit result is not entered** — the haematocrit is computed from the haemoglobin.
  - **Hemoglobin % (Hgb%) = Hgb × 8.25** — Male **or** Female, age **less than one year**
  - **Hemoglobin % (Hgb%) = Hgb × 7.50** — Male **or** Female, age **from 1 – 12 years**
  - **Hemoglobin % (Hgb%) = Hgb × 6.25** — Male, age **greater than 12 years**
  - **Hemoglobin % (Hgb%) = Hgb × 6.75** — Female, age **greater than 12 year**
- **Trigger:** During result entry, press the **"Constants"** button **at the bottom-right of the window**.
- **Preconditions:** The constant must be verified **before the first use of the system**; when editing during result entry for a child, **the child-specific constant is modified**, whereas for a male or a female the **adult constant** is modified.
- **Inputs:** the constant values (ISI, control time, concentration table entries, CBC factors).
- **Validation rules:** The four CBC haemoglobin factors are **sex- and age-partitioned exactly as listed** — 8.25 applies to both sexes below one year; 7.50 applies to both sexes from 1 to 12 years; 6.25 to males above 12 years and 6.75 to females above 12 years.
- **Execution sequence:** Open the result-entry form → press "Constants" (bottom-right) → modify the appropriate constant (child-specific or adult, per sex) → save.
- **Business logic:** These factors implement the **Hct-from-Hgb fallback**, so that a CBC can be completed when the haematocrit analyser result is missing. Editing is partitioned by sex and age band exactly as the derivation rules require.
- **Outputs:** Derived haematocrit and haemoglobin-percentage values; configured PT/PTT control values.
- **Side effects:** Changes the computed values of every subsequent CBC result derived from these factors.
- **Database interactions:** `constanttable` (3 statements — `SELECT * FROM constanttable where constantdiscrp='PTCONS'`), `normalrange` (95), `cbc` (10 statements; V2 added `Blast`, `Juvenile`, `Myelocytes`, `NRBCWBC`, `PDW`, `Promyelocyte`, `RDW`, `bandx`, `seg`), `pt` (11), `ptc` (4 — `select * FROM PTC where ConstID=`; V2 added `ConstID` IDENTITY and `concent` → float).
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `constanttable`, `cbc`, `pt`, `ptc`, `normalrange`.
- **Dependencies:** `normal_test`, `testrange`, `resultcbc`, `resultpt`, `qcfrm`.
- **UI entry point (exact form name):** `resultcbc` / `resultpt` (the "Constants" button on the result-entry form).
- **Postconditions:** Factor set updated and applied to subsequent derived results.
- **Evidence classification:** **VERIFIED** (manual gives the exact coefficients; the `constanttable` storage is confirmed by the V2 SQL extraction). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic nots.htm item 1]

### CAP-14 — Fixed test-numbering constraint

- **Function ID:** CAP-14
- **Name:** قيد ترقيم الفحوصات — Fixed test numbering
- **Purpose:** Protect the reserved test numbers that the system and the report layout depend on.
- **Functional domain:** Test master data
- **Description:** "Test numbers and the identity of the number assigned to each test must not be changed."
- **Trigger:** Attempting to renumber a test in the test-data window.
- **Preconditions:** The urine analysis test exists in the system as test number 4.
- **Validation rules (documented, complete):**
  - **The urine analysis test is number 4 in the system. It must not be changed to any other number — even if that slot happens to be empty — and its data and names cannot be freely modified**, e.g. `Urine` or `Urine Examination` or `Urineanalysis`.
- **Execution sequence:** The rule is preventive: it constrains what the operator may do in CAP-07's edit path.
- **Business logic:** Test numbers are a stable contract between the test master, the result forms, the report layouts and the barcode material rules; the manual reserves number 4 for urine analysis and forbids reassignment of that identity.
- **Outputs:** A stable test-number space; urine analysis permanently at number 4.
- **Side effects:** None — this is a constraint, not an action.
- **Database interactions:** `testtable` (`testcode`; 74 statements, 609 rows), `subgrouptable` (14 statements, 46 rows) — counts per the V2 vendor catalogue. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-1]
- **Permissions:** NOT DOCUMENTED — the rule is described as a usage note rather than an enforced error.
- **Error conditions:** NOT DOCUMENTED — no error message is specified for a violation.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `testtable`, `subgrouptable`, `customtesttable`.
- **Dependencies:** `setup1`/`setup2`/`setup3`, `testmain`.
- **UI entry point (exact form name):** `setup1` (test-data window) — the constraint applies to the edit path.
- **Postconditions:** Test numbering unchanged.
- **Evidence classification:** **VERIFIED** (explicit manual statement). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic nots.htm item 2]

### CAP-15 — Keyboard shortcuts and the results UI

- **Function ID:** CAP-15
- **Name:** اختصارات لوحة المفاتيح — Keyboard shortcuts
- **Purpose:** Give the operator a keyboard-driven path through the laboratory's high-frequency screens.
- **Functional domain:** UI behaviour
- **Description:** The shortcuts are **per-window**, and they are not uniform: the same key means different things in different windows. The full, window-by-window mapping is reproduced in **§5 Keyboard shortcuts and UI-action behaviours** of this document. `daytip` carries 20 Arabic tip texts that carry the F2 / F3 / F7 shortcuts.
- **Trigger:** Key press in a focused window.
- **Preconditions:** The window in question must be open; most shortcuts are stated to work "from any of the main program windows".
- **Inputs:** Key codes F1–F12, Enter, Esc, Up/Down arrows, Ctrl.
- **Validation rules:** F-key semantics are **window-scoped** — see §5. In the barcode window, the test-data window, the normal-ranges window, the report-settings window, the out-referred samples window and the accounts window, the manual states explicitly: **"لا توجد اختصارات بعد"** ("there are no shortcuts yet").
- **Execution sequence:** Press the key in the focused window → the corresponding navigation or state change occurs.
- **Business logic:** F2/F3/F4/F6/F7 are global *navigation* keys (patient data / search / results / delivery / out-referred samples), F5 is a *refresh* key, F8/F9/F12 are *state* keys (review / save-or-finish / printed) whose meaning depends on the window, F10 is *delete*, F11 is barcode or print-preview depending on the window.
- **Outputs:** Navigation, refresh, and state transitions (reviewed / finished / printed / saved / deleted / printed-receipt / barcode-window).
- **Side effects:** State changes in `patienttest` (review/finish/print flags) and deletions in the patient master.
- **Database interactions:** `patienttest` (`resultreview`, `resultfinsh`, `resultprint`), `patientinfo` (delete), `daytip` (2 SQL statements).
- **Permissions:** Deletion (F10) requires the delete-patient right.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** Esc is the universal "cancel / back to main menu" key and is documented as *discarding* unsaved changes in the result-entry window.
- **Related entities:** `daytip`, `patienttest`, `patientinfo`.
- **Dependencies:** `labmain`, `patientmain`, `addpatient`, `barcode`, `result*` forms.
- **UI entry point (exact form name):** Global — no single form; documented per window.
- **Postconditions:** The documented state transition has been applied.
- **Evidence classification:** **VERIFIED** (the shortcut lists are quoted from the CHM manual bundled with this build). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topics 003.htm, 004.htm, 004A.htm, 005.htm, 006.htm]

---

## 3. Detailed per-function specifications — the 41 objects introduced by this build

> **Counting note.** The upstream document labels its §2 table "41 كائنًا جديدًا" but the table itself lists only the **20** non-DataReport objects; the remaining **21** are the DataReports listed in its §3. Together the two tables account for exactly **41** objects. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 and §3 headings]
>
> For each of the 20 code objects below the **identifier is the exact VB6 object name**. Method counts are the V2 values; control counts come from `forms-blob.txt`.

### 3.1 New code objects (20) — full specifications

#### 3.1.1 `SMSfrmsenderos` (form, 139 methods, 186 controls)

- **Function ID:** `SMSfrmsenderos`
- **Name:** مُرسِل رسائل SMS — SMS message sender
- **Purpose:** Compose, target and send SMS messages to patients (and to doctors / laboratories) about results.
- **Functional domain:** SMS / notifications
- **Description:** The largest new V2 form by procedure count. It is the sending counterpart of the new SMS master tables (`smsgroups`, `smslist`, `SMStemplate`, `SMSSender`) and of the new `ReportSMS` DataReport.
- **Trigger:** NOT DOCUMENTED (no menu path is recorded in the CHM manual bundled with this build, which documents none of the 41 objects introduced by this build). **UNVERIFIED**: the vendor learning manual's "outside-the-index" section records *"إنشاء حساب للطبيب المعالج لاستخدام خدمة نتيجة"* and *"إنشاء حساب للمعمل لاستخدام خدمة نتيجة"* against `SMSSender` · `smsgroups`. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.7 table]
- **Preconditions:** A recipient phone number must exist in `smslist` (or a group in `smsgroups`); a message body may come from `SMStemplate`; a patient linkage is recorded via `patientid` and `PatDrName`.
- **Inputs (types + constraints):**
  - `patientid` — varchar(13) — the patient the message concerns.
  - `PatDrName` — varchar(60) — the doctor's name.
  - `smsMobile` — varchar(20) at creation, **widened to varchar(100)** by a V2 `ALTER COLUMN` (this widening is one of the 14 type changes in the 1.605 build).
  - `SMSLength` — Smallint — the message length.
  - `SMStext` — varchar(MAX) in the SQL-Server DDL variant, varchar(255) in the Access/AutoIncrement DDL variant.
  - `SMSautonum` — `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` — the send-record key.
  - `username` — varchar(50) — added by `ALTER TABLE` in V2 (the sending operator).
  - `smsgroups`: `ID` (identity), `grouptype` (Smallint), `smsgroup` (varchar(50)).
  - `smslist`: `ID` (identity), `smstype` (Smallint), `smsphone` (varchar(20)), `smsname` (varchar(50)), `smsgroup` (varchar(50)), plus V2-added `send` (Smallint).
  - `SMStemplate`: `templatenum` (identity), `smstext` (varchar(MAX) / varchar(255)).
- **Validation rules:** NOT DOCUMENTED at the UI level. Schema-level constraints are VERIFIED: `smsMobile` is capped at 100 characters; `SMStext` is capped at 255 characters in the Access dialect and unbounded in the SQL-Server dialect.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** The schema separates **recipients** (`smslist`), **recipient groups** (`smsgroups`), **message templates** (`SMStemplate`) and **sent-message audit records** (`SMSSender`, keyed by patient + doctor + mobile + text + length + operator + timestamp). This is an audit-bearing notification subsystem, not a bulk-sender without a log.
- **Outputs:** A row in `SMSSender` recording the send; a printed/visible `ReportSMS` output.
- **Side effects:** Writes to `SMSSender`; external SMS dispatch via a gateway (the gateway/transport is **NOT DOCUMENTED** in the evidence).
- **Database interactions:** `smssender` (10 statements — `Select * from SMSSender where patientid='…'`), `smslist` (10 — `Select * from smslist where smstype=`), `smsgroups` (8 — `Select * from smsgroups where ID=`), `smstemplate` (4 — `Select * from SMStemplate order By SMStext`), `patientinfo` (`SMSMob` — the patient's mobile, added in V2).
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `smssender`, `smslist`, `smsgroups`, `smstemplate`, `patientinfo` (`SMSMob`), `ReportSMS`.
- **Dependencies:** `smsgroups`, `smslist`, `SMStemplate`, `SMSSender` (tables created by the embedded DDL at run time).
- **UI entry point (exact form name):** `SMSfrmsenderos` itself (its launch path is NOT DOCUMENTED).
- **Postconditions:** The message is logged with its recipient, text, length, operator and timestamp.
- **Evidence classification:** **VERIFIED** for object identity, method/control counts, table and column inventory, DDL and the V2 type widening; **NOT DOCUMENTED** for the UI flow. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row SMSfrmsenderos] [P11 | analysis/BATCH-04/schema/created-tables.csv | SMSSender/SMStemplate/smsgroups/smslist rows] [P11 | analysis/V-CD-2019/02-schema.md | §4 type changes]

#### 3.1.2 `resultIgeAllergy` (form, 231 methods, 178 controls)

- **Function ID:** `resultIgeAllergy`
- **Name:** إدخال نتائج حساسية IgE — IgE allergy result entry
- **Purpose:** Enter and interpret allergen-specific IgE results across a large allergen panel.
- **Functional domain:** Result entry — new clinical profile (allergy)
- **Description:** The largest result-entry form in V2 (231 procedures). It operates on the `IgEallergy` table, which carries up to **40 allergen items**, each with a name, a result, a class and a type flag.
- **Trigger:** Double-clicking an IgE-allergy test on the patient's test list, exactly like the other profile forms (the general CAP-04 mechanism).
- **Preconditions:** The patient must have an IgE-allergy test ordered; the allergen panel configuration for that profile must exist.
- **Inputs (types + constraints):** for each of the up to 40 items — `Item<n>` varchar(50) (allergen name), `RESULT<n>` varchar(25) (the measured result), `Class<n>` Smallint (the IgE class 0–6 interpretation), `TypeF<n>` Smallint (a per-item type flag). V2 extended the table with the item blocks **12, 24 and 36** (each block adds `Item`, `RESULT`, `Class`, `TypeF` for 4 items) — the first three blocks (1–11) pre-existed the shipped schema.
- **Validation rules:** The class/flag semantics (IgE class boundaries) are **NOT DOCUMENTED** in the evidence; the vendor learning manual only records the report titles *"IgE food allergy test panel"*, *"Ref Range (Class):"* and *"Comment:"* from the corresponding INI profiles.
- **Execution sequence:** NOT DOCUMENTED at the field level; the profile-form convention (open → enter → F8 review → F9 save → F12 print) applies.
- **Business logic:** A class-per-item design is the standard IgE interpretation model (class boundaries 0–6); the presence of a separate `TypeF` per item distinguishes food allergens from inhalant allergens, matching the four panel profiles the lab ships: Food Panel (20 causes), Inhalant Panel (20 causes), Mixed Panel (food & inhalant, 40 causes), Pediatric Panel (20 causes).
- **Outputs:** Per-item results with class; a printed IgE report.
- **Side effects:** Writes to `IgEallergy` and to the generic `patienttest` row for the profile.
- **Database interactions:** `igeallergy` (1 statement — `SELECT * FROM IgEallergy where patientid='…'`), `patienttest`, `normalrange` (the class reference range).
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `IgEallergy`, `patienttest`, `normalrange`, `ReportIGE1`, `ReportIGE1s`.
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `resultIgeAllergy`.
- **Postconditions:** IgE results and their classes stored per patient.
- **Evidence classification:** **VERIFIED** for object identity, counts, the 40-item schema and the V2 item-block additions; **INFERRED** for the class-interpretation model. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row حساسية IgE] [P11 | analysis/BATCH-04/schema/added-columns.csv | igeallergy rows] [P11 | analysis/BATCH-02/ini/test-catalogue.csv | rows 164-167] [P11 | analysis/BATCH-07/ini-key-delta.csv | no `reportdata.formsubtitle` change for `164.ini`–`167.ini` — the four IgE panel titles are unchanged in the V2 template]

#### 3.1.3 `Resultsemen5` (form, 216 methods, 231 controls)

- **Function ID:** `Resultsemen5`
- **Name:** إدخال نتائج السائل المنوي v5 — Semen analysis v5 result entry
- **Purpose:** A second-generation semen-analysis entry form (v5) covering the expanded WHO-style semen parameters.
- **Functional domain:** Result entry — new clinical profile (andrology)
- **Description:** A distinct profile form alongside `Resultsemen` (222 procedures in V2). The 2019 printer profile list includes a distinct `SEMEN5` report category, confirming that v5 is a **separate report profile** from `SEMEN`.
- **Trigger:** Double-clicking a semen-v5 test on the patient's test list.
- **Preconditions:** A semen-v5 test must be ordered for the patient.
- **Inputs:** semen parameters (volume, concentration, motility, vitality, morphology, pH, liquefaction time …) — the exact analyte list is **NOT DOCUMENTED**; the V2 type changes on the shared `semen` table give the parameter types: `Liquefaction` → varchar(10), `Viscosity` → varchar(15), and a new `testcode` column was added.
- **Validation rules:** NOT DOCUMENTED. The shared `semen` table carries `resultt`…`resultt4` patterns with `Select * FROM semen where patientid='…'`.
- **Execution sequence:** NOT DOCUMENTED beyond the standard profile-form convention.
- **Business logic:** Semen analysis is implemented twice in parallel in this build: `Resultsemen` (222 procedures) and `Resultsemen5` (216 procedures) coexist as separate objects with separate report profiles (`SEMEN` and `SEMEN5`) — a parallel implementation rather than an in-place extension.
- **Outputs:** Semen results stored per patient; a `SEMEN5` report.
- **Side effects:** Writes to `semen` and `patienttest`.
- **Database interactions:** `semen` (2 statements — `Delete FROM semen where patientid='…'`), `patienttest`, `normalrange`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `semen`, `patienttest`, `normalrange`, `Reportsemen1`, `Reportsemen2`, `Reportsemen1s`, `Reportsemen2s`, `Reportsemen`.
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `Resultsemen5`.
- **Postconditions:** Semen v5 results stored.
- **Evidence classification:** **VERIFIED** for identity, counts, the `SEMEN5` report category and the `semen` type changes; **NOT DOCUMENTED** for the analyte list. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row Resultsemen5] [P11 | analysis/BATCH-02/ini/printer-settings.csv | SEMEN5 category] [P11 | analysis/V-CD-2019/02-schema.md | §4 type changes]

#### 3.1.4 `ResulturineAuto` (form, 184 methods, 195 controls)

- **Function ID:** `ResulturineAuto`
- **Name:** إدخال نتائج التحليل الآلي للبول — Automated urine analysis result entry
- **Purpose:** Enter results produced by an automated urine-analyser strip reader.
- **Functional domain:** Result entry — new clinical profile (urinalysis, automated)
- **Description:** A parallel automated-urinalysis entry form alongside the manual `Resulturine` (167 procedures in V2). The 2019 printer profile list contains a distinct **`URINEauto`** category alongside `URINE`, confirming a separate report profile.
- **Trigger:** Double-clicking an automated-urine test on the patient's test list.
- **Preconditions:** The patient must have an automated-urine test ordered.
- **Inputs:** strip analytes — the exact analyte list is **NOT DOCUMENTED**. The `urine` table gained three V2 columns: **`T56`, `T57`, `testid`**, which are consistent with additional analytes and with an explicit test-id link (the same `testid` pattern appears on the new `LBC` table).
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED beyond the profile-form convention.
- **Business logic:** The V2 addition of `urine.testid` lets an automated strip result be bound to a specific analyte/test identity rather than a positional slot, which is a prerequisite for instrument-driven entry.
- **Outputs:** Automated urine results stored per patient; a `URINEauto` report.
- **Side effects:** Writes to `urine` and `patienttest`.
- **Database interactions:** `urine` (3 statements — `Delete FROM Urine where patientid='…'`), `patienttest`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `urine`, `patienttest`, `normalrange`, `Reporturine`, `Reporturines`.
- **Dependencies:** `normal_test`, `reportsetup`, `instrument`.
- **UI entry point (exact form name):** `ResulturineAuto`.
- **Postconditions:** Automated urine results stored.
- **Evidence classification:** **VERIFIED** for identity, counts, the `URINEauto` category and the `urine` column additions. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row ResulturineAuto] [P11 | analysis/BATCH-02/ini/printer-settings.csv | URINEauto category] [P11 | analysis/V-CD-2019/02-schema.md | §3 urine row]

#### 3.1.5 `resulthpylori` (form, 83 methods, 94 controls)

- **Function ID:** `resulthpylori`
- **Name:** إدخال نتائج H. pylori — *H. pylori* result entry
- **Purpose:** Enter *Helicobacter pylori* diagnostic results (antigen/biopsy/urea-breath style determinations).
- **Functional domain:** Result entry — new clinical profile (gastroenterology)
- **Description:** Operates on the new `Helicobacter` table, which carries seven columns: `patientid` varchar(13), `requestdate` DATETIME, `comment` varchar(255) and six result fields `hpab`, `hpag`, `hpbiop`, `hpiga`, `hpigi`, `hpigm` (all varchar(50)).
- **Trigger:** Double-clicking an *H. pylori* test on the patient's test list.
- **Preconditions:** The patient must have an *H. pylori* test ordered.
- **Inputs (types + constraints):** `patientid` varchar(13); `requestdate` DATETIME; `comment` varchar(255); `hpab` varchar(50); `hpag` varchar(50); `hpbiop` varchar(50); `hpiga` varchar(50); `hpigi` varchar(50); `hpigm` varchar(50).
  - **Note on the two DDL paths:** the shipped `Helicobacter` CREATE statement defines **7** columns (`hpab`, `hpgi`, `hpag`, `hpigm`, `hpigi`, `comment` among them), and the V2 `ALTER TABLE` pass **adds `hpab`, `hpbiop`, `hpiga`** to the existing table — the two DDL paths (create-new vs. alter-existing) use slightly different column sets, which is exactly why the alter pass exists.
- **Validation rules:** NOT DOCUMENTED; all six analyte fields are free varchar(50) values.
- **Execution sequence:** NOT DOCUMENTED beyond the profile-form convention.
- **Business logic:** Six parallel result fields cover the recognised *H. pylori* determinations: **hpab** (antibody), **hpag** (antigen), **hpbiop** (biopsy), **hpiga** (IgA), **hpigi** (IgG), **hpigm** (IgM) — an antibody-isotype panel plus a direct antigen and a biopsy result on one patient record.
- **Outputs:** *H. pylori* results stored per patient with a free comment.
- **Side effects:** Creates the `Helicobacter` table if absent and adds its missing columns at run time (the embedded DDL applied at run time).
- **Database interactions:** `helicobacter` (8 statements — `SELECT * FROM Helicobacter where patientid='…'`), `patienttest`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `Helicobacter`, `patienttest`, `normalrange`, `instrument` (a `Helicobacter` report category exists in the printer profile list).
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `resulthpylori`.
- **Postconditions:** *H. pylori* results stored; the table/columns are guaranteed to exist.
- **Evidence classification:** **VERIFIED**. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row H. pylori] [P11 | analysis/BATCH-04/schema/created-tables.csv | Helicobacter rows] [P11 | analysis/BATCH-04/schema/added-columns.csv | helicobacter row]

#### 3.1.6 `ResultFMF` (form, 48 methods, 105 controls)

- **Function ID:** `ResultFMF`
- **Name:** إدخال نتائج حمى البحر المتوسط — Familial Mediterranean Fever result entry
- **Purpose:** Enter FMF (familial Mediterranean fever) diagnostic results.
- **Functional domain:** Result entry — new clinical profile (genetics / rheumatology)
- **Description:** Operates on the new `FMF` table.
- **Trigger:** Double-clicking an FMF test on the patient's test list.
- **Preconditions:** The patient must have an FMF test ordered.
- **Inputs (types + constraints):** `patientid` varchar(13) (the `FMF` table has **2 columns** in the shipped DDL — `patientid` and one further column, the second being an added column in the alter path).
- **Validation rules:** NOT DOCUMENTED — the analyte list is not recoverable from the evidence.
- **Execution sequence:** NOT DOCUMENTED beyond the profile-form convention.
- **Business logic:** An `FMF` report category is present in the 2019 printer profile list, confirming a dedicated FMF report template and print configuration.
- **Outputs:** FMF results stored per patient.
- **Side effects:** Creates the `FMF` table at run time if absent.
- **Database interactions:** `fmf` (1 statement — `SELECT * FROM FMF where patientid='…'`), `patienttest`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `FMF`, `patienttest`, `normalrange`.
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `ResultFMF`.
- **Postconditions:** FMF results stored.
- **Evidence classification:** **VERIFIED** for identity, counts, table and the `FMF` print category; the analyte list is **NOT RECOVERABLE**. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row حمى البحر المتوسط (FMF)] [P11 | analysis/BATCH-04/schema/created-tables.csv | FMF rows] [P11 | analysis/BATCH-02/ini/printer-settings.csv | FMF category]

#### 3.1.7 `ResultPCR` (form, 37 methods, 94 controls)

- **Function ID:** `ResultPCR`
- **Name:** إدخال نتائج PCR — PCR result entry
- **Purpose:** Enter qualitative/quantitative molecular (PCR) results.
- **Functional domain:** Result entry — new clinical profile (molecular biology)
- **Description:** Accompanied by the two new PCR DataReports `ReportPCR` and `ReportPCRs`. The 2019 INI profile catalogue already contains four MOLECULAR BIOLOGY REPORT profiles — `HBV - DNA (Qualitative)` (450), `HBV - DNA (Quantitative)` (451), `HCV - RNA (Qualitative)` (452), `HCV - RNA (Quantitative)` (453) — and `HCV genotyping` (454) plus four unnamed profiles (455–458) — i.e. the PCR report profiles existed in the INI layer before the V2 PCR entry form was added.
- **Trigger:** Double-clicking a PCR test on the patient's test list.
- **Preconditions:** A PCR test must be ordered.
- **Inputs:** the molecular target/result — the analyte list is **NOT DOCUMENTED**; no V2-new table is attributed to PCR in the DDL evidence (the molecular results reuse the generic `patienttest` result columns).
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED beyond the profile-form convention.
- **Business logic:** The laboratory's PCR service is delivered under the MOLECULAR BIOLOGY REPORT family with separate qualitative and quantitative report profiles per analyte, matching the two-level report set (`ReportPCR` full, `ReportPCRs` short).
- **Outputs:** PCR results stored per patient; printed PCR report.
- **Side effects:** Writes to `patienttest`.
- **Database interactions:** `patienttest` (343 statements), `normalrange`, `testtable`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `patienttest`, `normalrange`, `testtable`, `ReportPCR`, `ReportPCRs`.
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `ResultPCR`.
- **Postconditions:** PCR results stored.
- **Evidence classification:** **VERIFIED** for identity, counts, the two PCR DataReports and the MOLECULAR BIOLOGY REPORT INI family; the analyte list is **NOT RECOVERABLE**. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row PCR] [P11 | analysis/BATCH-02/ini/test-catalogue.csv | rows 450-458] [P11 | analysis/BATCH-07/ini-key-delta.csv | `reportdata.formsubtitle` rows for `450.ini`–`458.ini` — unchanged for 450–454, removed for 455–458, so the V2 payload carries the same nine molecular-biology profiles]

#### 3.1.8 `Patient_samples` (form, 89 methods, 101 controls)

- **Function ID:** `Patient_samples`
- **Name:** تتبّع عينات المريض — Patient sample tracking
- **Purpose:** Track the samples belonging to a patient (containers, tubes, draw order, outstanding samples).
- **Functional domain:** Sample tracking
- **Description:** A patient-side form introduced by this build and explicitly listed as a candidate implementation of `patient_registration` in the capability cross-reference for this build.
- **Trigger:** NOT DOCUMENTED (the cross-reference associates it with the patient-registration capability, i.e. reachable from the patient window).
- **Preconditions:** A patient must be selected.
- **Inputs:** sample identity — the `samples` table is referenced in V2 SQL (4 statements — `Select * from samples where patientid = '…'`).
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** In V2 the manual itself requires the operator to record "the type of the out-withdrawn sample" and to use the note field for "samples that have not yet arrived" (CAP-02) — a sample-tracking form is the natural V2 home for that state. This is an **INFERENCE**, not an evidenced statement.
- **Outputs:** Sample records per patient; the `RPTPatientVisit` patient-visit report.
- **Side effects:** Writes to `samples`.
- **Database interactions:** `samples` (4 statements), `patientinfo`, `patienttest`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `samples`, `patientinfo`, `patienttest`, `RPTPatientVisit`, `barcodes`.
- **Dependencies:** `patientmain`, `addpatient`, `barcode`.
- **UI entry point (exact form name):** `Patient_samples` (associated with patient registration in the capability cross-reference for this build).
- **Postconditions:** Sample state recorded for the patient.
- **Evidence classification:** **VERIFIED** for identity, counts, controls and the `samples` table binding; the internal behaviour is **NOT DOCUMENTED**, and the open question *"Is `Patient_samples` sample tracking or a sample repository?"* remains unanswered in the V2 evidence (V-04). [P11 | analysis/BATCH-04/help_v1605/capability-crossref.md | capability-crossref table row patient_registration] [P11 | analysis/V-CD-2019/07-open-questions.md | V-04]

#### 3.1.9 `resultLBC` (form, 33 methods, 52 controls)

- **Function ID:** `resultLBC`
- **Name:** إدخال نتائج LBC — LBC result entry
- **Purpose:** Enter results for the newly introduced LBC profile.
- **Functional domain:** Result entry — new clinical profile
- **Description:** Backed by the new `LBC` table, created by the V2 embedded DDL with **18 columns**: `patientid` varchar(13), `requestdate` DATETIME, `testid` Smallint, and eight result pairs `RESULT1` varchar(75) / `RESULT01` Memo, `RESULT2`/`RESULT02`, `RESULT3`/`RESULT03`, `RESULT4`/`RESULT04`, `RESULT5`/`RESULT05`, `RESULT6`/`RESULT06`, `RESULT7`/`RESULT07` — plus `LBCSAMPLE` YESNO.
- **Trigger:** Double-clicking an LBC test on the patient's test list.
- **Preconditions:** An LBC test must be ordered.
- **Inputs (types + constraints):** `patientid` varchar(13); `requestdate` DATETIME; `testid` Smallint; `RESULT1..RESULT7` varchar(75) (the displayed value) with `RESULT01..RESULT07` Memo (the accompanying text/note for that result); `LBCSAMPLE` YESNO.
- **Validation rules:** NOT DOCUMENTED. The schema implies each of the seven result slots has a short scalar value plus a free-text annotation.
- **Execution sequence:** NOT DOCUMENTED beyond the profile-form convention.
- **Business logic:** A `testid` column distinguishes **which analyte** a row carries (as also seen on `urine.testid`), and `LBCSAMPLE` marks the profile as a sample-type variant — consistent with a laboratory-specific profile that the vendor ships as an opaque new test family.
- **Outputs:** LBC results stored per patient; a printed LBC report.
- **Side effects:** Creates the `LBC` table at run time if absent.
- **Database interactions:** `lbc` (2 statements — `SELECT * FROM LBC where patientid= '…'`), `patienttest`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `LBC`, `patienttest`, `ReportLBC`, `ReportLBCs`.
- **Dependencies:** `normal_test`, `reportsetup`.
- **UI entry point (exact form name):** `resultLBC`.
- **Postconditions:** LBC results stored.
- **Evidence classification:** **VERIFIED** for identity, counts, the full 18-column schema and the report pair; the **meaning of the acronym "LBC"** is **NOT RECOVERABLE** (open question V-07). [P11 | analysis/BATCH-04/schema/created-tables.csv | LBC rows] [P11 | analysis/V-CD-2019/07-open-questions.md | V-07]

#### 3.1.10 `CardFrmSetx` (form, 22 methods, 29 controls)

- **Function ID:** `CardFrmSetx`
- **Name:** إعداد بطاقة المريض — Patient identity-card setup
- **Purpose:** Configure the layout and content of the printed patient identity card.
- **Functional domain:** Patient identity card
- **Description:** The companion setup form to `CardFrm` (the card form itself, 0 methods / 3 controls). Together they are the V2 **ID-card** capability, and the printing stack adds a dedicated **`IDprinter`** printer role and the `IDCARD.INI` configuration file.
- **Trigger:** NOT DOCUMENTED.
- **Preconditions:** A laboratory identity-card template exists.
- **Inputs:** card fields and layout — the content of `IDCARD.INI` is the documented configuration surface: section `[Billdata]` carries the **logo, e-mail and telephone**; section `[IDdata]` carries the **report text** used on the card/receipt.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** The vendor learning manual's Patient module §1-12b explicitly ties *"بيانات موقع نتيجة الخاصة بالمرضى وطباعتها على الإيصال"* to **`IDCARD.INI` · `SETING.ini`** (the connection settings), i.e. the same INI family governs the patient card and the NATIGH.COM receipt footer.
- **Outputs:** A printed patient identity card; the card configuration file.
- **Side effects:** Writes the card configuration (INI); prints to the `IDprinter` role.
- **Database interactions:** `patientinfo` (the patient's identity data printed on the card); `reportview` (report strips).
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `IDCARD.INI`, `SETING.ini`, `patientinfo`, `CardFrm`, `IDprinter`.
- **Dependencies:** `printerselect`, `reportsetup`, `CardFrm`.
- **UI entry point (exact form name):** `CardFrmSetx`.
- **Postconditions:** Card layout saved; card printable.
- **Evidence classification:** **VERIFIED** for identity, counts, controls and the `IDCARD.INI` binding; the UI flow is **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row بطاقة الهوية] [P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3 printer roles table] [P11 | analysis/V-CD-2019/10-training-video.md | §8]

#### 3.1.11 `CardFrm` (form, 0 methods, 3 controls)

- **Function ID:** `CardFrm`
- **Name:** نموذج بطاقة — ID-card form
- **Purpose:** The rendered patient identity card surface.
- **Functional domain:** Patient identity card
- **Description:** A 3-control form with no procedures of its own — a display/print surface driven by `CardFrmSetx` and by `IDCARD.INI`.
- **Trigger:** Invoked by the card-printing path.
- **Preconditions:** Card configuration present.
- **Inputs:** the patient's identity data from `patientinfo`.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** NOT DOCUMENTED beyond the "render + print to `IDprinter`" relationship.
- **Outputs:** A printable identity card.
- **Side effects:** A print job on the `IDprinter` role.
- **Database interactions:** `patientinfo`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `CardFrmSetx`, `IDCARD.INI`, `patientinfo`.
- **Dependencies:** `CardFrmSetx`, `printerselect`.
- **UI entry point (exact form name):** `CardFrm`.
- **Postconditions:** Card rendered/printed.
- **Evidence classification:** **VERIFIED** for identity and counts; behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row CardFrm] [P11 | analysis/BATCH-04/vb6/v1605/forms-blob.txt | CardFrm row]

#### 3.1.12 `Frmac` (form, 26 methods, 46 controls)

- **Function ID:** `Frmac`
- **Name:** نموذج AC — "AC" form
- **Purpose:** An additional laboratory form. The upstream V2 significance table describes it simply as "نموذج AC" (an AC form); the acronym is not expanded anywhere in the evidence.
- **Functional domain:** Laboratory forms (undetermined)
- **Description:** A 46-control form with 26 procedures. Its purpose is **NOT DOCUMENTED**; the vendor learning manual's "outside-the-index" section lists *"فصل وسحب العينات"* (sample separation and withdrawal, Laboratory icon) against **`cultures` · `cultureanti` · `sample`** — the closest evidenced laboratory-workstation capability, but there is **no direct evidence** linking `Frmac` to it.
- **Trigger:** NOT DOCUMENTED.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs:** NOT DOCUMENTED.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** NOT DOCUMENTED.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED — no V2 SQL statement is attributable to `Frmac` in the extracted corpus.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** NOT DOCUMENTED (candidate domain peers: `cultures`, `cultureanti`, `samples`).
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** `Frmac`.
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** only for the object's existence, type, method count and control count; **NOT DOCUMENTED** in every behavioural field. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row Frmac] [P11 | analysis/BATCH-04/vb6/v1605/forms-blob.txt | Frmac row]

#### 3.1.13 `labmainTools` (form, 6 methods, 13 controls)

- **Function ID:** `labmainTools`
- **Name:** أدوات الشاشة الرئيسية — Main-screen tools
- **Purpose:** Expose the maintenance/tooling functions (database maintenance, backup) from the main shell.
- **Functional domain:** Main shell / database maintenance
- **Description:** A narrow 13-control form (825 × 10215 twips) added in V2. The V2 capability cross-reference lists it among the "VB6 objects with no obvious CHM counterpart", which is consistent with a shell-level tools launcher.
- **Trigger:** NOT DOCUMENTED; the manual's Database Maintenance route is `اعدادات` → `Database Maintenance` (CAP-12).
- **Preconditions:** Logged in.
- **Inputs:** the tool selected.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** INFERRED — the V2 baseline summary lists **"أدوات الشاشة الرئيسية"** among the 41 objects introduced by this build and the manual's backup topic is the only documented "Database Maintenance" surface, which is also the reason `labmainTools` was grouped with the `patient_registration`/tools group in the capability cross-reference for this build.
- **Outputs:** Launch of a maintenance tool.
- **Side effects:** The application **closes** when entering Database Maintenance (per CAP-12).
- **Database interactions:** `labdb`/`labdb1` modules perform the work; the `Patients.mdb` / `data.mdb` files are the objects.
- **Permissions:** The Database Maintenance base password `123` guards the downstream function.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `tools`, `labdb`, `labdb1`.
- **Dependencies:** `labmain`, `tools`.
- **UI entry point (exact form name):** `labmainTools`.
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity and counts; **INFERRED** for the domain. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row labmainTools]

#### 3.1.14 `static6` (form, 24 methods, 87 controls)

- **Function ID:** `static6`
- **Name:** شاشة ساكنة جديدة — new static screen
- **Purpose:** A static (non-editable) display screen in the report-customisation family.
- **Functional domain:** Report design — static screens
- **Description:** The sixth member of the `static1`…`static6` family. The pre-existing `static1`(30) … `static5`(21) forms are the report-static design surfaces referenced by the CAP-09 report-customisation window.
- **Trigger:** NOT DOCUMENTED.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs:** NOT DOCUMENTED.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** NOT DOCUMENTED — the static family is the report-layout editor family.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED directly; the configuration it edits is held in `Data\*.ini` / `reportview`.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `static1`–`static5`, `reportsetup`, `reportsetup2`, `reportview`.
- **Dependencies:** `reportsetup`, `reportsetup2`.
- **UI entry point (exact form name):** `static6`.
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity and counts; behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row static6] [P11 | analysis/V-CD-2019/00-baseline-summary.md | §4 expanded objects list]

#### 3.1.15 `mInputbox` (module, 12 methods)

- **Function ID:** `mInputbox`
- **Name:** مربع إدخال مخصص — custom input box
- **Purpose:** A vendor-supplied modal input-dialog routine used instead of the VB6 `InputBox`.
- **Functional domain:** UI infrastructure
- **Description:** A standard module exposing 12 procedures. Because it is a module (not a form), it has no controls and no form entry point; it is called from wherever a text input is required.
- **Trigger:** Called programmatically by other objects.
- **Preconditions:** A calling context that needs a text input.
- **Inputs / outputs:** NOT DOCUMENTED at the parameter level (procedure signatures are not recoverable from the extracted object table — see the method-address limitation noted below).
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** INFERRED — a custom input box in an Arabic/RTL medical application typically exists to provide an RTL-aware, locally-styled prompt; this is an inference, not an evidenced statement.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NONE evidenced.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `otherfun`, `aaaClass`, `BiosData`.
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** NOT APPLICABLE (module) — invoked by callers.
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity, type and method count; behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row mInputbox] [P11 | analysis/BATCH-04/vb6/v1605/objects.json | object 189]

#### 3.1.16 `saveIOtemp` (module, 10 methods)

- **Function ID:** `saveIOtemp`
- **Name:** حفظ مؤقت للمدخلات — temporary persistence of inputs
- **Purpose:** Persist in-progress input state so that it survives a window close or a crash.
- **Functional domain:** Infrastructure — temporary persistence
- **Description:** A 10-procedure module. Its name states the function directly ("save I/O temp"), and V2 created a dedicated `testtemp` table whose purpose the schema document records as *"جدول مؤقت لتخزين نتائج الاختبار أثناء العمل"* (a temporary table for storing test results during work) with **1 column** (`patientid` varchar(13)).
- **Trigger:** Called programmatically; the exact call sites are NOT DOCUMENTED.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs:** the in-progress input payload.
- **Validation rules:** NOT DOCUMENTED.
- **Execution sequence:** NOT DOCUMENTED.
- **Business logic:** The `testtemp` table is written and deleted in the same SQL corpus (`Delete FROM testtemp` and `SELECT * FROM testtemp`), which is the signature of a **write-then-purge scratch table** for an interrupted result-entry session.
- **Outputs:** A temporary row set in `testtemp`.
- **Side effects:** Writes to and purges `testtemp`.
- **Database interactions:** `testtemp` (5 statements — `Delete FROM testtemp` and `SELECT * FROM testtemp`); the table is created by the embedded DDL with 1 column and its `normalrang` column is altered to MEMO.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED — but the existence of the scratch table is itself the crash-recovery affordance (INFERRED).
- **Related entities:** `testtemp`, `patienttest`, `testtable`.
- **Dependencies:** `labdb`, `labdb1`.
- **UI entry point (exact form name):** NOT APPLICABLE (module).
- **Postconditions:** Temporary state stored or cleared.
- **Evidence classification:** **VERIFIED** for identity, method count and the `testtemp` binding; the call sites and payload are **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row saveIOtemp] [P11 | analysis/BATCH-04/sql_v1605/tables.csv | testtemp row] [P11 | analysis/V-CD-2019/02-schema.md | §1 created tables]

#### 3.1.17 `boisais` (module, 16 methods)

- **Function ID:** `boisais`
- **Name:** وحدة فرعية للمورّد — vendor sub-module
- **Purpose:** Vendor-specific helper routines.
- **Functional domain:** Infrastructure — vendor module
- **Description:** A 16-procedure standard module. **The same module name also exists in the vendor installer `RL_SETUP.exe` v19.00** (the installer's module list is `FontInstaller`(38) · `RegistryInteraction`(7) · `Module1`(14) · `modFonts`(12) · `boisais`(16)) — so `boisais` is **shared code duplicated in both the application and the installer**. This is the strongest single piece of evidence about the module's role: it is the vendor's "AIS group" utility library.
- **Trigger:** Called programmatically.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs / outputs / validation / sequence / business logic:** NOT DOCUMENTED.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `aaaClass`, `BiosData` (the same helper class pair also appears in the installer).
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** NOT APPLICABLE (module).
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity, method count (16 — identical in application and installer) and the duplication fact; behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row boisais] [P11 | analysis/V-CD-2019/08-deployment-installer.md | §1.1 object-structure table]

#### 3.1.18 `otherfun` (module, 2 methods)

- **Function ID:** `otherfun`
- **Name:** دوال مساعدة — helper functions
- **Purpose:** Small helper routine pair.
- **Functional domain:** UI infrastructure
- **Description:** A 2-procedure module; the smallest new module in V2.
- **Trigger:** Called programmatically.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs / outputs / validation / sequence / business logic:** NOT DOCUMENTED.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `mInputbox`.
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** NOT APPLICABLE (module).
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity and method count; behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row otherfun]

#### 3.1.19 `aaaClass` (class, 15 methods)

- **Function ID:** `aaaClass`
- **Name:** صنف مساعد — helper class
- **Purpose:** A general-purpose helper class.
- **Functional domain:** Infrastructure — helper class
- **Description:** A 15-method class. **The same class also exists in the installer `RL_SETUP.exe`**, alongside `BiosData`(8) — i.e. `aaaClass` and `BiosData` are the vendor's shared class pair, duplicated across both executables.
- **Trigger:** Instantiated programmatically.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs / outputs / validation / sequence / business logic:** NOT DOCUMENTED.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `BiosData`, `boisais`.
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** NOT APPLICABLE (class).
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity and method count (15 in both executables); behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row aaaClass] [P11 | analysis/V-CD-2019/08-deployment-installer.md | §1.1 object-structure table]

#### 3.1.20 `BiosData` (class, 8 methods)

- **Function ID:** `BiosData`
- **Name:** بيانات حيوية — biological data class
- **Purpose:** A class carrying biological/clinical data.
- **Functional domain:** Infrastructure — clinical data model
- **Description:** An 8-method class; also present in the installer `RL_SETUP.exe` with the identical 8-method count.
- **Trigger:** Instantiated programmatically.
- **Preconditions:** NOT DOCUMENTED.
- **Inputs / outputs / validation / sequence / business logic:** NOT DOCUMENTED.
- **Outputs:** NOT DOCUMENTED.
- **Side effects:** NOT DOCUMENTED.
- **Database interactions:** NOT DOCUMENTED.
- **Permissions:** NOT DOCUMENTED.
- **Error conditions:** NOT DOCUMENTED.
- **Exception handling:** NOT DOCUMENTED.
- **Related entities:** `aaaClass`, `boisais`, `result*` profile forms (candidate consumers — INFERRED).
- **Dependencies:** NOT DOCUMENTED.
- **UI entry point (exact form name):** NOT APPLICABLE (class).
- **Postconditions:** NOT DOCUMENTED.
- **Evidence classification:** **VERIFIED** for identity and method count (8 in both executables); behaviour **NOT DOCUMENTED**. [P11 | analysis/V-CD-2019/03-capabilities.md | §2 table row BiosData] [P11 | analysis/V-CD-2019/08-deployment-installer.md | §1.1 object-structure table]

> **Method-address limitation (applies to every spec in §3):** `objects.json` reports `method_entries_read: 1268`, `unique_entries: 0`, `methods_without_address: 1268` — the VB6 procedure names and their addresses could not be recovered from the binary. Procedure **counts** are therefore reliable, but individual procedure **signatures, parameters and bodies** are **NOT RECOVERABLE** for every object in this document. [P11 | analysis/BATCH-04/vb6/v1605/objects.json | stats block] [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-23]

### 3.2 New DataReports (21) — full specifications

> All 21 are `datareport` objects with **0 procedures**; the designer layout of a DataReport is not extractable from the binary, so the layout is **NOT RECOVERABLE** for each. What *is* established is the object identity, its type, the report family it belongs to, the underlying data it can bind, and — where applicable — its INI print profile.

| Function ID | Name | Purpose | Domain | Description | Trigger | Preconditions | Inputs | Validation | Execution sequence | Business logic | Outputs | Side effects | Database interactions | Permissions | Errors | Exception handling | Related entities | Dependencies | UI entry point | Postconditions | Evidence class | Provenance |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `ReportIGE1` | IgE allergy report (full) | Print the full IgE allergy result report | Result reporting | Companion of `resultIgeAllergy`; prints the allergen panel with results and classes | Print action on an IgE test | An IgE test with entered & reviewed results | `IgEallergy` rows for the patient (Item/RESULT/Class/TypeF 1..40) | Print-only; the "verified" gate applies | select test → review → print | Class-per-item interpretation printed alongside the result | Printed IgE report | Print audit row (`resultprint`, `printuser`, `printdate`, `printnum`) | `igeallergy`, `patienttest` | NOT DOCUMENTED | "Not found any Verified selected tests or result to print it" | Print can be re-run | `igeallergy`, `patienttest`, `resultIgeAllergy` | `reportsetup`, `printerselect` | `resultIgeAllergy` → print | Report produced; print audit written | VERIFIED (object, family, data) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportIGE1] |
| `ReportIGE1s` | IgE allergy report (short) | Print the condensed IgE allergy report | Result reporting | "s" = short/condensed variant, matching the `Report*s` naming family across V2 | Same as `ReportIGE1` | Same | Same | Same | Same | Condensed layout of the same data | Condensed IgE report | Print audit | `igeallergy`, `patienttest` | NOT DOCUMENTED | Same gate | Same | same | same | same | Condensed report produced | VERIFIED (object) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportIGE1s] |
| `ReportPCR` | PCR report | Print the PCR result report | Result reporting | Full PCR report; four MOLECULAR BIOLOGY REPORT INI profiles exist (450–458) | Print action on a PCR test | PCR test entered & reviewed | `patienttest` result fields for the molecular profile | Same print gate | Same | Qualitative vs quantitative is distinguished by the INI profile, not by a different report object | Printed PCR report | Print audit | `patienttest`, `normalrange`, `testtable` | NOT DOCUMENTED | Same gate | Same | `patienttest`, `normalrange` | `resultIgeAllergy`… no: `ResultPCR`, `reportsetup` | `ResultPCR` → print | Report produced | VERIFIED (object, INI family) / NOT RECOVERABLE (layout) | [P11 \| analysis/BATCH-02/ini/test-catalogue.csv \| rows 450-458] · [P11 \| analysis/BATCH-07/ini-key-delta.csv \| `reportdata.formsubtitle` rows for `450.ini`–`458.ini`] |
| `ReportPCRs` | PCR report (short) | Condensed PCR report | Result reporting | Condensed variant | Same | Same | Same | Same | Same | Same | Condensed report | Print audit | `patienttest` | NOT DOCUMENTED | Same gate | Same | same | `ResultPCR` | same | Condensed report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportPCRs] |
| `ReportLBC` | LBC report | Print the LBC profile report | Result reporting | Full LBC report | Print on an LBC test | LBC test entered & reviewed | `LBC` rows (RESULT1..7 + RESULT01..07 + LBCSAMPLE) | Same gate | Same | The seven result slots are printed with their annotations | Printed LBC report | Print audit | `lbc`, `patienttest` | NOT DOCUMENTED | Same gate | Same | `LBC`, `resultLBC` | `resultLBC`, `reportsetup` | `resultLBC` → print | Report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/BATCH-04/schema/created-tables.csv \| LBC rows] |
| `ReportLBCs` | LBC report (short) | Condensed LBC report | Result reporting | Condensed variant | Same | Same | Same | Same | Same | Same | Condensed report | Print audit | `lbc` | NOT DOCUMENTED | Same gate | Same | same | `resultLBC` | same | Condensed report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportLBCs] |
| `ReportZN` | Zinc report | Print the zinc (trace element) result report | Result reporting | Full zinc report | Print on a zinc test | Zinc test entered & reviewed | `zn` rows for the patient | Same gate | Same | Zinc is part of the trace-element profile | Printed zinc report | Print audit | `zn`, `patienttest` | NOT DOCUMENTED | Same gate | Same | `zn`, `resultzn` | `resultzn`, `reportsetup` | `resultzn` → print | Report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportZN] |
| `ReportZNs` | Zinc report (short) | Condensed zinc report | Result reporting | Condensed variant | Same | Same | Same | Same | Same | Same | Condensed report | Print audit | `zn` | NOT DOCUMENTED | Same gate | Same | same | `resultzn` | same | Condensed report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportZNs] |
| `Reportliver7his` | Liver history report (7) | Print a liver-profile medical-history report | Clinical history | Full variant; the "7" denotes the liver profile's history variant | Print from the history window | Liver-profile results exist for the patient | `liver` rows across the patient's visits | NOT DOCUMENTED | NOT DOCUMENTED | The history is assembled across previous visits from the frozen per-test rows | Printed liver history | Print audit | `liver`, `patienttest`, `history` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `liver`, `Resultliver` | `patienthistory`, `reportsetup` | `patienthistory` / `Resultliver` | History printed | VERIFIED (object) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportliver7his] |
| `Reportlivers7his` | Liver history report (7, short) | Condensed liver history | Clinical history | Condensed variant | Same | Same | Same | Same | Same | Same | Condensed history | Print audit | `liver` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | same | same | same | Condensed history printed | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportlivers7his] |
| `ReportFatoraC` | Coagulation-factors report | Print the coagulation-factor result report | Coagulation | Full coagulation report | Print on a coagulation-factor test | Test entered & reviewed | `coagfactors` rows for the patient | Same gate | Same | PT/PTT/ISI and factor levels | Printed coagulation report | Print audit | `coagfactors`, `patienttest`, `constanttable` | NOT DOCUMENTED | Same gate | Same | `coagfactors`, `resultcoagfactor` | `resultcoagfactor`, `reportsetup` | `resultcoagfactor` → print | Report produced | VERIFIED / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatoraC] |
| `ReportFatorareset` | Coagulation-factor reset report | Print the "reset coagulation factors" report | Coagulation | A reset/correction report for coagulation-factor results | Print from the coagulation workflow | Coagulation results exist | `coagfactors` rows | NOT DOCUMENTED | NOT DOCUMENTED | Used to re-issue corrected coagulation results | Printed reset report | Print audit | `coagfactors` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `coagfactors`, `resultcoagfactor` | `resultcoagfactor` | `resultcoagfactor` | Reset report printed | VERIFIED (object) / NOT RECOVERABLE (layout, semantics) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatorareset] |
| `ReportFatorareset8` | Coagulation-factor reset report (copy 8) | A second reset variant | Coagulation | The "8" suffix marks a variant of `ReportFatorareset` | Print from the coagulation workflow | Same | Same | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | Printed reset report | Print audit | `coagfactors` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `coagfactors` | `resultcoagfactor` | `resultcoagfactor` | Reset report printed | VERIFIED (object) / NOT RECOVERABLE (variant semantics) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportFatorareset8] |
| `ReportTestTime` | Test-time report | Report turnaround time per test | Lab performance | The only V2 report explicitly about **test time**; `testtable.testtime` is the per-test turnaround in days (0 = same day) | Print from the reports/statistics area | NOT DOCUMENTED | `testtable.testtime`, `patienttest.requestdate`, delivery timestamps | NOT DOCUMENTED | NOT DOCUMENTED | Computes turnaround per test from request to completion/delivery | Printed turnaround report | Print audit | `patienttest`, `testtable` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `testtable`, `patienttest` | `statisReport`, `reportsetup` | `statisReport` / reports menu | Turnaround report produced | VERIFIED (object) / NOT RECOVERABLE (layout, exact metric) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportTestTime] |
| `ReportPatPhone` | Patient-phone report | List patients with their phone/mobile numbers | Patient contacts | Distinct from the general `Reportphone`; the V2 addition of `patientinfo.PFax` and `patientinfo.SMSMob` in the same schema change makes this a **contact-data** report | Print from the patient/reports area | NOT DOCUMENTED | `patientinfo.patientphone`, `patientinfo.patienttel`, `patientinfo.SMSMob`, `patientinfo.PFax`, `phone` rows | NOT DOCUMENTED | NOT DOCUMENTED | Produces a contactable-patient list | Printed phone report | Print audit | `patientinfo`, `phone` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `patientinfo`, `phone` | `phone`, `reportsetup` | `phone` / reports menu | Phone list printed | VERIFIED (object) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportPatPhone] |
| `ReportSMS` | SMS message report | List sent SMS messages | SMS / notifications | Audit report over `SMSSender` | Print from the SMS area | SMS records exist | `SMSSender` rows (patient, doctor, mobile, text, length, operator, date) | NOT DOCUMENTED | NOT DOCUMENTED | Operational audit of the notification subsystem | Printed SMS report | Print audit | `smssender` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `smssender`, `SMSfrmsenderos` | `SMSfrmsenderos` | `SMSfrmsenderos` | SMS audit printed | VERIFIED (object, data) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row ReportSMS] |
| `RPTPatientVisit` | Patient-visit report | Report of patient visits | Patient visit log | Paired with the new `Patient_samples` form and the `reportview` table; the V2 baseline lists "سجل زيارات المريض" (patient visit log) as a new domain | Print from the patient area | NOT DOCUMENTED | `patientinfo.requestdate`, `patientid`, `reportview` rows | NOT DOCUMENTED | NOT DOCUMENTED | Aggregates visits per patient over time | Printed visit report | Print audit | `patientinfo`, `patienttest`, `reportview` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `patientinfo`, `reportview`, `Patient_samples` | `Patient_samples`, `reportsetup` | `Patient_samples` / reports menu | Visit report printed | VERIFIED (object) / NOT RECOVERABLE (layout) | [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 row سجل زيارات المريض] |
| `pricelistsN` | Price list (N) | Print the price list | Billing | Companion of the pre-existing `pricelists` DataReport; vendor manual capability **3-5** is "طباعة قائمة أسعار التحاليل" (print the list of test prices) and maps it to `pricelistsN` (new report) | Print from the pricing area | Price lists exist | `pricelist`, `pricemenu`, `testtable` (patient price, lab-to-lab price) | NOT DOCUMENTED | NOT DOCUMENTED | Prints the configured price list(s) | Printed price list | Print audit | `pricelist`, `pricemenu`, `testtable` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `pricelist`, `z_pricelists` | `z_pricelists`, `reportsetup` | `z_pricelists` | Price list printed | VERIFIED (object, vendor mapping) | [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 table row 3-5] |
| `Reportmony01` | Financial report 01 | Financial/accounting report | Billing | First of the V2 "money" report family | Print from the accounts area | NOT DOCUMENTED | `payment`, `patientinfo.totalprice`, `patienttotal` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | Printed financial report | Print audit | `payment`, `patientinfo`, `patienttotal` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `payment`, `labfunction` | `labfunction`, `reportsetup` | accounts / stocktaking window | Financial report printed | VERIFIED (object) / NOT RECOVERABLE (layout, semantics) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportmony01] |
| `Reportmony5` | Financial report 5 | Financial/accounting report | Billing | Mid-numbered member of the money report family | Print from the accounts area | NOT DOCUMENTED | `payment`, `patientinfo`, `patienttotal` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | Printed financial report | Print audit | `payment`, `patientinfo` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `payment`, `labfunction` | `labfunction` | accounts window | Financial report printed | VERIFIED (object) / NOT RECOVERABLE (layout, semantics) | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table row Reportmony5] |
| `Reportmony11` | Financial report 11 | Financial/accounting report | Billing | The only DataReport in the entire V2 set with **1 procedure** (all others are 0) — i.e. it carries one piece of embedded logic | Print from the accounts area | NOT DOCUMENTED | `payment`, `patientinfo`, `patienttotal` | NOT DOCUMENTED | NOT DOCUMENTED | The single procedure is the only executable logic in any of the 21 new reports (INFERRED: a computed column/format routine) | Printed financial report | Print audit | `payment`, `patientinfo` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `payment`, `labfunction` | `labfunction` | accounts window | Financial report printed | VERIFIED (object, method count) / NOT RECOVERABLE (procedure body) | [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| object 186 Reportmony11 methods=1] |

---

## 4. Vendor catalogue (`RLS_Learn.pdf`) — the 7 capability modules

**Source artefact:** `RLS_Learn.pdf` — "Real Lab System Guide Book", RealLab Co., **212 pages**, Word 2010, 26 April 2017; **81,151 characters extracted, 510 headings, 7 functional modules**. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | header block + §1]

**Extraction caveat carried forward:** the PDF's Arabic text has **no `ToUnicode` CMap**, so extraction yields scrambled character order; the visual rendering is intact and **every heading below was corrected visually from the page images** (`analysis/BATCH-05/manuals/pages/`). `RL_Show.pdf` (77 pages) yielded only 77 characters and was read as images only. The catalogue's section numbers (`1-1`…`7-0`) are visible only in the rendered tables and were taken from page images 3–6. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §4 constraints table]

**Catalogue coverage note:** this manual is **specific to the 2019 build**; the CHM manual bundled with the application documents neither these 2019 additions nor the vendor's full functional catalogue. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §1 comparison table]

**Row count:** the catalogue enumerates **57 numbered/listed capability rows** across the 7 modules (§2.1–§2.7). The document itself summarises it as "~60 in 7 modules". See §9 (Count reconciliation) for how the two figures are reconciled.

### 4.1 Module 1 — Patient (1:1 – 1:13) — 15 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 1-1 | Add a new patient | Main menu → `المرضي` → add/edit patient data; also **F2** | Patient name, sex, age, account method, referral entity, test list; age constraints: under one month = days 1–29, under one year = months 1–11, fractions allowed (e.g. 2.5 y) | Account method must match the referral entity; `Individual` uses the lab's own patient prices even when a referral entity with its own price list is selected; `Lab to Lab` uses the entity's price list if it has one, otherwise the lab-to-lab price; `Free` ⇒ total account zero | Patient record + priced test list; receipt/barcode printable | `patientinfo`, `patienttest`, `pricelist` | Delete-patient right for deletion; error paths NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 table row 1-1] |
| 1-2 | Patient accounting — modify the patient's account | From the patient window (discount / paid amount / settle) | Discount as a whole number **or** a percentage; amount paid; settle via "خالص" then "موافق" | Total = Σ(test price under the chosen method) − discount − paid; the outstanding balance is either the lab's or the patient's | Account state; payment records | `patientinfo.totalprice`, `patientinfo.totalpricedisc`, `payment`, `patienttotal` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-2] |
| 1-3 | Deliver patient results and clear the account | `المرضي` → deliver results; **F6** | Patient selection; barcode flow (receipt code then file code) | Delivery gated on review→print→deliver; a remaining balance triggers a warning | `give` marker; settlement; delivery audit | `patienttest.give`, `patienttest.resultprint`, `payment` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-3] |
| 1-4 | Modify a patient's data or tests | Patient window; **F8** edit, **F10** delete, **F9** save | Patient fields; test list | Editing preserves identity; the Lab ID is the stable key across visits | Updated patient/test records | `patientinfo`, `patienttest` | Delete-patient right for deletion | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-4] |
| 1-5 | Enter report results | Results window; **F4**; double-click a test or arrow-select + Enter | Result values per analyte; units; comments | Abnormal/critical marking with flags; printed tests shaded green | Results stored with review/print state | `patienttest` (+ one profile table per test family) | "بي"/"تي" audit buttons restricted to administrator / absolute-rights users | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-5] |
| 1-6 | Produce a combined report | Results window action bar | Selection of patients/tests | SHAPE … APPEND constructs the combined dataset | Combined printed report | `Reportanyreport` DataReport; `patienttest` | Print gate on verified results | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-6] |
| 1-7 | Produce a blank report | Results window action bar | — | The blank report carries the barcode plus the laboratory name and logo | Blank report for other purposes | `anyreport` (17 rows) | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-7] |
| 1-8 | Enter farm-report results | Results window | Farm/antimicrobial susceptibility data | Farms carry their own test catalogue and antibiotic sensitivity set | Farm results; farm accounts | `sharekat`, `sharekathesab`, `sarfz`, `antibiotic`, `antibio`, `cultures`, `cultureanti` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-8] |
| 1-9 | Search for a patient | `المرضي` → search; **F3** | Code, name, phone, mobile, national ID; name search by prefix or anywhere | Maximum **100** rows displayed, deliberately, to protect confidentiality; bulk sorting is delegated to the statistics module | Patient list + selected patient's tests | `patientinfo` (`mid(patientid,…)`), `patienttest` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-9] |
| 1-10 | Search a patient and show **all** their visits with dates and tests | Search window → patient's history | Date range; visit list | The visit history is read from the 20-column `history` table keyed by lab id | Visit-by-visit history display | `history` (20 columns), `patienttest` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-10] |
| 1-11 | Follow up cases, amend them, enter results and print reports | Patient-test worklist | Case state; result entry; print | Case tracking separates "registered" from "result entered" | Case follow-up state; printed reports | `patienttest.resultreview`, `patienttest.resultprint` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-11] |
| 1-12 | **Deliver patient results via the NATIGH.COM website** | SMS/notification path | Patient mobile; doctor or laboratory account for the result service | Third-party online result service; the patient receives the result through NATIGH.COM rather than at the counter | Delivered electronic result; the send is logged | `Natigh` (installed file) · SMS system (`smsgroups`, `smslist`, `SMStemplate`, `SMSSender`) | Account creation for the treating doctor / for the laboratory is required (see §4.7 rows) | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-12] |
| 1-12a | Open the site and display the patient's result | Browser / the site's own page | Patient credentials or code | The site presents the patient's result | Result displayed on the website | NOT DOCUMENTED (external system) | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-12a] |
| 1-12b | The site's patient data and printing it on the receipt | Receipt configuration | Receipt footer content | The NATIGH.COM patient data are printed on the receipt via the connection-settings INI pair | Receipt carrying the site data | `IDCARD.INI`, `SETING.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-12b] |
| 1-13 | The patient's medical history | Result form → Patient history button | History entries; the button label changes with the number of stored results in that profile (ignoring today's result) | History is a per-profile narrative built from previous visits and printed in the report tail | Printed or on-screen medical history | `history`, `patienttest.historyname` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1 row 1-13] |

### 4.2 Module 2 — Work Sheet (2:1 – 2:2) — 2 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 2-1 | Build a work sheet for a group of patients over a date range | Reports / work-paper area | Date range; patient group | Two printed layouts exist — **"WORKPAPER BY PATIENT NAME"** (No. of Patients, Printed by, timestamp, then Test Name / Gender / Male / Age / Years / barcode, with per-group totals and per-sample-type volumes such as "1.25 m. Serum", "Reprinted") and **"WORKPAPER BY TEST NAME"** (No. of types of tests, then Test Code → F.B.C. / PP.B.C. / Viral / Urine / Stool / Abdomen with Patient Name / Result / ID) | Printed work sheet | `wasl` (`subgroupcode`, `testcode`, `waslname`, `testprice`, `testno`), `workpaper`, `workpaper2`, `testtable` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.2 rows 2-1/2-2] [P11 \| analysis/V-CD-2019/10-training-video.md \| §7] |
| 2-2 | Build a work sheet for one test or a group of tests over a date range | Reports / work-paper area | Test or subgroup; date range | A work sheet is a **subgroup (profile) of tests printed as a distribution plan** — "which of these tests are requested and where have they passed through"; `wasl` = "Work Analysis Sheet List" with `testno` and `testprice` | Printed work sheet; device routing by log group | `wasl`, `sarfz`, `testtable`, `loggroup` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.2 row 2-2] |

### 4.3 Module 3 — System (3:1 – 3:5) — 5 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 3-1 | Modify test data and prices | Main menu → `بيانات النظام` → `بيانات التحاليل` | The full 18-field test record (see CAP-07) | Test names exist in 5 contexts; prices exist per account class | Updated test master | `testtable` (609 tests across 46 profiles), `setup1`…`setup3` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-1] |
| 3-2 | Add a new test to the program | Test-data window → "اضافة تحليل" | Test master fields | New tests join a group and a branch | New test in the lists | `testtable`, `customtesttable` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-2] |
| 3-3 | **Modify the reference values of tests** | Test-data window → "المعدل الطبيعي" | Sex × age band ranges with low/high and critical thresholds and flags/comments | Ranges are keyed by (test, sex, age band, age unit); the six-band requirement applies to sex-independent tests | Reference ranges applied at entry and print | `normalrange` (852 ranges), `normal_test`, `testrange` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-3] |
| 3-4 | Add a new price list | Pricing area | Price list; prices per test | Price lists are per referral entity; a patient on "Lab to Lab" uses the entity's list if present | New price list effective for pricing | `pricelist`, `pricemenu`, `shopping` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-4] |
| 3-5 | Print the list of test prices | Pricing area → print | Price list selection | Prints the configured prices | Printed price list | `pricelistsN` (new V2 DataReport) | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-5] |

### 4.4 Module 4 — Server (4:1 – 4:5) — 6 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 4-1 | **Laboratory-performance statistics and monitoring** | Statistics module (`statisReport`) | Date range; breakdown dimensions | The statistics screen enumerates: patient count (from date / to date) · patient count by type · patient count (critical cases) · review count · test count by type · test count (critical) · test count per branch · test count per representative · test count (not finished) · sent-sample count · per branch · per referral entity · (not finished) · branch account: test count (per branch) · sent-sample count (per branch) | Statistics output; observed values in the training capture were patients 216, tests 50, sent samples 118, representatives 120, branch account 400 | `statisReport` DataReport, `loger` (new V2 log table), `patientinfo.requestdate`, `patientinfo.patientsex`, `patienttest` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-1] [P11 \| analysis/V-CD-2019/10-training-video.md \| §6] |
| 4-2 | Example: patient count for a given year, sorted by month and by sex | Statistics module | Year | Aggregation of `requestdate` × `patientsex` | Table of counts | `patientinfo.requestdate`, `patientinfo.patientsex` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-2] |
| 4-3 | Example: patient count for a given month | Statistics module | Month | As above at month granularity | Table of counts | same | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-3] |
| 4-4 | Example: rate of ordering a group of tests | Statistics module | Subgroup | Counts orders per subgroup | Rate table | `patienttest.subgroupcode` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-4] |
| 4-5 | Example: count of test samples in the year | Statistics module | Year | Sample/result counting per year | Count table | `patienttest` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-5] |
| 4-6 | **Stocktaking and laboratory accounting** | `حسابات` → `الجرد وحساب الدرج` (**F7**) | Period (default today) | Seven report sections (see CAP-11) | Period accounts, per-user workload, referral statements | `labfunction`, `pricelistsN`, `payment`, `patientinfo.totalprice` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.4 row 4-6] |

### 4.5 Module 5 — Accounting (5:1 – 5:5) — 5 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 5-1 | Stocktake of laboratory income over a period | Accounts & stocktaking window | Period | Income reconciled from patient payments and balances | Period income report | `payment`, `patientinfo.totalprice` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-1] |
| 5-2 | **Stocktake on a branch, within several inter-linked branches (the branches system)** | Accounts & stocktaking window | Branch; period | The branch is encoded **inside the patient id**: `SUBSTRING(patientid,9,1)`; `Patient.branche` is a smallint column added by the V2 DDL. Branches connect to the central lab over the internet. | Branch-level accounts | `Labbranch` (`labbranch` table, 7 statements), `Patient.branche`, `Branch_Data.mdb`, `loggroup` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-2] [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §5 master/reception table] |
| 5-3 | Stocktake for a specific treating doctor or referral entity | Accounts & stocktaking window | Referring doctor / entity | Commissions and dealings are attributed to the referral entity | Doctor/entity statement | `mowzaf` (referring doctor), `Gehats`, `patientinfo.referredbyname` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-3] |
| 5-4 | Stocktake of out-referred samples or by account type | Accounts & stocktaking window | Sample set; account type | Out-referral cost is tracked as an expense against the destination lab | Out-referral accounts | `sentout` / `send` on `patienttest` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-4] |
| 5-5 | Clear the account of out-referred samples | Out-referred samples window | Destination lab | Per-destination grouping and settlement | Settled accounts | `otherlabname` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.5 row 5-5] |

### 4.6 Module 6 — General (6:1 – 7:0) — 11 rows

| Function ID | Name / purpose | Trigger & UI entry | Inputs / validation | Business logic | Outputs / side effects | DB | Permissions / errors | Evidence |
|---|---|---|---|---|---|---|---|---|
| 6-1 | Modify the base system settings | Settings menu (`اعدادات`) | INI keys | System-wide configuration | Configuration written | `SETING.ini`, `BASE.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-1] |
| 6-2 | Report settings | Settings → report settings | Per-report switches | Governs the report content toggles | Report configuration | `reportsetup`, `reportsetup2` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-2] |
| 6-3 | Report margins | Report settings | `leftvalue`, `rightvalue`, `topvalue`, `bottomvalue` | Page and element margins | Margin configuration | `Data\*.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-3] |
| 6-4 | **Paper size used for printing (A4 / A5)** | Report settings | `papersize=A4` (or A5) | The whole laboratory prints on one configured paper size | Print output size | `SETING.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-4] |
| 6-5 | Report header and footer settings | Report settings | `formsubtitle`, `reportmaintitle` (+ `reportsubtitle1`, `main_symb`, `sub_symb`, `subtitle_symb`, `normal_label`, `comment_label`, `signature`, `signature2`, `signature3`) | Headings are data-driven per report profile | Header/footer configuration | `Data\*.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-5] [P11 \| analysis/BATCH-02/ini/test-catalogue.csv \| header row] |
| 6-6 | **Modify the colours of the report header and footer** | Report settings → "تعديل ألوان رأس وذيل التقرير" | `colora`…`colort` (24 colours); `REPORT.dll` `color1`…`color19` | Two colour surfaces: the per-report INI palette and the shared `REPORT.dll` palette file | Updated colours (local machine only) | `Data\*.ini`, `bin\REPORT.dll` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-6] |
| 6-7 | **Configure the dedicated printers used for printing** | Report settings | `reportprinterx` in `Data\*.ini`; `reportprinter` in `SETING.ini` | Six logical printer roles are configured (see §7) | Printer assignment | `Data\*.ini`, `SETING.ini`, `printerselect` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 6-7] |
| 7-7 | **Set the system's default account type** (prices, discounts, commissions, withdrawn samples) | Settings | `pricemethod` = `Lab To Lab` / `Individual` / `Free` | The default account method applies to new patients unless overridden | Default pricing behaviour | `patientinfo.pricemethod` (referenced in the `patientinfo` GROUP BY query) | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 7-7] |
| 8-7 | **Connection settings (receipt header and footer — receipt margins)** — to display NATIGH.COM result data on the receipt | Settings | `IDCARD.INI`, `SETING.ini` | Governs how external result data are laid out on the receipt | Receipt layout configuration | `IDCARD.INI`, `SETING.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 8-7] |
| 9-7 | Background settings | Settings | `backcolor` in `Data\*.ini` | Background colour of report surfaces | Updated background | `Data\*.ini` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 row 9-7] |
| — | **Sample separation and withdrawal** (Laboratory icon) | Laboratory icon on the main screen | Sample/withdrawal selection | The laboratory workstation phase where a sample is separated and withdrawn for testing | Sample withdrawn; the comment appears on the result report | `cultures`, `cultureanti`, `sample` | NOT DOCUMENTED | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 last row] |

### 4.7 Catalogue items outside the numbered index — 13 rows

| Function ID | Name / purpose | Evidence anchor | Domain | Evidence |
|---|---|---|---|---|
| (a) | Create an account for the treating doctor to use the result service | `SMSSender` · `smsgroups` | SMS / NATIGH result service | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 1] |
| (b) | Create an account for the laboratory to use the result service | ↑ (same anchor) | SMS / NATIGH result service | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 2] |
| (c) | Add users and administrators to the system | `users` (57 methods) · `useraccounts` · `grant13`…`grant17` | Security | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 3] |
| (d) | Modify user/administrator data and permissions | `useraccounts.gtype` / `hdd1` / `hdd2` | Security | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 4] |
| (e) | **Attendance and departure registration — to know the movement of users in and out** | `loger` (new table) · `loggroup` | Security / attendance | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 5] |
| (f) | Add a referral entity | `z_gehats` · `Gehats` | Master data | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 6] |
| (g) | Add a new farm to the program | `sharekat` · `sharekathesab` | Master data | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 7] |
| (h) | **Add an antibiotic for the farm** | `antibiotic` (38 rows · 25 columns) · `antibio` (96 rows) · `cultures` | Master data / microbiology | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 8] |
| (i) | Add a fixed comment on a specific test | `comments` (12) | Master data | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 9] |
| (j) | Add a group of tests | `subgrouptable` (46) · `customgrouptable` | Master data | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 10] |
| (k) | Add a treating doctor | `mowzaf` · `z_gehats` | Master data | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 11] |
| (l) | Samples referred out | `sentout` / `send` / `otherlabname` | Out-referral | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 12] |
| (m) | Modify the colours of the report header and footer | `REPORT.dll` | Report design | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 13] |

### 4.8 Catalogue coverage of the V2-only additions

The vendor catalogue's coverage-verification table names **11 capabilities**, of which **9 are marked absent from the CHM manual**; each is bound to a V2 object/table, which identifies the corresponding function as implemented by this build. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §3 coverage-verification table]

| Capability | CHM manual | Vendor guide | V2 object / table anchor |
|---|---|---|---|
| Deliver results via **NATIGH.COM** | ✘ | ✔ | `Natigh` · the SMS system |
| **Branch system (master / reception)** | ✘ | ✔ | `Patient.branche` · `Labbranch` · `Branch_Data.mdb` |
| **Laboratory-performance statistics** | ✘ | ✔ | `statisReport` · `loger` |
| **Attendance and departure registration** | ✘ | ✔ | `loger` · `loggroup` |
| **Work Sheet** | ✘ | ✔ | `workpaper` · `workpaper2` |
| **Farm reports + farm antibiotic** | ✘ | ✔ | `sharekat` · `antibiotic` · `antibio` |
| **Modify reference values** | ✔ | ✔ | `normalrange` (852) |
| **Set the default account type** | ✘ | ✔ | `pricemethod` |
| **Connection settings (for the receipt)** | ✘ | ✔ | `IDCARD.INI` · `SETING.ini` |
| **Sample separation and withdrawal** | ✘ | ✔ | `cultures` · `sample` |
| Modify test data and prices | ✔ | ✔ | `testtable` (609) |

> **Reading the table.** The two columns are the two manuals bundled with this build — the CHM help manual and the vendor guide — and record for each capability whether it is described in that manual. The anchor column binds each capability to the V2 object or table that implements it. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §3 table]

---

## 5. Keyboard shortcuts and UI-action behaviours (as evidenced)

All rows below are quoted from the official CHM manual bundled with this build (SHA-256 `624308649E523400F6672389FC877543DB9D286F27E743C1581B1CF507902A39`, 5,193,985 bytes, 15 topics) — so these shortcut semantics are the **documented behaviour of this build**. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | header] [P11 | analysis/V-CD-2019/03-capabilities.md | §1 preamble] [P11 | analysis/V-CD-2019/04-feature-delta.md | §4 official-manual table]

### 5.1 Global / navigation keys

| Key | Behaviour | Window(s) where it is documented | Evidence |
|---|---|---|---|
| **F1** | With the cursor in the test list, show the details of the selected test | Patient-data window | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 003.htm §11 + shortcut list] |
| **F2** | Add a new patient (patient-data window); **in the results, delivery and search windows: go to the patient-data window** | 003, 004, 005, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005/006 shortcut lists] |
| **F3** | Go to the search window | 003, 004, 005 (absent from 006 — the search window itself) | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005] |
| **F4** | Go to the result-entry window | 003, 004, 005, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005/006] |
| **F5** | **Refresh** — in the patient-data window: refresh the test list and prepare for a new test search; in the results and delivery windows: refresh the patient list and re-display today's patients; in the search window: refresh the window to prepare a new search | 003, 004, 005, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005/006] |
| **F6** | Go to the result-delivery window | 003, 004, 005, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005/006] |
| **F7** | Go to the out-referred samples window (topic 010) — and, in the manual's own wording, the same key opens the **"الجرد وحساب الدرج"** (stocktaking and accounts) window (topic 011) | 003, 004, 005, 006, 010, 011 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005/006/010/011] |
| **F8** | In the patient-data window: edit the selected patient's data. In the results / delivery windows: mark the result **reviewed / not reviewed**. In the result-entry form: mark the patient's selected tests **as reviewed** | 003, 004, 004A, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005] |
| **F9** | In the patient-data window: **save the new patient or the amendment**. In the results / delivery windows: mark the result **finished / not finished**. In the result-entry form: **save the results and the amendments** | 003, 004, 004A, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005] |
| **F10** | Delete the selected patient (from the system) | 003, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/006] |
| **F11** | In the patient-data window: go to the **barcode-printing** window for the selected patient. In the result-entry form: **print-preview** the results report | 003, 004A | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004A] |
| **F12** | In the patient-data window: **print the receipt** for the selected patient. In the results / delivery windows: mark the result **printed / not printed**. In the result-entry form: **print the result report** (the tests selected, entered **and reviewed**) | 003, 004, 004A, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005] |
| **Enter** | In the patient-data window: move between the entry boxes, **collect the price of the tests from the patient**, and add the selected test or group. In the results / delivery windows: show the selected patient's tests **or** open the result-entry window for the selected test. In the result-entry form: move to the **next result field**, and at the **last available field save the result and return to the results window** | 003, 004, 004A, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005] |
| **Up / Down arrows** | Move between the entry boxes, navigate the test list, and **change the search method when the cursor is in the test search box** (patient-data window). In the results / delivery windows: move between patients and navigate the patient's tests. In the result-entry form: move between the available result fields | 003, 004, 004A, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005] |
| **Ctrl** | In the patient-data window: move between the test/group search box and the test list. In the results / delivery windows: move between the patient list and the patient's tests | 003, 004, 005 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/005] |
| **Esc** | In the patient-data window: **cancel adding a new patient or amending a previous patient**, and return to the program main menu. In the results / delivery / search windows: return to the program main menu. In the result-entry form: return to the results list **without saving** | 003, 004, 004A, 005, 006 | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/004/004A/005/006] |

### 5.2 Windows explicitly documented as having **no** shortcuts yet

| Window | Documented statement | Evidence |
|---|---|---|
| Barcode window (003A) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 003A.htm shortcut list] |
| Test-data window (007) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 007.htm] |
| Normal-ranges window (008) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 008.htm] |
| Report-settings window (009) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 009.htm] |
| Out-referred samples window (010) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 010.htm] |
| Accounts & stocktaking window (011) | "لا توجد اختصارات بعد" | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 011.htm] |

### 5.3 Other evidenced UI-action behaviours

| Behaviour | Description | Evidence |
|---|---|---|
| **Double-click = "open"** | Double-click a test in the patient-data list to add it (and its price) to the patient; double-click a test in the patient's test list to remove it; double-click the patient's name in the search results to move on to the combined-results window; double-click the file code button to print it. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 003/003A/006] |
| **Drag-and-drop on barcode labels** | An element (test or free-text row) is deleted by dragging it over the trash basket and releasing; a test is moved from one label to another by dragging it. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 003A.htm items 6 and the closing note] |
| **Auto-complete on referral entity** | Typing the beginning of the referral entity's name activates auto-complete; clicking the name restores the entity's stored data; a newly typed entity is saved automatically. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 003.htm item 5] |
| **Two-step barcode confirmation on delivery** | Read the receipt code → the patient's data are displayed → read the result-file code → the system **compares** the displayed data with the file's data → it asks whether to deliver → it warns if a balance remains. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 005.htm] |
| **Status glyph semantics** | Seven glyphs (new, notes, green+blue arrows, printer, shopping cart, genie, badge) encode the patient's delivery/account state — reproduced in full in CAP-04. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 004.htm and 005.htm item 1] |
| **Shaded-green = printed test; shaded frame = persisted value** | In the profile result form, printed tests are shaded green and must be reviewed before printing/viewing; check boxes with a shaded frame (e.g. comment) stay fixed/saved in the window. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 004A.htm items 2-3] |
| **"تم" / "تمت" toggle** | Marks a test as done/printed/reviewed; pressing again reverts it to "not yet complete". | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 004.htm item 4] |
| **"دائما اليه" (always to it)** | Must be pressed **before** "موافق" or "خالص" for a changed destination lab to become the test's saved default; otherwise the change applies only to that dispatch. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 010.htm item 4 note] |
| **Auto-updating history button label** | The patient-history button's caption changes with the number of results stored for the patient in that profile, ignoring today's result. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 004A.htm note] |
| **Bilingual UI at screen level** | The login screen, patient registration, main menu, statistics and report setup are **Arabic**; the test-definition engine, the result grid column headers and the printed work sheet are **English**. The login screen's Arabic strings match `IDCARD.INI` verbatim (`الدخول للنظام` · `اسم المستخدم` · `كلمة السر` · `نسيت كلمة المرور؟ اضغط هنا`). | VERIFIED [P11 \| analysis/V-CD-2019/10-training-video.md \| §5 and the observed-strings block] |
| **Copy-to-clipboard single click** | A single mouse click on the patient's code or Lab ID field copies it for use elsewhere in the system. | VERIFIED [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topics 004.htm and 005.htm item 2] |
| **Day-tip system** | `daytip` is the tip-text table and `frmTip` (5 methods) is the tip-of-the-day form; `frmTip`/`daytip` are the in-product surfacing of the documented shortcuts. The number of tip texts a live V2 installation carries is **NOT RECOVERABLE** — the shipped schema was ingested as a schema dump only. | VERIFIED [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| daytip row] [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| object 116 frmTip] |

---

## 6. V2 feature domains — with exact table/object identifiers

Each domain below is implemented by the V2 objects, tables and columns listed. The **identifiers are exact**: VB6 object names, table names and column names as extracted from the 1.605 binary.

| # | V2 domain | VB6 object anchors (method count) | Table / column anchors | Evidence |
|---:|---|---|---|---|
| 1 | **NATIGH.COM result delivery + the complete SMS subsystem** | `SMSfrmsenderos` (139), `ReportSMS` (0) | `smsgroups` (`ID` identity, `grouptype` Smallint, `smsgroup` varchar(50)); `smslist` (`ID`, `smstype` Smallint, `smsphone` varchar(20), `smsname` varchar(50), `smsgroup` varchar(50), **V2-added `send` Smallint**); `SMStemplate` (`templatenum` identity, `smstext`); `SMSSender` (`SMSautonum` identity, `patientid` varchar(13), `PatDrName` varchar(60), `requestdate` smalldatetime, `smsMobile` varchar(20)→**varchar(100)**, `SMSLength` Smallint, `SMStext`, **V2-added `username` varchar(50)**); `patientinfo.**SMSMob**`; `patienttest.**NatighU**`; installed file `Natigh` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 first row] [P11 \| analysis/BATCH-04/schema/created-tables.csv \| SMSSender/SMStemplate/smsgroups/smslist rows] [P11 \| analysis/V-CD-2019/02-schema.md \| §3 patientinfo and patienttest rows] |
| 2 | **Branch system (master / reception)** | `server` (17), `z_branchs` (14) | `Patient.branche` (smallint, **V2-added**); `labbranch` (7 statements); `Branch_Data.mdb` (49 tables, 0 rows — schema template); `SUBSTRING(patientid,9,1)` as the branch discriminator; `loggroup` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 second row] [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §5 master/reception table] [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 row 10 — the branch template's "49 جدولًا، 0 صفوف"] |
| 3 | **Laboratory-performance statistics** | `statisReport` (datareport, 0) | `loger` (**new** V2 table, 5 statements — `SELECT * FROM loger where lognum=`); `patientinfo.requestdate`, `patientinfo.patientsex`; `patienttest.subgroupcode`; `patienttest` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 third row] [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| loger row] |
| 4 | **Attendance and departure registration** | `logindete` (6), `logindetect` (datareport, 0), `users` (57) | `loger` (new), `loggroup` (7 statements — `SELECT * FROM loggroup`), `tasgel` (6 statements — `select * from tasgel where username='…'`), `patients` (**14 statements** — `Select startwork,endwork,breakyorn,breaktime from patients where patientusname='…'` — i.e. the staff work/shift log) | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 fourth row] [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 5] |
| 5 | **Work Sheet (work orders / distribution plans)** | `workpaper` (17), `workpaper2` (18) | `wasl` (6 statements — `DELETE FROM wasl`; **V2-added columns `RESULTCASEPRINT`, `normalrang`, `resultt`, `subgroupname`, `testcodex`, `testunit`**), `sarfz`, `testtable` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 fifth row] [P11 \| analysis/V-CD-2019/02-schema.md \| §3 wasl row] |
| 6 | **Farm reports + farm antibiotic** | `sarfz` (26), `moenysharekat` (27), `antibioticfrm` (29), `sharekat` | `sharekat` (5 statements), `sharekathesab` (19), `antibiotic` (13 statements, 38 rows × 25 columns), `antibio` (2 statements, 96 rows), `cultures` (3), `cultureanti` (7) — row/column counts per the V2 vendor catalogue. [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 8] | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 sixth row] [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row 8] |
| 7 | **IgE allergy** | `resultIgeAllergy` (231), `ReportIGE1` (0), `ReportIGE1s` (0) | `IgEallergy` — `Item1..Item40`, `RESULT1..RESULT40` varchar(25), `Class1..Class40` Smallint, `TypeF1..TypeF40` Smallint; **V2-added blocks `Item12`, `Item24`, `Item36`** | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 eighth row] [P11 \| analysis/BATCH-04/schema/added-columns.csv \| igeallergy rows] |
| 8 | **PCR (molecular biology)** | `ResultPCR` (37), `ReportPCR` (0), `ReportPCRs` (0) | `patienttest` result fields; INI profiles 450–458 (`HBV - DNA (Qualitative)`, `HBV - DNA (Quantitative)`, `HCV - RNA (Qualitative)`, `HCV - RNA (Quantitative)`, `HCV genotyping`, 4 unnamed) | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 ninth row] [P11 \| analysis/BATCH-02/ini/test-catalogue.csv \| rows 450-458] [P11 \| analysis/BATCH-07/ini-key-delta.csv \| `reportdata.formsubtitle` rows for `450.ini`–`458.ini` — unchanged for 450–454, removed for 455–458, so the V2 payload carries the same nine molecular-biology profiles with the same five named titles] |
| 9 | **H. pylori** | `resulthpylori` (83) | `Helicobacter` — `patientid` varchar(13), `requestdate` DATETIME, `comment` varchar(255), `hpab`, `hpag`, `hpbiop`, `hpiga`, `hpigi`, `hpigm` (varchar(50)); **V2-added `hpab`, `hpbiop`, `hpiga`** | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 tenth row] [P11 \| analysis/BATCH-04/schema/created-tables.csv \| Helicobacter rows] |
| 10 | **FMF (familial Mediterranean fever)** | `ResultFMF` (48) | `FMF` (2 columns — `patientid` varchar(13) + one further column); `FMF` report category in the printer profile list | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 eleventh row] [P11 \| analysis/BATCH-04/schema/created-tables.csv \| FMF rows] |
| 11 | **Automated urine analysis** | `ResulturineAuto` (184) | `urine` — **V2-added `T56`, `T57`, `testid`**; `URINEauto` printer category | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 twelfth row] [P11 \| analysis/V-CD-2019/02-schema.md \| §3 urine row] |
| 12 | **Semen analysis v5** | `Resultsemen5` (216) | `semen` — **V2-added `testcode`**, **V2 type changes `Liquefaction`→varchar(10), `Viscosity`→varchar(15)**; `SEMEN5` printer category | VERIFIED [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| object 177 Resultsemen5] [P11 \| analysis/BATCH-02/ini/printer-settings.csv \| SEMEN5 category] |
| 13 | **Patient sample tracking** | `Patient_samples` (89) | `samples` (4 statements — `Select * from samples where patientid = '…'`); `RPTPatientVisit`; `reportview` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 thirteenth row] |
| 14 | **Permission model (first discovered in the project)** | `users` (57) | `Patient.grant13`, `grant14`, `grant15`, `grant16`, `grant17` — **Bit** columns; `useraccounts.gtype` (Smallint), `useraccounts.HDD1` varchar(20), `useraccounts.HDD2` varchar(20) | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 fourteenth row] [P11 \| analysis/BATCH-04/schema/added-columns.csv \| useraccounts row] [P11 \| analysis/V-CD-2019/02-schema.md \| §3 Patients row] |
| 15 | **Laboratory settings (per-lab configuration record)** | — | `MyLabSetting` / `mylabsetting` — `LabID` (the query is `Select * from MyLabSetting WHERE LabID=100 ;`) | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 fifteenth row] [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| mylabsetting row] |
| 16 | **Patient visit log** | `RPTPatientVisit` (0) | `reportview` (2 statements — `SELECT stripnum,stripdiscrp,strip1 FROM reportview where stripdiscrp='MAIN'`); `patientinfo.requestdate` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 sixteenth row] |
| 17 | **ID card (patient identity card)** | `CardFrm` (0, 3 controls), `CardFrmSetx` (22, 29 controls) | `IDCARD.INI` (`[Billdata]`, `[IDdata]`); printer role `IDprinter` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 seventeenth row] [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 printer-roles table] |
| 18 | **LBC** | `resultLBC` (33, 52 controls), `ReportLBC` (0), `ReportLBCs` (0) | `LBC` — 18 columns: `patientid` varchar(13), `requestdate` DATETIME, `testid` Smallint, `RESULT1..RESULT7` varchar(75), `RESULT01..RESULT07` Memo, `LBCSAMPLE` YESNO | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 eighteenth row] [P11 \| analysis/BATCH-04/schema/created-tables.csv \| LBC rows] |
| 19 | **Pages / reports (new output layer)** | `ReportZN`, `ReportZNs`, `ReportTestTime`, `ReportPatPhone`, `Reportliver7his`, `Reportlivers7his`, `Reportmony01`, `Reportmony11`, `Reportmony5`, `pricelistsN`, `ReportFatoraC`, `ReportFatorareset`, `ReportFatorareset8`, `ReportIGE1`, `ReportIGE1s`, `ReportPCR`, `ReportPCRs`, `ReportLBC`, `ReportLBCs`, `ReportSMS`, `RPTPatientVisit` (all datareport) | `zn`, `payment`, `patientinfo`, `patienttotal`, `smssender`, `igeallergy`, `lbc`, `reportview` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3 nineteenth row] |
| 20 | **Run-time schema evolution (DDL embedded in the binary)** | — (applies to all objects) | **268 embedded DDL statements** — **27 `CREATE TABLE` + 241 `ALTER TABLE`**; **12 tables created** and **228 columns added across 29 tables**, 14 column-type changes. The 12 created tables are `testtemp`, `MyLabSetting`, `smsgroups`, `smslist`, `SMStemplate`, `SMSSender`, `LBC`, `IgEallergy`, `pictures`, `hba1c`, `FMF`, `widal2`, `ratios`, `Helicobacter` | VERIFIED [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 rows 2 and 6 + §2] [P11 \| reports/Stage-3-V-CD-2019-Baseline-Report.md \| §4 embedded-DDL section] |
| 21 | **Engine portability (3 database engines)** | — | Access (Jet 4) `BASE.ini` → `XMSACCESSX`, `Patients.mdb`, `Branch_Data.mdb`; SQL Server Express 2005 (`SQLEXPR.EXE`, UDL → `SQLOLEDB.1`, databases `patients` + `Interface` + `VIDAS`); MySQL (Connector ODBC 3.51) | VERIFIED [P11 \| analysis/V-CD-2019/05-deployment.md \| §2] [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1] |
| 22 | **Licensing bound to hardware** | `BiosData` (8), `aaaClass` (15) — also present in the installer | `win32_processor` (1 SQL statement — `Select * from Win32_Processor`); WMI path `Hardware\Description\System` | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 licence table] [P11 \| analysis/V-CD-2019/02-schema.md \| §5 row 117] |
| 23 | **Print/PDF output stack** | `reportsetup` (113), `reportsetup2` (69), `printerselect` (11 module) | `patienttest.resultprint`, `printuser`, `printdate`, `printnum`; `Data\*.ini` `reportprinterx`; `SETING.ini` `reportprinter`, `papersize`; `bin\REPORT.dll` (`[reportdata]`, `color1..color19`) | VERIFIED — see §7 |

> **Count note on row 20.** The row states **12** created tables while naming **14** tables (`testtemp`, `MyLabSetting`, `smsgroups`, `smslist`, `SMStemplate`, `SMSSender`, `LBC`, `IgEallergy`, `pictures`, `hba1c`, `FMF`, `widal2`, `ratios`, `Helicobacter`). The discrepancy is present in the source evidence and is reproduced here as found rather than resolved. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 rows 2 and 6 + §2]

---

## 7. Printing / PDF output functions

### 7.1 The V2 print path (VERIFIED)

> **The one-line finding:** RealLab has **no PDF engine of its own**. It hands the report to an **external Windows print driver** — `Bullzip PDF Printer` — whose **device name and version are hard-coded as literals in the binary**. Pathology ⇒ PDF is produced **through the operating-system layer**, not through an application library. [P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | lead paragraph]

```
real lab system.exe — FileVersion 1.605
  • literal «Bullzip PDF Printer»                    ← the print device name
  • literal «Bullzip PDF Printer 11.1 - Create File» ← the default output name
  • EnumPrintersA / SetDefaultPrinterA              ← modern Win32 printer API
  • 6 printer roles · 5 selection combos (cboPrinters..5) · 6 imlPrinters
        │  the report is sent to the print port
        ▼
Bullzip PDF Printer 11.1.0.2600  (BioPDF ApS · Inno Setup 5.5.7)
  cf/Bullzip/PDF Printer/Ports/BULLZIP/bzpdf.dll   ← the port driver (213 KiB)
  app/gs/                                          ← bundled Ghostscript
  app/DocumentCollector.exe · app/Notify.exe · labels.txt × ~50 languages
        │  produces
        ▼
D:\PDF\Contracts\  ·  D:\PDF\Free\  ·  D:\PDF\Individual\  ·  D:\PDF\LabToLab\
```

[VERIFIED | P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §1 full path diagram]
[VERIFIED | P11 | بعد الدفعة الحادية عشر/pdf-print-stack.md | §2.1 offsets table — `Bullzip PDF Printer` at `0x6A2486`, `Bullzip PDF Printer 11.1 - Create File` at `0x6A255E`]

### 7.2 Printing / PDF function inventory

| Function ID | Name | Purpose | Domain | Description | Trigger | Preconditions | Inputs | Validation | Execution | Business logic | Outputs | Side effects | DB interactions | Permissions | Errors | Exception handling | Related entities | Dependencies | UI entry point | Postconditions | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| PF-01 | `reportsetup` — per-report settings editor | Configure one report's headings, layout, colours, toggles and margins | Report design | 113 procedures; edits a single report profile only, and only on the local machine | Orange group-name button on the result-entry form | A profile report must be open | Headings, alignment, colours, toggles, margins, per-element dimensions | Per-report scope and local-machine scope (rules 1–2 in CAP-09) | edit → save | Layout is INI-driven, not code-driven | Updated `Data\*.ini` profile | Local configuration change only | `reportview` (2 statements) | NOT DOCUMENTED | NOT DOCUMENTED | "عودة" discards | `Data\*.ini`, `reportview` | `printerselect`, `static1..6` | `reportsetup` | INI profile updated | VERIFIED [P11 \| analysis/V-CD-2019/10-training-video.md \| §8] |
| PF-02 | `reportsetup2` — global report settings editor | Configure system-wide report behaviour | Report design | 69 procedures; changes apply to all reports but only on the local machine | Report settings menu | — | Global report options | Global-but-local scope | edit → save | Central place for settings shared by all profiles | Updated global settings | Local configuration change only | `reportview` | NOT DOCUMENTED | NOT DOCUMENTED | "عودة" discards | `reportsetup`, `SETING.ini` | `printerselect` | `reportsetup2` | Global settings updated | VERIFIED [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| object 77] |
| PF-03 | `printerselect` (module, 11 procedures) + `selectprinter` + `check_onePrinter` | Resolve and validate the target print device | Print device management | The module that binds a logical printer role to a physical Windows device; it exposes 11 procedures | Called by the print paths | A printer role must be configured | Device list (`EnumPrintersA`), default device (`SetDefaultPrinterA`) | `check_onePrinter` validates the selection | enumerate → select → validate → print | Role-to-device indirection lets one report family use a colour printer | A resolved device | Default-printer state may be changed system-wide | NOT DOCUMENTED (device registry) | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `reportprinter`, `reportprinterx`, `zarfprinter`, `barcodeprinter`, `waslprinter`, `IDprinter` | `reportsetup`, `reportsetup2` | Settings → printers | Device resolved | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §2.4 last line] [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §2 comparison table] |
| PF-04 | Role `reportprinter` | Primary report printer | Print | The main report output path | Print action | Role configured | Report content | Verified-result gate (PF-09) | render → gate → print | The default path for all laboratory reports | Printed report | Print audit row | `patienttest.resultprint` etc. | NOT DOCUMENTED | PF-09 gate | NOT DOCUMENTED | `printerselect` | `reportsetup` | Any print action | Report printed | VERIFIED [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 roles table] |
| PF-05 | Role `reportprinterx` | Secondary report printer | Print | A second report output path (INDIAN `reportprinterx` in `Data\*.ini`) | Print action | Role configured | Report content | Same gate | render → gate → print | Dual-path printing (e.g. a different device for some profiles) | Printed report | Print audit | same | NOT DOCUMENTED | PF-09 gate | NOT DOCUMENTED | `printerselect` | `reportsetup` | Any print action | Report printed | VERIFIED [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 roles table] |
| PF-06 | Role `zarfprinter` | ZARF integration printer | External integration | Binding to an external system named **ZARF** | Print action | Role configured | Report content | Same gate | render → gate → print | Evidence of integration with an external lab/hospital information system | Externally consumed report | Print audit | same | NOT DOCUMENTED | PF-09 gate | NOT DOCUMENTED | `printerselect`, `zarf` (datareport, 1 procedure) | `reportsetup` | Print action | Report delivered to ZARF | VERIFIED [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 roles table] [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §2.4] |
| PF-07 | Role `barcodeprinter` | Barcode label printer | Print | Prints the file code, lab code, tube and container labels | Barcode window print | Role configured | Label content | The barcode window's own rules (CAP-03) | render → print | Tubing and specimen labelling | Printed labels | Print job | `barcodes`, `patienttest` | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `barcode`, `z_barcodes` | `printerselect` | `barcode` | Labels printed | VERIFIED [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 roles table] |
| PF-08 | Role `waslprinter` | WASL integration printer | External integration | Binding to an external system named **WASL** (the work-sheet family) | Print action | Role configured | Work-sheet content | Same gate | render → gate → print | Evidence of an external work-order/scheduling integration | Externally consumed work sheet | Print audit | `wasl` | NOT DOCUMENTED | PF-09 gate | NOT DOCUMENTED | `printerselect`, `workpaper`, `workpaper2` | `reportsetup` | Print action | Work sheet delivered | VERIFIED [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3 roles table] |
| PF-09 | Print-quality gate + print audit | Refuse to print an unverified result; record who printed what, when and how many times | Print control | The gate message is `Not found any Verified selected tests or result to print it`; the audit columns are `resultprint`, `printuser`, `printdate`, `printnum` and the printable set is `testcode in (6,7,8,9,14,15,16,17,18,19,20,21)` — **12 test types only** | Any print action on a result | — | The selected tests and their review state | A result must be **reviewed**; the test type must be in the 12-type printable set | check → refuse or print → write audit | **An unverified result cannot be printed**; `printnum` is a sequential counter, i.e. **numbered printing** to make unauthorised copies detectable | Printed report; audit row | Audit row written on every print | `patienttest.resultprint`, `printuser`, `printdate`, `printnum`, `testcode`, `patientid` | NOT DOCUMENTED | The gate message | NOT DOCUMENTED | `patienttest`, `printerselect` | `reportsetup` | Print action | Result printed and audited | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §2.5 SQL block] [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4 quality-controls table] |
| PF-10 | Bullzip PDF output + 4 classification folders | Produce the PDF file | PDF output | The application prints to the `Bullzip PDF Printer` device; Bullzip's port driver writes the file into one of four folders keyed by the billing class: `Contracts`, `Free`, `Individual`, `Lab To Lab` (stored as `LabToLab`) | Any print action routed to the PDF device | Bullzip installed **with the exact device name** | The rendered report | The device name and version are **hard-coded literals** — a different Bullzip install breaks the path | print → port driver → bundled Ghostscript → file | Four output roots reflect the commercial/operational classification of laboratory paperwork (contracts · free · individual · lab-to-lab) | A PDF file in `D:\PDF\<class>\` | Files written to the D: volume | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | `printerselect` | `reportsetup` | Print action | PDF produced in the classified folder | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §2.2 output-tree table] |
| PF-11 | Report colour and paper configuration | Define the report palette, header/footer colours and paper size | Print configuration | Per-profile colours `colora..colort` (24) and `colorafn..colortfn` in `Data\*.ini`; the shared palette `bin\REPORT.dll` is **not a DLL** but a text INI with `[reportdata]` and `color1..color19`; paper size via `SETING.ini` `papersize=A4` (or A5) | Settings → report setup | — | INI keys | NOT DOCUMENTED | edit → save | Two colour surfaces exist; the "DLL" naming is misleading | Updated configuration | Local configuration change | `reportview` | NOT DOCUMENTED | NOT DOCUMENTED | "أبيض وأسود" resets to B/W | `Data\*.ini`, `bin\REPORT.dll`, `SETING.ini` | `reportsetup`, `reportsetup2` | Settings → report setup | Palette/paper configured | VERIFIED [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.6 rows 6-4/6-6] [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-12] |

### 7.3 Print-related facts that constrain the function set

| Fact | Statement | Evidence |
|---|---|---|
| No internal PDF library | The RealLab PDF stack contains **0** references to `real lab`, `RL_SETUP`, `Lab_data`, `.mdb`, `Attach_*` in its five files, and **0** references to `Bullzip`/`BZPDF`/`PDF Printer` inside them — i.e. the stack is **pure third-party** with no internal binding. | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §1 table] |
| The three side tools are never called | `gslite`, `ghostscript`, `pdftops`, `xpdf`, `pdfpowertool` each have **0** occurrences in the 1.605 code — they are **manual operator tools** installed in `System\PDF\`, not part of the application path. | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §5 tool table] |
| Arabic RTL in the PDF layer | Bullzip ships `app/labels.txt` in ~50 languages **including `ara`** — RTL support is provided by the print engine, not by the application. | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §3.1] |
| Install-order defect | `RL_SETUP.exe` invokes `System\PDF\SetupP.bat` (Bullzip only) **before** `System\SetupPZ.bat` (.NET 4 then Bullzip), and `SetupFN4.bat` is orphaned with a broken relative path — Bullzip 11 requires .NET 4, so the first attempt fails and the second succeeds. | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §5.1 table] |

---

## 8. Installer / setup functions

### 8.1 The vendor installer

| Attribute | Value | Evidence |
|---|---|---|
| Artefact | `RL_SETUP.exe` · 23,060,480 B · FileVersion **19.00** · `ProductName: RealLab CD` · `InternalName: RL_SETUP` | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1 identity table] |
| Technology | Visual Basic 6.0 SP6 · single import `MSVBVM60.DLL` (161 functions) · linker 6.0 · PE32, 3 sections, `.text` 22,953,984 B (entropy 7.39 — a **compressed payload inside the code**, no overlay) | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1 table] |
| Size | **57 objects · 599 procedures** | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1 table] [P05 \| Stage-4-V-CD-2019-Deployment-Report.md \| §3] |
| Archive format | **No standard archive signature** (no ZIP/CAB/RAR/7z/Inno/NSIS) ⇒ a **custom VB6 container format** | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1 table] |

### 8.2 Installer / setup function inventory

| Function ID | Name | Purpose | Description | Trigger | Preconditions | Inputs | Validation | Execution | Business logic | Outputs | Side effects | DB interactions | Permissions | Errors | Exception handling | Related entities | Dependencies | UI entry point | Postconditions | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| IF-01 | `RL_SETUP.exe` main wizard | Drive the whole installation | English + Arabic **parallel** step families: `Form1`(43) `Form2`(10) `frm_start`(2) main processor; `Frm_rls1..8` + `Frm_rlsAr1..8` (8 steps); `Frm_rli1..7` + `Frm_rliAr1..7` (7 steps); `Frm_mssql1..4` + `Frm_mssqlAr1..4` (4 steps); `Frm_repair0..5` (17) repair path; `Frm_help1..4` | Running `RL_SETUP` from the CD, **choosing the first option** | — | 16 `cmd.exe` invocations; the deployment tree | NOT DOCUMENTED | 16 command lines executed (see §8.3) | A multi-step, bilingual installer is the vendor's chosen model for a Windows/Access/SQL-Client mix | Installed system tree | Writes the whole payload to `D:\real lab system\`, registers 24 ActiveX components in the Windows registry | `D:\Lab_data\Patients.mdf`, `Interface.mdf` | Administrative rights for the registry writes | NOT DOCUMENTED | "Repair Installed Software" path (`Frm_repair0..5`) | `Setup*.bat`, `SETUP.LST`, CABs | `System\Setup*.bat`, `WIN7\WINXP` | `RL_SETUP` | Application installed and launched | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1.1 + §3.1] |
| IF-02 | Database-engine selection | Choose Access or SQL Server as the data store | Two options: **Microsoft Access database** (`Microsoft.JET.OLEDB.4.0`, `D:\real lab system\bin\Patients.mdb`) and **Microsoft SQL server database** (`MS SQL Server 2005`, `D:\Lab_data\Patients.mdf`). Messages: `You don't select the database type, Please select the type first`; `Please wait while setup install MS SQL Server 2005`; `Installing MS SQL Server 2005` | The third wizard option (SQL Server) or the Access option | — | Engine choice; for SQL Server, the instance name and credentials | The engine must be selected before the wizard proceeds | choose → provision → attach | **Converting between engine types does not transfer the data**: *"If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD."* | A provisioned database | Database files and services created | `patients`, `Interface`, `VIDAS` databases | Administrator | The "please select the type first" message | NOT DOCUMENTED | `Frm_mssql1..4`, `Attach_*.bat` | `Setup.bat`, `Setup4.bat` | `RL_SETUP` → engine option | Engine selected and attached | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2 + §2.1] |
| IF-03 | Hardware-bound licensing | Bind the licence to the machine | `Choose your systems (licensed only)`; the licence is bound to **hard disk + motherboard + CPU**: *"If the computer hard disk, Mother board and CPU damage or lost the RealLab not responsible and you will purchased the other license for the SOFTWARE."*; fingerprint via the WMI path `Hardware\Description\System`; the application itself queries `Select * from Win32_Processor` (the `win32_processor` table) | Licence step (`Frm_rli1..7`) | The machine's hardware identifiers must be readable | Machine fingerprint | — | read → bind | A hardware-locked licence model | A licence tied to the machine | Reads machine identity | `win32_processor` (1 statement) | — | NOT DOCUMENTED | The tool `RealLab_Show_Info.exe` (v19.00) prints the machine serial; the vendor guide says to run it **as administrator on Windows 7** | `BiosData`, `aaaClass` (also in the installer) | `RLS_Setup.pdf` pp.2–6 | `RealLab_Show_Info` → `RL_SETUP` | Licence bound | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 licence table] [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §6 documented steps 1-2] |
| IF-04 | Font installation | Install the five laboratory fonts | Five lab fonts ship with the media (`ais lab.ttf`, `ais symbol.ttf`, `MCS Taybah.ttf`, `WBCW_UPCEAN.ttf`, `WBCWS_UPCEAN.ttf`) and are installed **manually** via `D:\real lab system\Fonts` → select all → Copy → `Control Panel\Fonts` → Paste; "the font already exists" is accepted | The documented setup step (guide p.42) | — | The five TTF files | Pre-existing fonts are tolerated | copy → paste | **The manual copy contradicts the code**: the installer contains a `FontInstaller` module with **38 procedures** and a `modFonts` module with 12, i.e. the code path exists but the documented path is manual — so there is **no effective registry-based font install in the standard path** | Fonts available to the report engine | Fonts installed into the system font directory | NONE | Administrative rights for system fonts | "font already exists" is accepted | NOT DOCUMENTED | `FontInstaller`(38), `modFonts`(12) | `System\Fonts` | Guide p.42 | Fonts installed | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1.1 + §6 step 3 note] [P11 \| analysis/V-CD-2019/12-install-media.md \| §2.1 Font rows] |
| IF-05 | Date display language configuration | Force the Windows date display language to **English (Canada)** | Guide step: `Control Panel` → `Region and Language` → display language = **English (Canada)**; the CHM repeats it as the recovery for the error *"رجاء تحويل التاريخ الى اللغة الانجليزية"* | During installation, or after the error dialog | Windows with the language installed | Locale setting | The application refuses to run with a non-English display language | change → re-run | A **non-obvious product-imposed prerequisite** on the host OS locale | An application that starts | OS locale changed | NONE | Administrator | The error message and the closed application | The CHM's documented recovery path | `SETING.ini` (locale-related keys NOT DOCUMENTED) | Windows locale | Guide step 4 / CHM 001.htm | Application starts | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §6 step 4] [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 001.htm] |
| IF-06 | Database attachment | Attach the SQL Server databases | `cmd.exe /C start /B /wait D:\Lab_data\Attach_Patients.bat`, `…Attach_Interface.bat`, `…Attach_VIDAS.bat`; the main chain also runs `OSQL -S %COMPUTERNAME% -E /i Attaching.sql` after `cd\Lab_data` (`OSQL -E` = integrated Windows authentication) | After the engine is installed | SQL Server instance running | `Attaching.sql`, `Attach_database.bat` — **created or uploaded at install time; not present in the shipped tree** | NOT DOCUMENTED | attach → verify | **Three** databases are attached: `patients`, **`Interface`** (the configuration/interface DB, separate from patient data) and `VIDAS` | Attached databases | SQL Server databases created on the D: volume | `patients`, `Interface`, `VIDAS` | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | `Interface.mdf`, `Patients.mdf` | `Setup.bat` | `RL_SETUP` → SQL Server path | Databases attached | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1 + §3.1] [P11 \| analysis/V-CD-2019/05-deployment.md \| §4] |
| IF-07 | `Setup.bat` main prerequisite chain | Install the prerequisite stack | Order: Windows Installer 3.1 → MSXML 6.0 → .NET Framework 2.0 → SQL Server Express 2005 → `OSQL … Attaching.sql` → `Attach_database.bat`; `Setup1.bat` = `WI-KB893803-v2-x86.exe /passive /norestart /overwriteoem`; `Setup2.bat` = `msxml6_x86.msi /passive /norestart`; `Setup3.bat` = `dotnetfx.exe /q:a /c:"install.exe /q"`; `Setup4.bat` = SQL Express; `Setup5.bat` = `mysql-connector-odbc-3.51.30-win32.msi /passive` | `RL_SETUP` | Administrator | Each MSI/installer path | NOT DOCUMENTED | Each with `/passive` or `/qb` (unattended) | Prerequisites before the application | Prerequisite runtimes installed | Windows Installer, MSXML, .NET 2.0, SQL Express, MySQL ODBC | NONE | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | The five referenced Microsoft installers | `System\Setup*.bat` | `RL_SETUP` | Prerequisites installed | VERIFIED [P11 \| analysis/V-CD-2019/05-deployment.md \| §1 script table] |
| IF-08 | PDF prerequisite chain (`SetupPZ.bat` / `SetupP.bat` / `SetupFN4.bat`) | Install .NET 4 and Bullzip | `SetupPZ.bat` = `dotNetFx40_Full_x86_x64.exe /q` → `Setup_BullzipPDFPrinter_11_1_0_2600_PRO_EXP.exe /VERYSILENT /NORESTART`; `SetupP.bat` = Bullzip only; `SetupFN4.bat` = .NET 4 with a broken relative path and **no caller** | `RL_SETUP` | Administrator | The three scripts | NOT DOCUMENTED | `SetupP.bat` is invoked **before** `SetupPZ.bat`, so Bullzip is installed before .NET 4 (which Bullzip 11 requires) — the first attempt fails and the second succeeds | Correct ordering is .NET 4 first, then Bullzip | .NET 4 + Bullzip installed | System files written; Ghostscript bundled inside Bullzip | NONE | Administrator | First Bullzip attempt fails without .NET 4 | The retry through `SetupPZ.bat` | `bzpdf.dll`, `app/gs/` | `System\PDF\`, `System\SetupPZ.bat` | `RL_SETUP` | PDF path available | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §5.1 table] [P11 \| analysis/V-CD-2019/05-deployment.md \| §1 row SetupPZ.bat] |
| IF-09 | `SETUP.LST` / CAB deployment | Deploy the 45-entry manifest payload (6 bootstrap + 39 Setup1 files) onto the client machine | `[Bootstrap] SetupTitle=Install` `CabFile=real lab system.CAB` `Spawn=Setup1.exe` `Uninstal=st6unst.exe` `TmpDir=msftqws.pdw` `Cabs=1`; `[Setup] Title=RealLab` `DefaultDir=$(ProgramFiles)\real lab system` `AppExe=real lab system.exe` `AppToUninstall=real lab system.exe`. The 39 files: **22** → `$(WinSysPathSysFile)` (OLEAUT32.DLL, OLEPRO32.DLL, ASYCFILT.DLL, VB5DB.DLL + the 12 Jet files), **16** → `$(WinSysPath)` (the 19 ActiveX files + MSDBRPTR.DLL, MSSTDFMT.DLL, MSBIND.DLL), **5** → `$(Font)`, **1** → `$(MSDAOPath)` (dao360.dll). Execution: **24** `$(DLLSelfRegister)`, **1** `$(TLBRegister)`, **31** `$(Shared)` | `WIN7\setup.exe` / `WINXP\setup.exe` (Microsoft VB6 Setup Toolkit bootstrap 6.00.9782) | Administrator | The CAB per target | NOT DOCUMENTED | copy → self-register → verify | The installer writes directly into `System32`/`SysWOW64` and **self-registers 24 components in the Windows registry** — administrative rights are mandatory and the vendor does not declare them | Application tree at `C:\Program Files\real lab system`; fonts installed | 24 registry self-registrations; System32 writes | NONE | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | Jet 4, VB6 runtime, 19 ActiveX, 5 fonts | `real lab system.CAB` | `WIN7`/`WINXP` | `SETUP.LST` | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §2, §2.1, §2.2, §2.3] |
| IF-10 | VB6 SP6 redistributable + MDAC TypeLib | Provide the DataReport/VB6 runtime the application needs | `System\datareport_vh\` (73 files): `VS6sp6B1.cab` (9,036,800 B: `msinet.ocx`, `mswinsck.ocx`, `tlbinf32.dll`, `oleaut32.dll`, `stdole2.tlb`, `VCMAgg.dll`, `RepVCM.dll`), `vbrun60.cab` (`VBRUN60.EXE`), `Msvbvm60.cab` (`MSVBVM60.DLL` + INF), `Oleaut.cab`, 16 ActiveX CABs, `acmsetup.exe`, `setupsp6.exe` + `.lst`, `sp698vbo.dll`, script-support files, debug symbols, `readme.htm`/`toc.htm`/`eula.txt`; plus `System\MDAC_TYP\MDAC_TYP.EXE` (8,124,720 B, PE32 self-extracting CAB installer) | `RL_SETUP` | Administrator | The CAB set | NOT DOCUMENTED | install | **The `redist.txt` manifest (213 entries) also contains `vfp6run.exe`, `vfp6t.dll`, `vfp6rrus.dll`** — a **Visual FoxPro 6.0** engine — plus `.dbf`/`.fpt` project files, which is the most likely origin of the otherwise unexplained **`VIDAS`** component | VB6 SP6 runtime installed; MDAC TypeLib installed | Registry and system-file writes | NONE | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | VB6 SP6 payload | `System\datareport_vh\`, `System\MDAC_TYP\` | `RL_SETUP` | Runtime present | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §5, §5.1, §6] |
| IF-11 | Repair path (`Frm_repair0..5`) | Repair an existing installation | A dedicated 6-form repair path inside the installer | `RL_SETUP` → "Repair Installed Software" | An existing installation | NOT DOCUMENTED | NOT DOCUMENTED | repair | Re-runs the installation steps without a full reinstall | Installation repaired | NOT DOCUMENTED | NOT DOCUMENTED | NOT DOCUMENTED | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | `Frm_repair0..5` | `RL_SETUP` | Repair completes | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1.1] |
| IF-12 | ActiveX self-registration (24 components in the Setup1 phase; 27 declared manifest-wide) | Make the controls usable by the application | `$(DLLSelfRegister)` on 24 OCX/DLL files in `[Setup1 Files]` plus 3 more in `[Bootstrap Files]` (`COMCAT.DLL`, `OLEPRO32.DLL`, `OLEAUT32.DLL`), and `$(TLBRegister)` on `STDOLE2.TLB` | During CAB deployment | Administrator | The 24 components | NOT DOCUMENTED | self-register → registry write | The vendor forces **24 ActiveX registrations** on every client machine — a permanent registry footprint and an administrative requirement | Registered controls | 24 registry entries; System32/SysWOW64 writes | NONE | Administrator | NOT DOCUMENTED | NOT DOCUMENTED | The 19 ActiveX + Jet DLL set | `SETUP.LST` | `WIN7`/`WINXP` | Controls registered | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §2.2] |

### 8.3 The 16 `cmd.exe` invocations executed by the installer

| # | Command | Effect | Evidence |
|---:|---|---|---|
| 1 | `cmd.exe /C start /B /wait System\SETUP1.bat` | Windows Installer 3.1 | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3.1] |
| 2 | `… SETUP2.bat` | MSXML 6.0 | VERIFIED [P11 \| same] |
| 3 | `… SETUP3.bat` | .NET Framework 2.0 | VERIFIED [P11 \| same] |
| 4 | `… SETUP4.bat` | SQL Server Express 2005 | VERIFIED [P11 \| same] |
| 5 | `… SETUP5.bat` | MySQL Connector ODBC 3.51 | VERIFIED [P11 \| same] |
| 6 | `… System\SetupPZ.bat` | .NET 4 + Bullzip PDF Printer | VERIFIED [P11 \| same] |
| 7 | `… System\PDF\SetupP.bat` | Bullzip PDF Printer (order defect — see IF-08) | VERIFIED [P11 \| same] |
| 8 | `… XCOPY` | Copy the deployment payload | VERIFIED [P11 \| same] |
| 9 | `… WIN7\setup.exe /sc:\setup.log` | Windows 7 target | VERIFIED [P11 \| same] |
| 10 | `… WINXP\setup.exe /sc:\setup.log` | Windows XP target | VERIFIED [P11 \| same] |
| 11 | `… D:\Lab_data\Attach_Patients.bat` | Attach `patients` | VERIFIED [P11 \| same] |
| 12 | `… D:\Lab_data\Attach_Interface.bat` | Attach `Interface` | VERIFIED [P11 \| same] |
| 13 | `… D:\Lab_data\Attach_VIDAS.bat` | Attach `VIDAS` | VERIFIED [P11 \| same] |
| 14–16 | `cmd.exe /C start /B WIN7\setup.exe /sc:\setup.log` and `… WINXP\setup.exe /sc:\setup.log` (without `/wait`) | Write the setup log to `C:\setup.log` **in the drive root** and **do not wait** for completion — so the user may start the application before the ActiveX and fonts finish installing | VERIFIED [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §5.2] |

### 8.4 Deployment-tree split (two install roots, not one)

| Root | Contents | Evidence |
|---|---|---|
| `C:\Program Files\real lab system\` | The application tree (`$(ProgramFiles)\real lab system` per `SETUP.LST`) | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §2.3] |
| `D:\real lab system\` | `real lab system.exe` (FileVersion 1.605) · `real lab system help.chm` · `bin\` (`Patients.mdb`, `RLUTool.exe`, `real lab timer.exe`, `Patient Data Transport.exe`, `RealLab support.exe`, `Branch_Data.mdb`) · `Data\` (+ `Data\data_emp\`) · `Cache\` · `Images\` · `Fonts\` | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §3 tree] |
| `D:\Lab_data\` | The SQL Server data root (`Patients.mdf`, `Interface.mdf`, `VIDAS`), the attach scripts and `Attaching.sql` | VERIFIED [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1] |

> **STRONGLY SUPPORTED (from the source document):** the two-root split is why `Setup.bat` refers to `D:\Lab_data` while the CAB installs into `Program Files` — **two separate commands, not one path**. [P11 | analysis/V-CD-2019/12-install-media.md | §2.3 note]

### 8.5 Installer-media facts relevant to the function set

| Fact | Statement | Evidence |
|---|---|---|
| The CAB carries **no application code** | `WIN7\real lab system.CAB` and `WINXP\real lab system.CAB` each have **48 entries** and contain **no `.exe` of the application, no `.mdb`, no `.ini`, no `.dat`** — only the Jet 4 engine, the VB6 runtime, 19 ActiveX controls, type libraries/OLE and 5 fonts. | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §1 table] |
| Two divergent runtime builds ship on the media | The CAB's `msvbvm60.dll` (1,386,496 B, 2009) and `msado27.tlb` (98,304 B, 2010) are **newer** than the `OCX\` copies (1,384,479 B, 2004 / 81,920 B, 2008), while the `OCX\` copies of `MSCOMM32.OCX` and `MSFLXGRD.OCX` are **newer** than the CAB's. **All 12 Jet 4 engine files differ between the two targets** (16 of 48 differ in total; 32 are byte-identical). | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §4 + §4.1] |
| The install is therefore **non-deterministic** | `Setup.bat` copies `OCX\` to the install root **before** running the CAB, so the final state of each component depends on copy order — there is **no single source per component**. | VERIFIED (source document's own assessment) [P11 \| analysis/V-CD-2019/12-install-media.md \| §4.1 note] |
| Five large Microsoft installers are **missing** from the shipped tree | `SQLEXPR.EXE`, `WI-KB893803-v2-x86.exe`, `msxml6_x86.msi`, `dotnetfx.exe`, `mysql-connector-odbc-3.51.30-win32.msi` — 28 of the 39 CAB files are present and verified. | VERIFIED [P11 \| analysis/V-CD-2019/12-install-media.md \| §7 table] |

---

## 9. Count reconciliation

### 9.1 The counting method

Every function/function-group in this document was counted **once**, at the level of the smallest unit the evidence identifies as a distinct capability or callable object. Six layer groups were counted — Layer B contributes two disjoint groups, code objects and DataReports — and the layers are **disjoint** (no object appears in two layers) except where explicitly noted.

| Layer | What is counted | Unit of count | Count | Basis |
|---|---|---|---:|---|
| **A** | Documented CHM capabilities | One per CHM topic group listed in the V2 capabilities table | **15** | CAP-01..CAP-15 [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 table] |
| **B1** | VB6 code objects introduced by this build (forms, modules, classes) | One per entry of the upstream capabilities document's §2 table whose type is not `datareport` | **20** | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §2 table] × [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| type field] |
| **B2** | DataReports introduced by this build | One per entry of the upstream capabilities document's §3 table | **21** | [P11 \| analysis/V-CD-2019/03-capabilities.md \| §3 table] |
| **C** | Vendor-catalogue capability rows | One per numbered row in the `RLS_Learn.pdf` catalogue (§2.1–§2.7) | **57** | [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.1–§2.7] |
| **D** | Printing / PDF output functions | One per printing function defined in §7.2 (PF-01..PF-11) | **11** | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §3–§5] [P11 \| بعد الدفعة الحادية عشر/pdf-print-stack.md \| §2.2–§2.5] |
| **E** | Installer / setup functions | One per installer/setup function defined in §8.2 (IF-01..IF-12) | **12** | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §1–§6] [P11 \| analysis/V-CD-2019/12-install-media.md \| §2–§8] |

### 9.2 Totals

| Total | Definition | Count |
|---|---|---:|
| **136** | **All function/capability specification blocks in this document** (A + B1 + B2 + C + D + E = 15 + 20 + 21 + 57 + 11 + 12) | **136** |
| **56** | **Application** functions (A + B1 + B2 = 15 + 20 + 21) | **56** |
| 57 | Vendor-catalogue capability rows | 57 |
| 23 | Printing/PDF + installer/setup functions (D + E = 11 + 12) | 23 |
| **21** | **Vendor-catalogue capability groups** — the 57 rows of Layer C collapsed into 21 functional groups (see §9.4) | **21** |
| 23 | V2 feature domains enumerated in §6 | 23 |
| 210 | V2 VB6 objects in the binary (132 form + 66 datareport + 9 module + 3 class) | 210 |
| 8,026 | V2 VB6 procedures across those objects (as reported by the `objects.json` stats block; the `Methods` column of §1.3 sums to 8,038 — see the counting note under §1.3) | 8,026 |

### 9.3 Ambiguities and how each was resolved

| # | Ambiguity | Resolution |
|---|---|---|
| 1 | The upstream V2 capabilities document labels its object table "41 كائنًا جديدًا" but the table lists only **20** rows; the other 21 are in the DataReport table. | Resolved against the object table itself: the 20 code objects of §1.2 B.1 plus the 21 DataReports of §1.2 B.2 are **20 + 21 = 41**, with no overlap and no gap, and every one of the 41 appears in the 210-object table of §1.3 (verified by name and by procedure count). |
| 2 | The catalogue is to be presented as "**the 21 vendor-catalogue capability groups**", but the catalogue itself enumerates **57 numbered/listed rows** across 7 modules and summarises itself as "~60 in 7 modules". | **All 57 rows are specified individually** (§4.1–§4.7) — no subset was selected — and they are additionally **collapsed into exactly 21 functional groups** (§9.4) to satisfy the group reading. The discrepancy between 57 and "~60" in the source is stated, not silently resolved. |
| 3 | Do the Layer-D and Layer-E functions double-count Layer-B objects (e.g. `reportsetup`, `printerselect`)? | **Yes, deliberately**, and the overlap is stated: PF-01/PF-02 are the *printing functions* built on the `reportsetup`/`reportsetup2` objects, and PF-03 is the printing function implemented by the `printerselect` module. The counting is by **function**, not by object; the object-level inventory in §1.3 is the authoritative non-duplicating list of the 210 objects. |
| 4 | The CHM manual bundled with this build documents CAP-01..CAP-15 but documents none of the 41 objects introduced by this build — how are both presented? | They are presented separately and without overlap: §2 specifies the **15 documented capabilities** and §3 specifies the **41 objects the CHM manual does not document**. §6 adds the V2 domains that belong to neither set (settings, licensing, engine portability, print stack). [P11 \| analysis/V-CD-2019/03-capabilities.md \| §1 preamble] |
| 5 | Some inventory figures are stated in more than one artefact. | The **V2-primary** artefact is cited in every case — the V2 vendor catalogue (`analysis/V-CD-2019/09-vendor-capability-catalogue.md`) and the Stage-9 report — e.g. `normalrange` = 852 ranges, `testtable` = 609 tests, `comments` = 12 rows, `subgrouptable` = 46 rows, `antibiotic` = 38 rows × 25 columns, `antibio` = 96 rows. For the configuration layer the V2-primary artefacts are the 2019 payload report (`analysis/V-CD-2019/11-deployment-payload-2019.md`) — `Data\*.ini` = 223 report profiles, `Cache\*.rtf` = 29 method sheets — and `analysis/BATCH-07/ini-key-delta.csv`, which decides which per-profile value the V2 payload carries; the INI catalogue itself is cited for structure only. |
| 6 | Procedure-level detail (names, parameters, bodies) is unavailable. | `objects.json` reports `method_entries_read: 1268`, `unique_entries: 0`, `methods_without_address: 1268` — procedure addresses and names were not recoverable. **Procedure counts are reliable; procedure signatures and bodies are NOT RECOVERABLE** and are marked as such wherever a spec would otherwise have stated them. [P11 \| analysis/BATCH-04/vb6/v1605/objects.json \| stats block] [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-23] |
| 7 | DataReport designer layouts. | **NOT RECOVERABLE** — the tool cannot extract DataReport designs from the binary; only the object identity, type and bound data are evidenced. Stated per-report in §3.2. [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-24] |
| 8 | Control-level properties (Text/Caption of individual controls). | Not recoverable on Linux without COM; the control **counts** and form **geometry** are recovered and are used in §1.2 / §3.1. [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-06] |

### 9.4 The 21 vendor-catalogue capability groups

| Group | Name | Catalogue rows covered |
|---:|---|---|
| G01 | Patient registration, pricing and account settlement | 1-1, 1-2, 1-3 |
| G02 | Patient record amendment and case follow-up | 1-4, 1-11 |
| G03 | Result entry, combined reporting and blank reporting | 1-5, 1-6, 1-7 |
| G04 | Farm result entry and farm reporting | 1-8 |
| G05 | Patient search, visit history and medical history | 1-9, 1-10, 1-13 |
| G06 | NATIGH.COM / SMS electronic result delivery | 1-12, 1-12a, 1-12b |
| G07 | Work sheet / work-order production | 2-1, 2-2 |
| G08 | Test master data and test pricing | 3-1, 3-2 |
| G09 | Reference-range management | 3-3 |
| G10 | Price-list management and price-list printing | 3-4, 3-5 |
| G11 | Laboratory-performance statistics and monitoring | 4-1, 4-2, 4-3, 4-4, 4-5 |
| G12 | Laboratory stocktaking and accounting | 4-6 |
| G13 | Period income stocktake | 5-1 |
| G14 | Branch stocktake (branch system) | 5-2 |
| G15 | Referring-doctor / referral-entity stocktake | 5-3 |
| G16 | Out-referred-sample stocktake and account clearing | 5-4, 5-5 |
| G17 | Base system settings | 6-1 |
| G18 | Report settings — margins, paper size, header/footer, colours, printers | 6-2, 6-3, 6-4, 6-5, 6-6, 6-7 |
| G19 | Default account type, receipt/connection settings, background settings | 7-7, 8-7, 9-7 |
| G20 | Sample separation and withdrawal | catalogue §2.6 final row |
| G21 | Result-service accounts, users & permissions, attendance, master data, out-referral, header/footer colours | catalogue §2.7, all 13 rows |

**Check:** 15 + 2 + 5 + 6 + 5 + 11 + 13 = **57 rows** distributed across **21 groups**. ✓

### 9.5 Evidence-classification profile of this document

| Class | Where it dominates |
|---|---|
| **VERIFIED** | The 210-object inventory and all method counts; the 41-object set introduced by this build; every table and column name; every INI key; every literal string quoted; every manual rule in CAP-01..CAP-15; the printing stack and the installer scripts. |
| **INFERRED** | The IgE class-interpretation model; the custom-input-box RTL rationale; the crash-recovery role of `testtemp`; `Frmac`'s likely domain; `labmainTools` as the Database Maintenance launcher; `Reportmony11`'s single procedure being a computed-column routine. Each inference is labelled at the point of use. |
| **UNVERIFIED** | The upstream documents' own assessments that could not be independently re-derived here — e.g. the "installation is non-deterministic" conclusion (supported by two verified byte-level facts but not re-run as an install) and the "Visual FoxPro 6.0 is the likely origin of VIDAS" hypothesis. |
| **NOT DOCUMENTED** | The majority of behavioural fields for the 20 new code objects, the entire behaviour of `Frmac`, `otherfun`, `mInputbox`, `aaaClass`, `BiosData`, and all DataReport internals. |
| **NOT RECOVERABLE** | Procedure names/signatures/bodies (all 210 objects); DataReport designer layouts (all 66 datareports); control-level text/caption properties; the meaning of the acronym "LBC"; the FMF analyte list; the full PCR/urine-auto analyte lists; the internal SQL of the backup routine. |

### 9.6 Open functional questions carried from the V2 evidence

| ID | Question | Where it bites in this document | Evidence |
|---|---|---|---|
| V-01 | What are `Attaching.sql` and `Attach_database.bat`? | IF-06 (not present in the shipped tree) | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-01] |
| V-02 | What is the `win32_processor` table and why is it created? | IF-03 (licence fingerprint) — **INFERRED**, not proven | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-02] |
| V-03 | What is the `loger` (log) table? | CAP-01, G11, §6 row 4 — the table's *columns* are known, its *purpose* is not | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-03] |
| V-04 | Is `Patient_samples` sample tracking or a sample repository? | §3.1.8 | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-04] |
| V-05 | How are `grant13..grant17` + `useraccounts.gtype/hdd1/hdd2` used? | §6 row 14; §2.7 rows (c)(d) | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-05] |
| V-06 | What is the role of `samples` / `reportview` / `mylabsetting` in the schema? | §6 rows 13, 15, 16 | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-06] |
| V-07 | What does "LBC" mean? | §3.1.9, §3.2 (`resultLBC`) | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-07] |
| V-08 | Does `loger` record HIPAA/operational events? | CAP-01, G11 | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-08] |
| V-09 | What is the difference between the SQL `Patients` table and the Jet `patientinfo` table? | CAP-01, CAP-02 (the `patients` table is the **staff work log**) | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-09] |
| V-10 | What are the new `Insulin` and `antibio` tables? | §6 rows 6, 20 (`antibio` = 96 rows; `insulin` = 23 SQL statements) | [P11 \| analysis/V-CD-2019/07-open-questions.md \| V-10] |

---

## Appendix A — Source provenance

### A.1 V2-primary sources read in full (P11 tree)

| Path | Role in this document |
|---|---|
| `analysis/V-CD-2019/03-capabilities.md` | CAP-01..CAP-15; the 20 new code objects; the 21 new DataReports; the top-15 expanded objects |
| `analysis/V-CD-2019/09-vendor-capability-catalogue.md` | The 7-module vendor catalogue; the 57 capability rows; the extraction constraints |
| `analysis/V-CD-2019/00-baseline-summary.md` | The new-object-by-domain table (23 domains); the decisive numbers (210 / 8,026 / 132 / 66 / 9 / 3) |
| `analysis/V-CD-2019/04-feature-delta.md` | The 17 new tables; the `Branch_Data.mdb` narrowing |
| `analysis/V-CD-2019/07-open-questions.md` | V-01..V-10 |
| `analysis/V-CD-2019/02-schema.md` | 12 created tables; 228 added columns; 14 type changes; the 117 SQL-referenced tables |
| `analysis/V-CD-2019/13-pdf-print-architecture.md` | The print path; the 6 printer roles; the quality controls; the PDF output folders |
| `analysis/V-CD-2019/12-install-media.md` | `SETUP.LST`; the CAB contents; the two-target divergence; the missing Microsoft installers |
| `analysis/V-CD-2019/08-deployment-installer.md` | The installer's object structure; the engine choice; the licence model; the 16 `cmd.exe` invocations; the master/reception architecture |
| `analysis/V-CD-2019/05-deployment.md` | The 7 `Setup*.bat` scripts; the 3 engines; the `sa`/`12345678` install-time credential |
| `analysis/V-CD-2019/10-training-video.md` | The screen-by-screen UI inventory; the result-grid ↔ `patienttest` field mapping; the statistics screen; the two work-sheet layouts; the report-settings window |
| `analysis/BATCH-04/help_v1605/help-manual-ar.md` | The 15 CHM topics — every documented rule and every keyboard shortcut |
| `analysis/BATCH-04/help_v1605/help-topics.csv` | Topic/character/image index |
| `analysis/BATCH-04/help_v1605/capability-crossref.md` | The capability cross-reference for this build |
| `analysis/BATCH-04/vb6/v1605/objects.json` | The authoritative 210-object table with method counts |
| `analysis/BATCH-04/vb6/v1605/forms-blob.txt` | Control counts and geometry for 131 forms |
| `analysis/BATCH-04/vb6/v1605/objects-full.txt` | The object table in text form (cross-check) |
| `analysis/BATCH-04/sql_v1605/tables.csv` | The 117 SQL-referenced tables with statement counts and sample statements |
| `analysis/BATCH-04/schema/created-tables.csv` | The exact column list of each DDL-created table |
| `analysis/BATCH-04/schema/added-columns.csv` | The 228 added columns with types |
| `analysis/BATCH-04/schema/column-evolution.csv` | Column-type evolution |
| `analysis/BATCH-02/ini/test-catalogue.csv` | The catalogue of the shipped payload's `Data\*.ini` report profiles (categories 100–458+) — **structure only** (the profile set and the key names); a per-profile *value* is a V2 value only where the V2 template key delta records no change for it. |
| `analysis/BATCH-02/ini/printer-settings.csv` | The printer↔category map over those same profiles, incl. `SEMEN5`, `URINEauto`, `FMF`, `Helicobacter` — the category set, not the per-profile printer names. |
| `analysis/BATCH-02/rtf/test-library.md` | The 29-document test-description library and its critical-level thresholds; the V2 payload ships these 29 `Cache\*.rtf` files byte-identically (EV-ANA-051). |
| `analysis/BATCH-02/rtf/report-structure.md` | The 29 RTF report templates and the report anatomy — likewise byte-identical in the V2 payload (EV-ANA-051). |
| `analysis/BATCH-07/ini-key-delta.csv` | The V2 template key delta for `Data\*.ini` — the authority for which per-profile values the V2 payload actually carries. |
| `analysis/V-CD-2019/11-deployment-payload-2019.md` | The 2019 payload file inventory: `Data\*.ini` = 223 report profiles, `Cache\*.rtf` = 29 method sheets, and the `bin\` payload file set. |
| `reports/Stage-3-V-CD-2019-Baseline-Report.md` | §4 embedded-DDL schema evolution; §5 deployment; §6 capabilities; §7 transport tool |
| `reports/Stage-9-V-CD-2019-Final-Comprehensive-Report.md` | §8.1–§8.3 extracted replacement requirements (architecture A-01..A-08, security S-01..S-10, operational O-01..O-05) |
| `10-Issues/Open-Issues-and-Limitations.md` | ISS-06, ISS-12, ISS-23, ISS-24, ISS-33, ISS-34, ISS-35, ISS-36 |
| `بعد الدفعة الحادية عشر/pdf-print-stack.md` (P11 extract folder) | The PDF/print stack detail, Bullzip contents, signing, licensing, install-order defect |

### A.2 Additional patch-level sources used for facts first published at an earlier stage

| Patch | File | Fact taken |
|---|---|---|
| P04 | `03-capabilities.md` (byte-identical to the P11 copy) | The CAP-01..CAP-15 table and the new-object table, as first published at Stage 3 |
| P04 | `Stage-3-V-CD-2019-Baseline-Report.md` §3–§4 | The quantified object/procedure counts and the embedded-DDL schema-evolution model |
| P05 | `Stage-4-V-CD-2019-Deployment-Report.md` §3 | `RL_SETUP.exe` identity (57 objects / 599 procedures) and the installer's step families |
| P06 | `03-capabilities.md` · `09-vendor-capability-catalogue.md` (byte-identical to the P11 copies) | The catalogue as first published with the learning manual |
| P10 | `12-install-media.md` | The `SETUP.LST` deployment spec and the CAB/WIN7-vs-WINXP divergence, as first published at Stage 8 |
| P11 | `13-pdf-print-architecture.md` · `pdf-print-stack.md` · `Stage-9-…-Final-Comprehensive-Report.md` §8 | The print/PDF architecture and the extracted replacement requirements |

> **Note on `بعد الدفعة العاشرة/12-install-media.md` vs the P11 nested copy:** the two differ only in the precision of the WIN7/WINXP divergence paragraph (the P11 copy adds the per-file Jet-engine breakdown and the `MSCOMCTL.OCX` case-sensitivity note). The P11 copy is cited as the more precise form; the P10 marker is used for the facts that are identical in both. [P10 | 12-install-media.md | §4] [P11 | analysis/V-CD-2019/12-install-media.md | §4.1]

## Provenance and method

This deliverable was produced by restructuring the source findings file `02_functional_findings.md` — the analysis-stage extraction of the RefLab V2 evidence archive — into specification form, preserving its identifiers, tables, rules, provenance markers and evidence classes. The evidence roots are the patch deliverable trees P04..P11: principally `analysis/BATCH-04/` (VB6 object table, forms blob, SQL/table extraction, schema DDL diffs and the CHM manual text), `analysis/BATCH-02/` (the catalogue of the shipped payload's INI report-profile and printer-setting templates and of its RTF method sheets, cited for structure only — catalogue-level counts are re-based to the V2-primary artefacts named in §9.3), `analysis/V-CD-2019/` (capabilities, schema, baseline summary, vendor capability catalogue, deployment, install media, PDF/print architecture and the training-video analysis) and the `reports/Stage-3…` / `reports/Stage-9…` reports; every claim carries a marker of the form `[Pxx | path | anchor]` naming the patch and the path of the file relative to that patch's deliverable tree. The evidence classes used are exactly **VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED** and **NOT RECOVERABLE** as defined in §0.2, each stated at the point of use, and no gap has been closed with a conventional software-engineering assumption. The inventory figures quoted are counted from this document's own tables: 15 CAP rows (§1.1), 20 + 21 Layer-B rows (§1.2), 210 Layer-C object rows summing to 132 forms + 66 datareports + 9 modules + 3 classes (§1.3), 57 vendor-catalogue rows across the seven module tables of §4 (15 + 2 + 5 + 6 + 5 + 11 + 13), 11 printing-function rows (§7.2), 12 installer-function rows (§8.2), 21 catalogue-group rows (§9.4) and 23 feature-domain rows (§6), giving 136 function/capability specification blocks (15 + 20 + 21 + 57 + 11 + 12). Two arithmetic checks are reported where the source and its own tables diverge: the Layer-C `Methods` column sums to 8,038 against the 8,026 procedures reported by the `objects.json` stats block, and the §6 embedded-DDL row names 14 tables against its own stated 12 — both are reproduced as found rather than resolved.

---

**End of document — RefLab V2 functional specification.** 136 function/capability specification blocks; 210 V2 VB6 objects enumerated; 8,026 procedures accounted for; every substantive claim cited to a P04/P05/P06/P10/P11 source with its section or table row.
