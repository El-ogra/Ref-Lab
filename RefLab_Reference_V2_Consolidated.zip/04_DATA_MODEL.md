# RefLab Version 2 — Data Model Specification

**Target:** RefLab Version 2 (V2) = **RealLab V-CD-2019**, the shipped executable `real lab system.exe` **FileVersion 1.605** (76,292,096 B, `Description: RLS 1.605`, `CompanyName: RealLab`, PE32 / linker 6.0, PE build stamp `1595435962` = 2020-07-22 16:39:22 UTC, SHA-256 `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0`), deployed under `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`). [P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | version_info + "pe"."timestamp"] [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 1]

This document specifies the complete, evidenced data model of RefLab V2: the table inventory, the column-level type/width/nullability specifications, the key and constraint situation, the relationships between tables, the semantics of the identifiers that carry the model, the naming traps, and the schema ambiguities that remain open.

---

## 0. Evidence base and method

### 0.1 The three V2 schema sources

The V2 schema was established from three independent sources mined out of the evidence archive and cross-checked against one another:

| Source | What it is | Marker used in citations |
|---|---|---|
| `analysis/BATCH-04/schema/ddl-all.txt` | The **268 embedded DDL literals** in the v1.605 binary's string pool (**27 `CREATE TABLE`** + **241 `ALTER TABLE`**) — the application's own runtime schema-application script, i.e. the statements the binary executes against the live store | `[P11 \| analysis/BATCH-04/schema/ddl-all.txt \| …]` |
| `analysis/BATCH-04/sql_v1605/*` | The **1,797 SQL statements** extracted from the same binary, classified into **117 SQL-referenced table names** and a qualified-column frequency list | `[P11 \| analysis/BATCH-04/sql_v1605/… \| …]` |
| `analysis/BATCH-07/db/v2019-Patients.mdb.sql` | `mdb-schema` dump of the **2019-shipped `RL_CD2019Access\bin\Patients.mdb`** (2,682,880 B) — the authoritative physical V2 table list | `[P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| …]` |

Supporting evidence used for cross-checking and for per-table detail: `analysis/BATCH-04/schema/created-tables.csv`, `analysis/BATCH-04/schema/added-columns.csv`, `analysis/BATCH-04/schema/column-evolution.csv`; `analysis/BATCH-07/migration-proof.md` and `migration-proof.json` (the DDL↔shipped-schema reconciliation report); `analysis/BATCH-02/db/Branch_Data/schema.sql` (the schema dump of the V2-shipped `bin\Branch_Data.mdb` template); `analysis/BATCH-04/vb6/v1605/objects.json`; `analysis/CUMULATIVE/cumulative-schema.csv`; `analysis/CUMULATIVE/02-data-model.md`; `analysis/V-CD-2019/02-schema.md`, `00-baseline-summary.md`, `08-deployment-installer.md`, `09-vendor-capability-catalogue.md`, `11-deployment-payload-2019.md`; `analysis/BATCH-04/help_v1605/help-manual-ar.md` (the V2 CHM manual); `10-Issues/Open-Issues-and-Limitations.md`; `11-Evidence/Evidence-Register.md`.

### 0.2 Citation convention

Every substantive claim ends with a provenance marker of the form `[PATCH | file | anchor]`, where `PATCH` is the evidence patch marker (`[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`), `file` is the path of the evidence file relative to that patch's deliverable tree, and `anchor` is a real section heading, table row, literal statement text or virtual address (VA) actually read from that file. No line numbers, page numbers or file names are invented. Where an anchor is a virtual address, it is given as `VA xxxxxx`. Two anchors in the source evidence are recorded only as *prefix classes* rather than single addresses (`VA 8A6F16-style`, `VA 6B1Bxx-class`); they are reproduced as such and are approximate by construction.

### 0.3 Evidence classification

- **VERIFIED** — directly read from a V2 artefact (shipped schema dump, embedded DDL, extracted SQL, or the 2019 CD database).
- **INFERRED** — derived by a stated, reproducible rule from VERIFIED evidence.
- **UNVERIFIED** — asserted by an evidence file but not independently corroborated, or contradicted (see §9).
- **NOT DOCUMENTED** — the artefact or property exists in the product but no preserved evidence describes it.
- **NOT RECOVERABLE** — the artefact exists in the product but no preserved evidence reveals it.

**Documentation-only identifiers.** Identifiers prefixed `ISS-` (open-issue register) and `EV-ANA-` (evidence register) are **documentation-only reference numbers created by the analysis effort**. They are not system identifiers, not table or column names, and not runtime values; they are cited only so that a reader can locate the originating observation in the archive.

### 0.4 Counting method and known counting ambiguities

All inventory figures in this document were re-counted row-by-row against the source findings tables rather than copied. The counting methods are stated next to each figure in §2.1, §2.2, §4.23, §5.4 and §6.1. Three ambiguities are inherent to the evidence and are flagged wherever they bear on a quoted number:

1. **Tables created by embedded DDL vs tables present in the shipped database are different populations.** The binary's embedded DDL names **14 distinct tables**; the shipped 2019 `Patients.mdb` contains **103 tables**; the SQL corpus references **117 distinct table-name tokens**. No two of these numbers is a subset count of the other, and §2.3 exists precisely to show why: the 117-token list mixes real table names with SQL alias artefacts, and the 103-table payload contains tables that the SQL corpus never names.
2. **The published "16 absent tables" figure is an enumeration, not a subtraction.** 117 − 103 = 14, not 16; §2.3's own enumeration yields 16 names, of which 6 denote real tables and 10 are alias/artefact tokens. See §9.14.
3. **Profile-table counts depend on whether `cultureanti` is counted.** The §4.23 enumeration yields 51 clinical profile tables + 7 structural tables = 58 tables carrying both `patientid` and `requestdate`; `cultureanti` (12 columns, carries `patientid`) is a further candidate profile table that the enumeration omits. See §4.23 and §9.15.

---

## 1. Database topology (V2)

V2 supports **three database engines**; the application ships Jet 4 (Access 2000) `.mdb` files and can be pointed at SQL Server Express 2005 or MySQL. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §2 — the "supported database engines" section]

| DB / file | Engine | Role in V2 | Evidence |
|---|---|---|---|
| `RL_CD2019Access\bin\Patients.mdb` (2,682,880 B) | Jet 4 | **Live patient + test store.** 103 tables | [P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| 103 × `CREATE TABLE`] · [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-045] |
| `RL_CD2019Access\bin\Patients_backup.mdb` (2,146,304 B) | Jet 4 | **Backup copy shipped on the CD.** Not the live store; neither its schema nor any row count or cell value taken from it is used as V2 evidence anywhere in this document | [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6 `bin\` table — the `Patients_backup.mdb` row] |
| `RL_CD2019Access\bin\data.mdb` (249,856 B) | Jet 4 | **System data**: `history`, `patientinfo` (3-col projection), `wasl` (6-col projection). 3 tables / 34 columns | [P07 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| full file] |
| `RL_CD2019Access\bin\Branch_Data.mdb` (970,752 B) | Jet 4 | **Branch schema template** shipped with the V2 payload: 49 tables / 969 columns / **0 rows** (a schema-only scaffold) | [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 row 10 — "49 جدولًا، 0 صفوف"] · [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §1 `Branch_Data.mdb` (bin) row] · [P11 \| analysis/BATCH-02/db/Branch_Data/schema.sql \| `CREATE TABLE` field lines] |
| `RL_CD2019Access\System\Branch_Data.mdb` (966,656 B) | Jet 4 | **New** branch template in `System\`; 49 tables / 969 columns / 0 rows, but `patientinfo.moreinfo` widened Text(22)→Memo(255) and `patienttest` **lost 9 columns** (`normalrang` `lowlimit` `highlimit` `nolowexe` `nohighexe` `testabrev` `testname` `testunit` `historyname`) with `resultt..4` narrowed 50→35. **Its schema dump is NOT preserved in the archive** | [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-033] |
| SQL Server `patients` catalog | SQL Server Express 2005 | Alternative live store (`D:\Lab_data\Patients.mdf`) | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 — the database section] |
| SQL Server `Interface` catalog | SQL Server Express 2005 | Interface DB (`D:\Lab_data\Interface.mdf`) | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 — the database section] |
| `VIDAS` catalog | SQL Server | Third system, attach script only, no schema recovered | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4 — the database section] |

**VERIFIED FACT (engine selection):** the installer lets the operator pick the engine and creates **two** SQL Server catalogs, `patients` + `Interface`, with connection strings `Provider=SQLOLEDB.1;Password=12345678;Persist Security Info=True;User ID=sa;Initial Catalog=patients;…` and `…Initial Catalog=Interface;…`. [P11 | analysis/V-CD-2019/08-deployment-installer.md | §4]

---

## 2. Table inventory

### 2.1 Totals and counting method

| Population | Count | Counting method | Evidence |
|---|---:|---|---|
| **V2 shipped `Patients.mdb` (2019)** | **103 tables** | Count of `CREATE TABLE` statements in the preserved `mdb-schema` dump; re-counted here from the §2.2 inventory table = **103 rows, 103 distinct names, no case-variant duplicates** | [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| 103 × `CREATE TABLE`] |
| V2 shipped `Patients.mdb` — **columns** | **1,682** | Count of bracketed field-definition lines in the same dump; **re-counted here as the sum of the 103 per-table column figures in §2.2 = 1,682 exactly** — conflicts with the 1,617 published figure; see §9.1 | [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| field lines] |
| V2 shipped `data.mdb` | **3 tables / 34 columns** | Same method on `v2019-data.mdb.sql`: `history` 25 + `patientinfo` 3 + `wasl` 6 = 34 | [P07 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| full file] |
| V2 `Branch_Data.mdb` (bin copy, on the 2019 CD) | **49 tables / 969 columns / 0 rows** | `CREATE TABLE` field lines of the shipped template's schema dump; **re-counted here from the §2.4 listing = 49 named rows summing to 969 column cells**; the "0 rows" figure is the V2 baseline's own statement about the shipped template | [P11 \| analysis/BATCH-02/db/Branch_Data/schema.sql \| `CREATE TABLE` field lines] · [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 row 10] |
| SQL-referenced table names in the v1.605 binary | **117** | Distinct table tokens across the 1,797 extracted SQL statements | [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| 117 rows] |
| Embedded DDL statements | **268** = **27 `CREATE TABLE`** + **241 `ALTER TABLE`** (of the 241: **228** column `ADD`, **13** `ALTER COLUMN` type change) | Literal parse of `ddl-all.txt`; 27 + 241 = 268 and 228 + 13 = 241 both check | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| header line "268 statements"] |
| Distinct table names created by embedded DDL | **14** (not 12 — see §3.1) | Distinct `Create Table <name>` names in `ddl-all.txt`; the 14 names are enumerated in §3.1 | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| 14 `Create Table` literals] |
| Tables **not** present in the 2019 Access payload but referenced by V2 SQL | **16** | Enumeration of §2.3 (10 rows, 16 names): 6 real tables + 10 alias/artefact tokens. The naive subtraction 117 − 103 = 14 does **not** reproduce this figure — see §9.14 | [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| …] vs [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| …] |
| Tables carrying both `patientid` and `requestdate` | **58** (51 profile + 7 structural) | Enumeration of the §4.23 tables; `cultureanti` is a further candidate that the enumeration omits — see §4.23 and §9.15 | [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE field lists] |

**Row counts for the live 2019 `Patients.mdb`: NOT RECOVERABLE.** BATCH-07 preserved only `mdb-schema` output for the 2019 payload — no `mdb-export` was kept, so per-table row counts of the live V2 store were never captured. [P07-08 | analysis/BATCH-07/db/ | directory listing: `branding/`, `db/*.sql`, `ini-diff-summary.*`, `migration-proof.*`] The shipped schema dump carries structure only — no row data — and no row-level extract of the live V2 store exists anywhere in the evidence, so **no per-table row count of the live V2 `Patients.mdb` can be stated**. The catalogue-level counts that a V2-primary source does state are the test-catalogue size (§4.4) and the reference-range count (§4.5).

**CAUTION — the `rows_patients_mdb` column of `cumulative-schema.csv` does not describe the shipped V2 `Patients.mdb` and must not be quoted as a V2 figure.** Class: **UNVERIFIED** for V2. [P11 | analysis/CUMULATIVE/cumulative-schema.csv | `rows_patients_mdb` column]

**CAUTION — `columns_branch_data_mdb` in `cumulative-schema.csv` is a broken constant.** It is **7 or 8 for every row and wrong for all 49 tables** that actually exist in `Branch_Data.mdb` (e.g. it claims `ABO`=7 but `ABO` really has 8 columns; `BONEMAR`=7 vs 23; `CSFT`=7 vs 22; `patientinfo`=7 vs 33; `patienttest`=9 vs 44). Verified by re-parsing `analysis/BATCH-02/db/Branch_Data/schema.sql`. **Use the `Branch_Data` schema dump, not this column.** [P11 | analysis/CUMULATIVE/cumulative-schema.csv | `columns_branch_data_mdb` column] vs [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | `CREATE TABLE` field lines]

### 2.2 Complete V2 table inventory (2019 shipped `Patients.mdb`, 103 tables)

Column counts are from the 2019 payload dump. **DDL** = the table is created by an embedded `CREATE TABLE` in the v1.605 binary; the complete DDL-created set is the 14 tables of §3.1, of which the 11 marked here are present in this payload and `LBC`, `IgEallergy` and `FMF` are not. **In `data.mdb`?** is populated only where the same table name also exists in `RL_CD2019Access\bin\data.mdb` (see §7.7 for the differing widths). Role is taken from the SQL usage evidence unless marked otherwise.

| # | Table (exact name) | Cols | In `data.mdb`? | DDL-created? | Role | Primary evidence |
|---:|---|---:|---|---|---|---|
| 1 | `abbreviations` | 3 | | | Abbreviation dictionary (`abbid`/`abbre`/`mean`) | [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [abbreviations]] |
| 2 | `ABO` | 8 | | | Blood-group profile | [P07 \| … \| CREATE TABLE [ABO]] |
| 3 | `Abuse` | 12 | | | Drug-abuse screen profile | [P07 \| … \| CREATE TABLE [Abuse]] |
| 4 | `antibio` | 2 | | | Anti-symptom symbols + scientific names | [P07 \| … \| CREATE TABLE [antibio]] |
| 5 | `antibiotic` | 25 | | | Antibiotic catalogue (8 commercial names, 8 print flags, pregnancy/child flags) | [P07 \| … \| CREATE TABLE [antibiotic]] |
| 6 | `anyreport` | 26 | | | Free-text report body per test (`text1..text22`) | [P07 \| … \| CREATE TABLE [anyreport]] |
| 7 | `barcodes` | 2 | | | Barcode → id map | [P07 \| … \| CREATE TABLE [barcodes]] |
| 8 | `BILH` | 9 | | | Bilharzia profile | [P07 \| … \| CREATE TABLE [BILH]] |
| 9 | `BloodGases` | 10 | | | Blood-gas profile | [P07 \| … \| CREATE TABLE [BloodGases]] |
| 10 | `BONEMAR` | 23 | | | Bone-marrow profile (`T01..T20`) | [P07 \| … \| CREATE TABLE [BONEMAR]] |
| 11 | `cardiac` | 9 | | | Cardiac enzymes profile | [P07 \| … \| CREATE TABLE [cardiac]] |
| 12 | `CoagFactors` | 11 | | | Coagulation factors profile | [P07 \| … \| CREATE TABLE [CoagFactors]] |
| 13 | `comments` | 5 | | | Per-test comment library keyed by `testcode`/`subgroupcode` | [P07 \| … \| CREATE TABLE [comments]] |
| 14 | `constanttable` | 8 | | | **Clinical constants** (`constantdiscrp` = `PTCONS`, `CBCCONS`, `RATIOS`) | [P07 \| … \| CREATE TABLE [constanttable]] |
| 15 | `converts` | 6 | | | Unit-conversion factors | [P07 \| … \| CREATE TABLE [converts]] |
| 16 | `crossmat` | 84 | | | Cross-match profile (10 donors) | [P07 \| … \| CREATE TABLE [crossmat]] |
| 17 | `CSFT` | 24 | | | CSF profile | [P07 \| … \| CREATE TABLE [CSFT]] |
| 18 | `cultureanti` | 12 | | | Culture ↔ antibiotic susceptibility result | [P07 \| … \| CREATE TABLE [cultureanti]] |
| 19 | `cultures` | 35 | | | Culture profile (organism/condition/colony) | [P07 \| … \| CREATE TABLE [cultures]] |
| 20 | `culturesec` | 3 | | | Secondary-culture code list (`secabre`/`secname`) | [P07 \| … \| CREATE TABLE [culturesec]] |
| 21 | `customgrouptable` | 2 | | | Custom profile-group dictionary | [P07 \| … \| CREATE TABLE [customgrouptable]] |
| 22 | `customtesttable` | 5 | | | Custom profile → testcode + price | [P07 \| … \| CREATE TABLE [customtesttable]] |
| 23 | `daytip` | 2 | | | Daily tips (Arabic abbreviation text) | [P07 \| … \| CREATE TABLE [daytip]] |
| 24 | `Drugs` | 14 | | | Therapeutic-drug monitoring profile | [P07 \| … \| CREATE TABLE [Drugs]] |
| 25 | `Electrolytes` | 20 | | | Electrolytes profile | [P07 \| … \| CREATE TABLE [Electrolytes]] |
| 26 | `ESR` | 5 | | | ESR profile | [P07 \| … \| CREATE TABLE [ESR]] |
| 27 | `Fertlity` | 17 | | | Fertility hormones profile | [P07 \| … \| CREATE TABLE [Fertlity]] |
| 28 | `GLUCOSETOLERANCE` | 25 | | | GTT profile | [P07 \| … \| CREATE TABLE [GLUCOSETOLERANCE]] |
| 29 | `hba1c` | 5 | | **DDL** | HbA1c / eAG profile | [P07 \| … \| CREATE TABLE [hba1c]] |
| 30 | `Helicobacter` | 6 | | **DDL** | *H. pylori* profile (`hpigi` `hpigm` `hpag`) | [P07 \| … \| CREATE TABLE [Helicobacter]] |
| 31 | `hepatitis` | 20 | | | Hepatitis serology profile | [P07 \| … \| CREATE TABLE [hepatitis]] |
| 32 | `Hgbectrophoresis` | 8 | | | Hb electrophoresis profile | [P07 \| … \| CREATE TABLE [Hgbectrophoresis]] |
| 33 | `history` | 25 | **yes** | | **Dynamic 20-column history/report-layout table** (`selector`, `labid`, `column1..column20`, `printflag`, `noofcol`) | [P07 \| … \| CREATE TABLE [history]] · [P07 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| CREATE TABLE [history]] |
| 34 | `Immunoglobulin` | 10 | | | Immunoglobulin profile | [P07 \| … \| CREATE TABLE [Immunoglobulin]] |
| 35 | `IMMUNOLOGY` | 19 | | | Autoimmune profile | [P07 \| … \| CREATE TABLE [IMMUNOLOGY]] |
| 36 | `instrument` | 20 | | | Instrument (analyser) registry | [P07 \| … \| CREATE TABLE [instrument]] |
| 37 | `insulin` | 2 | | | Insulin type dictionary (`id`, `insulin`) — present in the 2019 payload, but **no embedded `CREATE`** | [P07 \| … \| CREATE TABLE [insulin]] |
| 38 | `iron` | 9 | | | Iron studies profile | [P07 \| … \| CREATE TABLE [iron]] |
| 39 | `Labbranch` | 2 | | | **Lab branch registry** (`branchid`, `branchname`) | [P07 \| … \| CREATE TABLE [Labbranch]] |
| 40 | `Lipids` | 11 | | | Lipid profile | [P07 \| … \| CREATE TABLE [Lipids]] |
| 41 | `liver` | 15 | | | Liver function profile | [P07 \| … \| CREATE TABLE [liver]] |
| 42 | `loggroup` | 2 | | | Result-work-group dictionary (`logid`, `logname`) | [P07 \| … \| CREATE TABLE [loggroup]] |
| 43 | `MyLabSetting` | 20 | | **DDL** | **Lab settings** (SMS gateway, sender numbers, schedule) — contains `accuntID`/`accuntpw` | [P07 \| … \| CREATE TABLE [MyLabSetting]] |
| 44 | `normalrange` | 18 | | | **Reference ranges** (`normalid`, `testcode`, `subgroupcode`, `sex`, age band, `lowlimit`/`highlimit`) | [P07 \| … \| CREATE TABLE [normalrange]] |
| 45 | `noteic` | 6 | | | Internal notes (`noteid`, `noteuser`, `notedate`, `thenote`) | [P07 \| … \| CREATE TABLE [noteic]] |
| 46 | `Pancreas` | 13 | | | Pancreas profile | [P07 \| … \| CREATE TABLE [Pancreas]] |
| 47 | `Paste Errors` | 6 | | | Junk table `Field0..Field5` (all Memo) — a **paste-error log by an unowned table name with a space** | [P07 \| … \| CREATE TABLE [Paste Errors]] |
| 48 | `patientinfo` | **39** | **yes** (3-col projection) | | **PATIENT MASTER** — one row per accession | [P07 \| … \| CREATE TABLE [patientinfo]] |
| 49 | `patients` | **33** | | | **OPERATOR / USER-ACCOUNT table** — *not* patients: `patientusid`, `patientusname`, `grant1..grant17`, shift times | [P07 \| … \| CREATE TABLE [patients]] |
| 50 | `patienttest` | **46** | | | **TEST ORDER / RESULT INDEX** — one row per ordered test | [P07 \| … \| CREATE TABLE [patienttest]] |
| 51 | `patienttestgroup` | 46 | | | Same shape as `patienttest` plus `maintestcode` — **profile-group ordering**; no embedded `CREATE` | [P07 \| … \| CREATE TABLE [patienttestgroup]] |
| 52 | `patienttotal` | 15 | | | Per-patient totals roll-up (`t01..t12`) | [P07 \| … \| CREATE TABLE [patienttotal]] |
| 53 | `payment` | 10 | | | Payments | [P07 \| … \| CREATE TABLE [payment]] |
| 54 | `phone` | 19 | | | Contact/address book | [P07 \| … \| CREATE TABLE [phone]] |
| 55 | `pictures` | 73 | | **DDL** | Patient pictures + 12 label pairs + 15 numeric + 15 numeric-text + 12 shape slots | [P07 \| … \| CREATE TABLE [pictures]] |
| 56 | `postcoitalt` | 17 | | | Post-coital test profile | [P07 \| … \| CREATE TABLE [postcoitalt]] |
| 57 | `pregnancy` | 6 | | | Pregnancy profile | [P07 \| … \| CREATE TABLE [pregnancy]] |
| 58 | `pricelist` | 4 | | | Price lists | [P07 \| … \| CREATE TABLE [pricelist]] |
| 59 | `pricemenu` | 1 | | | Distinct price-list names (menu) | [P07 \| … \| CREATE TABLE [pricemenu]] |
| 60 | `Proelectrophoresis` | 8 | | | Serum protein electrophoresis profile | [P07 \| … \| CREATE TABLE [Proelectrophoresis]] |
| 61 | `prostaticx` | 53 | | | Prostatic fluid profile | [P07 \| … \| CREATE TABLE [prostaticx]] |
| 62 | `pt` | 16 | | | Prothrombin-time profile | [P07 \| … \| CREATE TABLE [pt]] |
| 63 | `PTC` | 3 | | | **PT control curve** (time ↔ concentration) — `control`, `concent`, `ConstID` | [P07 \| … \| CREATE TABLE [PTC]] |
| 64 | `ratios` | 12 | | **DDL** | Calculated ratios (Ca/Cr, PT/Cr, Uric/Cr, Alb/Cr) | [P07 \| … \| CREATE TABLE [ratios]] |
| 65 | `reportview` | 42 | | | Report strip layout (`strip1..strip30`, `stripb1..stripb10`) | [P07 \| … \| CREATE TABLE [reportview]] |
| 66 | `sarfeda3` | 3 | | | Referral-fee discount list | [P07 \| … \| CREATE TABLE [sarfeda3]] |
| 67 | `seana` | 10 | | | Instrument maintenance/service record | [P07 \| … \| CREATE TABLE [seana]] |
| 68 | `semen` | 60 | | | Semen-analysis profile | [P07 \| … \| CREATE TABLE [semen]] |
| 69 | `sharekat` | 6 | | | "Sharek" (referral partner) master | [P07 \| … \| CREATE TABLE [sharekat]] |
| 70 | `sharekathesab` | 7 | | | "Sharek" account ledger (`saader`/`wareed` = debit/credit) | [P07 \| … \| CREATE TABLE [sharekathesab]] |
| 71 | `shopping` | 7 | | | Supply purchases | [P07 \| … \| CREATE TABLE [shopping]] |
| 72 | `smsgroups` | 3 | | **DDL** | SMS recipient groups | [P07 \| … \| CREATE TABLE [smsgroups]] |
| 73 | `smslist` | 6 | | **DDL** | SMS recipient phone list | [P07 \| … \| CREATE TABLE [smslist]] |
| 74 | `SMSSender` | 8 | | **DDL** | **Outbound SMS log** | [P07 \| … \| CREATE TABLE [SMSSender]] |
| 75 | `SMStemplate` | 2 | | **DDL** | SMS text templates | [P07 \| … \| CREATE TABLE [SMStemplate]] |
| 76 | `stone` | 19 | | | Stone-analysis profile | [P07 \| … \| CREATE TABLE [stone]] |
| 77 | `stool` | 61 | | | Stool profile (`t01..t58`) | [P07 \| … \| CREATE TABLE [stool]] |
| 78 | `subgrouptable` | 4 | | | **Profile (subgroup) catalogue** | [P07 \| … \| CREATE TABLE [subgrouptable]] |
| 79 | `Suprarenal` | 16 | | | Adrenal profile | [P07 \| … \| CREATE TABLE [Suprarenal]] |
| 80 | `tasgel` | 11 | | | Attendance/timesheet (`startwork`/`endwork`/overtime) | [P07 \| … \| CREATE TABLE [tasgel]] |
| 81 | `testlearn` | 3 | | | Test learning/education text | [P07 \| … \| CREATE TABLE [testlearn]] |
| 82 | `testname` | 8 | | | Test-name denormalised view (`groupcode`,`subgroupcode`,`arrangnum`,`testcode`) | [P07 \| … \| CREATE TABLE [testname]] |
| 83 | `testtable` | **38** | | | **TEST CATALOGUE** + prices + flags | [P07 \| … \| CREATE TABLE [testtable]] |
| 84 | `testunits` | 2 | | | Unit dictionary | [P07 \| … \| CREATE TABLE [testunits]] |
| 85 | `titless` | 3 | | | Titles dictionary | [P07 \| … \| CREATE TABLE [titless]] |
| 86 | `TORCH` | 13 | | | TORCH profile | [P07 \| … \| CREATE TABLE [TORCH]] |
| 87 | `trace` | 25 | | | Trace-elements profile (serum/urine pairs) | [P07 \| … \| CREATE TABLE [trace]] |
| 88 | `TUBERCULINT` | 6 | | | Tuberculin profile | [P07 \| … \| CREATE TABLE [TUBERCULINT]] |
| 89 | `urine` | 60 | | | Urine profile (`t01..t57`) | [P07 \| … \| CREATE TABLE [urine]] |
| 90 | `Vitamins` | 15 | | | Vitamins profile | [P07 \| … \| CREATE TABLE [Vitamins]] |
| 91 | `wasl` | 12 | **yes** (6-col projection) | | **Work-Sheet analysis list** + prices (`waslname`,`waslname2`,`testno`,`testprice`) | [P07 \| … \| CREATE TABLE [wasl]] · [P07 \| analysis/BATCH-07/db/v2019-data.mdb.sql \| CREATE TABLE [wasl]] |
| 92 | `widal` | 16 | | | Widal (1st gen) profile | [P07 \| … \| CREATE TABLE [widal]] |
| 93 | `widal2` | 26 | | **DDL** | Widal 2nd generation + Weil-Felix | [P07 \| … \| CREATE TABLE [widal2]] |
| 94 | `ZN` | 8 | | | Ziehl-Neelsen profile | [P07 \| … \| CREATE TABLE [ZN]] |
| 95 | `cbc` | 29 | | | CBC profile | [P07 \| … \| CREATE TABLE [cbc]] |
| 96 | `CRP` | 11 | | | CRP/serology profile | [P07 \| … \| CREATE TABLE [CRP]] |
| 97 | `Gehats` | 21 | | | **Referring entity** master (`gehahname`, commission `omola`, `khasm`) | [P07 \| … \| CREATE TABLE [Gehats]] |
| 98 | `hormones` | 16 | | | Thyroid/hormone profile | [P07 \| … \| CREATE TABLE [hormones]] |
| 99 | `kidney` | 15 | | | Renal profile | [P07 \| … \| CREATE TABLE [kidney]] |
| 100 | `renalfailure` | 11 | | | Renal-failure profile | [P07 \| … \| CREATE TABLE [renalfailure]] |
| 101 | `sugar` | 12 | | | Glucose profile | [P07 \| … \| CREATE TABLE [sugar]] |
| 102 | `testtemp` | 28 | | **DDL** | **Scratch table for in-progress test results** | [P07 \| … \| CREATE TABLE [testtemp]] |
| 103 | `Tumors` | 14 | | | Tumour-marker profile | [P07 \| … \| CREATE TABLE [Tumors]] |

### 2.3 Tables referenced by V2 SQL but **absent** from the 2019 Access payload (16)

Counting method: the table below enumerates **16 distinct names** in 10 rows. Six denote real tables; ten are SQL alias or truncated-token artefacts that the extractor classified as table names.

| Name | V2 SQL usage | Interpretation | Class |
|---|---|---|---|
| `useraccounts` | `select * FROM useraccounts where usersnum=` · `order by usersdr asc` · `where usersdr= '` | **SQL-Server-only operator table.** Columns evidenced: `usersnum`, `usersdr`; DDL adds `HDD1` Text(20), `HDD2` Text(20), `Gtype` Smallint — none applied in the Access payload | UNVERIFIED (Access DDL not applied) |
| `loger` | `SELECT * FROM loger where lognum=` · `where compname= ` · `SELECT username FROM loger where datein >= ` · `where username= ` · `Delete loger where datein >= ` | **SQL-Server-only attendance/event log.** Columns evidenced from predicates only: `lognum`, `compname`, `datein`, `username` | INFERRED (column set from WHERE clauses) |
| `samples` | `Select * from samples where patientid = '` · `Delete from samples where patientid= '` | **Patient sample tracking** (matches VB6 object `Patient_samples`) | INFERRED |
| `LBC` | `SELECT * FROM LBC where patientid= '` ×2 | DDL-created, **ABSENT** from the Access payload | VERIFIED (absence) |
| `IgEallergy` | `SELECT * FROM IgEallergy where patientid= '` | DDL-created, **ABSENT** from the Access payload | VERIFIED (absence) |
| `FMF` | `SELECT * FROM FMF where patientid= '` | DDL-created, **ABSENT** from the Access payload | VERIFIED (absence) |
| `patient`, `p`, `pa`, `patien`, `t` | e.g. `SELECT patienttest.resultt,patienttest.resultt1,… FROM patienttest …` | **SQL aliases, not tables.** The extractor mis-tokenised `AS <alias>` and `FROM (…)` sub-query aliases | VERIFIED (alias) |
| `immunolo`, `immunolog` | `SELECT Top 10 IMMUNOLOGY.requestdate, IMMUNOLOGY.ANA,…` | Truncated-prefix artefacts of the same `IMMUNOLOGY` query | VERIFIED (artefact) |
| `supr`, `supra` | `SELECT Top 10 Suprarenal.requestdate, Suprarenal.ACTH9AM,…` | Truncated-prefix artefacts of `Suprarenal` | VERIFIED (artefact) |
| `win32_processor` | `Select * from Win32_Processor` | **WMI system query**, not an application table | VERIFIED |

[P11 | analysis/BATCH-04/sql_v1605/tables.csv | rows `useraccounts`,`loger`,`samples`,`LBC`,`IgEallergy`,`FMF`,`patient`,`p`,`pa`,`patien`,`t`,`immunolo`,`immunolog`,`supr`,`supra`,`win32_processor` — `sample_statement` column] · [P07-08 | analysis/BATCH-07/migration-proof.md | §1 table of CREATE verification: `LBC` ABSENT, `IgEallergy` ABSENT, `FMF` ABSENT]

### 2.4 The `Branch_Data.mdb` profile template — 49 tables

The branch template that the V2 payload ships as `RL_CD2019Access\bin\Branch_Data.mdb` is a **schema-only scaffold (0 rows in every table)** carrying 46 of the per-profile result tables plus `patientinfo` and `patienttest` templates. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 10 — "49 جدولًا، 0 صفوف، مخطط مُعدَّل"] · [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | `CREATE TABLE` field lines per table]

Counting method: the listing below enumerates **49 named tables** in 17 physical rows (three tables per row except the last two rows, which carry two each), whose column cells sum to **969**. Note that the 49th table of the template — `cultureanti` — is **not** one of the 46 profile tables named in the source prose and is **not** listed in §4.23's profile enumeration; see §9.15.

| Table | Cols | Table | Cols | Table | Cols |
|---|---:|---|---:|---|---:|
| `ABO` | 8 | `hormones` | 16 | `stone` | 19 |
| `Abuse` | 10 | `Immunoglobulin` | 10 | `stool` | 58 |
| `BILH` | 9 | `IMMUNOLOGY` | 19 | `sugar` | 12 |
| `BloodGases` | 10 | `iron` | 9 | `Suprarenal` | 16 |
| `BONEMAR` | 23 | `kidney` | 14 | `TORCH` | 13 |
| `cardiac` | 9 | `Lipids` | 11 | `trace` | 25 |
| `cbc` | 20 | `liver` | 15 | `TUBERCULINT` | 6 |
| `crossmat` | 84 | `Pancreas` | 13 | `Tumors` | 14 |
| `CRP` | 11 | `patientinfo` | 33 | `urine` | 58 |
| `CSFT` | 22 | `patienttest` | 44 | `Vitamins` | 15 |
| `cultureanti` | 12 | `postcoitalt` | 17 | `widal` | 16 |
| `cultures` | 25 | `pregnancy` | 6 | `ZN` | 8 |
| `Electrolytes` | 20 | `Proelectrophoresis` | 8 | `CoagFactors` | 11 |
| `ESR` | 5 | `prostaticx` | 45 | `Drugs` | 14 |
| `Fertlity` | 17 | `pt` | 16 | `Hgbectrophoresis` | 8 |
| `GLUCOSETOLERANCE` | 25 | `renalfailure` | 11 |  |  |
| `hepatitis` | 20 | `semen` | 59 |  |  |

[P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | `CREATE TABLE` field lines per table]

The 2019 `System\Branch_Data.mdb` template differs (see §1): `patienttest` in the 2019 `System` template has **35** columns (9 fewer) and `resultt..4` are Text(35) instead of Text(50). [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-033]

### 2.5 Keys, auto-number columns and nullability declarations

**Declared auto-number (surrogate) columns.** The embedded DDL is the only place where an auto-number is introduced; each is declared `bigint IDENTITY(1,1) NOT NULL` in the T-SQL dialect and `AUTOINCREMENT(1, 1)` in the Jet dialect, and each lands in the shipped 2019 payload as a `Long Integer`:

| Table | Column | Declared as | Shipped Jet type | Evidence |
|---|---|---|---|---|
| `smsgroups` | `ID` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 6755EA / VA 67B7AE] · [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [smsgroups]] |
| `smslist` | `ID` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 6772BA / VA 67D4D6] |
| `SMStemplate` | `templatenum` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 6773DA / VA 67D5E2] |
| `SMSSender` | `SMSautonum` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 6774AE / VA 67D692] |
| `payment` | `paymentnum` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 677EC2 / VA 67D95E] |
| `PTC` | `ConstID` | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1, 1)` | `Long Integer` | [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 677FA6 / VA 67D816] |

**Nullability.** `NOT NULL` is Jet's actual constraint and appears in the shipped dump on: every `Boolean` flag column of `patienttest`, `patienttestgroup`, `testtemp`, `testtable`, `patients` (`patientad`, `patientus`, `grant1..grant17`, `showtip`, `breakyorn`), `antibiotic` (`anticomprint1..8`, `prgnancy`, `child`), `Gehats` (`flose`, `printorno`), `subgrouptable.deleteprotect`, `testtable` (`active`, `inotherlab`, `anyqus`, `deleteprotect`, `printwith`, `addorno`, `testorno`), `barcodes.barcode`, `Labbranch.branchname`, `loggroup.logname`, `PTC.control`, `PTC.concent`, `insulin.id`, `insulin.insulin`, `antibio.antisymbol`, and `customtesttable`'s two FK columns. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

**Nullability trap:** the shipped `Patients.mdb` declares `patientinfo.patientid` as `Text (13)` with **no `NOT NULL`**, whereas the `Branch_Data.mdb` branch template declares `patientinfo.patientid` as `Text (13) NOT NULL`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo]] vs [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [patientinfo]]

**Declared constraint objects.** The material cited for the shipped schema records field types, `NOT NULL` and `AUTOINCREMENT` declarations only. No `PRIMARY KEY`, `FOREIGN KEY`, `UNIQUE`, `CHECK` or `INDEX` clause is recorded for any table in that dump, and no such clause appears in the 268 embedded DDL literals. Whether the shipped `.mdb` files carry any such constraint objects is **NOT DOCUMENTED**; every "PK"/"FK" statement in §5 is therefore a derivation from column names, declared types and runtime SQL, not a read constraint. Class: **NOT DOCUMENTED**.

---

## 3. The DDL-created tables

### 3.1 How many are there really?

- The binary contains **27 `CREATE TABLE` literals** naming **14 distinct tables**: `FMF`, `Helicobacter`, `IgEallergy`, `LBC`, `MyLabSetting`, `SMSSender`, `SMStemplate`, `hba1c`, `pictures`, `ratios`, `smsgroups`, `smslist`, `testtemp`, `widal2`. [P11 | analysis/BATCH-04/schema/ddl-all.txt | 27 `Create Table` literals]
- The P11 schema document lists only **12** and omits `MyLabSetting` and `IgEallergy`. [P11 | analysis/V-CD-2019/02-schema.md | §1 الجداول المُنشأة (12)]
- Both `MyLabSetting` and `IgEallergy` are independently corroborated: `MyLabSetting` ships in the 2019 payload with 20 columns and is queried as `Select * from MyLabSetting WHERE LabID=100 ;`; `IgEallergy` is queried as `SELECT * FROM IgEallergy where patientid= '`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 68269A / VA 73C02C]

**Conclusion: 14 DDL-created tables; the published "12" under-counts by two.** Class: **VERIFIED** (the DDL literals), **UNVERIFIED** (the published count of 12).

Of the 14, **11 are present in the shipped 2019 `Patients.mdb`** (`hba1c`, `Helicobacter`, `MyLabSetting`, `pictures`, `ratios`, `smsgroups`, `smslist`, `SMSSender`, `SMStemplate`, `testtemp`, `widal2`) and **3 are absent** (`LBC`, `IgEallergy`, `FMF` — see §2.3). Counting method: set intersection of the 14 names of this section with the 103 names of §2.2 = 11; remainder = 3.

### 3.2 T-SQL vs Jet duality

The binary ships **two dialect variants** of every schema statement, because the product supports SQL Server and Access simultaneously. Types differ systematically:

| Concept | T-SQL variant | Jet (Access) variant |
|---|---|---|
| Auto-number | `bigint IDENTITY(1,1) NOT NULL` | `AUTOINCREMENT(1, 1)` |
| Long text | `varchar(MAX)` | `Memo` |
| Boolean | `Bit` | `YESNO` |
| Date | `smalldatetime` (in `CREATE`) / `DATETIME` | `DATETIME` |
| Unicode string | `nvarchar(n)` | `varchar(n)` |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | e.g. `Create Table smsgroups (ID bigint IDENTITY(1,1) NOT NULL, …)` vs `Create Table smsgroups (ID AUTOINCREMENT(1, 1), …)`; `ALTER Table patienttest ADD NatighU Bit` vs `ALTER Table patienttest ADD COLUMN NatighU YESNO`; `ALTER Table patients ADD grant13 Bit` vs `ALTER Table patients ADD COLUMN grant13 YESNO`]

### 3.3 Full column lists of the DDL-created tables

Notation: **TSQL** = T-SQL literal; **JET** = Access literal; **SHIP** = the column as it actually exists in the 2019 shipped `Patients.mdb`; **—** = column absent from the shipped payload.

#### 3.3.1 `smsgroups` — 3 columns

| Column | TSQL | JET | SHIP (2019 `Patients.mdb`) |
|---|---|---|---|
| `ID` | `bigint IDENTITY(1,1) NOT NULL` | `AUTOINCREMENT(1, 1)` | `Long Integer` |
| `grouptype` | `Smallint` | `Smallint` | `Integer` |
| `smsgroup` | `varchar(50)` | `varchar(50)` | `Text (50)` |

[D11 literal: `Create Table smsgroups (ID bigint IDENTITY(1,1) NOT NULL, grouptype Smallint, smsgroup varchar(50) );`] [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 6755EA] and [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67B7AE] · SHIP: [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [smsgroups]]

#### 3.3.2 `smslist` — 5 columns (6 after the 1.605 ALTER)

| Column | TSQL | JET | SHIP | Added in 1.605 |
|---|---|---|---|---|
| `ID` | `bigint IDENTITY(1,1) NOT NULL` | `AUTOINCREMENT(1, 1)` | `Long Integer` | — |
| `smstype` | `Smallint` | `Smallint` | `Integer` | — |
| `smsphone` | `varchar(20)` | `varchar(20)` | `Text (20)` | — |
| `smsname` | `varchar(50)` | `varchar(50)` | `Text (50)` | — |
| `smsgroup` | `varchar(50)` | `varchar(50)` | `Text (50)` | — |
| `send` | `Smallint` | `Smallint` | `Integer` | **YES** — `ALTER Table smslist ADD send Smallint` (VA 677A2A) |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs VA 6772BA (TSQL) / VA 67D4D6 (JET) / VA 677A2A (ALTER)] [P11 | analysis/BATCH-04/schema/ddl-all.txt] · SHIP: [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [smslist]]

#### 3.3.3 `SMStemplate` — 2 columns

| Column | TSQL | JET | SHIP |
|---|---|---|---|
| `templatenum` | `bigint IDENTITY(1,1) NOT NULL` | `AUTOINCREMENT(1, 1)` | `Long Integer` |
| `smstext` | `varchar(MAX)` | `varchar(255)` | `Text (255)` |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs VA 6773DA (TSQL) / VA 67D5E2 (JET)] [P11 | analysis/BATCH-04/schema/ddl-all.txt] · SHIP: [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [SMStemplate]]

#### 3.3.4 `SMSSender` — 7 columns (8 after the 1.605 ALTER)

| Column | TSQL | JET | SHIP | Added in 1.605 |
|---|---|---|---|---|
| `SMSautonum` | `bigint IDENTITY(1,1) NOT NULL` | `AUTOINCREMENT(1, 1)` | `Long Integer` | — |
| `username` | — | — | `Text (50)` | **YES** — `ALTER Table SMSSender ADD username varchar(50)` (VA 6776A6); type later widened to `varchar(50)` by `ALTER Table SMSSender ALTER COLUMN username varchar(50)` (VA 67484A) |
| `patientid` | `varchar(13)` | `varchar(13)` | `Text (13)` | — |
| `PatDrName` | `varchar(60)` | `varchar(60)` | `Text (60)` | — |
| `requestdate` | `smalldatetime` | `DATETIME` | `DateTime` | — |
| `smsMobile` | `varchar(20)` | `varchar(20)` | `Text (100)` | widened: `ALTER Table SMSSender ALTER COLUMN smsMobile varchar(100)` (VA 6748BE) |
| `SMSLength` | `Smallint` | `Smallint` | `Integer` | — |
| `SMStext` | `varchar(MAX)` | `varchar(255)` | `Text (255)` | — |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs VA 6774AE (TSQL) / VA 67D692 (JET) / VA 6776A6 (ADD) / VA 6748BE + VA 67484A (ALTER COLUMN)] [P11 | analysis/BATCH-04/schema/ddl-all.txt] · SHIP: [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [SMSSender]]

#### 3.3.5 `Helicobacter` — 6 columns in the DDL, 9 after ALTER, **6 shipped**

| Column | TSQL | JET | SHIP | Added in 1.605 |
|---|---|---|---|---|
| `patientid` | `varchar(13)` | `varchar(13)` | `Text (13)` | — |
| `requestdate` | `smalldatetime` | `DATETIME` | `DateTime` | — |
| `hpigi` | `varchar(50)` | `varchar(50)` | `Text (50)` | — |
| `hpigm` | `varchar(50)` | `varchar(50)` | `Text (50)` | — |
| `hpag` | `varchar(50)` | `varchar(50)` | `Text (50)` | — |
| `comment` | `varchar(255)` | `varchar(255)` | `Memo/Hyperlink (255)` | — |
| `hpab` | `varchar(50)` | `varchar(50)` | **—** | **YES** — `ALTER Table Helicobacter ADD hpab varchar(50)` (VA 67B442); **NOT APPLIED in the shipped Access payload** |
| `hpbiop` | `varchar(50)` | `varchar(50)` | **—** | **YES** — VA 67B4A2; **NOT APPLIED** |
| `hpiga` | `varchar(50)` | `varchar(50)` | **—** | **YES** — VA 67B666; **NOT APPLIED** |

**Runtime/schema conflict (VERIFIED):** the v1.605 SQL **reads** `Helicobacter.hpiga`, `Helicobacter.hpab`, `Helicobacter.hpbiop` — e.g. `SELECT Top 10 Helicobacter.requestdate, Helicobacter.hpigi, Helicobacter.hpigm, Helicobacter.hpiga, Helicobacter.hpab, Helicobacter.hpbiop, Helicobacter.hpag, patientinfo.labid FROM patientinfo INNER JOIN Helicobacter ON patientinfo.patientid = Helicobacter.patientid` — but the 2019-shipped Access `Helicobacter` has only those 6 columns, so the query fails against the shipped Jet payload. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 7314DC / VA 731734 / VA 7319AC / VA 731C00] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [Helicobacter]]

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs VA 67B522 (TSQL, truncated) / VA 67DAAE (JET, complete) / VA 67B442, 67B4A2, 67B666 (ALTERs)] [P11 | analysis/BATCH-04/schema/ddl-all.txt]

#### 3.3.6 `MyLabSetting` — 20 columns shipped (DDL literal truncated)

DDL literal: `Create Table MyLabSetting (LabID Smallint` — **truncated in the string pool; the remaining columns are NOT RECOVERABLE from the DDL.** [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 674A32]

The **shipped** 2019 `MyLabSetting` is complete: `LabID` Integer · `sendername` Text(15) · `accuntID` Text(50) · `accuntpw` Text(50) · `updateflage` Byte · `Hourflag` Integer · `SMSNo` Integer · `totalsms` Double · `SMSSend` Double · `SMSbakey` Double · `phoneNo1..phoneNo6` Text(15) ×6 · `phonenum` Integer · `Timess` Text(100) · `FridaySend` Byte · `shortsms` Byte. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]]

> Note the plain-text credential pair `accuntID` / `accuntpw` stored in the same table as the SMS gateway settings. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [MyLabSetting]] **Stage 2:** the pair is **populated** in the shipped V2 store — the `LabID` = 100 row carries an 8-character `accuntID` and a 6-character `accuntpw` in clear text, and rows 200–500 carry empty credential columns. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only via Microsoft.ACE.OLEDB.12.0]`

#### 3.3.7 `LBC` — 18 columns, **ABSENT from the Access payload**

| Column | TSQL | JET | SHIP |
|---|---|---|---|
| `patientid` | `varchar(13)` | `varchar(13)` | — |
| `requestdate` | `smalldatetime` | `DATETIME` | — |
| `testid` | `Smallint` | `Smallint` | — |
| `RESULT1` | `varchar(75)` | `varchar(75)` | — |
| `RESULT01` | `varchar(MAX)` | `Memo` | — |
| `RESULT2` | `varchar(75)` | `varchar(75)` | — |
| `RESULT02` | `varchar(MAX)` | `Memo` | — |
| `RESULT3` | `varchar(75)` | `varchar(75)` | — |
| `RESULT03` | `varchar(MAX)` | `Memo` | — |
| `RESULT4` | `varchar(75)` | `varchar(75)` | — |
| `RESULT04` | `varchar(MAX)` | `Memo` | — |
| `RESULT5` | `varchar(75)` | `varchar(75)` | — |
| `RESULT05` | `varchar(MAX)` | `Memo` | — |
| `RESULT6` | `varchar(75)` | `varchar(75)` | — |
| `RESULT06` | `varchar(MAX)` | `Memo` | — |
| `RESULT7` | `varchar(75)` | `varchar(75)` | — |
| `RESULT07` | `varchar(MAX)` | `Memo` | — |
| `LBCSAMP…` (T-SQL truncated; JET shows `LBCSAMPLE YESNO`) | `LBCSAMP` | `LBCSAMPLE YESNO` | — |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs VA 6756BE (TSQL, truncated) / VA 67B88A (JET, complete)] [P11 | analysis/BATCH-04/schema/ddl-all.txt] · ABSENT: [P07-08 | analysis/BATCH-07/migration-proof.md | §1 "LBC | — | — | 0 | ABSENT"]

The JET variant is the one whose `LBCSAMPLE YESNO` tail is intact, so the final column is `LBCSAMPLE` (Boolean in Access terms).

#### 3.3.8 `IgEallergy` — 4 header columns + 40×4 item block, **ABSENT from the Access payload**

Header (both dialects): `patientid varchar(13)`, `requestdate` (`smalldatetime` / `DATETIME`), `testid Smallint`, `itemNo Smallint`. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 6759F6 (TSQL) / VA 67BB4A (JET)]

Item block pattern (from the intact prefix of the JET literal):
`Item1 varchar(50), RESULT1 varchar(25), Class1 Smallint, TypeF1 Smallint, Item2 varchar(50), RESULT2 varchar(25), Class2 Smallint, TypeF2 Smallint, …` [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67BB4A]

1.605 extensions (three multi-column `ALTER`s, each truncated in the dump):
- `ALTER Table IgEallergy ADD COLUMN Item12 varchar(50),RESULT12 varchar(25),Class12 Smallint, TypeF12 Smallint, Item13 …, Item14 …, Item15 …, Item16 varchar(50),RESULT16 varchar(25),Class16 Smallint ,Type` [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67C266]
- `ALTER Table IgEallergy ADD COLUMN Item24 varchar(50),RESULT24 varchar(25),Class24 Smallint ,TypeF24 Smallint, … Item28 …, Type` [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67C9D2]
- `ALTER Table IgEallergy ADD COLUMN Item36 varchar(50),RESULT36 varchar(25),Class36 Smallint ,TypeF36 Smallint, … Item40 varchar(50),RESULT40 varchar(25),Class40 Smallint ,Type` [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67D13E]

**Exact final item count: NOT RECOVERABLE** — all three `ALTER` literals are cut off mid-statement. The highest item index directly evidenced is **Item40**; if the numbering is continuous from 1, the implied width is 4 header columns + 40 × 4 item columns = **164 columns**, but that figure is **INFERRED**, not verified. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67D13E] · ABSENT from Access payload: [P07-08 | analysis/BATCH-07/migration-proof.md | §1 "IgEallergy | — | — | 0 | ABSENT"]

#### 3.3.9 `ratios` — 12 columns shipped

DDL literals are truncated to `Create Table ratios (patientid varchar(13)` (VA 67B11E, VA 67DC5E, VA 67DDAA — the table is created **three times** in the binary, once per dialect path). [P11 | analysis/BATCH-04/schema/ddl-all.txt]

Shipped 2019 columns: `patientid` Text(13) · `requestdate` DateTime · `cacreat` Text(10) · `ptcreat` Text(10) · `uriccreat` Text(10) · `creat` Text(10) · `ca` Text(10) · `pt` Text(10) · `uric` Text(10) · `comment` Memo/Hyperlink(255) · `albu` Text(10) · `albcreat` Text(10). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [ratios]]

1.605 additions: `ALTER Table ratios ADD albu varchar(10)` (VA 67B05E) and `ALTER Table ratios ADD albcreat varchar(10)` (VA 67B0B2) — **both applied** in the shipped payload. [P11 | analysis/BATCH-04/schema/ddl-all.txt] · [P07-08 | analysis/BATCH-07/migration-proof.md | §2 "ratios | albu | ADDED-BY-MIGRATION", "ratios | albcreat | ADDED-BY-MIGRATION"]

#### 3.3.10 `hba1c` — 5 columns shipped

DDL literal truncated to `Create Table hba1c (patientid varchar(13)` (VA 679ABA, VA 67FD32). [P11 | analysis/BATCH-04/schema/ddl-all.txt]

Shipped: `patientid` Text(13) · `requestdate` DateTime · `hba1c` **Double** · `eag` **Double** · `comment` Memo/Hyperlink(255). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [hba1c]]

Note the numeric typing: unlike every profile table, `hba1c` stores its two analytes as **Double**, not Text. The runtime reads both: `SELECT Top 10 hba1c.requestdate, hba1c.hba1c, hba1c.eag, patientinfo.labid …`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 72DA74]

#### 3.3.11 `widal2` — 26 columns shipped

DDL literal truncated to `Create Table widal2 (patientid varchar(13)` (VA 67A10E, VA 67FEAE). [P11 | analysis/BATCH-04/schema/ddl-all.txt]

Shipped: `patientid` Text(13) · `requestdate` DateTime · `widal1a..widal8b` Text(20) ×16 · `widalresult` Text(50) · `weilfelix1a..weilfelix3b` Text(20) ×6 · `comment` Text(255). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [widal2]]

#### 3.3.12 `pictures` — 73 columns shipped

DDL literal truncated to `Create Table pictures (patientid varchar(13), requestdate DATETIME, testcode Smallint` (VA 6785B6, VA 67E58E). [P11 | analysis/BATCH-04/schema/ddl-all.txt]

1.605 additions (all applied, 42 `ALTER` statements): `numsx1..numsx15` Text(50), `numsxt1..numsxt15` Text(5), `shapesx1..shapesx12` Text(50). [P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 678552→679A56 and 67E4D2→67F966] · [P11 | analysis/V-CD-2019/02-schema.md | §3 `pictures` 42]

Shipped (73): `patientid` Text(13) · `requestdate` DateTime · `testcode` Long Integer · `pictpix1..pictpix4` Text(50) ×4 · `Label1V..Label12V` Text(50) ×12 · `Label1T..Label12T` Text(75) ×12 · `numsx1..numsx15` Text(50) ×15 · `shapesx1..shapesx12` Text(50) ×12 · `numsxt1..numsxt15` Text(5) ×15. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [pictures]]

#### 3.3.13 `testtemp` — 28 columns shipped

DDL literal truncated to `Create Table testtemp (patientid varchar(13)` (VA 674396). [P11 | analysis/BATCH-04/schema/ddl-all.txt]

1.605 type change: `ALTER Table testtemp ALTER COLUMN normalrang MEMO` (VA 67413A) — the only `ALTER COLUMN` on this table. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67413A]

Shipped (28): `patientid` Text(13) · `requestdate` DateTime · `testcode` Long Integer · `subgroupcode` Long Integer · `testsimp` Text(50) · `loggroup` Text(50) · `arrangnum` Long Integer · `RESULTT` Text(50) · `testprice` Double · `sentout` Boolean NOT NULL · `testpriceout` Double · `otherlabname` Text(40) · `testtime` Integer · `printwith` Boolean NOT NULL · `testabrev` Text(50) · `testname` Text(50) · `historyname` Text(50) · `testunit` Text(15) · `lowlimit` Double · `highlimit` Double · `nolowexe` Text(20) · `nohighexe` Text(20) · `detelethis` Long Integer · `resultfinsh` Boolean NOT NULL · `resultreview` Boolean NOT NULL · `resultprint` Boolean NOT NULL · `give` Boolean NOT NULL · `normalrang` Memo/Hyperlink(255). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [testtemp]]

`testtemp` is a **column-for-column mirror of `patienttest`** (28 of the same field names) plus `detelethis` — it is a scratch/staging table for in-progress results. Runtime evidence: `Delete FROM testtemp` · `Select testcode FROM testtemp where testcode=41 and detelethis=0` · `SELECT * FROM testtemp where testsimp='`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 6A868A / 6A90C2 / 732380 / 732594]

#### 3.3.14 `FMF` — **ABSENT** from the Access payload; columns NOT RECOVERABLE

Both DDL literals are truncated to `Create Table FMF (patientid varchar(13)` (VA 679C46, VA 68037E). The only other V2 reference is `SELECT * FROM FMF where patientid= '`. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 679C46 / VA 68037E] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 73961C]

**Every column of `FMF` beyond `patientid` is NOT RECOVERABLE.** The published V2 column count for `FMF` (1) reflects only the truncated literal, not the real table width. [P04 | column-evolution.csv | row `fmf,no,yes,0,1,patientid,`]

### 3.4 The `ALTER COLUMN` type changes in the embedded DDL — 13 literals, 12 distinct pairs

| # | Table | Column | New type (T-SQL literal) | Jet counterpart | Shipped 2019 Jet type | Applied? |
|---:|---|---|---|---|---|---|
| 1 | `testtemp` | `normalrang` | `MEMO` | (same literal) | `Memo/Hyperlink (255)` | **YES** |
| 2 | `SMSSender` | `username` | `varchar(50)` | — | `Text (50)` | **YES** |
| 3 | `SMSSender` | `smsMobile` | `varchar(100)` | — | `Text (100)` | **YES** |
| 4 | `semen` | `Liquefaction` | `varchar(10)` | — | `Text (10)` | **YES** |
| 5 | `cultures` | `organism` | `varchar(80)` | — | `Text (80)` | **YES** |
| 6 | `cultures` | `organism2` | `varchar(80)` | — | `Text (80)` | **YES** |
| 7 | `cultures` | `organism3` | `varchar(80)` | — | `Text (80)` | **YES** |
| 8 | `patientinfo` | `PatRPW` | `varchar(20)` | — | `Text (20)` | **YES** |
| 9 | `normalrange` | `normalrang` | `varchar(MAX)` | `Memo` | `Text (255)` | **NO** — shipped value is still `Text (255)` |
| 10 | `cultureanti` | `Sensitivityvalue` | `varchar(10)` | — | `Text (10)` | **YES** (changed from Double) |
| 11 | `semen` | `Viscosity` | `varchar(15)` | — | `Text (15)` | **YES** |
| 12 | `PTC` | `concent` | `float` | — | `Double` | **YES** |
| 13 | `normalrange` | `normalrang` | `Memo` | — | `Text (255)` | **NO** (duplicate of #9, opposite dialect) |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | the 13 `ALTER … ALTER COLUMN` literals] · SHIP types: [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [cultures] / [semen] / [cultureanti] / [PTC] / [normalrange]]

**Count discrepancy:** the P11 baseline and evidence register both state **14** type changes; the DDL contains **13** `ALTER COLUMN` literals (12 distinct table/column pairs — `normalrange.normalrang` appears twice, once per dialect). [P11 | analysis/V-CD-2019/00-baseline-summary.md | §2 "تغييرات أنواع أعمدة | 14"] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-031 "14 تغيير نوع"] vs [P11 | analysis/BATCH-04/schema/ddl-all.txt | 13 `ALTER COLUMN` literals]

---

## 4. Per-table column specifications

Types below are the **2019 shipped Jet 4 types** from the 2019 payload dump. `NOT NULL` is Jet's actual constraint. "Added in 1.605" = the column was introduced by the embedded DDL and **is present in the shipped payload**; "DDL-added, NOT APPLIED" = introduced by the embedded DDL but **absent** from the shipped payload.

### 4.1 `patientinfo` — PATIENT MASTER — 39 columns

| # | Column | Type (2019 Jet) | Notes |
|---:|---|---|---|
| 1 | `patientsefa` | Text (20) | Arabic national id |
| 2 | `patientnamear` | Text (40) | |
| 3 | `patientsex` | Text (7) | |
| 4 | `patientaddress` | Text (70) | |
| 5 | `patientphone` | Text (12) | |
| 6 | `PFax` | Text (15) | **Added in 1.605** (`ALTER Table patientinfo ADD PFax varchar(15)`, VA 677B9A) |
| 7 | `PatRPW` | Text (20) | **Added in 1.605** (VA 677C66) + type set to `varchar(20)` (VA 677CCA) |
| 8 | `SMSMob` | Text (15) | **Added in 1.605** (VA 677BFA) |
| 9 | `requestdate` | DateTime | accession date |
| 10 | `outdate` | DateTime | |
| 11 | `timein` | Text (10) | stored as text, not time |
| 12 | `referredbysefa` | Text (20) | |
| 13 | `referredbyname` | Text (40) | |
| 14 | `gehaName` | Text (50) | **Added in 1.605** (VA 67432E) — refers to `Gehats.gehahname` |
| 15 | `pricemethod` | Text (10) | |
| 16 | `totalprice` | Double | |
| 17 | `patientageunit` | Text (5) | `Years`/`Days`/`Mons.` |
| 18 | `elmadfoo3` | Double | |
| 19 | `elbakyma3mal` | Double | |
| 20 | `totalpricedisc` | Double | |
| 21 | **`patientid`** | **Text (13)** | **natural key of the whole model; nullable in the shipped Jet table** |
| 22 | `labid` | Text (13) | branch/lab identifier — *different* from `MyLabSetting.LabID` (Integer) and `history.labid` (Text(50)) |
| 23 | `patientage` | Double | |
| 24 | `PBirthDay` | DateTime | present in the 2019 payload but **has no embedded-DDL statement** → added by the vendor's database build, not by the runtime script |
| 25 | `discount100` | Double | |
| 26 | `discount` | Double | |
| 27 | `mowzaf` | Text (40) | "discount/referrer" |
| 28 | `editdate` | Text (40) | **stored as text** |
| 29 | `completes` | Text (1) | |
| 30 | `recepnote` | Text (100) | |
| 31 | `moreinfo` | Text (22) | in the 2019 `System\Branch_Data.mdb` template this is Memo(255) |
| 32 | `barcode` | Text (25) | |
| 33 | `patienttel` | Text (12) | |
| 34 | `email` | Text (40) | |
| 35 | `kawmy` | Text (14) | |
| 36 | `edituser2` | Text (40) | |
| 37 | `editdate2` | Text (40) | |
| 38 | `editnum` | Integer | |
| 39 | `moreinfo2` | Text (30) | **Added in 1.605** (VA 67B6D6 `varchar(30)`, VA 67DA36 `ADD COLUMN … varchar(30)`; a third, invalid `text(30)` form also exists at VA 67D9D2) |

[All column names/types: P07 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo]] · [DDL additions: P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 67432E, 677B9A, 677BFA, 677C66, 677CCA, 67B6D6, 67D9D2, 67DA36] · [Column counts per dialect: P11 | analysis/BATCH-04/schema/added-columns.csv | rows `patientinfo,…`]

**Nullability trap:** the shipped `Patients.mdb` declares `patientid Text (13)` with **no `NOT NULL`**, whereas the `Branch_Data.mdb` branch template declares `patientid Text (13) NOT NULL`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo]] vs [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [patientinfo]]

**Runtime evidence for the key:** `patientinfo.patientid` is the most-referenced qualified column in the binary (341 references), ahead of `patientinfo.patientnamear` (272) and `patientinfo.labid` (213). [P11 | analysis/BATCH-04/sql_v1605/columns.csv | rows 2–4]

### 4.2 `patienttest` — TEST ORDER / RESULT INDEX — 46 columns

| # | Column | Type | Notes |
|---:|---|---|---|
| 1 | `requestdate` | DateTime | |
| 2 | **`patientid`** | Text (13) | FK → `patientinfo.patientid` |
| 3 | `testcode` | Integer | FK → `testtable.testcode` (Long Integer) |
| 4 | `testsimp` | Text (50) | FK → `testtable.testsimp` |
| 5 | `subgroupcode` | Integer | FK → `subgrouptable.subgroupcode` |
| 6 | `testtime` | Integer | |
| 7 | `testprice` | Double | |
| 8 | `printwith` | Boolean NOT NULL | |
| 9 | `resultfinsh` | Boolean NOT NULL | entry complete |
| 10 | `resultprint` | Boolean NOT NULL | printed |
| 11 | `testpriceout` | Double | |
| 12 | `RESULTCASEPRINT` | Text (15) | |
| 13 | `RESULTT` | Text (50) | primary result value |
| 14 | `resultt1` | Text (50) | |
| 15 | `resultt2` | Text (50) | |
| 16 | `resultt3` | Text (50) | |
| 17 | `resultt4` | Text (50) | |
| 18 | `arrangnum` | Integer | report ordering |
| 19 | `give` | Boolean NOT NULL | result handed over |
| 20 | `edituser` | Text (40) | |
| 21 | `printuser` | Text (40) | |
| 22 | `editdate` | Text (40) | text, not DateTime |
| 23 | `printdate` | Text (40) | text |
| 24 | `printnum` | Double | print counter |
| 25 | `prevuser` | Text (40) | |
| 26 | `prevdate` | Text (40) | text |
| 27 | `taslimuser` | Text (40) | |
| 28 | `taslimdate` | Text (40) | text |
| 29 | `loggroup` | Text (50) | **name**, not id — see §5.2 (I8) and §8.5 |
| 30 | `resultreview` | Boolean NOT NULL | reviewed |
| 31 | `sentout` | Boolean NOT NULL | outsourced |
| 32 | `otherlabname` | Text (40) | |
| 33 | `testpriceoutmadfo` | Double | |
| 34 | `send` | Boolean NOT NULL | |
| 35 | `commentx` | Memo/Hyperlink (255) | |
| 36 | `testabrev` | Text (50) | |
| 37 | `testname` | Text (50) | |
| 38 | `historyname` | Text (50) | |
| 39 | `normalrang` | Text (255) | **frozen copy of the reference range at entry time** (note: table is `normalrange`, column is `normalrang`) |
| 40 | `testunit` | Text (15) | |
| 41 | `lowlimit` | Double | |
| 42 | `highlimit` | Double | |
| 43 | `nolowexe` | Text (20) | |
| 44 | `nohighexe` | Text (20) | |
| 45 | `Timeout` | Text (10) | present in the 2019 payload; **no embedded-DDL statement** |
| 46 | `Taketime` | Integer | present in the 2019 payload; **no embedded-DDL statement** |

[All: P07 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patienttest]] · [DDL addition for this table: `ALTER Table patienttest ADD NatighU Bit` (VA 67764E) / `ALTER Table patienttest ADD COLUMN NatighU YESNO` (VA 67D8F6) — **`NatighU` is NOT present in the shipped payload**] [P11 | analysis/BATCH-04/schema/ddl-all.txt] · [P07-08 | analysis/BATCH-07/migration-proof.md | §2 "patienttest | NatighU | — | — | NOT-APPLIED"]

**`patienttest` is the second-most-referenced table** (343 statements) and `patienttest.patientid` is the 4th most-referenced qualified column (116). [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `patienttest`] · [P11 | analysis/BATCH-04/sql_v1605/columns.csv | row `patienttest.patientid`]

### 4.3 `patienttestgroup` — PROFILE-GROUP ORDERING — 46 columns

Identical to `patienttest` **plus** `maintestcode` Integer inserted after `patientid`; **without** `testprice` Double (which `patienttest` has). Full column list: `requestdate` DateTime · `patientid` Text(13) · `maintestcode` Integer · `testcode` Integer · `testsimp` Text(50) · `subgroupcode` Integer · `testtime` Integer · `printwith` Boolean NOT NULL · `resultfinsh` Boolean NOT NULL · `resultprint` Boolean NOT NULL · `testpriceout` Double · `RESULTCASEPRINT` Text(15) · `RESULTT` Text(50) · `resultt1..resultt4` Text(50) ×4 · `arrangnum` Integer · `give` Boolean NOT NULL · `edituser` Text(40) · `printuser` Text(40) · `editdate` Text(40) · `printdate` Text(40) · `printnum` Double · `prevuser` Text(40) · `prevdate` Text(40) · `taslimuser` Text(40) · `taslimdate` Text(40) · `loggroup` Text(50) · `resultreview` Boolean NOT NULL · `sentout` Boolean NOT NULL · `otherlabname` Text(40) · `testpriceoutmadfo` Double · `send` Boolean NOT NULL · `commentx` Memo/Hyperlink(255) · `testabrev` Text(50) · `testname` Text(50) · `historyname` Text(50) · `normalrang` Text(255) · `testunit` Text(15) · `lowlimit` Double · `highlimit` Double · `nolowexe` Text(20) · `nohighexe` Text(20) · `Timeout` Text(10) · `Taketime` Integer. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patienttestgroup]]

`patienttestgroup` has **no `CREATE TABLE` in the embedded DDL** — its origin is the vendor's database build. **UNVERIFIED** as to provenance. [P11 | analysis/BATCH-04/schema/ddl-all.txt | no `Create Table patienttestgroup` literal]

### 4.4 `testtable` — TEST CATALOGUE — 38 columns

| # | Column | Type | Notes |
|---:|---|---|---|
| 1 | **`testcode`** | Long Integer | **PK** of the catalogue |
| 2 | `testcodebill` | Text (13) | **Added in 1.605** (`ALTER Table testtable ADD testcodebill nvarchar(13)` VA 678036 / `ADD testcodebill varchar(13)` VA 67DBF2) |
| 3 | `arrangnum` | Integer | report ordering |
| 4 | `subgroupcode` | Integer | FK → `subgrouptable.subgroupcode` |
| 5 | `testsimp` | Text (50) | short name; the natural join key used across the model |
| 6 | `testabrev` | Text (50) | |
| 7 | `testname` | Text (50) | |
| 8 | `waslname` | Text (50) | Work-Sheet name |
| 9 | `waslname2` | Text (50) | |
| 10 | `historyname` | Text (50) | |
| 11 | `barcodesymb` | Text (50) | |
| 12 | `testnamear` | Text (50) | Arabic name |
| 13 | `subgroupname` | Text (40) | denormalised |
| 14 | `loggroup` | Text (50) | |
| 15 | `active` | Boolean NOT NULL | |
| 16 | `inotherlab` | Boolean NOT NULL | |
| 17 | `otherlabname` | Text (50) | |
| 18 | `otherlabprice` | Double | |
| 19 | `patientprice` | Double | |
| 20 | `labprice` | Double | |
| 21 | `anyqus` | Boolean NOT NULL | |
| 22 | `thequse` | Text (150) | |
| 23 | `testdiscr` | Text (100) | |
| 24 | `testeffect` | Text (100) | |
| 25 | `testusage` | Text (100) | |
| 26 | `typeofsample` | Text (100) | |
| 27 | `deleteprotect` | Boolean NOT NULL | |
| 28 | `testtime` | Integer | |
| 29 | `printwith` | Boolean NOT NULL | |
| 30 | `barcode1` | Text (50) | |
| 31 | `barcode2` | Text (50) | |
| 32 | `barcode3` | Text (50) | |
| 33 | `branch` | Text (50) | |
| 34 | `seereport` | Text (50) | |
| 35 | `normaltype` | Text (50) | |
| 36 | `addorno` | Boolean NOT NULL | |
| 37 | `testorno` | Boolean NOT NULL | |
| 38 | `REFRANGE` | Text (1) | **Added in 1.605** (`ADD REFRANGE nvarchar(1)` VA 67AB12 / `ADD COLUMN REFRANGE varchar(1)` VA 680EB2) — reference-range mode flag |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [testtable]] · [DDL: P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 678036, 67DBF2, 67AB12, 680EB2]

The V2 vendor catalogue states that the test catalogue holds **609** tests. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-1] The per-test content of a live V2 installation — the prices, flags and names as entered — is **NOT RECOVERABLE** from this evidence, because the shipped schema was ingested as a schema dump only and no row-level extract of the live V2 store exists.

### 4.5 `normalrange` — REFERENCE RANGES — 18 columns

| # | Column | Type | Notes |
|---:|---|---|---|
| 1 | `normalid` | Long Integer | surrogate key |
| 2 | `testcode` | Long Integer | FK → `testtable.testcode` |
| 3 | `testsimp` | Text (50) | FK → `testtable.testsimp` |
| 4 | `subgroupcode` | Integer | FK → `subgrouptable.subgroupcode` |
| 5 | `sex` | Text (10) | `Male` / `Female` / `All` |
| 6 | `firstold` | Double | age band lower bound |
| 7 | `secondold` | Double | age band upper bound |
| 8 | `ageunit` | Text (10) | `Years` / `Days` / `Mons.` |
| 9 | `pregsmok` | Single | **semantics unexplained — see §9.9** |
| 10 | `normalrang` | Text (255) | display text of the range (the **column** `normalrang`, not the table `normalrange`) |
| 11 | `testunit` | Text (15) | |
| 12 | `lowlimit` | Double | |
| 13 | `highlimit` | Double | |
| 14 | `nolowexe` | Text (20) | low-exception text |
| 15 | `nohighexe` | Text (20) | high-exception text |
| 16 | `lowcomment` | Memo/Hyperlink (255) | |
| 17 | `highcomment` | Memo/Hyperlink (255) | |
| 18 | `REFRANGE` | Text (1) | **Added in 1.605** (`ADD REFRANGE varchar(1)` VA 67AB9A / `ADD COLUMN REFRANGE varchar(1)` VA 680F22) |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [normalrange]] · [DDL: P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 67AB9A, 680F22, 677D3E, 67D886]

`normalrange` is the **3rd most-referenced table** (95 statements). [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `normalrange`]

The V2 vendor catalogue states that the reference-range table holds **852** ranges. [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-3] The per-range content of a live V2 installation — the limits, exception texts and comments — is **NOT RECOVERABLE** from this evidence, because the shipped schema was ingested as a schema dump only and no row-level extract of the live V2 store exists.

### 4.6 `constanttable` — CLINICAL CONSTANTS — 8 columns

`constantdiscrp` Text(50) · `constant1` Text(50) · `constant2` Text(50) · `constant3` Text(50) · `constant4` Text(50) · `constant5` Text(50) · `constant6` Text(50) · `constant7` Text(50). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [constanttable]]

`constant7` is present in the 2019 payload but has **no embedded-DDL statement** — added by the vendor's DB build. [P11 | analysis/BATCH-04/schema/ddl-all.txt | no `ALTER Table constanttable` literal]

`constantdiscrp` is the **discriminator key**: the runtime reads `SELECT * FROM constanttable where constantdiscrp='PTCONS'` and `SELECT * FROM constanttable where constantdiscrp='RATIOS'`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 8A6F16-style constanttable queries — actual literals: `SELECT * FROM constanttable where constantdiscrp='PTCONS'` (tables.csv row `constanttable`, `sample_statement`) and `SELECT * FROM constanttable where constantdiscrp='RATIOS'` (VA 72F81C)]

**The constants the V2 manual documents (VERIFIED):** PT — *ISI, Control Time and Concentration table*; PTT — *Control Time*; and the CBC derivation factors `Hct (Hematocrit) = Hgb * 3.3`, `Hemoglobin % (Hgb%) = Hgb * 8.25` (Male or Female, age less than one year) · `Hgb% = Hgb * 7.50` (Male or Female, age from 1 – 12 years) · `Hgb% = Hgb * 6.25` (Male age greater than 12 years) · `Hgb% = Hgb * 6.75` (Female age greater than 12 year). [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic nots.htm item 1]

**The values stored in the V2 `constanttable` rows are NOT RECOVERABLE.** The shipped schema defines `constanttable` with 8 columns (`constantdiscrp` + `constant1..constant7`) and the runtime reads the rows by discriminator — `SELECT * FROM constanttable where constantdiscrp='PTCONS'` — but the shipped schema was ingested as a schema dump only, so the numeric content a live V2 installation holds under each discriminator (including the PT control time, the second-level control time, the ISI and the Westgard flag) is **NOT RECOVERABLE** from this evidence. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [constanttable]] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | the `constanttable` discriminator queries]

> **`constanttable` vs `PTC` vs `PTCONS` naming trap:** `PTCONS` is **not a table** — it is a `constanttable.constantdiscrp` value. The `PTC` table is a different thing entirely (the PT control curve). See §7.4.

### 4.7 `useraccounts` — **SQL-Server-only operator table**

Not present in the 2019 Access payload. Columns recoverable only from the DDL and from SQL predicates:

| Column | Type | Source |
|---|---|---|
| `usersnum` | **NOT RECOVERABLE** (numeric key) | `select * FROM useraccounts where usersnum=` [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 726A64] |
| `usersdr` | **NOT RECOVERABLE** (sortable name/dir) | `Select * from useraccounts order by usersdr asc` · `where usersdr= '` [VA 726AC0, VA 726DFC] |
| `HDD1` | varchar(20) | `ALTER Table useraccounts ADD HDD1 varchar(20)` (VA 677A7E) — **NOT APPLIED** in Access |
| `HDD2` | varchar(20) | `ALTER Table useraccounts ADD HDD2 varchar(20)` (VA 677ADE) — **NOT APPLIED** |
| `Gtype` | Smallint | `ALTER Table useraccounts ADD Gtype Smallint` (VA 677B3E) — **NOT APPLIED** |

[P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 677A7E, 677ADE, 677B3E] · [P07-08 | analysis/BATCH-07/migration-proof.md | §2 "useraccounts | HDD1 … NOT-APPLIED"]

> The Access-engine equivalent of the operator table is **`patients`** (§4.10). `useraccounts` is the SQL-Server name.

### 4.8 `payment` — 10 columns

`patientid` Text (13) · `paiddate` DateTime · `type` Integer · `gehah` Text (50) · `testsimp` Text (50) · `money` Double · `mowzaf` Text (40) · `editdate` Text (40) · `comment` Text (100) · `paymentnum` Long Integer (**Added in 1.605** — `ALTER Table payment ADD paymentnum bigint IDENTITY(1,1) NOT NULL` VA 677EC2 / `AUTOINCREMENT(1, 1)` VA 67D95E).

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [payment]] · [DDL: P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 677EC2, 67D95E]

### 4.9 `comments` — 5 columns

`commentid` Long Integer · `testcode` Integer · `subgroupcode` Integer · `testsimp` Text (50) · `comments` Memo/Hyperlink (255). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [comments]]

Keyed by **test identity, not patient**: `SELECT comments FROM comments where testcode in (…)`. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `comments`, `sample_statement`]

### 4.10 `patients` — OPERATOR / USER ACCOUNT TABLE — 33 columns

**This is not a patient table.** `patientusid` Long Integer · `patientusname` Text (40) · `lastvisit` Text (40) · `patientuscap` Text (40) · `patientword` Text (40) · `patientad` Boolean NOT NULL · `patientus` Boolean NOT NULL · `grant1`..`grant12` Boolean NOT NULL ×12 · `showtip` Boolean NOT NULL · `tipnum` Long Integer · `startwork` Text (15) · `endwork` Text (15) · `breakyorn` Boolean NOT NULL · `breaktime` Text (15) · `khasmlimit` Long Integer · **`branche` Integer** · **`SecWord` Text (10)** · **`grant13`..`grant17` Boolean NOT NULL ×5**. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients]]

The last 7 columns are the **V2 privilege/branch model** and are exactly the columns added by the embedded DDL to the table named `Patients`: `ALTER Table Patients ADD branche smallint` (VA 6DC264) / `ADD COLUMN branche Smallint` (VA 6DC6AC) · `ADD SecWord varchar(10)` (VA 6DC2BC / 6DC714) · `ADD grant13..grant17 Bit` (VAs 6DC31C–6DC460) / `ADD COLUMN grant13..grant17 YESNO` (VAs 6DC4B0–6DC64C). [P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 6DC264…6DC714]

**VERIFIED FACT (contradicting a published verdict):** these 7 columns **ARE present in the 2019-shipped Jet `patients` table**. The published reconciliation report records them as `NOT-APPLIED` with `present_in_v2019: False` for all 15 `Patients` rows — an artefact of case-sensitive lookup of the table name `Patients` against the Jet table `patients`. See §9.2. [P07-08 | analysis/BATCH-07/migration-proof.json | `alter_checks` entries with `table == "Patients"`] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients]]

Runtime: `select startwork,endwork,breakyorn,breaktime from patients where patientusname= '` — attendance/permission lookup. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `patients`]

### 4.11 `Gehats` — REFERRING ENTITY MASTER — 21 columns

`gehahid` Long Integer · `gehahsefa` Text (20) · `gehahname` Text (40) · `masolsefa` Text (10) · `masolname` Text (40) · `madina` Text (40) · `addressxc` Text (100) · `phone` Text (12) · `mobil` Text (12) · `fax` Text (12) · `mail` Text (50) · `web` Text (50) · `flose` Boolean NOT NULL · `khasm` Double · `omola` Double (commission %) · `morsel` Integer · `pricemethod` Text (20) · `masolphone` Text (12) · `printorno` Boolean NOT NULL · **`ReferredPW` Text (20)** · **`ReferredID` Long Integer** — the last two are **Added in 1.605** (`ALTER Table Gehats ADD ReferredPW varchar(20)` VA 67797A; `ADD ReferredID int` VA 6779DA) and are **applied** in the shipped payload. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [Gehats]] · [P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 67797A, 6779DA]

Runtime: `SELECT gehahname,morsel,phone,mobil FROM Gehats where gehahname= '`. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `gehats`]

### 4.12 `subgrouptable` — PROFILE CATALOGUE — 4 columns

`subgroupcode` Long Integer · `subgroupname` Text (50) · `arname` Text (50) · `deleteprotect` Boolean NOT NULL. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [subgrouptable]]

> The `Branch_Data.mdb` branch template carries a fifth column **`groupcode`** that the 2019 live `subgrouptable` does not — it is **absent** in the shipped 2019 store with **no `DROP COLUMN` statement anywhere in the embedded DDL**. See §9.4. [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [subgrouptable]] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [subgrouptable]]

### 4.13 `testunits`, `converts`, `abbreviations`, `barcodes`, `Labbranch`, `loggroup` — small dictionaries

| Table | Columns | Types |
|---|---|---|
| `testunits` | 2 | `unitsid` Long Integer · `unitsname` Text (15) |
| `converts` | 6 | `testsimp` Text (100) · `Funit` Text (50) · `Sunit` Text (50) · `Factors` Double · `Ffix` Integer · `Sfix` Integer |
| `abbreviations` | 3 | `abbid` Long Integer · `abbre` Text (30) · `mean` Text (100) |
| `barcodes` | 2 | `barcode` **Text (50) NOT NULL** · `barcodeid` Long Integer |
| `Labbranch` | 2 | `branchid` Long Integer · `branchname` **Text (50) NOT NULL** |
| `loggroup` | 2 | `logid` Long Integer · `logname` **Text (50) NOT NULL** |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [testunits] / [converts] / [abbreviations] / [barcodes] / [Labbranch] / [loggroup]]

`Labbranch` is queried as `SELECT * FROM labbranch order by branchname`, `FROM Labbranch where branchid=`, `FROM Labbranch where branchname like ` — the **branch registry**. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `labbranch`] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 6B1Bxx-class `FROM Labbranch where branchid=`]

### 4.14 `loger` — attendance/event log (SQL-Server-only)

Not in the Access payload. Columns recoverable **only** from SQL predicates: `lognum` (equality filter), `compname` (equality filter), `datein` (range filter + `Delete loger where datein >= `), `username` (`SELECT username FROM loger where datein >= `, `where username= `). **Full column set NOT RECOVERABLE.** [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 66F746, 6EFF14, 72ABDC, 72B7A4, 72BD2C, 72C568]

The published open issue (documentation-only reference **ISS-34**) flags `loger` and `win32_processor` as "possibly a system/event query — undocumented behaviour". `win32_processor` is now resolved as a **WMI query** (`Select * from Win32_Processor`), used by the licence check. `loger` remains open. [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-34] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA for `Select * from Win32_Processor`] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-039]

### 4.15 `workpaper` / `wasl` — the Work-Sheet feature

`workpaper` and `workpaper2` are **VB6 form objects, not tables** — they are the two Work-Sheet screens ("Work Sheet" is unit 2 of the official learning guide). [P11 | analysis/BATCH-04/vb6/v1605/objects.json | `objects` entries `workpaper`, `workpaper2`] · [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 "ورقة العمل (Work Sheet) | `workpaper` `workpaper2` · `wasl`"]

The **table** behind them is `wasl`:

`Patients.mdb` (2019) — 12 columns: `subgroupcode` Long Integer · `testcode` Long Integer · `waslname` Text (255) · `waslname2` Text (255) · `testprice` Double · `testno` Integer · `resultt` Text (50) · `testunit` Text (50) · `RESULTCASEPRINT` Text (50) · `normalrang` Memo/Hyperlink (255) · `testcodex` Text (50) · `subgroupname` Text (50). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [wasl]]

The last **6** columns are **Added in 1.605**: `ALTER Table wasl ADD resultt varchar(50)` (VA 67831E) · `testunit` (678376) · `RESULTCASEPRINT` (6783CE) · `normalrang varchar(MAX)` (678436) · `testcodex` (678496) · `subgroupname` (6784F2), each repeated in the Jet dialect at VAs 681212–681456. [P11 | analysis/BATCH-04/schema/ddl-all.txt]

`data.mdb` (2019) — 6 columns: `subgroupcode` Long Integer · `testcode` Long Integer · `waslname` Text (255) · `waslname2` Text (255) · `testprice` Double · `testno` Integer. [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [wasl]]

So the **same table name `wasl` exists in two V2 databases with different widths (12 vs 6)** — see §9.5.

### 4.16 `mylabsetting` / `MyLabSetting` — 20 columns

See §3.3.6 for the full list. Runtime: `Select * from MyLabSetting WHERE LabID = 100 ;` — the query is **single-row**, but the shipped table is not: it carries **five rows**, one per branch slot (`LabID` 100, 200, 300, 400, 500). [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 68269A]. **Stage 2 (VERIFIED):** the shipped V2 `Patients.mdb` was opened read-only and the table was read directly. In the `LabID` = 100 row, `accuntID` holds an 8-character value and `accuntpw` a 6-character value, both stored as clear `Text (50)`, with `SMSbakey` (3 characters), `sendername` = `RealLab`, `totalsms` = 1000, `SMSSend` = 23, `shortsms` = 1, `FridaySend` = 0, `phonenum` = 1 and a 48-character `Timess` schedule string; rows 200–500 carry empty credential columns (row 200 keeps only `phoneNo1` = `201007676559,20` and `totalsms` = 1). The database was opened read-only and no live system was contacted. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only via Microsoft.ACE.OLEDB.12.0]`

### 4.17 `smsgroups` / `smslist` / `SMStemplate` / `SMSSender`

See §3.3.1–3.3.4.

Runtime semantics:
- `smsgroups.grouptype` discriminates two recipient groups — `Select smsgroup from smsgroupS WHERE grouptype=1 order By smsgroup asc` and `… grouptype=0 …`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 7345E4, VA 7348C4]
- `smslist.smstype` likewise discriminates 0/1, and `send` flags whether the number was already sent: `Select TOP 1 * from smslist where send <> 1 AND smstype=`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 7358C4]
- `smslist.smsgroup` is a **name** (Text(50)), not a foreign key to `smsgroups.ID` — there is **no numeric FK** between the two SMS tables. **INFERRED** from the DDL column types. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [smslist] / [smsgroups]]
- `SMSSender` is the **outbound log**: `Select SMSautonum,smstext,SMSMOBILE,SMSLength,requestdate from SMSSender order by SMSautonum`, and it is purged wholesale with `Delete FROM SMSSender` / `Delete FROM SMSSender where patientid<>'500'` — `'500'` being a sentinel patient id. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 7355B4, VA 7352CC, VA 7354FC]

### 4.18 `history` — DYNAMIC HISTORY TABLE — 25 columns, in TWO databases

`selector` Integer · `labid` Text (50) · `requestdate` DateTime · `column1`..`column20` Text (25) ×20 · `printflag` Boolean NOT NULL · `noofcol` Integer.

- **Identical definition in `Patients.mdb` and in `data.mdb`** (both 25 columns). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [history]] · [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [history]]
- Runtime: `SELECT * FROM History WHERE selector = 1 and labid= '` — `selector` discriminates report/history templates and `labid` scopes them to a lab; `noofcol` says how many of the 20 free columns are actually used. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 6A2872] · [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `history`, `sample_statement`]

> **Discrepancy with the published data model:** the cumulative data model states `history` has **23** columns; the shipped schema shows **25** (3 fixed + 20 free + `printflag` + `noofcol`). The same document states `wasl` = 12 (correct for `Patients.mdb`, wrong for `data.mdb` where it is 6), and the evidence register repeats `history` (23) / `wasl` (12) for `data.mdb`. [P11 | analysis/CUMULATIVE/02-data-model.md | §1 row `history` "23"] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-014] vs [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [history]] — see §9.5.

### 4.19 `ratios`, `hba1c`, `widal2`

See §3.3.9, §3.3.10, §3.3.11 for full column lists.

`ratios` is queried with its computed columns explicitly: `SELECT cacreat,ptcreat,uriccreat,albcreat,comment FROM ratios where patientid= '` and `SELECT Top 10 ratios.requestdate, ratios.creat, ratios.ca, ratios.cacreat, ratios.pt, ratios.ptcreat, ratios.uric, ratios.uriccreat, ratios.albu, ratios.albcreat, …`. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 72FAA0, VA 73003C]

### 4.20 `pictures`, `testtemp`

See §3.3.12, §3.3.13.

### 4.21 `IgEallergy` / `resultIgeAllergy` / `FMF`

- `IgEallergy` — **table**, SQL-Server-only, see §3.3.8.
- **`resultIgeAllergy` is NOT a table** — it is a **VB6 form/datareport object with 231 methods**, i.e. the IgE result-entry screen. Same family: `ResultFMF` (48), `ResultPCR` (37), `ResulturineAuto` (184), `resulthpylori` (83), `ResultLBC` (33). [P11 | analysis/BATCH-04/vb6/v1605/objects.json | `objects` array] · [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3]
- `FMF` — table, see §3.3.14.

### 4.22 `PTC` — PT CONTROL CURVE — 3 columns

`control` **Double NOT NULL** · `concent` **Double NOT NULL** · `ConstID` Long Integer (**Added in 1.605**: `ALTER Table PTC ADD ConstID bigint IDENTITY(1,1) NOT NULL` VA 677FA6 / `AUTOINCREMENT(1, 1)` VA 67D816). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [PTC]] · [P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 677FA6, 677D816, 677F4A]

`ALTER Table PTC ALTER COLUMN concent float` (VA 677F4A) changed `concent` from Double to float in T-SQL; the shipped Jet value is `Double`. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 677F4A]

Runtime: `select * FROM PTC where ConstID=`. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `ptc`]

### 4.23 The per-profile result tables (V2 payload)

A **profile result table** is any table carrying both `patientid` and `requestdate`. In the 2019 payload there are **58** such tables: **51 clinical/result profile tables** (listed below) and **7 structural tables** — `patientinfo`, `patienttest`, `patienttestgroup`, `patienttotal`, `pictures`, `testtemp`, `SMSSender`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

Counting method: 51 rows in the first table below + 7 rows in the second table below = 58, both enumerated explicitly. **Caveat:** `cultureanti` (12 columns) carries `patientid` and appears in the branch template (§2.4) but is **not** enumerated in either list below; if it also carries `requestdate` — which the shared profile template of the next paragraph would imply — the population is 59. Class for `cultureanti.requestdate`: **NOT DOCUMENTED**. See §9.15.

| Profile table | Cols | Profile table | Cols | Profile table | Cols |
|---|---:|---|---:|---|---:|
| `ABO` | 8 | `hepatitis` | 20 | `Suprarenal` | 16 |
| `Abuse` | 12 | `Hgbectrophoresis` | 8 | `TORCH` | 13 |
| `BILH` | 9 | `Immunoglobulin` | 10 | `trace` | 25 |
| `BloodGases` | 10 | `IMMUNOLOGY` | 19 | `TUBERCULINT` | 6 |
| `BONEMAR` | 23 | `iron` | 9 | `urine` | 60 |
| `cardiac` | 9 | `Lipids` | 11 | `Vitamins` | 15 |
| `CoagFactors` | 11 | `liver` | 15 | `widal` | 16 |
| `crossmat` | 84 | `Pancreas` | 13 | `widal2` | 26 |
| `CSFT` | 24 | `postcoitalt` | 17 | `ZN` | 8 |
| `cultures` | 35 | `pregnancy` | 6 | `anyreport` | 26 |
| `Drugs` | 14 | `Proelectrophoresis` | 8 | `cbc` | 29 |
| `Electrolytes` | 20 | `prostaticx` | 53 | `CRP` | 11 |
| `ESR` | 5 | `pt` | 16 | `hormones` | 16 |
| `Fertlity` | 17 | `ratios` | 12 | `kidney` | 15 |
| `GLUCOSETOLERANCE` | 25 | `semen` | 60 | `renalfailure` | 11 |
| `hba1c` | 5 | `stone` | 19 | `sugar` | 12 |
| `Helicobacter` | 6 | `stool` | 61 | `Tumors` | 14 |

**The 7 structural (non-profile) tables that also carry `patientid`+`requestdate`:**

| Table | Cols | Table | Cols | Table | Cols |
|---|---:|---|---:|---|---:|
| `patientinfo` | 39 | `patienttotal` | 15 | `testtemp` | 28 |
| `patienttest` | 46 | `pictures` | 73 | `SMSSender` | 8 |
| `patienttestgroup` | 46 |  |  |  |  |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

**Shared profile template (VERIFIED):** every profile table starts with `patientid` Text (13) and `requestdate` DateTime, then analyte columns, then a `comment` column. Analyte types are overwhelmingly `Text (10)` (one-line values), `Text (30)` (serology/titre values), `Text (50)` (free text), or `Memo/Hyperlink (255)` (comment). **Every analyte is TEXT, never numeric** — the only numeric exceptions in the whole model are `hba1c.hba1c`/`hba1c.eag` (Double), `PTC.control`/`PTC.concent` (Double), `normalrange.firstold/secondold/lowlimit/highlimit` (Double), `normalrange.pregsmok` (Single), and the price/amount columns (`Double`). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists] — **VERIFIED**

**1.605 additions to profile tables:**

| Table | Columns added in 1.605 | Applied in the shipped payload? |
|---|---|---|
| `cbc` | `RDW` `PDW` `seg` `bandx` `Juvenile` `Myelocytes` `Promyelocyte` `Blast` `NRBCWBC` — all Text (10) | **YES** (all 9 present) |
| `cultures` | `condition2` Text (50) · `other1..other4` Text (50) · `Few5..Few8` Text (10) · `organism3` Text (80) | `condition2`, `organism3` **YES**; `Few5..Few8`/`other1..other4` **already existed** in the store and were re-typed |
| `prostaticx` | `reactp` `react1` `react2` `crystalp` Text (50) · `crystalpr` `crystalp2r` Text (25) · `crystalpt` bit | **YES** — all 8 are present, but the payload spells them `Crystalp` / `Crystalpr` / `Crystalp2` / `Crystalp2r` / `crystalpt` (Jet is case-insensitive) |
| `urine` | `T56` `T57` Text (50) · `testid` Smallint | `T56`/`T57` **YES** (as `t56`/`t57`); `testid` **NO** |
| `stool` | `t56` `t57` `t58` Text (50) | **YES** |
| `BloodGases` | `pO2AA1` `pO2AA2` `ctCO2` `Aniongap` `HCO3std` `FiO2` `ctHB` `TempRAT` — all Text (10) | **NO** — none present |
| `Proelectrophoresis` | `Beta2` nvarchar(10) / varchar(10) · `immunolgo` nvarchar(10) / varchar(10) | **NO** |
| `pregnancy` | `normalrange3` varchar(MAX) / MEMO | **NO** |
| `CSFT` | `rbc2` `wbc2` Text (10) | **YES** |
| `Abuse` | `tramadol` `ecstasy` Text (10) | **YES** |
| `lipids` | `nonhdl` varchar(10) | **NO** |
| `Kidney` | `egfr` varchar(10) | **YES** |
| `semen` | `testcode` Smallint | **YES** |
| `testtable` | `REFRANGE` nvarchar(1)/varchar(1) · `testcodebill` nvarchar(13)/varchar(13) | **YES** |
| `normalrange` | `REFRANGE` varchar(1) | **YES** |
| `patienttest` | `NatighU` Bit / YESNO | **NO** |
| `patientinfo` | `gehaname` `PFax` `SMSMob` `PatRPW` `moreinfo2` | `PFax`/`SMSMob`/`PatRPW`/`moreinfo2` **YES**; `gehaname` **YES** (as `gehaName`) |
| `patients` | `branche` `SecWord` `grant13..grant17` | **YES** (all 7) |
| `PTC` | `ConstID` | **YES** |
| `payment` | `paymentnum` | **YES** |
| `smslist` | `send` | **YES** |
| `SMSSender` | `username` | **YES** |
| `Gehats` | `ReferredPW` `ReferredID` | **YES** |
| `Helicobacter` | `hpab` `hpbiop` `hpiga` | **NO** |
| `ratios` | `albu` `albcreat` | **YES** |
| `wasl` | `resultt` `testunit` `RESULTCASEPRINT` `normalrang` `testcodex` `subgroupname` | **YES** |
| `pictures` | 42 columns (`numsx*`, `numsxt*`, `shapesx*`) | **YES** |
| `useraccounts` | `HDD1` `HDD2` `Gtype` | table absent in Access |

[DDL statements: P11 | analysis/BATCH-04/schema/ddl-all.txt | all `ALTER Table … ADD …` literals] · [Applied/not-applied verdicts: P07 | analysis/BATCH-07/migration-proof.md | §2] · [Shipped presence: P07 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

**VERIFIED partition of the 228 embedded column-`ADD` statements** (recomputed here by matching every `ALTER Table <t> ADD <col>` literal against the shipped 2019 payload, case-insensitively — which is how Jet resolves identifiers):

| Outcome | Statements | Distinct (table, column) pairs | Notes |
|---|---:|---:|---|
| Target column **is present** in the shipped payload | **201** | — | includes the 15 `Patients` statements (`branche`, `SecWord`, `grant13..grant17`) that the published reconciliation report marks NOT-APPLIED |
| Target **table is absent** from the Access payload | **6** | 6 (`useraccounts`×3, `IgEallergy`×3) | SQL-Server-only tables |
| Target column is **genuinely absent** from an existing Access table | **21** | **17** | `lipids.nonhdl` · `BloodGases.pO2AA1` `pO2AA2` `ctCO2` `Aniongap` `HCO3std` `FiO2` `ctHB` `TempRAT` · `patienttest.NatighU` · `Proelectrophoresis.Beta2` `immunolgo` · `urine.testid` · `Helicobacter.hpab` `hpbiop` `hpiga` · `pregnancy.normalrange3` |

[DDL statements: P11 | analysis/BATCH-04/schema/ddl-all.txt | the 228 `ALTER Table … ADD …` literals] · [Shipped presence: P07 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

The **published partition** is `22 added · 145 pre-existing · 61 not applied (23 SQL-Server-only + 38 in existing Access tables)`. [P07-08 | analysis/BATCH-07/migration-proof.md | §2 summary table] · [P07-08 | analysis/BATCH-07/migration-proof.json | `summary` object] The published figures are **over-stated on the "not applied" side** because the checker matched table and column names **case-sensitively** against a case-insensitive engine — see §9.2 for the full list of affected verdicts.

---

## 5. Relationships

Every relationship below is classified as **explicitly documented** (an explicit join, sub-query or predicate exists in the extracted SQL), **strongly inferred** (name + type identity plus a supporting runtime predicate), or an **unverified candidate** (name plausibility only, or the widths contradict the link). Identifier prefixes `R`/`I`/`U` are documentation-only labels created by this document.

### 5.1 EXPLICITLY DOCUMENTED (12)

| # | Relationship | Cardinality | Evidence |
|---:|---|---|---|
| R1 | `patientinfo.patientid` → every profile table's `patientid` | 1 : N | **Explicit `INNER JOIN` in the extracted SQL**: `SELECT hba1c.requestdate, hba1c.patientid, patientinfo.labid FROM patientinfo INNER JOIN hba1c ON patientinfo.patientid = hba1c.patientid WHERE (patientinfo.labid = '` — and the same pattern for `Helicobacter`, `ratios`, `pt`. [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 72D698, VA 730F40, VA 72FC70, VA 6CAFD4] |
| R2 | `patientinfo` is the patient master; `patienttest` is the order/result index | 1 : N | The two most-referenced tables (428 and 343 statements), always joined on `patientid`. [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| rows `patientinfo`, `patienttest`] |
| R3 | `patienttest.testcode` → `testtable.testcode` | N : 1 | `testtable.testcode` is the catalogue key (19 qualified references); `patienttest.testcode` is its FK. [P11 \| analysis/BATCH-04/sql_v1605/columns.csv \| rows `testtable.testcode` (19), `patienttest.testcode` (36)] |
| R4 | `normalrange.testcode` → `testtable.testcode` | N : 1 | `normalrange.testcode` (26 qualified refs) is the same domain as `testtable.testcode`. [P11 \| analysis/BATCH-04/sql_v1605/columns.csv \| rows `normalrange.testcode`, `testtable.testcode`] |
| R5 | `antibiotic.antiid` → `cultureanti.antiid` | 1 : N | **Explicit sub-query**: `SELECT * From antibiotic WHERE (antiid NOT IN (SELECT antiid AS sdsdsd From cultureanti WHERE patientid= '` — i.e. `cultureanti.antiid` is a FK to `antibiotic.antiid`. [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| row `antibiotic`, `sample_statement`] |
| R6 | `sharekathesab.sherkaid` → `sharekat.sherkaid` | N : 1 | `sharekat.sherkaid` Long Integer (PK) and `sharekathesab.sherkaid` Long Integer (FK) — same type and name; `sharekathesab` is the ledger of `sharekat`. [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [sharekat] / [sharekathesab]] |
| R7 | `seana.instrumentid` → `instrument.instrumentid` | N : 1 | `Select * from seana where instrumentid=` · `select * from instrument where instrumentid=`. [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| rows `seana`, `instrument`] |
| R8 | `customtesttable.customgroupcode` → `customgrouptable.customgroupcode`; `customtesttable.testcode` → `testtable.testcode` | N : 1 | `select * FROM customtesttable where testcode=`; `Select customgroupcode,customgroupname from customgrouptable order By customgroupcode`; both FK columns are declared `Integer NOT NULL`. [P11 \| analysis/BATCH-04/sql_v1605/tables.csv \| rows `customtesttable`, `customgrouptable`] · [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [customtesttable]] |
| R9 | `patientinfo.barcode` → `barcodes.barcode` | N : 1 (soft) | `patientinfo.barcode` Text (25) vs `barcodes.barcode` Text (50) NOT NULL — **different widths**, so it is a soft/logical link only. [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [patientinfo] / [barcodes]] |
| R10 | `patientinfo.gehaName` → `Gehats.gehahname` | N : 1 (soft) | Both Text; `gehaName` is written by the 1.605 DDL and `Gehats.gehahname` is the master name. [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| `ALTER Table patientinfo ADD gehaname varchar(50)`] · [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [Gehats]] |
| R11 | `patientinfo.labid` → the lab/branch scope | 1 : N | `patientinfo.labid` is the **filter key in every "Top N tests" report query**: `… FROM patientinfo INNER JOIN <profile> ON patientinfo.patientid = <profile>.patientid WHERE (patientinfo.labid = '`. [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 72D698, VA 72FC70, VA 730F40] |
| R12 | `patienttest` ⇄ `testtemp` (one-to-one staging copy) | 1 : 1 | `testtemp` shares **27 of `patienttest`'s 46 columns**, adds one column of its own (`detelethis`), and omits the 19 `patienttest`-only columns (`RESULTCASEPRINT`, `resultt1..resultt4`, the six user/date audit columns, `printnum`, `testpriceoutmadfo`, `send`, `commentx`, `Timeout`, `Taketime`); it is the in-progress staging table. [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [testtemp]] vs [CREATE TABLE [patienttest]] |

### 5.2 STRONGLY INFERRED (20)

| # | Relationship | Basis | Class |
|---:|---|---|---|
| I1 | `patienttest.subgroupcode` → `subgrouptable.subgroupcode` | Name identity + `SHAPE {SELECT subgrouptable.subgroupcode, subgrouptable.subgroupname FROM subgrouptable …}` | INFERRED |
| I2 | `patienttest.testsimp` → `testtable.testsimp` | Name identity; `testtable.testsimp` (16 refs) is the natural key | INFERRED |
| I3 | `patienttest.testcode` → `testtable.testcode` | Same as R3 | INFERRED |
| I4 | `testtable.subgroupcode` → `subgrouptable.subgroupcode` | Name identity | INFERRED |
| I5 | `normalrange.subgroupcode` → `subgrouptable.subgroupcode` | Name identity | INFERRED |
| I6 | `comments.testcode`/`comments.subgroupcode` → `testtable`/`subgrouptable` | `SELECT comments FROM comments where testcode in (…)` | INFERRED |
| I7 | `testname.testcode`/`subgroupcode`/`arrangnum` → `testtable` | `testname` is a denormalised view of the catalogue (identical field names) | INFERRED |
| I8 | `patienttest.loggroup` / `testtable.loggroup` → `loggroup.logname` (**not** `logid`) | The FK column is `Text (50)` = `loggroup.logname` width; `loggroup.logid` is `Long Integer` and is never used as a join target in the SQL | INFERRED |
| I9 | `payment.patientid` → `patientinfo.patientid` | Same name/type; `Select * from payment where patientid = '` | INFERRED |
| I10 | `payment.gehah` → `Gehats.gehahname` | Same 50-char width; `payment.gehah` is the referring entity | INFERRED |
| I11 | `patienttotal.patientid` → `patientinfo.patientid` | Same name/type; `SELECT * FROM patienttotal where patientid = '` | INFERRED |
| I12 | `patientinfo.referredbyname` / `referredbysefa` → `Gehats.gehahname` / `gehahsefa` | Same widths (40 / 20) and identical names in `Gehats` | INFERRED |
| I13 | `history.labid` → the lab scope (same domain as `patientinfo.labid`) | Both used as lab filters, but widths differ (50 vs 13) | INFERRED (weak) |
| I14 | `smslist.smsgroup` → `smsgroups.smsgroup` (**name-to-name**, not `ID`) | Both Text (50); the runtime always filters `smsgroups` by `smsgroup`/`grouptype` and `smslist` by `smsgroup`/`smstype` — never by `smsgroups.ID` | INFERRED |
| I15 | `wasl.testcode`/`subgroupcode` → `testtable`/`subgrouptable` | Same names/types (Long Integer) | INFERRED |
| I16 | `patienttestgroup.maintestcode` → `testtable.testcode` | Same name/type as `patienttest.testcode` | INFERRED |
| I17 | `testtemp.patientid` → `patientinfo.patientid` | Same name/type; `testtemp` mirrors `patienttest` | INFERRED |
| I18 | `SMSSender.patientid` → `patientinfo.patientid` | `Select * from SMSSender where patientid=` | INFERRED |
| I19 | `cultureanti.patientid` → `patientinfo.patientid`; `cultureanti.culutrenum` → `cultures.cultid` | Same names (`culutrenum` appears in both `cultureanti` and `antibiotic`) | INFERRED |
| I20 | `antibiotic.antisymbol` ⇄ `antibio.antisymbol` | Both Text; `antibio` is the 2-column symbol dictionary, `antibiotic` the 25-column catalogue — `antibiotic.antisymbol` is Text (50) vs `antibio.antisymbol` Text (20) | INFERRED (weak) |

### 5.3 UNVERIFIED CANDIDATES (11)

| # | Candidate | Why it cannot be confirmed | Class |
|---:|---|---|---|
| U1 | `PTC.constid` → a control-chart series | `PTC` has no patient column; `ConstID` is a plain auto-number. The control curve rows are (time, concentration) pairs. | UNVERIFIED |
| U2 | `converts.testsimp` → `testtable.testsimp` | `converts.testsimp` is Text (100) while `testtable.testsimp` is Text (50) — the join key is a name, not an id. | UNVERIFIED |
| U3 | `pricelist.testsimp` → `testtable.testsimp` | Same issue (Text (50) both) — plausible but unproven. | UNVERIFIED |
| U4 | `customtesttable.testsimp` → `testtable.testsimp` | Same. | UNVERIFIED |
| U5 | `insulin.id` → any catalogue | `insulin` holds `(id Integer NOT NULL, insulin Text (100) NOT NULL)` — an ordered list of insulin types; no FK. | UNVERIFIED |
| U6 | `Labbranch.branchid` → `patients.branche` | `patients.branche` is `Integer`, `Labbranch.branchid` is `Long Integer` — plausible but the SQL never joins them; branch membership is derived from `patientid` positions instead. | UNVERIFIED |
| U7 | `phone.contactid` → `patientinfo` | `phone` is a standalone address book (19 columns incl. `birthday`, `mail1a/b`, `land1/2`) with no patient key at all. | UNVERIFIED |
| U8 | `noteic.noteid` → `patientinfo.patientid` | `noteic` has `noteid`, `noteuser`, `notedate`, `noteend`, `fromuser`, `thenote` — **no patient column**. It is an internal note queue. | UNVERIFIED |
| U9 | `shopping.matlobid` → `patientinfo.patientid` | `shopping` is a supply ledger with no patient key. | UNVERIFIED |
| U10 | `reportview.stripnum` → anything | Pure layout table. | UNVERIFIED |
| U11 | `Patient_samples` / `samples` → `patientinfo.patientid` | `samples` exists only in SQL (`Select * from samples where patientid = '`) and never appears in the Access payload; the VB6 object `Patient_samples` (89 methods) is the matching screen. | INFERRED (strong) but the table's other columns are NOT RECOVERABLE |

### 5.4 Relationship counts and counting method

| Class | Count | Counting method |
|---|---:|---|
| Explicitly documented | **12** | Rows `R1`–`R12` of §5.1 |
| Strongly inferred | **20** | Rows `I1`–`I20` of §5.2 |
| Unverified candidates | **11** | Rows `U1`–`U11` of §5.3 |
| **Total relationship statements** | **43** | 12 + 20 + 11; re-counted row-by-row |

Note that `I3` restates `R3` under a weaker class, so the number of *distinct* links asserted by the document is smaller than 43; the 43 figure counts relationship **statements**, not distinct links.

---

## 6. Identifier semantics

### 6.1 `patientid` — 13 characters, composite

`patientid` is **`Text (13)`** in every table that carries it. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

It is **not** a surrogate key: the binary slices it positionally to derive lab, branch and display identifiers.

| Slice `(start, len)` | Meaning | `SUBSTRING` form | `MID` form | total |
|---|---|---:|---:|---:|
| `(2,1)` | **first half of the branch code** | 18 | 18 | 36 |
| `(9,1)` | **second half of the branch code** | 18 | 18 | 36 |
| `(2,1) + (9,1)` `AS bran` | the **complete branch code (2 chars)** | — | — | 18 statements |
| `(5,2)` `AS mmmd` | a 2-char "mmm" grouping code | 16 | 16 | 32 |
| `(7,2)` `AS mmmd` | a second "mmm" grouping code (used in the price/age statistics queries) | 13 | 15 | 28 |
| `(3,4)` | a 4-char slice used for `COUNT(...)` grouping | 30 | 31 | 61 |
| `(3,2)` | a 2-char slice used as an equality filter | 29 | 31 | 60 |
| `(5,4)` | a 4-char slice used for `COUNT(...)` grouping | 16 | 20 | 36 |
| `(10,3)` `AS patid` | the **3-char short display id** (positions 10–12) | 7 | 9 | 16 |
| `(2,11)` | positions 2–12 (11 chars) used as an equality filter | 1 | 1 | 2 |
| `(1,6)` | a 6-char slice from position 1 | 0 | 1 | 1 |

**308 slice occurrences across 109 of the 1,797 statements.**

*Counting method:* the figure **308** is the sum of the `total` column over the **ten single-slice rows** of the table above (36 + 36 + 32 + 28 + 61 + 60 + 36 + 16 + 2 + 1 = 308). The composite `(2,1) + (9,1) AS bran` row is a two-slice expression and is reported separately as **18 statements**; including it, the slice-bearing occurrence count of the table is **326**. The "109 of the 1,797 statements" figure is a count of *distinct statements* and is not derivable by summing the table.

[P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 72714C / 72764C / 727AA0 / 727F74 / 7283A4 / 728868 and the `SUBSTRING(patientid,…)` predicate family]

**The composite layout (INFERRED, high confidence):** position 1 = a constant or year prefix; position 2 = branch digit A; positions 3–6 = a serial block; positions 5–6 or 7–8 = the "mmm" grouping; position 9 = branch digit B; positions 10–12 = the short display id; position 13 = a check character. The published model states that `mid(patientid,10,3)` is "a short display identifier derived from the composite 13-char key". [P11 | analysis/CUMULATIVE/02-data-model.md | §4 آليات Jet الخاصة] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 682F56 `Select SUBSTRING(patientid,10,3) as patid , patientid , patientnamear , completes from patientinfo where requestdate = '`]

**Branch digit (EXPLICIT):** the branch-split tool `Patient Data Transport.exe` filters by branch with **`SUBSTRING(patientid,9,1)`** and carries the guard string `'<<< Blank >>>'`. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 9] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-035]

> **Two readings of the same evidence.** (a) The P11 baseline states that `SUBSTRING(patientid,9,1)` "= branch digit" — a single-digit branch discriminator used by the transport tool. [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 9] (b) The v1.605 statistics SQL actually derives the branch key as the **pair** `SUBSTRING(patientid,2,1) + SUBSTRING(patientid,9,1)` `AS bran`, i.e. a **2-character branch code**, while position 9 alone is used only by the separate transport tool. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 72714C, VA 72764C, VA 727AA0, VA 727F74, VA 7283A4, VA 728868] Both are consistent with a 13-char key whose 9th character is a branch component; which digit the branch is keyed on is **UNVERIFIED**.

### 6.2 `labid` — three incompatible types, one concept

| Location | Type | Meaning |
|---|---|---|
| `patientinfo.labid` | Text (13) | the accession's lab/branch scope; the filter key of every "Top N" report query |
| `history.labid` | Text (50) | the lab scope of a history/report template |
| `MyLabSetting.LabID` | Integer | the lab-settings key; the runtime hard-codes `LabID = 100` |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo] / [history] / [MyLabSetting]] · [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 687106, VA 6A2872, VA 68269A]

**`patientinfo.labid` (Text 13) vs `patientid` (Text 13)** — same width, and `patientinfo.labid` is referenced 213 times versus `patientinfo.patientid` 341. **INFERRED**: `labid` is a *lab code*, not a patient id; but both being 13 chars is a live source of confusion. [P11 | analysis/BATCH-04/sql_v1605/columns.csv | rows 2 and 4]

### 6.3 `testcode`

- `testtable.testcode` = **Long Integer**, the catalogue's primary key; `patienttest.testcode` / `patienttestgroup.testcode` / `normalrange.testcode` / `comments.testcode` / `customtesttable.testcode` = **Integer** (same domain, narrower type). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]
- `testtable.testcodebill` = **Text (13)**, added in 1.605 — a **billing code** distinct from the numeric test code. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 678036 `ALTER Table testtable ADD testcodebill nvarchar(13)`]
- `semen.testcode` = **Smallint**, added in 1.605 — a *per-sample* test reference, not a catalogue FK. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 6742DA]
- `pictures.testcode` = **Long Integer**, `testtemp.testcode` = **Long Integer**, `LBC.testid` = **Smallint** — the latter two are *instance* ids, not catalogue codes. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [pictures] / [testtemp]]
- `urine.testid` = Smallint, added by 1.605 DDL but **not applied** in the Access payload. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67B3F2]

**The system runs two parallel test identities:** a numeric `testcode` and the short-name key `testsimp` (Text 50). `testsimp` is the more widely used join key — `testtable.testsimp` has 16 qualified references, `patienttest.testsimp` 50, and `converts`/`pricelist`/`customtesttable` are all keyed by `testsimp`. [P11 | analysis/BATCH-04/sql_v1605/columns.csv | rows `patienttest.testsimp`, `testtable.testsimp`]

### 6.4 `subgroupcode`

`subgrouptable.subgroupcode` = **Long Integer** (the profile id); referenced as `Integer` in `testtable`, `patienttest`, `patienttestgroup`, `normalrange`, `comments`, and `Long Integer` in `wasl` and `testtemp`. Same domain, three declared widths. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

`subgrouptable` = the **profile (test category) catalogue**: `subgroupcode` · `subgroupname` · `arname` (Arabic name) · `deleteprotect`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [subgrouptable]]

### 6.5 `arrangnum`

`arrangnum` = **report/print ordering index**. Declared `Integer` in `testtable`, `patienttest`, `patienttestgroup`; `Long Integer` in `testname` and `testtemp`. It is *not* unique — no unique index on it is documented, and the observed value set in the archived store is not a V2 datum and is therefore not reproduced here. Class for the V2 value domain: **NOT DOCUMENTED**. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists]

`arrangnum` also appears in `testname` (`Long Integer`) and `cultureanti` (`Integer` — the sensitivity-disc ordering). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [cultureanti]]

### 6.6 `printnum`, `printwith`

- `patienttest.printnum` = **Double** — a *print counter*, not a print flag. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patienttest]]
- `patienttest.printwith` = **Boolean NOT NULL** — "print together with" (group printing). [P07-08 | … | CREATE TABLE [patienttest]]
- `patienttest.resultprint` = **Boolean NOT NULL** — "has been printed". The two are distinct and both are reported columns in the on-screen result grid (`Test Name | Result | Unit | L or H | Normal Range | Verified | Print`). [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3 row `Patient.granche`·`Labbranch`] for the branch model; the grid column set is quoted in [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-043]
- `testtable.printwith` = Boolean NOT NULL — the *catalogue-level* default for the same flag. [P07-08 | … | CREATE TABLE [testtable]]
- `Gehats.printorno` = Boolean NOT NULL — "print the referral number". [P07-08 | … | CREATE TABLE [Gehats]]

### 6.7 Branch code

Two independent mechanisms coexist:

1. **Derived from `patientid`** — `SUBSTRING(patientid,2,1) + SUBSTRING(patientid,9,1)` `AS bran`, used by the statistics queries. [P11 | analysis/BATCH-04/sql_v1605/statements.csv | VA 72714C and siblings]
2. **Stored** — `patients.branche` (Integer, operator's branch), `testtable.branch` (Text (50), test's owning branch), `Labbranch.branchid` / `Labbranch.branchname` (the branch registry). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients] / [testtable] / [Labbranch]]

`testtable.branch` is **Text (50)** while `patients.branche` is **Integer** — they are not directly comparable. [P07-08 | … | CREATE TABLE [testtable] / [patients]]

The branch master is queried as `SELECT * FROM labbranch order by branchname`, `FROM Labbranch where branchid=`, `FROM Labbranch where branchname like `. [P11 | analysis/BATCH-04/sql_v1605/tables.csv | row `labbranch`]

## 7. Naming traps

### 7.1 `patientinfo` vs `patients` vs `patient` vs `patien` vs `pa` vs `patientid`

| Token | What it really is | Trap |
|---|---|---|
| `patientinfo` | **The patient master** (39 cols in the 2019 payload). One row per accession. | Most referenced table (428 statements). |
| `patients` | **The operator/user table** (33 cols) — `patientusid`, `patientusname`, `grant1..grant17`, shift times. | The name says "patients" but the rows are **staff accounts**. The prefix `patientus…` = "patient user". |
| `Patients` (in the DDL) | The **same operator table**, capitalised — Jet is case-insensitive so `Patients` ≡ `patients`. The 1.605 DDL adds `branche`, `SecWord`, `grant13..grant17` to it. | A reader sees `ALTER Table Patients ADD grant13` and assumes a patient table. |
| `patient` | **Not a table** — a SQL alias. `SELECT patienttest.resultt,patienttest.resultt1,… FROM patienttest …` | The extractor listed it as a table (3 statements). |
| `patien` | **Not a table** — a truncated alias of a "Top 10 Electrolytes" query. | Appears once in the 117-list. |
| `pa` | **Not a table** — a truncated alias of a "Top 5 trace" query. | Appears once. |
| `p` | **Not a table** — alias of a `patientinfo` projection query. | Appears twice. |
| `t` | **Not a table** — alias of a `patienttest` projection query. | Appears once. |
| `patientid` | A **column**, Text (13), in 58 tables. | Also the name of a *table* in the SQL-Server `patients` catalog context. |
| `patienttotal` | A **real table** — a per-patient roll-up (`t01..t12`), not a patient master. | Confusable with `patientinfo`. |

[P11 | analysis/BATCH-04/sql_v1605/tables.csv | rows `patientinfo`, `patients`, `patient`, `patien`, `pa`, `p`, `t`, `patienttotal`] · [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patientinfo] / [patients] / [patienttotal]]

### 7.2 `normalrange` (table) vs `normalrang` (column)

- **`normalrange`** = the reference-range **table** (18 cols, 95 SQL references).
- **`normalrang`** = a **column** that appears in *four different places* with *two different types* (Text (255) in the two master tables, Memo/Hyperlink (255) in the two 1.605-era tables):
  - `normalrange.normalrang` — Text (255) — the human-readable range text.
  - `patienttest.normalrang` — Text (255) — the **frozen copy** of the range at entry time.
  - `wasl.normalrang` — Memo/Hyperlink (255) — added in 1.605.
  - `testtemp.normalrang` — Memo/Hyperlink (255) — added in 1.605 by `ALTER Table testtemp ALTER COLUMN normalrang MEMO`.

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [normalrange] / [patienttest] / [wasl] / [testtemp]] · [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67413A, VA 678436]

Also distinct: **`normalrange3`** (added to `pregnancy` in 1.605, `varchar(MAX)`/MEMO, **not applied**) and **`REFRANGE`** (Text(1), added to both `testtable` and `normalrange` in 1.605). [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67B73E / VA 6811A6, VA 67AB12, VA 67AB9A]

### 7.3 `antibio` vs `antibiotic`

- **`antibio`** = 2 columns: `antisymbol` Text (20) NOT NULL, `scientificname` Text (50). A **symbol → scientific-name dictionary**.
- **`antibiotic`** = 25 columns: `antiid` Long Integer, `culutrenum` Integer, `culutretype` Text (50), `antisymbol` Text (50), `scientificname` Text (50), `anticomname1..8` Text (50), `anticomprint1..8` Boolean NOT NULL, `prgnancy` Boolean NOT NULL (sic — typo for "pregnancy"), `child` Boolean NOT NULL, `Sensitivity` Text (50), `Sensitiveunit` Text (10). The **full anti-biogram catalogue**.

`antibio.antisymbol` is Text (20) but `antibiotic.antisymbol` is Text (50) — the same logical key at two widths. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [antibio] / [antibiotic]]

### 7.4 `PTC` (table) vs `PTCONS` (a value)

- **`PTC`** = the PT control curve: `control` Double NOT NULL, `concent` Double NOT NULL, `ConstID` Long Integer. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [PTC]]
- **`PTCONS`** = a **`constanttable.constantdiscrp` value**, not a table: the row holding the PT constants that the V2 manual names as *ISI, Control Time and Concentration table*. The numbers a live V2 installation stores in that row — the control time, the second-level control time, the ISI and the Westgard flag — are **NOT RECOVERABLE** from this evidence. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [constanttable]] · [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic nots.htm item 1]
- The sibling `CBCCONS` holds the CBC auto-calculation constants documented by the same V2 manual — `3.3` · `8.25` · `7.50` · `6.25` · `6.75` — quoted in full in §4.6; the discriminator label the CBC set is filed under is not stated by any V2-primary source. [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic nots.htm item 1]

### 7.5 `Patients` (DDL) vs `Patients.mdb` (file) vs `Patients_backup.mdb` (file)

- `Patients.mdb` (2019, 2,682,880 B) = the live store, **103 tables**.
- `Patients_backup.mdb` (2019 CD, 2,146,304 B) = the **backup copy shipped on the CD**; it is not the live store, and neither its schema nor any row count or cell value taken from it is used as V2 evidence in this document.
- The DDL's `ALTER Table Patients …` targets the **operator table inside** `Patients.mdb` (in SQL-Server mode, the `patients` catalog), not the file.

[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 `bin\` table — the `Patients.mdb` and `Patients_backup.mdb` rows] · [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | `CREATE TABLE` lines]

### 7.6 `labbranch` vs `branche` vs `Labbranch`

- **`Labbranch`** = the branch registry table (`branchid` Long Integer, `branchname` Text (50) NOT NULL).
- **`branche`** = a **column** on `patients` (Integer) — the operator's branch — added in 1.605.
- **`branch`** = a **column** on `testtable` (Text (50)) — the test's owning branch. Note the differing spelling `branche` vs `branch` for two different things.
- The lowercase token `labbranch` appears in the SQL-table list because the extractor lower-cases; Jet is case-insensitive.

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [Labbranch] / [patients] / [testtable]] · [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 6DC264 `ALTER Table Patients ADD branche smallint`]

### 7.7 `history` in two databases

`history` exists **identically** (25 columns) in both `Patients.mdb` and `data.mdb` in V2. `patientinfo` and `wasl` also exist in **both**, but with different widths:

| Table | `Patients.mdb` (2019) | `data.mdb` (2019) |
|---|---|---|
| `history` | 25 cols | 25 cols (identical definition) |
| `patientinfo` | **39 cols** | **3 cols** (`patientid` Text(13), `patientnamear` Text(50), `completes` Text(1)) |
| `wasl` | **12 cols** | **6 cols** |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [history] / [patientinfo] / [wasl]] · [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [history] / [patientinfo] / [wasl]]

The `data.mdb` `patientinfo` is a **3-column projection** used by the branch-transfer tool (it needs only the id, the name and the completion flag). [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [patientinfo]]

### 7.8 `wasl` / `workpaper`

`wasl` is a **table** (12 cols in `Patients.mdb`, 6 in `data.mdb`); `workpaper` / `workpaper2` are **VB6 form objects**; `testtable.waslname` / `waslname2` are **columns** holding the Work-Sheet names. All four meanings coexist. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [wasl] / [testtable]] · [P11 | analysis/BATCH-04/vb6/v1605/objects.json | objects `workpaper`, `workpaper2`]

### 7.9 `resultIgeAllergy` and the other `Result*` names are **objects, not tables**

`resultIgeAllergy` (231 methods), `ResultFMF` (48), `ResultPCR` (37), `ResulturineAuto` (184), `resulthpylori` (83), `ResultLBC` (33) are **VB6 forms/datareports**. The tables behind them are `IgEallergy`, `FMF`, `LBC`, `Helicobacter`. [P11 | analysis/BATCH-04/vb6/v1605/objects.json | `objects` array] · [P11 | analysis/V-CD-2019/00-baseline-summary.md | §3]

### 7.10 Other silent spellings

| Written as | Means |
|---|---|
| `resultfinsh` | "result **finish**" — the entry-complete flag (misspelled in the schema) |
| `RESULTCASEPRINT` vs `RESULTT` | two different columns on `patienttest` — *case-insensitive print* flag vs the result text |
| `arrangnum` | "**arrange** number" (report order) |
| `culutrenum` / `culutretype` | "**culture** number / type" (missing the `c`) |
| `prgnancy` | "pregnancy" (missing the `e`) in `antibiotic` |
| `mowzaf` | Arabic *mawzif* — the referring/discount entity on `patientinfo` and `payment` |
| `elmadfoo3` / `elbakyma3mal` | Arabic-derived numeric fields (patient age/weight fields) |
| `gehaName` vs `gehahname` | `patientinfo.gehaName` (Text 50) vs `Gehats.gehahname` (Text 40) — **different widths for the same concept** |
| `kawmy` | Arabic "my dear" — the free-text remark field |
| `Khasm` / `khasm` | Arabic "special/exception" — `Gehats.khasm` Double vs `patients.khasmlimit` Long Integer |
| `SMSMob` / `smsMobile` / `smsphone` / `phoneNo1..6` | four distinct mobile-number fields on four tables |
| `customgrouptable` / `customgroupcode` / `customgroupname` | the custom-group dictionary and its two key columns — `customgroupcode` is also the FK column of `customtesttable` |
| `Paste Errors` | a table name **containing a space** |

[P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field lists] · [P11 | analysis/BATCH-04/sql_v1605/tables.csv | rows `patients`, `patienttest`]

---

## 8. Similar identifiers with different meanings

The following identifier families are **superficially similar but semantically distinct** inside the V2 model. Each row states the exact identifier, where it occurs, its declared type, and what it actually denotes, so that a reader of the shipped schema does not merge two unrelated concepts.

### 8.1 The patient-id family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `patientinfo.patientid` | `patientinfo` | Text (13) | the accession key of the patient master; the model's natural key (341 qualified references) |
| `patientid` | 57 other tables (`patienttest`, `patienttestgroup`, `patienttotal`, `payment`, `testtemp`, `SMSSender`, `cultureanti` and every profile table) | Text (13) | the **foreign key** to `patientinfo.patientid` — not an independent identifier |
| `patientsefa` | `patientinfo` | Text (20) | the patient's national id (Arabic form) |
| `patientusid` | `patients` | Long Integer | the **operator account** id — an entirely different entity |
| `patientusname` | `patients` | Text (40) | the operator account name |
| `patientuscap` | `patients` | Text (40) | the operator's capability/role text |
| `patientword` | `patients` | Text (40) | the operator's password text |
| `patientad` / `patientus` | `patients` | Boolean NOT NULL | operator flags (administration / user-active), not patient attributes |
| `patientnamear` | `patientinfo` | Text (40) | the patient's Arabic name |
| `patientage` / `patientageunit` | `patientinfo` | Double / Text (5) | patient age and its unit |
| `patienttotal.*` | `patienttotal` | — | a **per-patient roll-up** table (`t01..t12`), not a patient master |
| `samples.patientid`, `Patient_samples` | SQL-only / VB6 object | — | sample-tracking key / screen, with no counterpart in the Access payload |

### 8.2 The lab and branch family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `patientinfo.labid` | `patientinfo` | Text (13) | the accession's lab scope; the filter key of every "Top N" report |
| `history.labid` | `history` | Text (50) | the lab scope of a report/history template |
| `MyLabSetting.LabID` | `MyLabSetting` | Integer | the settings-row key, hard-coded at `100` at runtime |
| `patients.branche` | `patients` | Integer | the **operator's** branch |
| `testtable.branch` | `testtable` | Text (50) | the **test's** owning branch |
| `Labbranch.branchid` / `branchname` | `Labbranch` | Long Integer / Text (50) | the branch registry master |
| `patientinfo.referredbysefa` / `referredbyname` | `patientinfo` | Text (20) / Text (40) | the referring physician's id / name (the *referrer*, not the branch) |
| `SUBSTRING(patientid,2,1)` + `SUBSTRING(patientid,9,1)` | derived | — | the **derived** 2-character branch code (18 statements) |

### 8.3 The test-identity family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `testtable.testcode` | `testtable` | Long Integer | the catalogue's numeric test key |
| `patienttest.testcode`, `patienttestgroup.testcode`, `normalrange.testcode`, `comments.testcode`, `customtesttable.testcode` | various | Integer | foreign keys onto the catalogue key (narrower declared type) |
| `testtable.testcodebill` | `testtable` | Text (13) | the **billing** code — a string, not a catalogue id |
| `testtable.testsimp` / `patienttest.testsimp` / `converts.testsimp` / `pricelist.testsimp` | various | Text (50) / Text (100) | the **short-name** test identity, used as the model's practical join key |
| `pictures.testcode`, `testtemp.testcode` | various | Long Integer | the **instance** of a test on a given accession, not a catalogue code |
| `LBC.testid`, `urine.testid` | various | Smallint | per-row item ids, not catalogue codes |
| `semen.testcode` | `semen` | Smallint | a per-sample test reference |
| `patienttestgroup.maintestcode` | `patienttestgroup` | Integer | the profile's main test, keyed like `testtable.testcode` |
| `wasl.testcodex` | `wasl` | Text (50) | a **textual** test reference on the Work-Sheet table |
| `testname.testcode` / `arrangnum` | `testname` | — | a denormalised **view** of the catalogue's key and ordering |

### 8.4 The reference-range family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `normalrange` | table | — | the reference-range master table |
| `normalrange.normalrang` | `normalrange` | Text (255) | the human-readable range text as maintained |
| `patienttest.normalrang` | `patienttest` | Text (255) | a **frozen copy** of the range at entry time |
| `wasl.normalrang` | `wasl` | Memo/Hyperlink (255) | the Work-Sheet copy of the range |
| `testtemp.normalrang` | `testtemp` | Memo/Hyperlink (255) | the staging copy of the range |
| `normalrange3` | `pregnancy` | `varchar(MAX)`/MEMO | a pregnancy-specific range field (DDL-added, **not applied**) |
| `REFRANGE` | `testtable`, `normalrange` | Text (1) | the reference-range **mode flag** |
| `normalrange.lowlimit` / `highlimit` / `nolowexe` / `nohighexe` | `normalrange` | Double / Text (20) | the numeric bounds and the exception texts |
| `patienttest.lowlimit` / `highlimit` / `nolowexe` / `nohighexe` | `patienttest` | Double / Text (20) | the same four fields **copied at entry time** |

### 8.5 The work-group family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `loggroup.logid` | `loggroup` | Long Integer | the numeric id of a result work-group — never used as a join target |
| `loggroup.logname` | `loggroup` | Text (50) | the work-group **name** |
| `patienttest.loggroup` | `patienttest` | Text (50) | a **name**, not an id (the inferred target is `loggroup.logname`) |
| `testtable.loggroup` | `testtable` | Text (50) | the catalogue-level default work-group name |
| `patienttest.historyname` / `testtable.historyname` | various | Text (50) | the **history report template** name, not a work-group |
| `history.selector` | `history` | Integer | the report/history template selector |

### 8.6 The referring-entity family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `Gehats.gehahname` | `Gehats` | Text (40) | the referring entity's **name** (master) |
| `patientinfo.gehaName` | `patientinfo` | Text (50) | the referring entity's name **as written on the accession** (50-char variant of the same concept) |
| `payment.gehah` | `payment` | Text (50) | the referring entity recorded on a payment |
| `Gehats.gehahsefa` / `patientinfo.referredbysefa` | various | Text (20) | the referring physician's identifier |
| `Gehats.masolsefa` / `masolname` | `Gehats` | Text (10) / Text (40) | the **owning/manager** of the referring entity — a different role from the referrer |
| `Gehats.khasm` | `Gehats` | Double | the referring entity's **commission** |
| `patients.khasmlimit` | `patients` | Long Integer | the operator's **commission cap** — a different quantity with a similar name |

### 8.7 The anti-biogram family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `antibio.antisymbol` | `antibio` | Text (20) NOT NULL | the **symbol** in the 2-column dictionary |
| `antibiotic.antisymbol` | `antibiotic` | Text (50) | the symbol in the 25-column catalogue (same logical key, different width) |
| `antibiotic.antiid` | `antibiotic` | Long Integer | the catalogue row id (parent of `cultureanti.antiid`) |
| `antibiotic.scientificname` / `antibio.scientificname` | various | Text (50) | the scientific name, duplicated in both tables |
| `cultureanti.antiid` | `cultureanti` | — | the antibiotic referenced by a culture susceptibility row |
| `antibiotic.culutrenum` / `cultureanti.culutrenum` | various | Integer | the culture number (same name, two tables) |

### 8.8 The SMS family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `smsgroups.ID` | `smsgroups` | Long Integer | the auto-number of a recipient group |
| `smsgroups.smsgroup` | `smsgroups` | Text (50) | the group's **name** — this, not `ID`, is what `smslist` carries |
| `smslist.smsgroup` | `smslist` | Text (50) | the referenced group name (name-to-name link) |
| `smsgroups.grouptype` | `smsgroups` | Integer | the discriminator 0/1 between two recipient groups |
| `smslist.smstype` | `smslist` | Integer | the discriminator 0/1 on the recipient list |
| `smslist.send` | `smslist` | Integer | the "already sent" flag |
| `SMSSender.SMSautonum` | `SMSSender` | Long Integer | the outbound-log row id |
| `SMSSender.smsMobile` | `SMSSender` | Text (100) | the mobile number actually dialled (widened from Text (20)) |
| `smslist.smsphone` | `smslist` | Text (20) | the stored recipient number |
| `patientinfo.SMSMob` | `patientinfo` | Text (15) | the **patient's** mobile number |
| `MyLabSetting.phoneNo1..6` / `phonenum` | `MyLabSetting` | Text (15) / Integer | the **gateway's** sender numbers |

### 8.9 The money and pricing family

| Identifier | Location | Type | Actually denotes |
|---|---|---|---|
| `patientinfo.totalprice` | `patientinfo` | Double | the accession's total |
| `patientinfo.totalpricedisc` / `discount` / `discount100` | `patientinfo` | Double | discount amounts |
| `patientinfo.pricemethod` | `patientinfo` | Text (10) | the pricing method code |
| `patienttest.testprice` | `patienttest` | Double | the price of one ordered test |
| `patienttest.testpriceout` / `testpriceoutmadfo` | `patienttest` | Double | the outsourced price |
| `testtable.patientprice` / `labprice` / `otherlabprice` | `testtable` | Double | the three catalogue price points |
| `payment.money` | `payment` | Double | the amount actually paid |
| `Gehats.omola` | `Gehats` | Double | the referring entity's commission percentage |
| `pricelist` / `pricemenu` | tables | — | price-list master and its name menu |

### 8.10 The "patient" tables that are not patient tables

| Identifier | Location | Actually denotes |
|---|---|---|
| `patients` | table | the **operator / user-account** table |
| `useraccounts` | SQL-only table | the **SQL-Server** operator table (the Access equivalent is `patients`) |
| `patienttotal` | table | a per-patient totals roll-up |
| `patienttestgroup` | table | profile-group ordering |
| `patienttest` | table | the test-order/result index |
| `patientinfo` | table | the patient master |
| `patient_samples` / `Patient_samples` | VB6 object / SQL-only table | the sample-tracking screen/table |

### 8.11 The Work-Sheet family

| Identifier | Location | Actually denotes |
|---|---|---|
| `wasl` | table (12 cols in `Patients.mdb`, 6 in `data.mdb`) | the Work-Sheet **analysis list** |
| `workpaper` / `workpaper2` | VB6 form objects | the two Work-Sheet **screens** |
| `testtable.waslname` / `waslname2` | columns | the Work-Sheet **names** on the catalogue |
| `wasl.waslname` / `waslname2` | columns | the Work-Sheet names on the analysis list |
| `wasl.testno` | column | the Work-Sheet line number |

### 8.12 The print and result family on `patienttest`

| Identifier | Type | Actually denotes |
|---|---|---|
| `RESULTT` | Text (50) | the primary result value |
| `resultt1` … `resultt4` | Text (50) | the four sub-result values |
| `resultt` (on `wasl`) | Text (50) | the Work-Sheet result value — same name, different table |
| `RESULTCASEPRINT` | Text (15) | the case-insensitive print flag |
| `resultprint` | Boolean NOT NULL | "has been printed" |
| `printwith` | Boolean NOT NULL | "print together with" (group printing) |
| `printnum` | Double | a print **counter** |
| `printuser` / `printdate` | Text (40) | who printed / when (stored as text) |
| `resultfinsh` | Boolean NOT NULL | entry-complete flag (misspelled) |
| `resultreview` | Boolean NOT NULL | reviewed flag |

---

## 9. Schema ambiguities and conflicts

### 9.1 The published column count for the 2019 payload (1,617) contradicts the preserved dump (1,682)

- **Published:** "103 جدولًا · 1,617 عمودًا" — repeated in the P11 baseline summary, the deployment-payload report and the evidence register (EV-ANA-045). [P11 | analysis/V-CD-2019/00-baseline-summary.md | §1 row 14] · [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1 table row `Patients.mdb`] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-045]
- **Preserved dump:** `analysis/BATCH-07/db/v2019-Patients.mdb.sql` contains **103 `CREATE TABLE` statements** and **1,682** bracketed field definitions. The figure 1,682 is **independently reproducible** by summing the 103 per-table column counts of §2.2 of this document. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | field lines]

**Both readings are cited; the preserved schema dump is treated as authoritative here.** Class: **VERIFIED conflict, unexplained**.

### 9.2 The `Patients` ALTERs are recorded as NOT-APPLIED but are demonstrably applied — and the same case-sensitivity error corrupts 9 further verdicts

- **Published:** every one of the 15 `Patients` alter-checks carries `present_in_v2019: False` and `verdict: NOT-APPLIED`; the report concludes that 23 unapplied ALTERs target "SQL-Server-only tables — `Patients` (a SQL Server table name, vs `patientinfo` in Jet) … so they can never apply to the shipped Access database". [P07-08 | analysis/BATCH-07/migration-proof.json | `alter_checks` where `table == "Patients"`] · [P07-08 | analysis/BATCH-07/migration-proof.md | §3]
- **Preserved schema:** the 2019 Jet `patients` table **has** `branche` Integer, `SecWord` Text (10) and `grant13`..`grant17` Boolean NOT NULL — exactly the seven columns the DDL adds. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients]]
- **Semantic error inside the published reasoning:** `Patients` is **not** the SQL-Server patient master. The DDL adds `branche`, `SecWord` and `grant13..grant17` to it — permission/branch columns that sit alongside the pre-existing `grant1..grant12` on the **operator** table `patients`. The Jet table `patients` and the SQL-Server table `Patients` are the *same logical table* (the operator account table); the patient master is `patientinfo` in both engines. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients]] · [P11 | analysis/BATCH-04/schema/ddl-all.txt | VAs 6DC264–6DC714]
- **Explanation (INFERRED):** the checker matched table **and** column names case-sensitively against a case-insensitive engine. Every verdict that fails on casing alone is wrong. The affected published `NOT-APPLIED` verdicts whose columns **are** in fact present in the shipped payload are: `Patients.branche`, `Patients.SecWord`, `Patients.grant13`..`grant17` (7 columns) · `patientinfo.gehaname` (shipped as `gehaName`) · `cultures.Few5`..`Few8` (shipped as `few5`..`few8`) · `prostaticx.crystalp` `crystalpr` `crystalp2` `crystalp2r` `crystalpt` (shipped as `Crystalp` `Crystalpr` `Crystalp2` `Crystalp2r` `crystalpt`) · `urine.T56` `T57` (shipped as `t56` `t57`). [P07-08 | analysis/BATCH-07/migration-proof.json | `alter_checks` entries with `verdict == "NOT-APPLIED"`] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [patients] / [patientinfo] / [cultures] / [prostaticx] / [urine]]
- **Consequence:** the published "22 columns added by the embedded script" / "61 not applied" / "23 SQL-Server-only" totals are **overstated**; the verified partition (201 present · 6 on absent tables · 21 genuinely absent = 17 distinct columns) is in §4.23. Class: **VERIFIED conflict; the published verdicts are demonstrably incorrect.**

### 9.3 `IgEallergy` is listed among the V2 payload's added tables, but it is not there

- **Published:** the published table-addition list is `Helicobacter`, `insulin`, `IgEallergy`, `patienttestgroup`, `SMSSender`, `SMStemplate`, `smsgroups`, `smslist`, `MyLabSetting`, `testtemp`, `Paste Errors` — **eleven names for a list announced as "10 tables"**. [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-045] · [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.1]
- **Preserved schema:** `IgEallergy` is **absent** from the 103-table payload; the ten names of that list that are present are `Helicobacter`, `MyLabSetting`, `Paste Errors`, `SMSSender`, `SMStemplate`, `insulin`, `patienttestgroup`, `smsgroups`, `smslist`, `testtemp`. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE list] · [P07-08 | analysis/BATCH-07/migration-proof.md | §1 "IgEallergy | — | — | 0 | ABSENT"]
- The reconciliation report itself records `IgEallergy` as **ABSENT** and places it in the SQL-Server-only bucket. [P07-08 | analysis/BATCH-07/migration-proof.md | §3]

Class: **VERIFIED conflict** — the published documents disagree with each other and with the preserved schema.

### 9.4 `column-evolution.csv`'s `v2019_columns` is **not** the shipped table width

The `v2019_columns` column of `column-evolution.csv` counts only the columns **named in the V2 DDL statements** for that table, not the columns of the shipped table. Worked examples:

| Table | `column-evolution.csv` `v2019_columns` | Actual shipped width (2019 payload) |
|---|---:|---:|
| `patientinfo` | 5 | **39** |
| `patienttest` | 1 | **46** |
| `cultures` | 10 | **35** |
| `normalrange` | 1 | **18** |
| `testtemp` | 1 | **28** |
| `Helicobacter` | 9 | **6** |
| `fmf` | 1 | **NOT RECOVERABLE** |
| `igeallergy` | 3 | **NOT RECOVERABLE** (table absent) |

[P04 | column-evolution.csv | `v2019_columns` column] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE field counts]

The same CSV's `removed_in_v2019` column is also misleading and must **not** be read as a list of removed columns: it enumerates the columns that **no V2 DDL statement mentions** (i.e. the columns the runtime schema script leaves untouched). It records no removal event and no column absence for any V2 table, so it cannot support a statement that a column is absent from a shipped V2 table. The only column on which the two V2-shipped artefacts disagree is `subgrouptable.groupcode`, which the V2-shipped `Branch_Data.mdb` template carries and the V2-shipped live `Patients.mdb` does not — with **no `DROP COLUMN` statement anywhere in the embedded DDL**. The CSV additionally lists `normalrange.criticalrang/lowlcrit/highlcrit/criticalexe/criticalcomment` and `pricelist.gehahname`; no V2-shipped artefact corroborates those two, so they remain **UNVERIFIED** for V2. [P04 | column-evolution.csv | `removed_in_v2019` column] vs [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [normalrange] / [pricelist] / [subgrouptable]] · [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [subgrouptable]]

### 9.5 `history` column count: 23 (published) vs 25 (shipped)

Published as 23 in the cumulative data model and in EV-ANA-014; the shipped schema has **25** (`selector`, `labid`, `requestdate`, `column1..column20`, `printflag`, `noofcol`). [P11 | analysis/CUMULATIVE/02-data-model.md | §1 row `history`] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-014] vs [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql | CREATE TABLE [history]]

### 9.6 The 2019 payload dump contains exactly 103 `CREATE TABLE` statements and 103 distinct names

Verified by re-counting the dump and by re-counting the §2.2 inventory table of this document: 103 `CREATE TABLE` lines, no duplicate names, no case-variant duplicates. The published figure of "103 tables" is therefore sound; only the accompanying column count is not (§9.1). [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | `CREATE TABLE` lines]

### 9.7 `Patients_backup.mdb` is a shipped backup copy, not the live store

`RL_CD2019Access\bin\Patients_backup.mdb` (2,146,304 B) is the backup copy shipped on the 2019 CD. The live V2 store is `RL_CD2019Access\bin\Patients.mdb` (2,682,880 B, 103 tables). The backup's own schema, column and row counts are **not** V2-live figures; no row count, value distribution or cell value taken from it is quoted anywhere in this document. [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 `bin\` table — the `Patients_backup.mdb` and `Patients.mdb` rows] · [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | `CREATE TABLE` lines]

**Rule for this document:** no count or value taken from the shipped backup copy is cited at all; the live V2 store's row counts are **NOT RECOVERABLE** (§2.1, §10).

### 9.8 `Branch_Data.mdb` — which copy is in the archive?

The archive's `analysis/BATCH-02/db/Branch_Data/schema.sql` (49 tables / 969 columns) is the **`bin\` copy** that the 2019 CD ships. The 2019 `System\` copy has the same table/column totals but a **different schema** (`patientinfo.moreinfo` Memo(255); `patienttest` with 9 fewer columns and `resultt..4` at Text(35)). The archive does **not** contain the `System\` schema dump. [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1 `Branch_Data.mdb` rows] · [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-033] · [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [patientinfo] / [patienttest]]

### 9.9 `pregsmok` semantics remain open

`normalrange.pregsmok` is declared **`Single`** in the shipped V2 schema, but its meaning (pregnancy? smoking? a factor?) was never established. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [normalrange]] · [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-26 — documentation-only issue reference] The V2 vendor catalogue states that the reference-range table carries **852** ranges [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 table row 3-3]; whether `pregsmok` is populated on **every** one of those rows is **NOT RECOVERABLE** from this evidence, because the shipped schema was ingested as a schema dump only and no row-level extract of the live V2 store exists.

### 9.10 `pictures`, `history`, `wasl` and `patientinfo` exist in **four** V2 databases

`Patients.mdb` (live), `Patients_backup.mdb` (backup copy shipped on the CD), `data.mdb` (system), `Branch_Data.mdb` (branch template) — with different widths for the same table names. [P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 `bin\` table] · [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql] · [P07-08 | analysis/BATCH-07/db/v2019-data.mdb.sql] · [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql] — see §7.7.

### 9.11 `column-evolution.csv` also flags `useraccounts`, `IgEallergy` and `Helicobacter`

`useraccounts` and `IgEallergy` are **not** in the shipped Access payload; `Helicobacter` is present but only with **6** of its 9 DDL-defined columns. [P04 | column-evolution.csv | rows `useraccounts`, `igeallergy`, `helicobacter`]

### 9.12 The 12-vs-14 DDL-created-table count, and the 14-vs-13 type-change count

See §3.1 and §3.4. Both published counts under-count the preserved evidence.

### 9.13 The published column counts ignore the `Paste Errors` table

`Paste Errors` (6 Memo columns) is a genuine table in the 2019 payload and is counted in the 103. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [Paste Errors]]

### 9.14 The "16 tables absent from the payload" figure is an enumeration, not a subtraction

The source states the figure as "set difference: 117 SQL-referenced names minus the 103 payload tables", but 117 − 103 = **14**, not 16. The figure 16 is in fact reproducible as the **enumeration** of §2.3 (10 rows, 16 distinct names), of which 6 name real tables and 10 are alias/artefact tokens; the two populations are not nested, so the subtraction is meaningless. Class: **VERIFIED enumeration; the stated derivation is UNVERIFIED**.

### 9.15 `cultureanti` and the profile-table population

`cultureanti` (12 columns) carries `patientid` and is present in the V2-shipped `Branch_Data.mdb` template, but it is **not** enumerated among the 51 clinical profile tables of §4.23, and its `requestdate` column is not documented. Depending on whether `cultureanti` also carries `requestdate`, the population of "tables carrying `patientid` and `requestdate`" is **58 or 59**. Class: **NOT DOCUMENTED**. [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE [cultureanti]] · [P11 | analysis/BATCH-02/db/Branch_Data/schema.sql | CREATE TABLE [cultureanti]]

### 9.16 The `IgEallergy` item-block width is bounded but not exact

The three `ALTER` literals are truncated; the highest evidenced item index is `Item40`, implying at most 164 columns (4 header + 40 × 4) if the numbering is continuous. The exact final count is **NOT RECOVERABLE**. [P11 | analysis/BATCH-04/schema/ddl-all.txt | VA 67D13E]

---

## 10. What is **NOT RECOVERABLE** from the preserved evidence

| Item | Status | Reason |
|---|---|---|
| Row counts of the live 2019 `Patients.mdb` | NOT RECOVERABLE | BATCH-07 preserved `mdb-schema` only; no `mdb-export` was kept for the 2019 payload. [P07 \| analysis/BATCH-07/db/ \| directory contents] |
| All columns of `FMF` beyond `patientid` | NOT RECOVERABLE | Both `CREATE` literals truncated; only `SELECT * FROM FMF where patientid= '` exists. [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 679C46 / VA 68037E] |
| The exact final item count of `IgEallergy` | NOT RECOVERABLE | All three `ADD COLUMN` literals truncated; highest evidenced index is `Item40`. [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 67D13E] |
| The full `MyLabSetting` DDL column list | PARTIALLY NOT RECOVERABLE | The DDL literal is truncated to `Create Table MyLabSetting (LabID Smallint`; the shipped 20-column definition is known, but the original DDL order/type mapping is not. [P11 \| analysis/BATCH-04/schema/ddl-all.txt \| VA 674A32] |
| `useraccounts` full column set | NOT RECOVERABLE | Only `usersnum`, `usersdr` (from predicates) + 3 DDL-added columns. [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 726A64 / VA 726AC0] |
| `loger` full column set | NOT RECOVERABLE | Only `lognum`, `compname`, `datein`, `username` from predicates. [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 66F746 / 6EFF14 / 72ABDC] |
| `samples` full column set | NOT RECOVERABLE | Only `patientid` is evidenced. [P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| VA 687A3E] |
| `LBC` columns beyond the 18 in the Jet DDL | NOT RECOVERABLE (table absent from the Access payload) | — |
| The 2019 `System\Branch_Data.mdb` schema | NOT RECOVERABLE (only the delta vs the `bin\` copy is recorded) | [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-033] |
| The `Interface` and `VIDAS` SQL Server catalogs' schemas | NOT RECOVERABLE | No schema extraction was performed for them. [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4] |
| The semantics of `normalrange.pregsmok` | NOT RECOVERABLE | Open issue ISS-26 (documentation-only reference). |
| Whether the branch digit is position 9 alone or the 2-char pair | PARTIALLY NOT RECOVERABLE | Two readings; see §6.1. |
| Declared PRIMARY KEY / FOREIGN KEY / UNIQUE / INDEX constraint objects | NOT DOCUMENTED | No such clause appears in the cited schema dump or in the 268 embedded DDL literals; see §2.5. |
| The V2 value domain of `arrangnum` | NOT DOCUMENTED | No V2-shipped export survives; see §6.5. |
| Whether `cultureanti` carries `requestdate` | NOT DOCUMENTED | See §9.15. |
| Live-V2 row counts for every table | NOT RECOVERABLE | Same reason as the first row above. |
| The stored values of the `constanttable` clinical-constant rows (`PTCONS`, `CBCCONS`) | NOT RECOVERABLE | The shipped V2 schema defines the 8 columns and the V2 manual names the constants (PT *ISI, Control Time and Concentration table*; PTT *Control Time*; the CBC factors 3.3 / 8.25 / 7.50 / 6.25 / 6.75), but the numbers a live V2 installation stores under each discriminator — the PT control time, the second-level control time, the ISI, the Westgard flag — are stated nowhere in a V2-primary source. [P07 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE [constanttable]] · [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic nots.htm item 1] |
| The per-test and per-range content of the live V2 `testtable` and `normalrange` | NOT RECOVERABLE | The catalogue sizes are stated by the V2 vendor catalogue (`testtable` 609, `normalrange` 852); the row content is not, because the shipped schema was ingested as a schema dump only. [P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 table rows 3-1 and 3-3] |

---

## 11. Evidence index

| File (as cited) | What it contributes |
|---|---|
| `analysis/BATCH-04/schema/ddl-all.txt` | The 268 embedded DDL literals — authoritative exact types for all 1.605 schema changes. |
| `analysis/BATCH-04/schema/created-tables.csv` | Per-DDL-created-table column rows (note: `column_count_in_table` is a **row count**, not a column count). |
| `analysis/BATCH-04/schema/added-columns.csv` | The 228 `ADD` statements with their dialect-specific types. |
| `analysis/BATCH-04/schema/column-evolution.csv` | Per-table DDL-touch lists; **read with the caveats in §9.4**. |
| `analysis/BATCH-04/sql_v1605/tables.csv` | The 117 SQL-referenced table names with statement counts and sample statements (source of the alias traps). |
| `analysis/BATCH-04/sql_v1605/columns.csv` | Qualified-column reference frequencies (source of the FK inferences). |
| `analysis/BATCH-04/sql_v1605/statements.csv` | The 1,797 SQL statements — the source of every relationship, every `SUBSTRING(patientid,…)` slice and every runtime–schema conflict. |
| `analysis/BATCH-04/sql_v1605/ddl-evidence.txt` | The DDL literals keyed by virtual address. |
| `analysis/BATCH-04/sql_v1605/domain-vocabulary.txt` | Identifier frequency across the SQL corpus. |
| `analysis/BATCH-04/vb6/v1605/objects.json` | 210 objects / 8,026 methods — separates VB6 *objects* (`workpaper`, `resultIgeAllergy`) from tables. |
| `analysis/BATCH-07/db/v2019-Patients.mdb.sql` | **The authoritative V2 table list** (103 tables / 1,682 columns). |
| `analysis/BATCH-07/db/v2019-data.mdb.sql` | The V2 `data.mdb` (3 tables / 34 columns). |
| `analysis/BATCH-07/migration-proof.md` / `.json` | DDL↔shipped-schema reconciliation — **contains the errors in §9.2 and §9.3**. |
| `analysis/BATCH-02/db/Branch_Data/schema.sql` | The schema dump of the **V2-shipped** branch template `bin\Branch_Data.mdb` — 49 tables / 969 columns; the template ships with 0 rows. |
| `analysis/V-CD-2019/09-vendor-capability-catalogue.md` | The V2 catalogue-level counts: the test-catalogue size (`testtable` 609), the reference-range count (`normalrange` 852), the category count (`subgrouptable` 46), and the `antibiotic` / `antibio` / `comments` / `anyreport` row counts. |
| `analysis/BATCH-04/help_v1605/help-manual-ar.md` | The V2 CHM manual — the clinical constants the application applies (PT *ISI, Control Time and Concentration table*; PTT *Control Time*; the CBC derivation factors 3.3 / 8.25 / 7.50 / 6.25 / 6.75). |
| `analysis/CUMULATIVE/cumulative-schema.csv` | Cross-check only — **its row counts do not describe the shipped V2 store and its branch column counts are broken** (§2.1). |
| `analysis/CUMULATIVE/02-data-model.md` | The published data model — cited here only for the claims it makes, never as a V2 fact. |
| `analysis/V-CD-2019/02-schema.md` | The DDL-derived V2 schema summary (12 created tables, 228 adds, 14 type changes) — **counts corrected in §3.1/§3.4**. |
| `analysis/V-CD-2019/00-baseline-summary.md` | V2 baseline numbers (210 objects, 8,026 methods, 1,797 SQL, 268 DDL, 103 tables). |
| `analysis/V-CD-2019/11-deployment-payload-2019.md` | 2019 payload file inventory. |
| `analysis/V-CD-2019/08-deployment-installer.md` | The SQL Server catalogs (`patients`, `Interface`, `VIDAS`). |
| `10-Issues/Open-Issues-and-Limitations.md` | ISS-26 (`pregsmok`), ISS-34 (`loger`, `win32_processor`) — documentation-only issue references. |
| `11-Evidence/Evidence-Register.md` | EV-ANA-014, EV-ANA-031, EV-ANA-033, EV-ANA-035, EV-ANA-039, EV-ANA-043, EV-ANA-045, EV-ANA-046 — documentation-only evidence-register references. |

---

## 12. Provenance and method

This document was produced from the source findings file `04_data_model_findings.md` (extracted from the evidence archive `Reference_V2_Patches_04-11.zip`, patches 04–11). The evidence roots used are the three V2 schema sources named in §0.1 — the embedded DDL literal set `analysis/BATCH-04/schema/ddl-all.txt`, the extracted SQL corpus `analysis/BATCH-04/sql_v1605/*`, and the shipped-schema dump `analysis/BATCH-07/db/v2019-Patients.mdb.sql` — with the V2 `data.mdb` dump, the `Branch_Data` template schema, the VB6 object inventory and the published V2 baseline, schema and deployment reports as supporting evidence. Every substantive claim carries a `[PATCH | file | anchor]` marker using only real file paths and real anchors; documentation-only identifiers (`ISS-`, `EV-ANA-`) and the relationship labels (`R`/`I`/`U`) are labelled as such. Claims are classified as **VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED** or **NOT RECOVERABLE**, and the evidence classes are unchanged from the source findings. All inventory figures were re-counted row-by-row against the source tables: 103 tables (103 rows, 103 distinct names) and 1,682 columns (sum of the 103 per-table column counts) in the shipped `Patients.mdb`; 3 tables / 34 columns in `data.mdb`; 49 tables / 969 columns in `Branch_Data.mdb`; 117 SQL-referenced table names; 268 embedded DDL literals = 27 `CREATE TABLE` + 241 `ALTER TABLE` (228 column `ADD` + 13 `ALTER COLUMN`); 14 distinct DDL-created tables; 58 tables carrying `patientid` + `requestdate` (51 profile + 7 structural, with `cultureanti` noted as a further candidate); and 43 relationship statements (12 explicitly documented, 20 strongly inferred, 11 unverified candidates). Where a figure could not be reproduced by direct summation — the "16 absent tables" arithmetic and the `cultureanti` population — the discrepancy is stated in §9 rather than silently reconciled.



