# RefLab V2 — Permissions, Roles & Security

## Version identity

**The system under documentation: RefLab Version 2 (V2), the RealLab V-CD-2019 line.**

- **Shipped executable:** `real lab system\RL_CD2019Access\System\real lab system.exe` — **FileVersion 1.605**, `Description: RLS 1.605`, `CompanyName: RealLab`, **76,292,096 bytes**, PE32 / linker 6.0, **PE build stamp 1595435962 = 2020-07-22 16:39:22 UTC** — [P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | `"pe"."timestamp"`]. SHA-256 `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0` — same file.
- **Deployment root:** `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`).
- **Evidence patch markers used in this document:** `[P04] [P05] [P07-08] [P11]` (mapping in the next section).

## Evidence base and method

**Patch-marker → evidence-root mapping** (paths in citations are relative to that patch's deliverable tree):

| Marker | Evidence root | Files cited from it |
|---|---|---|
| `P04` | fourth patch — the v1.605 executable and its analysis tree | `analysis/BATCH-04/**` (schema, SQL pool, VB6 object tables) |
| `P05` | fifth patch — vendor manuals and the learning guide | `analysis/BATCH-05/manuals/RLS_Learn.txt` |
| `P07-08` | seventh/eighth patch — the 2019 shipped Access database and the 2019 deployment payload | `analysis/BATCH-07/db/v2019-Patients.mdb.sql`, `analysis/V-CD-2019/**` |
| `P11` | eleventh patch — BATCH-11 analysis and the V-CD-2019 synthesis | `analysis/V-CD-2019/**`, `analysis/BATCH-11/**`, `10-Issues/Open-Issues-and-Limitations.md`, `11-Evidence/Evidence-Register.md`, `pdf-print-stack.md` |

**Evidence classes used on every substantive item:**

- **VERIFIED** — directly observed in a named file.
- **INFERRED** — reasoned from evidence; explicitly marked as such.
- **UNVERIFIED** — asserted somewhere but not confirmed for V2.
- **NOT DOCUMENTED** — the product's own documentation does not cover the point.
- **NOT RECOVERABLE** — no evidence exists in the archive; the evidence that would close the gap is named.

> **Method note.** All security statements below are *observed* or *documented*, never "recommended-by-default". Where the
> archive does not establish a mechanism, this document says so explicitly instead of substituting a conventional security
> control. Dynamic analysis of the PE was never possible (no Wine on the analysis host) — [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-07].
> Every citation keeps the form `[patch marker | path relative to that patch's deliverable tree | anchor]`.

---

## 1. Roles

### 1.1 The honest headline

**The archive does NOT contain an enumerated role model.** There is no role table, no role-to-privilege matrix, no named
permission dictionary, and no mapping from any grant flag to a labelled capability. What the evidence establishes is a
**flag-based per-account model**: one row per user account, carrying boolean capability flags and free-text labels.

Concretely: **a role catalogue is NOT RECOVERABLE.** Evidence that would be needed: the `users` form's control captions
(the permission check-box labels live only in on-screen images/control properties, which require VB6 COM property extraction
— blocked per ISS-06) or an exported permission dictionary.

### 1.2 What the evidence *does* establish about accounts and roles

| # | Element | Exact column / object | Type | Evidence | Class |
|---|---|---|---|---|---|
| 1 | **Account record table** | table `patients` (Access) — named `Patients` in the embedded DDL | — | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patients]`] ; [P04 \| analysis/BATCH-04/schema/ddl-all.txt \| `ALTER Table Patients …`] | VERIFIED |
| 2 | Account name | `patientusname` | Text (40) | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patients]`] | VERIFIED |
| 3 | **Capability/role label** | `patientuscap` | Text (40) | same as #2 | VERIFIED (column) / **NOT RECOVERABLE** (semantics — free text, no enumerated values found) |
| 4 | **Administrator flag** | `patientad` | Boolean NOT NULL | [P07-08 \| …v2019-Patients.mdb.sql]; exercised by `SELECT * FROM patients where patientad=True` [P04 \| analysis/BATCH-04/sql_v1605/statements.csv \| 6EF0FC, 6EF184] | VERIFIED |
| 5 | Active/registered flag | `patientus` | Boolean NOT NULL | [P07-08 \| …v2019-Patients.mdb.sql] | VERIFIED |
| 6 | **Capability flags** | `grant1` … `grant17` | Boolean NOT NULL (Access) / `Bit` (SQL Server) | §2.1 below | VERIFIED |
| 7 | Primary password | `patientword` | Text (40) | [P07-08 \| …v2019-Patients.mdb.sql] | VERIFIED |
| 8 | Secondary password | `SecWord` on `Patients` | varchar(10) | [P04 \| analysis/BATCH-04/schema/ddl-all.txt \| `ALTER Table Patients ADD SecWord varchar(10)` / `ADD COLUMN SecWord varchar(10)`] | VERIFIED (column) / **INFERRED** (it is the *secondary* password — see §2.5) |
| 9 | Account branch scoping | `branche` on `Patients` | Smallint / Integer | [P04 \| analysis/BATCH-04/schema/ddl-all.txt \| `ALTER Table Patients ADD branche smallint`]; [P07-08 \| …v2019-Patients.mdb.sql \| `[branche] Integer`] | VERIFIED |
| 10 | Account-type table (**SQL Server only**) | `useraccounts` | — | §2.2 | VERIFIED (existence) |
| 11 | Attendance log (**not present in the shipped Access DB**) | `loger` | — | §2.3 | VERIFIED (existence) · INFERRED (SQL-Server-resident) |

### 1.3 Role words that the vendor's own documentation uses

These are the only *named* role concepts in the whole archive. All come from V2-official vendor documentation, not from
inference:

| Term (Arabic) | English | Where it is documented | Class |
|---|---|---|---|
| **مدير النظام** | system administrator | the only role that may view users' attendance / overtime / lateness — [P05 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| §3-4 (body heading) / TOC entry 4-3] | VERIFIED (documented) |
| **المستخدمون أصحاب الصلاحيات المطلقة** | users with absolute permissions | CHM `004.htm`, numbered part **6)** of that topic — the audit section is enabled for "the system administrator **or** users with absolute permissions" — [P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| topic 004.htm, part 6] | VERIFIED (documented) |
| **المستخدمون والمديرون** | users and administrators | CHM/RFL guide TOC entry "3-11 إضافة مستخدمين ومديري النظام / تعديل بيانات وصلاحيات المستخدمين والمديرين" — [P05 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| TOC] | VERIFIED (documented) |
| **مستخدم** (generic) | user | the per-user permission assignment workflow — [P05 \| …RLS_Learn.txt \| §1-4] | VERIFIED (documented) |

**Count:** **4 named role terms** (counting the rows of the table above); **0 enumerated roles** (no role catalogue exists in
the archive — §1.1).

**Note on the CHM:** the official help file `real lab system help.chm` (15 topics) is shipped with the V2 deployment; the
extracted text file `analysis/BATCH-04/help_v1605/help-manual-ar.md` has MD5 `00182711966046b5d328741536d68814`
[P11 | analysis/V-CD-2019/03-capabilities.md]. ⇒ **every CHM quotation in §3 is a statement about the V2 product.**

### 1.4 The `admin` account — first-run bootstrap

The CHM (topic `002.htm`) documents, verbatim (Arabic original, then faithful English):

> ‏١) قم بإختيار اسم المستخدم من القائمة المنسدلة (لأول مرة اختر "admin" ثم قم بإنشاء مستخدمين وإحذف هذا الحساب)
> ‏٢) ادخل كلمة المرور الخاصة بك فى الخانة المخصصة لذلك ويجب مراعاة حالة الحروف (كبيرة ام صغيرة) (لأول مرة بعد اختيار اسم المستخدم " admin " ادخل نفس الكلمة ككلمة مرور)
> ‏٣) لتسجيل الدخول اضغط على الزر "تسجيل دخول"
> ‏٤) لإنهاء البرنامج والخروج منه اختر "خروج"

**Faithful translation:**
1) Choose the user name from the drop-down list (the **first time choose "admin"**, then create users and delete this account).
2) Enter your own password in the designated field, and **letter case must be observed** (upper or lower) (the first time, after choosing the user name **"admin", enter that same word as the password**).
3) To log in press the "تسجيل دخول" ("Log in") button.
4) To end the program and exit choose "خروج" ("Exit").

[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 002.htm].

**Consequences that are evidence-backed:**
- The **login user list is a drop-down populated from the account table**, not a free-text field — corroborated by
  `SELECT patientusname FROM patients order by patientusname` [P04 | analysis/BATCH-04/sql_v1605/statements.csv | 6D76E8, 704D98].
- The **first-run password equals the account name** ("admin"/"admin") — a credential identical to the user name, case-sensitive.
- The **`admin` account is expected to be deleted after real users are created** — corroborated by the deletion statement
  `Delete FROM patients where patientusid=` [P04 | analysis/BATCH-04/sql_v1605/statements.csv | 6EF2AC].
- The CHM shipped with this build (FileVersion 1.605) carries that `admin`/`admin` instruction unchanged.
- **Presence of an `admin` literal inside the V2 binary is NOT RECOVERABLE.** The archive retains no literal scan of the
  v1.605 executable (`real lab system.exe`), so the `admin` string itself is unconfirmed for the shipped binary; a literals
  scan of `real lab system.exe` v1.605 would be required.
- The CUMULATIVE claim "حساب `admin`/`admin` موثّق افتراضيًا" is therefore **UNVERIFIED for the V2 binary** (the documentation
half is VERIFIED) · [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-21 note]. **Stage 2:** the V1.605 executable was inspected directly — it carries exactly one UTF-16LE occurrence of the `admin` literal (file offset `0x2DA262`) and no ASCII occurrence, so the literal is **present in the shipped binary**; its role is still not established. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\System\real lab system.exe | UTF-16LE literal scan, offset 0x2DA262]`

---

## 2. Permission definitions — every permission-bearing field

### 2.1 `Patients.grant1 .. grant17` — the V2 capability flags

**The V2 permission surface comprises `grant1` .. `grant17` — 17 boolean capability flags carried on the single account
table `patients` / `Patients`.** (Count: the columns named `grant<N>` in the `CREATE TABLE [patients]` column list of the 2019
Access schema — `grant1`..`grant17` inclusive; 15 of them are declared inside the `CREATE TABLE`, and the remaining
`grant13`..`grant17` are also issued by the embedded DDL shown below.)

**Exact DDL for `grant13`..`grant17` (both dialects are shipped as separate statements in the same executable):**

```sql
-- VA 6DC31C / 6DC36C / 6DC3BC / 6DC410 / 6DC460   (SQL Server dialect)
ALTER Table Patients ADD grant13 Bit
ALTER Table Patients ADD grant14 Bit
ALTER Table Patients ADD grant15 Bit
ALTER Table Patients ADD grant16 Bit
ALTER Table Patients ADD grant17 Bit

-- VA 6DC4B0 / 6DC510 / 6DC570 / 6DC5EC / 6DC64C   (Access/Jet dialect)
ALTER Table Patients ADD COLUMN grant13 YESNO
ALTER Table Patients ADD COLUMN grant14 YESNO
ALTER Table Patients ADD COLUMN grant15 YESNO
ALTER Table Patients ADD COLUMN grant16 YESNO
ALTER Table Patients ADD COLUMN grant17 YESNO
```

[P04 | analysis/BATCH-04/schema/ddl-all.txt | grant13..grant17]; identical in
[P04 | analysis/BATCH-04/sql_v1605/ddl-evidence.txt | lines 258–267].

The embedded DDL therefore creates **10 grant-bearing statements** (5 columns × 2 dialects) and, together with the two
`SecWord` statements and the `branche` statement, **seven columns on the account table**: `branche`, `grant13`, `grant14`,
`grant15`, `grant16`, `grant17`, `secword` — all of them on the same table that carries `grant1`..`grant12`.

**Where the permission-bearing data actually lives — two different tables, one product:**

| Engine | Table | Permission columns | Source |
|---|---|---|---|
| Access (Jet) — the shipped `Patients.mdb` | `patients` | `grant1`..`grant17`, all `Boolean NOT NULL` | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [patients]`] |
| SQL Server — the `Patients` table the embedded DDL targets | `Patients` | `grant13`..`grant17` added as `Bit`; `branche` Smallint; `SecWord` varchar(10) | [P04 \| analysis/BATCH-04/schema/ddl-all.txt] |

**Per-flag Bit semantics: NOT RECOVERABLE.** Three independent reasons, each reproducible:

1. **No SQL literal in the v1.605 binary reads any `grantN` column.** The only occurrences of `grant` in the entire V2 SQL
   pool are the 10 DDL statements above — no `SELECT`/`WHERE` on `grant1..grant17`
   ([P04 | analysis/BATCH-04/sql_v1605/statements.csv | grep `grant` → only lines 887–896]).
   ⇒ the flag values are read through `SELECT * FROM patients where patientusname= '…'` and then consumed in VB6 code, which was
   not decompiled to statement level (ISS-23).
2. **The vendor guide shows the permissions as on-screen check-boxes only** — the extracted PDF text contains no per-permission
   label, and the PDF has no `ToUnicode` map so the text layer is letter-reversed
   ([P05 | analysis/BATCH-05/manuals/RLS_Learn.txt | §1-4 "ثم نقوم بتحديد صلاحيات المستخدم كما هو موضح"] — "…then we set the
   user's permissions as shown" — the permissions themselves are in the screenshot).
3. **VB6 control properties (captions) were never extracted** — [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-06]
   ("the detailed properties (Text/Caption) still need COM").

**Evidence that would be needed to close this:** (a) the `users` form control captions/names via VB6 COM property extraction
(ISS-06), or (b) a VB6 decompilation of the `users` form's 57 methods to the statement level (ISS-23), or (c) the per-permission
labels from the `RLS_Learn.pdf` page images (visual read of the §1-4 screenshots).

**What *is* evidenced about the flags' behaviour** (documented, not inferred):
- Permissions are **per user account** and are enforced **at navigation time** — [P05 | …RLS_Learn.txt | §1-4]:
  > ‫عند تسجٌل الدخول بالمستخدم الجدٌد تكون صالحٌاته محددة كما تم إدخالها ‪ ،‬وعند محاولة الدخول فى عنصر ؼٌر مصرح له تظهر الرسالة األتٌة ( أنت ال تملك الصالحٌة لهذا العمل راجع مدٌر النظام )‬
  > *"When logging in with the new user, his permissions are as entered; and when attempting to enter an item not permitted, the following message appears: (أنت لا تملك الصلاحية لهذا العمل راجع مدير النظام) — 'You do not have the permission for this work; consult the system administrator'."*
- One specific permission is named in the CHM: **"صلاحية حذف مرضى" — the delete-patient permission** (§3.3 below).
- The V2 flag count is **17** (VERIFIED): `grant1`..`grant17`.

### 2.2 `useraccounts.gtype / HDD1 / HDD2` — the SQL-Server-only account-type table

**Exact DDL:**

```sql
-- VA 677A7E
ALTER Table useraccounts ADD HDD1 varchar(20)
-- VA 677ADE
ALTER Table useraccounts ADD HDD2 varchar(20)
-- VA 677B3E
ALTER Table useraccounts ADD Gtype Smallint
```

[P04 | analysis/BATCH-04/schema/ddl-all.txt]; identical in [P04 | analysis/BATCH-04/sql_v1605/ddl-evidence.txt | lines 35–37].

| Column | Exact type | Class |
|---|---|---|
| `Gtype` | `Smallint` | VERIFIED (column + type) · **NOT RECOVERABLE** (semantics) |
| `HDD1` | `varchar(20)` | VERIFIED (column + type) · **NOT RECOVERABLE** (semantics) |
| `HDD2` | `varchar(20)` | VERIFIED (column + type) · **NOT RECOVERABLE** (semantics) |

**Where it lives:** `useraccounts` **does not exist in the shipped Access database**. The 2019 shipped `Patients.mdb` has
**103 tables** [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | 103 × `CREATE TABLE`], and `useraccounts` is **not one of
them** (grep for `useraccounts` in that file → 0 hits). The table is created and attached only in the SQL-Server deployment
mode, and it belongs to the **`Interface`** settings database, not to the patient database —
[P11 | analysis/V-CD-2019/08-deployment-installer.md | §2.1].
⇒ **`useraccounts` is a SQL-Server-only table, in the `Interface` database of the SQL-Server deployment mode.**

**Which columns the code actually uses:** only `usersnum` and `usersdr` appear in the v1.605 SQL pool (6 statements):

```sql
select * FROM useraccounts where usersnum=
Select * from useraccounts order by usersdr asc
SELECT * FROM useraccounts where usersdr= '
SELECT * FROM useraccounts where (usersdr= '
select * FROM useraccounts where usersnum=
Select * from useraccounts where usersdr like '
```

[P04 | analysis/BATCH-04/sql_v1605/statements.csv | 726A64, 726AC0, 726DFC, 726F70, 727018, 727074];
[P04 | analysis/BATCH-04/sql_v1605/tables.csv | row `useraccounts` → 6 statements].
⇒ **`Gtype`, `HDD1`, `HDD2` are never named in any SQL literal** — their meaning is confined to VB6 code.

**Semantics — explicitly NOT RECOVERABLE.** The only legitimate reading is by name and by the vendor guide's own citation:
the guide's capability row cites `useraccounts.gtype/hdd1/hdd2` as the evidence for "تعديل بيانات وصلاحيات المستخدمين والمديرين"
(editing users' and administrators' data and permissions) [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.7].
That establishes *purpose*, not *meaning*:
- `Gtype` → **INFERRED** "group type" (an account-grouping discriminator); the actual enumerated values are **NOT RECOVERABLE**.
- `HDD1` / `HDD2` → **INFERRED** two additional hard-disk/path slots (`varchar(20)` — consistent with a short path such as
  `E:\Lab_data`); **NOT RECOVERABLE** as fact.
- **Evidence that would be needed:** the VB6 code of the `z_labaccount` form (18 methods, 32 controls) or of the `users` form
  (57 methods, 83 controls), decompiled to statement level (ISS-23), plus the `useraccounts` CREATE statement from the
  SQL-Server attach script `D:\Lab_data\Attaching.sql` (which is created at install time and was **not** captured — see ISS-33
  note in [P11 | analysis/V-CD-2019/12-install-media.md | §7]).

### 2.3 `loggroup` and `loger` — attendance and work-group data

**`loggroup` (dictionary table; SQL-Server *and* Access):**

| Column | Type | Notes |
|---|---|---|
| `logid` | Long Integer | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| `CREATE TABLE [loggroup]`] |
| `logname` | Text (50) NOT NULL | same |

7 SQL statements reference it: `SELECT * FROM loggroup`, `… where logname= '`, `… order by logname asc`, `… where logid=`
[P04 | analysis/BATCH-04/sql_v1605/statements.csv | 6B28D8, 6F0E94, 6F0EE8, 6F0FC8, 6F105C, 6F10CC, 6F111C].

> ⚠️ **Correction to a likely misreading:** `loggroup` is **not** a permission or role group. `testtable.loggroup` and
> `patienttest.loggroup` are `Text (50)` **columns that tag a test with its log/work group**
> [P07-08 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | `CREATE TABLE [testtable]` / `[patienttest]`];
> [P04 | analysis/BATCH-04/sql_v1605/statements.csv | 6AA272, 70BED4, 7327CC]. The `loggroup` *table* is the dictionary of those
> group labels. **It carries no privilege meaning in the evidence.** (VERIFIED)

**`loger` — the attendance log:**

| Attribute | Value | Source |
|---|---|---|
| Present in the V2 SQL pool? | **Yes** — 5 statements | [P04 \| analysis/BATCH-04/sql_v1605/tables.csv \| row `loger`] |
| Columns referenced in code | `lognum`, `username`, `datein`, `compname` | [P04 \| analysis/BATCH-04/sql_v1605/statements.csv \| 66F746, 6EFF14, 72ABDC, 72B7A4, 72BD2C] |
| Retention statement | `Delete loger where datein >= '` | [P04 \| …statements.csv \| 72C568] |
| In the shipped Access DB? | **No** — not among the 103 tables of the 2019 `Patients.mdb`; and no `CREATE TABLE loger` exists in the 268 embedded DDL statements ⇒ the table is created **outside** the shipped schema (most plausibly by the SQL-Server attach script, which was never captured) | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql]; [P04 \| analysis/BATCH-04/schema/ddl-all.txt \| 27 `CREATE TABLE` statements, none for `loger`] |
| Documented purpose | attendance/departure registration per user, with break period, overtime and lateness | [P05 \| analysis/BATCH-05/manuals/RLS_Learn.txt \| §3-4 (body heading) / TOC entry 4-3] |

**Documented behaviour (RLS_Learn.pdf, official V2 learning guide, 2017):**

> ‫‏3-4‬تسجٌل الحضور واإلنصراؾ لمعرفة حركة المستخدمٌن فى الدخول والخروج من النظام‬
> ‫لمتابعة حركة المستخدمٌن فى الدخول والخروج من النظام ومتابعة أوقات العمل ومعرفة الوقت اإلضافى للمستخدم والتأخٌر ‪ٌ ،‬تم استخدام نظام الحضور واإلنصراؾ وفترة الراحة لكل مستخدم ‪ ،‬حٌث ٌقوم المستخدم بتسجٌل الحضور عند بدء العمل على البرنامج وتسجٌل فترة الراحة – إن وجدت – كما ٌقوم بتسجٌل إنصراؾ عند انتهاء دوام العمل‬
>
> *"3-4 — Attendance and departure registration, to know the movement of users entering and leaving the system. To follow the movement of users entering and leaving the system, to follow working times and to know each user's overtime and lateness, an attendance-and-departure system with a break period is used for each user: the user registers attendance when starting work on the program, registers the break period if one exists, and registers departure when the working day ends."*

> ‫ٌمكن لمدٌر النظام فقط اإلطالع على أوقات دخول وخروج المستخدمٌن ومعرفة الوقت اإلضافى والتأخٌر لكل مستخدم ‪.‬‬
> *"**Only the system administrator** can view the users' entry and exit times and know the overtime and lateness for each user."*

[P05 | analysis/BATCH-05/manuals/RLS_Learn.txt | §3-4 (body heading) / TOC entry 4-3].
*Caveat: `RLS_Learn.pdf` has no `ToUnicode` map, so the extracted Arabic text above is letter-reversed; the page rendering is correct and the quoted strings were visually corrected — [P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | header note].*

**The attendance parameters are stored per account**, not in `loger`: `startwork`, `endwork`, `breakyorn`, `breaktime`
— all on the account table — read by
`select startwork,endwork,breakyorn,breaktime from patients where patientusname= '…'`
[P04 | analysis/BATCH-04/sql_v1605/statements.csv | 6D6F18; columns in P07-08 | …v2019-Patients.mdb.sql | `CREATE TABLE [patients]`].
**Class: VERIFIED.**

**`loger` column types: NOT RECOVERABLE.** Only the four referenced column names are known; the full `CREATE TABLE loger`
was never captured (the table is not in the Access DB and no `CREATE TABLE loger` appears in the 268 embedded DDL statements —
the 12 creates are FMF, Helicobacter, LBC, SMSSender, SMStemplate, hba1c, pictures, ratios, smsgroups, smslist, testtemp, widal2
[P11 | analysis/V-CD-2019/02-schema.md | §1]).
**This is the standing open issue** — [P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-34].

### 2.4 Other permission-bearing or security-relevant account fields

| Column | Type | Reading | Class |
|---|---|---|---|
| `patientad` | Boolean NOT NULL | administrator flag | VERIFIED |
| `patientus` | Boolean NOT NULL | account-active flag | VERIFIED |
| `patientuscap` | Text (40) | free-text capability/role label | VERIFIED (column) / NOT RECOVERABLE (value domain) |
| `patientword` | Text (40) | primary password | VERIFIED (column) / NOT RECOVERABLE (storage form) |
| `SecWord` | varchar(10) | secondary password | VERIFIED (column) / INFERRED (semantics — §2.5) |
| `branche` | Integer / Smallint | branch the account belongs to | VERIFIED |
| `khasmlimit` | Long Integer | numeric limit (name reads as "khasm limit") | VERIFIED (column) / NOT RECOVERABLE (meaning) |
| `showtip`, `tipnum` | Boolean, Long Integer | UI tip behaviour, not permissions | VERIFIED |
| `lastvisit` | Text (40) | last visit stamp | VERIFIED |

### 2.5 The two-password model — INFERRED mapping

The 2017 vendor guide documents the user-creation dialog as collecting **two** passwords plus a branch plus the permission set:

> ‫إلضافة مستخدم جدٌد نضؽط على زر ( إضافة ) ونقوم بكتابة إسم المستخدم وكلمة المرور الرئٌسٌة والفرعٌة الخاصه به ثم نقوم بتحدٌد صالحٌات المستخدم كما هو موضح‬
> *"To add a new user we press the (Add) button and write the user name and **the primary and secondary password** belonging to it, then we set the user's permissions as shown."*

[P05 | analysis/BATCH-05/manuals/RLS_Learn.txt | §1-4].
**Mapping to columns:** `patientword` (Text 40) = primary password; `SecWord` (varchar 10, a column of the V2 account table
created by the same embedded DDL that creates `grant13..grant17`) = secondary password — **INFERRED**, based on (a) the guide's
two-password wording, (b) `SecWord` being created on the account table by this executable's DDL together with `grant13..grant17`,
and (c) the name. **The exact rule for which password is checked at login, and whether `SecWord` gates a second operation, is
NOT RECOVERABLE.**

---

## 3. Authorization rules — exactly what is gated, and by what evidence

Every row below is a **documented** rule (vendor documentation), except the last row, which is an explicit absence of evidence.

**Count: 11 rows (A1–A11) — of which 9 are documented authorization rules (A1–A9), 1 is a documented quality gate (A10) and 1
is an explicit absence of evidence (A11).**

| # | Gated operation | Gate | Source | Class |
|---|---|---|---|---|
| A1 | **Application login** | user name chosen from a drop-down + a password, **case-sensitive** | CHM 002.htm — "يجب مراعاة حالة الحروف (كبيرة ام صغيرة)" | VERIFIED (documented) |
| A2 | **First run** | account `admin`, **password = "admin"**; the CHM instructs creating real users and then **deleting** that account | CHM 002.htm (quoted verbatim in §1.4) | VERIFIED (documented) |
| A3 | **Entering a module not granted** | denied at navigation time with the message **"أنت لا تملك الصلاحية لهذا العمل راجع مدير النظام"** ("You do not have the permission for this work — consult the system administrator") | RLS_Learn.pdf §1-4 | VERIFIED (documented) |
| A4 | **Deleting a patient** | "لحذف مريض يجب ان يكون المستخدم الحالى له **صلاحية حذف مرضى**" ("to delete a patient the current user must have the **delete-patient permission**") | CHM 003.htm | VERIFIED (documented) |
| A5 | **The audit/history panel (main window part 6)** | enabled for "مدير النظام او المستخدمين اصحاب **الصلاحيات المطلقة**" only — i.e. the system administrator or users with **absolute permissions** | CHM `004.htm`, part **6)** | VERIFIED (documented) |
| A6 | **Creating or editing users and their permissions** | the program asks for the **internal-window password** → `123`, or the changed password if the user changed it | RLS_Learn.pdf §1-4 and §2-4 | VERIFIED (documented) |
| A7 | **Database Maintenance (backup / restore / data wipe / master-password change)** | master password → `123` by default ("ويفضل تغير كلمة المرور بعد ذلك لضمان حماية النظام من العبث" — "and it is preferable to change the password afterwards **to guarantee protection of the system from tampering**") | CHM `backup.htm` | VERIFIED (documented) |
| A8 | **Viewing users' attendance / overtime / lateness** | **only the system administrator** | RLS_Learn.pdf §3-4 (body heading; TOC entry 4-3) | VERIFIED (documented) |
| A9 | **Server-settings window fields** | "نوع سماحية الدخول للنظام **وهى ثابتة دائما** فى حالة استخدام برنامج التثبيت الخاص بنا" ("the type of system login permission **is always fixed** when using our own installation program"); "اسم وكلمة مرور المستخدم **ويمنع تغيرها**" ("the user name and password **cannot be changed**"); "اسم قاعدة البيانات **ويمنع تغيرها**" ("the database name **cannot be changed**") | CHM 001.htm | VERIFIED (documented) |
| A10 | **Printing an unverified result** | quality gate, not an authorization rule: `Not found any Verified selected tests or result to print it` | [P11 \| pdf-print-stack.md \| §2.5] | VERIFIED (documented behaviour) |
| A11 | **Any access-log of permission/account changes** | — | **NOT RECOVERABLE** — no evidence of any audit table for account or permission changes anywhere in the archive | NOT RECOVERABLE |

**A7 verbatim (the master password of the maintenance window) — CHM `backup.htm`:**

> ‏سوف يتم غلق النظام وفتح مربع حوار كما فى الشكل التالي قم بإدخال **كلمة المرور الاساسية 123** ثم موافق **ويفضل تغير كلمة المرور بعد ذلك لضمان حماية النظام من العبث.**
> *"The system will close and a dialogue box will open as in the figure; enter **the master password 123**, then OK. **It is preferable to change the password afterwards to guarantee protection of the system from tampering.**"*

[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic `backup.htm`].

**A6 verbatim — RLS_Learn.pdf §1-4 / §2-4:**

> ‫عند الضؽط على زر ( إنشاء مستخدمٌن ) ٌطلب البرنامج كلمة مرور النوافذ الداخلٌة / نقوم بإدخال كلمة المرور ( 123 ) أو كلمة المرور الخاصة بالمستخدم فى حالة قام المستخدم بتؽٌٌرها‬
> *"When the (Create users) button is pressed, the program asks for the internal-window password; enter the password (**123**) or the user's own password if the user has changed it."*

[P05 | analysis/BATCH-05/manuals/RLS_Learn.txt | §1-4, §2-4].

**A9 verbatim — CHM 001.htm (server settings window):**

> ‏2) نوع سماحية الدخول للنظام وهى ثابتة دائما فى حالة استخدام برنامج التثبيت الخاص بنا.
> ‏3) اسم وكلمة مرور المستخدم ويمنع تغيرها وهى خاصة ببيانات الاتصال بخادم قواعد البيانات.
> ‏4) اسم قاعدة البيانات ويمنع تغيرها نظرا لأنها من ثوابت النظام.
>
> *"2) The type of login permission for the system — it is always fixed when using our own installation program.
> 3) The user's name and password — changing them is prevented; they are for the database-server connection data.
> 4) The database name — changing it is prevented, because it is one of the system's constants."*

[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 001.htm].
*Reading:* the client's UI cannot change the authentication mode or the DB account — the client is bound to whatever the vendor's
installer configured (i.e. `sa` / `12345678`). **INFERRED consequence, VERIFIED premise.**

**A8's gate is also evidenced by a second, independent artifact**: the attendance data is in a table (`loger`) that is
**SQL-Server-only** and is queried through `SELECT * FROM loger where username= '…'` / `… where datein >= '`
[P04 | analysis/BATCH-04/sql_v1605/statements.csv | 72BD2C, 72B7A4] — no row-level or user-level SQL filter is evidenced,
so the admin-only gate must be enforced in the application layer (INFERRED).

---

## 4. Protected functions / operations

**Count: 13 protected functions / operations (P1–P13), counted as the rows of the table below.**
*(The row labels `P1`–`P13` are protected-function identifiers used in this document; the patch markers `[P04] [P05] [P07-08] [P11]`
are quoted only inside the Evidence column.)*

| # | Function / operation | Where it lives | Evidence of the protection (or its absence) | Class |
|---|---|---|---|---|
| P1 | **Patient data transport between installations** | `Patient Data Transport.exe` — VB6, its own PE `FileVersion 1.00`, CompanyName "ais group", 1,294,336 B, timestamp 1294177718 (2011-01-04), 1 import (`MSVBVM60.DLL`, 84 functions), 2 objects (`Form1` 14 · `Module1` 15), **50 profiled tables**, 12,324 literals | copies patient rows **signed with the patient's name** and filtered by branch via `SUBSTRING(patientid,9,1)`; guard literal `'<<< Blank >>>'`; helpers `Txtrest_sql`, `Txtback_sql`, `combackup`; source `[P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-035]`; the branch scoping is finding **F-05** in [P11 \| analysis/V-CD-2019/06-security.md \| F-05] | VERIFIED |
| P2 | **Branch-scoped patient export** (the `SUBSTRING(patientid,9,1)` branch) | `Patient Data Transport.exe`; also `Patient.branche` / `Patients.branche` (Smallint) and `Branch_Data.mdb` (template, 49 tables, **0 rows**) | [P11 \| analysis/V-CD-2019/06-security.md \| F-05]; [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 row 10] | VERIFIED |
| P3 | **Backup / restore / data wipe ("Database Maintenance")** | Settings → "Database Maintenance" | gated by the master password `123` (A7); two documented variants — *large labs* (full backup/restore of the DB path, `Patient_yyyymmdd.bak` inside the DB folder) and *small labs* (period-based backup/restore of a single patient by code); "zero all system data" available via part 2 | VERIFIED |
| P4 | **The shipped backup copy is stale** | `bin\Patients_backup.mdb`, 2,146,304 B | the shipped backup holds **2,786 rows** against **3,123** rows in the live `Patients.mdb` — it is **not** an updated copy of the live database — [P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §backup]; [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-18] | VERIFIED |
| P5 | **Database-engine selection** | `RL_SETUP.exe` (VB6 v19.00, built 2020-09-01, 57 objects, 599 procedures, 22.95 MiB compressed payload, entropy 7.39, no standard archive signature) | the client chooses **Access** or **SQL Server** (or MySQL per the install layout); documented warning: *"If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD."* | VERIFIED |
| P6 | **SQL Server install configuration** | `System\Setup.bat` and `System\Setup4.bat` | `start /wait System/MSSQL_Server_Express_2005/SQLEXPR.EXE /qb ADDLOCAL=ALL INSTANCENAME=MSSQLSERVER SECURITYMODE=SQL SQLAUTOSTART=1 SQLBROWSERAUTOSTART=1 SAPWD=12345678 DISABLENETWORKPROTOCOLS=0` | VERIFIED |
| P7 | **User administration UI** | `users` form — **83 controls**, **57 methods**; `userspw` — 15 controls / 12 methods; `login` — 8 controls / 13 methods; `logindete` — 12 controls / 6 methods; `logindetect` — datareport, 0 methods | [P04 \| analysis/BATCH-04/vb6/v1605/objects.json]; [P04 \| analysis/BATCH-04/vb6/v1605/forms-blob.txt] | VERIFIED |
| P8 | **Server-configuration UI** | `server` form — **27 controls**, **17 methods** | [P04 \| …v1605/objects.json] | VERIFIED |
| P9 | **Lab-account maintenance UI** | `z_labaccount` form — 18 methods, **32 controls** | [P04 \| …v1605/forms-blob.txt]; [P04 \| …v1605/objects.json] | VERIFIED (counts) / INFERRED (that it edits `useraccounts`) |
| P10 | **Print audit trail** | `patienttest.resultprint`, `printuser`, `printdate`, `printnum`; `printnum` = sequential counter | [P11 \| pdf-print-stack.md \| §2.5] | VERIFIED |
| P11 | **Licence verification** | `Select * from Win32_Processor` (1 SQL statement), `Hardware\Description\System` (WMI), `RealLab_Show_Info.exe` | [P04 \| analysis/BATCH-04/sql_v1605/statements.csv \| 69119A]; [P04 \| …tables.csv \| row `win32_processor`]; [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4] | VERIFIED |
| P12 | **Results delivery to third parties** | NATIGH.COM (`Natigh` + `SMSSender` + `smsgroups`/`smslist`/`SMStemplate`), SMS sender form `SMSfrmsenderos` (139 methods), the SMS-gateway account columns `accuntID` and `accuntpw` of the `MyLabSetting` settings table | [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §3]; `MyLabSetting` DDL/columns in [P07-08 \| …v2019-Patients.mdb.sql] | VERIFIED (existence) — **no evidence of any authorisation gate on delivery**: NOT RECOVERABLE |
| P13 | **PDF output surfaces** | `D:\PDF\Contracts\`, `D:\PDF\Free\`, `D:\PDF\Individual\`, `D:\PDF\LabToLab\` — four commercial categories, written by an external print driver | [P11 \| pdf-print-stack.md \| §2.2] | VERIFIED |

---

## 5. Access boundaries & documented security boundaries

### 5.1 Database-engine surface (three engines, one deployment)

| Engine | How it is selected | Evidence | Class |
|---|---|---|---|
| **Microsoft Access (Jet 4)** | `BASE.ini` → `Databasetype=XMSACCESSX`; `D:\real lab system\bin\Patients.mdb` | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2]; [P07-08 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §3] | VERIFIED |
| **Microsoft SQL Server Express 2005** | `Setup.bat`/`Setup4.bat` → `SQLEXPR.EXE INSTANCENAME=MSSQLSERVER`; `data_connection*.udl` → `SQLOLEDB.1` | [P11 \| analysis/V-CD-2019/05-deployment.md \| §2] | VERIFIED |
| **MySQL** | `Setup5.bat` → MySQL Connector ODBC 3.51; `BASE.ini` carries `DataSource=REAL_LAB` and `loca=E:\Lab_data`, i.e. the UDL can point at whichever engine is installed | [P11 \| analysis/V-CD-2019/06-security.md \| F-04]; [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.2] | VERIFIED |

### 5.2 Multi-database boundary in SQL-Server mode

| Database | File | Attach script | Evidence |
|---|---|---|---|
| `patients` | `D:\Lab_data\Patients.mdf` | `D:\Lab_data\Attach_Patients.bat` | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1] |
| **`Interface`** (settings/config DB) | `D:\Lab_data\Interface.mdf` | `D:\Lab_data\Attach_Interface.bat` | same |
| **`VIDAS`** (third system) | — | `D:\Lab_data\Attach_VIDAS.bat` | same |

> The document states the structural discovery explicitly: *"there is not one database — but a **separate database for the
> interface (`Interface`) apart from the patient data (`patients`)"*, and notes this explains why the setting tables
> (`useraccounts`, `mylabsetting`, `reportview`) are separated in the queries.
> [P11 | analysis/V-CD-2019/08-deployment-installer.md | §2.1]

Default instance/server name: **`reallabserver`** (customisable via `servername`) — [P11 | …/08-deployment-installer.md | §2.1].
**Boundary fact (VERIFIED for `useraccounts`; INFERRED for `loger`):** `useraccounts` and `loger` are **absent from the Access
`Patients.mdb`**; `useraccounts` is a **SQL-Server-only** table of the `Interface` database, while `loger` has no
`CREATE TABLE` in the embedded DDL and is therefore created outside the shipped schema (§2.2, §2.3).
⇒ *INFERRED: the permission/attendance model is fully present only in the SQL-Server deployment — the Access deployment has no
`useraccounts` table at all.*

### 5.3 Branch scoping (the multi-installation boundary)

| Element | Value | Evidence |
|---|---|---|
| Branch digit inside the patient id | `SUBSTRING(patientid,9,1)` | [P11 \| analysis/V-CD-2019/06-security.md \| F-05]; [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §5] |
| Branch column on the account table | `Patients.branche` (smallint) | [P04 \| analysis/BATCH-04/schema/ddl-all.txt] |
| Branch table | `Labbranch` (7 columns) | [P04 \| analysis/BATCH-04/sql_v1605/tables.csv] |
| Per-branch schema template | `Branch_Data.mdb` — 49 tables, **0 rows** (schema-only template) | [P11 \| analysis/V-CD-2019/00-baseline-summary.md \| §1 row 10] |
| Master/reception model | "The main (master) computer works most hours of the day (reception computer)"; "You install SQL Server on one computer in the laboratory and only one time"; "The SQL database save on the master computer only"; **"Allow to connect the lab branches through the internet"** | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §5] |
| Per-user branch | `patients.branche` (Integer) | [P07-08 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql] |

### 5.4 Documented security boundaries stated by the vendor

1. **Do not connect the server machine to the internet** — *"يفضل عدم توصيل انترنت على جهاز السيرفر للحفاظ علي نظام التشغيل أطول فترة ممكنة وللحفاظ على سرية البيانات من احتمالية الأختراق"*
   ("prefer **not** to connect the internet to the server machine, in order to keep the operating system for as long as possible
   and **to preserve data confidentiality from the possibility of intrusion**") — [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 001.htm].
   **VERIFIED (documented).** ⇒ the vendor's own security boundary is "isolate the server", while the same product ships
   `DISABLENETWORKPROTOCOLS=0` and a branch-internet feature — the two are in tension, and the archive records both.
2. **The client cannot change the authentication mode, the DB user, or the DB name** (A9 above).
3. **The client must run elevated installers** — the CAB self-registers **24 OCX/DLL components** into the Windows registry
   — 24 `$(DLLSelfRegister)` entries in the manifest's `[Setup1 Files]` section and 3 more in `[Bootstrap Files]`, **27 declared manifest-wide** — and writes into `System32`/`SysWOW64` → [P11 | analysis/V-CD-2019/12-install-media.md | §2.2]; [SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Bootstrap Files] and [Setup1 Files] sections];
   the document's own note: *"any modern alternative must declare its privilege requirements instead of concealing them."*
4. **The application refuses to run from an unprotected workstation** — *"لو ظهرت هذة الرسالة على جهاز اخر غير السيرفر المثبت عليه السيكول"* ("if this message appears on a machine other than the server on which SQL is installed") and the server must be started, not the application
   — [P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | topic 001.htm]. ⇒ **the client machines do not hold the database**.
5. **Licence is bound to hardware** — disk + motherboard + CPU: *"If the computer hard disk, Mother board and CPU damage or lost
   the RealLab not responsible and you will purchased the other license for the SOFTWARE."* — [P11 | analysis/V-CD-2019/08-deployment-installer.md | §4].

---

## 6. Documented security findings

### 6.1 The V2 security document (primary numbering) — `analysis/V-CD-2019/06-security.md` F-01..F-06

> This file carries MD5 `5ba0ab535d6f1b50ef301ef04036e988`.
> Its header states its provenance: *"ملاحظات موثّقة على ملفات BATCH-04. لا استploitation ولا اختبار اختراق"* —
> "documented observations on the BATCH-04 files; **no exploitation and no penetration testing**".

| ID | Exact finding (exact value + exact file) | Why it matters | Class |
|---|---|---|---|
| **F-01** | **`SAPWD=12345678`** in `Setup.bat` and `Setup4.bat` — **the same value** in `BASE.ini` (`UserID=sa`, `Password=12345678`) and in `data_connection1.udl` (`User ID=sa;Password=12345678`). *"مُثبَّتة في القرص المُشحَن — قابلة للاستخراج دون أي وصول للنظام"* — **hard-coded on the shipped disc, extractable without any system access**. | The database superuser credential is a fixed, publicly-readable artefact of the product. | VERIFIED |
| **F-02** | **`DISABLENETWORKPROTOCOLS=0`** together with **`SECURITYMODE=SQL`** in the SQL Server Express install ⇒ *"النسخة الافتراضية تفتح الاستماع الشبكي بكلمات مرور ضعيفة"* — the default install opens network listening with weak passwords. | The `sa` account of the patient database is reachable over the LAN by default. | VERIFIED |
| **F-03** | **`Persist Security Info=True`** in `BASE.ini` and `data_connection1.udl` — *"يسمح بإعادة إمداد الاعتماد مع كل اتصال، فتصبح كلمة المرور مرتبطة بكل اتصال ومُخزَّنة في سجلات"* — the credential is re-supplied with every connection and therefore becomes connection-bound and stored in logs. | Credential propagation into any log that records connection strings. | VERIFIED |
| **F-04** | `Setup5.bat` installs **MySQL Connector ODBC 3.51**; `BASE.ini` carries **`DataSource=REAL_LAB`** and **`loca=E:\Lab_data`** — indicating the UDL directs whichever engine is installed. | The shipped product's credential surface is engine-agnostic; a third engine (MySQL) is provisioned with the same installer and the same hard-coded credential. | VERIFIED |
| **F-05** | `Patient Data Transport.exe` copies patient records **signed with the patient's name** via **`SUBSTRING(patientid,9,1)`** — i.e. scoped by the branch identifier. *"أداة نقل بيانات patients بين المعامل، وتستحق مراجعة صلاحيات في `Ref Lab`"* — a patient-data transport tool between labs, deserving a permissions review. | A separate, name-bearing executable performs bulk patient-data movement between installations; it is branch-scoped, not user-scoped. | VERIFIED (that the tool exists and how it filters) · **the absence of any user/role gate on it is NOT RECOVERABLE** (the tool's UI was never decompiled to statement level — ISS-23) |
| **F-06** | The official manual **documents none of this**: it mentions neither SQL Server, nor MySQL, nor SMS, nor **الصلاحيات** (the permissions) — the shipped documentation set gives a customer no security model at all. | The customer receives no documented security model for the product they install. | VERIFIED |

**Corroboration of the F-01 values inside the shipped 2019 payload** — the hard-coded credential is part of the V2 shipped media:

```ini
[oledb]
Databasetype=XMSACCESSX
loca=E:\Lab_data
DataSource=REAL_LAB
PersistSecurityInfo=True
UserID=sa
Password=12345678
InitialCatalog=Patients
[lastlog]
try1=20170926##ACCESS##SPRT007-PC##0##sa##12345678
try2=20170926##MS_SQL##SPRT007-PC##0##sa##12345678
try3= … try10=  (empty)
```

[P07-08 | analysis/V-CD-2019/11-deployment-payload-2019.md | §3 (F-09)] — file `bin\BASE.ini` (2019).
⇒ **`sa` / `12345678` and `PersistSecurityInfo=True` are confirmed present in the 2019 shipped payload**, with the actual
host name (`SPRT007-PC`) written to disk.

### 6.2 Additional security findings (Stage numbering)

These live in the Stage-7/9 reports and the BATCH-07 payload report; their `F-` numbering **is a different scheme** from the
V2 security document's F-01..F-06 and is cited with its own document attribution to avoid confusion.

| ID | Finding | Exact location / value | Class |
|---|---|---|---|
| **F-09** (Stage) | **The connection-attempt log writes the database password in clear text**, plus the machine name, in the format `date ## engine ## machine ## lab id ## user ## password`; the password `12345678` is stored literally, and the last 10 attempts are retained. | `bin\BASE.ini` → `[lastlog]` `try1..try10` | VERIFIED — [P07-08 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §F-09]; evidence id [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-050] |
| **F-06** (Stage) | The **barcode carries the patient identifier** ⇒ it is a personally identifying document. | `barcodeprinter` / barcode payload | VERIFIED (as a design fact) — [P11 \| Stage-9-V-CD-2019-Final-Comprehensive-Report.md \| §6 security layer, F-06] |
| **F-11** (Stage) | **Windows-registry self-registrations** — 24 `$(DLLSelfRegister)` entries in the manifest's `[Setup1 Files]` section and 3 more in `[Bootstrap Files]`, **27 declared manifest-wide** — + writes into `System32`/`SysWOW64`. (Stage 2: the figure is read directly from the V1.605 manifests.) | `SETUP.LST` | VERIFIED — [P11 | Stage-9-V-CD-2019-Final-Comprehensive-Report.md | §6, F-11]; [P11 | analysis/V-CD-2019/12-install-media.md | §2.2]; [SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Bootstrap Files] and [Setup1 Files] sections] |
| **F-12** (Stage) | **3 of 5 PDF-stack binaries are unsigned and 2 use SHA-1** ⇒ "Unknown publisher" on modern Windows. | `osslsigncode` verification | VERIFIED — §7 below; [P11 \| pdf-print-stack.md \| §4] |
| **F-13** (Stage) | **.NET Framework 4.0 RTM** — out of support since 2014-04-29 and incompatible with Win10/11. | `dotNetFx40_Full_x86_x64.exe` | VERIFIED — [P11 \| pdf-print-stack.md \| §3.2] |
| **F-07** (Stage) | **Converting the database engine type does not move the data** — data stays on disk in the first database and is invisible in the second. | `RL_SETUP.exe` text | VERIFIED — [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2] |
| **F-08** (Stage) | The embedded manual is **~9 years older** than the application (CHM 2010 vs. a 2020 build) — a 4× documentation gap. | `help.chm` vs `RLS_Learn.pdf` | VERIFIED — [P11 \| analysis/V-CD-2019/03-capabilities.md] |
| **F-04** (Stage) | **Licence bound to hardware.** | `RL_SETUP.exe` / `Win32_Processor` | VERIFIED — [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4] |
| **F-10** (Stage) | `Patients_backup.mdb` **never updated** despite the live database changing. | `bin\` inventory | VERIFIED — [P07-08 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §backup]; ISS-18 |

### 6.3 The hard-coded `sa` / `12345678` credential — exact locations (VERIFIED, six independent sources)

| # | Exact location | Exact text | Source |
|---|---|---|---|
| 1 | `System\Setup.bat` | `SAPWD=12345678` | [P11 \| analysis/V-CD-2019/06-security.md \| F-01]; [P11 \| analysis/V-CD-2019/05-deployment.md \| §3] |
| 2 | `System\Setup4.bat` | `SAPWD=12345678` | same |
| 3 | `bin\BASE.ini` (2019 payload) | `UserID=sa` / `Password=12345678` (+ `PersistSecurityInfo=True`) | [P11 \| analysis/V-CD-2019/06-security.md \| F-01]; [P07-08 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §3] |
| 4 | `bin\data_connection1.udl` | `User ID=sa;Password=12345678` (+ `Persist Security Info=True`) | [P11 \| analysis/V-CD-2019/06-security.md \| F-01]; [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-018] |
| 5 | **`RL_SETUP.exe`** (the V2 installer) — two literal connection strings | `Provider=SQLOLEDB.1;Password=12345678;Persist Security Info=True;User ID=sa;Initial Catalog=patients;Data Source=<server>` and the same with `Initial Catalog=Interface` | [P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.1 and §2.2 row 4]; [P11 \| 11-Evidence/Evidence-Register.md \| EV-ANA-038] |
| 6 | **`bin\BASE.ini` → `[lastlog] try1`** — the on-disk log | `try1=20170926##ACCESS##SPRT007-PC##0##sa##12345678` | [P07-08 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §F-09] |

**Count: 6 locations** (rows 1–6 of the table above — rows 1–5 are file locations, row 6 is the `[lastlog]` entry inside
`bin\BASE.ini`). **All six are VERIFIED.**

---

## 7. Binary signing and licensing-compliance findings (V2)

Source: the BATCH-11 PDF/print stack analysis, `pdf-print-stack.md` §4 and §6, plus the PE envelope.

### 7.1 §4 — digital signature findings (VERIFIED, `osslsigncode` + `openssl pkcs7`)

| File | Signed? | Digest algorithm | Signer | Verification result |
|---|---|---|---|---|
| `Setup_BullzipPDFPrinter_11_1_0_2600_PRO_EXP.exe` | ✔ | **SHA-1** | **BioPDF ApS** (DK, Bohusvej 6) — issued by **COMODO RSA Code Signing CA** | **verification FAILED** |
| `dotNetFx40_Full_x86_x64.exe` | ✔ | **SHA-1** | **Microsoft Corporation** — Microsoft Code Signing PCA | **verification FAILED** |
| `gslite.exe` | ✘ | — | — | **no signature at all** |
| `pdfpowertool_setup.exe` | ✘ | — | — | **no signature at all** |
| `xpdfsetup.exe` | ✘ | — | — | **no signature at all** |

[P11 | pdf-print-stack.md | §4 digital signature]; envelope data in [P11 | analysis/BATCH-11/pe-envelope.md | §1 Envelope table] and
[P11 | analysis/BATCH-11/pe-envelope.csv]; evidence ids [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-060, EV-ANA-064].

**Bullzip certificate chain (exact):** Primary `CN=BioPDF ApS, O=BioPDF ApS, L=Alsager, postalCode=3140, ST=DK`;
issued by `COMODO RSA Code Signing CA`; **valid 2015-10-12 → 2020-10-11**; timestamp signer
`COMODO SHA-1 Time Stamping Signer` valid **2015-12-31 → 2019-07-09**; recorded signing time **2017-03-10 16:27:29 UTC**;
`osslsigncode verify` ⇒ `Signature verification: failed` and `Timestamp Server Signature verification: failed`, while the
**message digest matches** (`Current == Calculated`) ⇒ **the file was not modified; the failure is in the trust chain /
timestamping authority only.**
**.NET chain:** full Microsoft chain, **entirely SHA-1**, certificate valid 2009-12-07 → 2011-03-07, timestamp 2010-03-19 01:13:46 UTC.
[P11 | pdf-print-stack.md | §4].

**Documented conclusion (verbatim):** *"التوقيعان «موجودان وصالحان وقت التوقيع، لكنهما لا يُتحقَّق منهما اليوم»"* —
"the two signatures are *present and valid at the time of signing, but today they do not verify*", because of the broken **SHA-1**
algorithm and the expiry of the timestamping authority (2019) and of the Bullzip signing certificate (2020); on modern
Windows 10/11 this shows **"Unknown publisher"** or a warning. And: *"ثلاثة من خمسة ملفات **غير موقَّعة إطلاقًا**"* — three of the
five files are **not signed at all** (Ghostscript/AGPL, Xpdf/GPL, PDF Power Tool), so **their provenance and integrity cannot be
proven**. [P11 | pdf-print-stack.md | §4].

**PE import envelope (documented security-relevant analysis of what each binary pulls in)** — full table in
[P11 | analysis/BATCH-11/pe-envelope.md | §2 Imports]. Security-relevant import observations, all VERIFIED:
- `dotNetFx40_Full_x86_x64.exe` imports `ADVAPI32.dll` → `CryptGenRandom`, `CryptReleaseContext`, `CryptAcquireContextA`, **`DecryptFileW`**; plus `Cabinet.dll` (ordinal only), `SHELL32.dll` → `CommandLineToArgvW`, `SHBrowseForFolderW`, and a **50,258,992-byte overlay** (99.6 % of the file) that is a 7-Zip archive (LZMA:26 BCJ2) of the .NET 4.0 RTM payload.
- `gslite.exe`, `pdfpowertool_setup.exe`, `Setup_BullzipPDFPrinter…exe` and `xpdfsetup.exe` share an import set including
  **`ADVAPI32.dll` → `OpenProcessToken`, `LookupPrivilegeValueW`, `AdjustTokenPrivileges`** (token-privilege manipulation),
  `ExitWindowsEx` (shutdown/reboot from `user32`), and `VirtualProtect` (memory-protection change). All four are
  **Inno Setup** installers (Inno 5.5.0 / 5.5.6 / 5.5.7) with large overlays (98.8 % for Bullzip).
[P11 | analysis/BATCH-11/pe-envelope.md | §2].

### 7.2 §6 — licence compliance findings (VERIFIED)

| Component | Shipped licence | Impact on the vendor | Class |
|---|---|---|---|
| **Ghostscript 9.14.17 Lite** (`gslite.exe`) | **GNU AGPL v3** — the shipped `COPYING` is the complete AGPL text with **no exception** | **the strongest**: AGPL §13 requires source availability when used over a network | VERIFIED |
| **Xpdf 3.3.4** (`xpdfsetup.exe`) | **GPL v2 or v3** (dual) — `README` requires distributing the unmodified copies *with* README + COPYING + COPYING3 + documentation files; the installer **does** include them ✔ | attribution obligation | VERIFIED |
| **Bullzip PDF Printer 11.1** | commercial (BioPDF ApS) | **PRO/EXP is a paid edition** — one licence per copy | VERIFIED |
| **PDF Power Tool 4.0** | commercial (pdfpowertool.com) — `license.txt` (34.4 KiB) shipped | commercial licence verification required | VERIFIED |
| **.NET Framework 4.0** | Microsoft EULA | out of support | VERIFIED |

[P11 | pdf-print-stack.md | §6]; evidence ids [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-065].

**The document's own precise caveat (quoted):** Ghostscript is **not merged into RealLab's own code**; it is invoked as a
separate process or shipped inside Bullzip ⇒ *"الأرجح أن «تجميع عادي» (mere aggregation) ولا يسري التزام GPL على RealLab نفسه"*
("most likely mere aggregation, so the GPL obligation does not bind RealLab itself") — but (1) licence disclosure is mandatory,
(2) any networked use of Ghostscript reopens the §13 question, (3) the disc distributes an AGPL tool through commercial
intermediaries, *"وهذه منطقة تحتاج رأيًا قانونيًا، ولستُ مُقرِّرًا هنا"* ("this area needs legal opinion, and I am not the decider here").
[P11 | pdf-print-stack.md | §6].

**Cross-cutting facts for the licensing/signing section (VERIFIED):**
- **Zero RealLab references inside the five binaries**: 0 strings pointing at `real lab` / `RL_SETUP` / `Lab_data` / `.mdb` /
  `Attach_*` / `Bullzip` / `gslite` / `pdftops` / `xpdf` / `pdfpowertool` — the stack is **pure third-party** and therefore
  wholly replaceable without touching application logic [P11 | pdf-print-stack.md | §1]; [P11 | 11-Evidence/Evidence-Register.md | EV-ANA-061].
- **3 / 5 files unsigned · 2 / 5 files signed with SHA-1** — the two audit counters used in the document
  [P11 | pdf-print-stack.md | §7 audit numbers].
- The PDF path depends on an **externally installed print driver with a hard-coded device name and version**
  (`Bullzip PDF Printer` @0x6A2486; `Bullzip PDF Printer 11.1 - Create File` @0x6A255E) — a **fragile coupling** that also
  means the PDF output surface is outside the application's own trust boundary.
  [P11 | pdf-print-stack.md | §2.1].
- The install chain is defective: `RL_SETUP.exe` calls `System\PDF\SetupP.bat` **before** `System\SetupPZ.bat`, so the first
  attempt installs Bullzip **before** .NET 4 exists (Bullzip 11 requires .NET 4); `System\PDF\SetupFN4.bat` is orphaned and has
  a broken relative path; and the log is written to **`C:\setup.log`** (drive root) via `start /B` **without `/wait`**
  [P11 | pdf-print-stack.md | §5.1–5.2].

---

## 8. Unverified security assumptions — what the evidence does **not** establish

Each item is explicitly marked and names the evidence that would close it. **None of these may be presented as a property of
the V2 product.**

**Four gaps are the highest-consequence ones and are named explicitly here:** (a) **credential storage** — how
`patientword` / `SecWord` are protected is **U-01**; (b) **session handling** — idle timeout, auto-logout and lockout are
**U-02** and **U-03**; (c) **the audit trail** — the only "who did what" trail beyond the print log (`printuser` /
`printdate` / `printnum`) and the attendance log (`loger`) is **U-04**, and permission changes are untraced; (d) **the SMS-gateway
credentials** `accuntID` / `accuntpw` in the `MyLabSetting` settings table — their protection and the authorisation on
third-party delivery are **U-17** and **P12**.

**Count: 17 named assumptions (U-01 … U-17), counted as the rows of the table below.**

| # | Assumption an implementer might make | Status | What is missing | Evidence that would be needed |
|---|---|---|---|---|
| U-01 | "Passwords are hashed (MD5/SHA/bcrypt) in the account table." | **NOT RECOVERABLE** | The account table stores `patientword` as `Text (40)` and `SecWord` as `varchar(10)`. No hash format, salt, iteration count or algorithm string appears anywhere in the archive; no SQL literal references `patientword` at all (the row is loaded with `SELECT * FROM patients where patientusname= '…'` and compared in VB6 code). | A VB6 decompilation of the `users`/`login` forms to statement level (ISS-23) showing the comparison routine, or a populated `patients` table row from a real installation. |
| U-02 | "There is a session timeout / auto-logout." | **NOT RECOVERABLE** | No timer, timeout or expiry literal is evidenced; the CHM documents only a manual "خروج" (Exit) button (CHM 002.htm step 4). | The `login`/`labmain` form code (13 / 71 methods) decompiled to statement level. |
| U-03 | "Failed logins are counted / the account is locked." | **NOT RECOVERABLE** | The only failure-adjacent artifact is `BASE.ini [lastlog] try1..try10`, which is a **database-connection** attempt log (engine, host, user, password), not an application login-attempt log. | `login` form code; or an application-level log table (none is evidenced). |
| U-04 | "There is an audit log of access/permission changes (who granted what, when)." | **NOT RECOVERABLE** | No such table exists in the 103-table shipped schema; the only "who did what" trail evidenced is **result-level** (`printuser`/`printdate`/`printnum`, `edituser2`/`editdate2`/`editnum` on `patientinfo`) and the **attendance** log (`loger`). Permission changes are not traced. | A `CREATE TABLE` for an access-audit table in the SQL-Server attach script `Attaching.sql` (not captured), or a `loger`-style table with an action column. |
| U-05 | "`grant1..grant17` map to named capabilities (e.g. delete-patient, print-result, edit-price…)." | **NOT RECOVERABLE** | No SQL literal reads any `grantN`; the vendor guide shows them only as screenshots; VB6 control captions were never extracted (ISS-06). | VB6 control-property extraction of the `users` form, or a visual read of the `RLS_Learn.pdf` §1-4 page images. |
| U-06 | "`useraccounts.Gtype` is an enumerated role type; `HDD1`/`HDD2` are defined paths." | **NOT RECOVERABLE** | Only `usersnum` and `usersdr` are referenced in SQL; `Gtype`/`HDD1`/`HDD2` never appear in a SQL literal. | The `z_labaccount`/`users` form code, or the `CREATE TABLE useraccounts` statement from the SQL-Server attach script. |
| U-07 | "Roles are pre-defined and assigned; permissions are not per-user." | **NOT RECOVERABLE / partly CONTRADICTED** | The vendor guide describes per-user permission setting (§1-4 "تحديد صلاحيات المستخدم"), and the flags are per account row. `Gtype` may provide grouping, but that is name-level inference only. | As U-06. |
| U-08 | "Data at rest is encrypted (TDE, file encryption, encrypted MDF)." | **NOT RECOVERABLE** | No encryption evidence; the product uses a plain `.mdb` (Access) / `.mdf` (SQL Server) and even the *administrative* credential is stored in clear text (§6.3). | Evidence of TDE or EFS in the deployment; none is present in the archive. |
| U-09 | "The transport tool (`Patient Data Transport.exe`) is permission-gated." | **NOT RECOVERABLE** | The tool is a separate VB6 executable with its own UI (`Form1` 14 methods, `Module1` 15 methods — 29 in total); it filters by branch, and **no user/role check is evidenced**. It is described as a patient-data movement tool deserving a permissions review (V2 F-05). | Statement-level decompilation of the tool's 29 methods. |
| U-10 | "The four PDF output folders are access-controlled." | **NOT RECOVERABLE** | `D:\PDF\Contracts\|Free\|Individual\|LabToLab` are plain filesystem paths written by an external print driver; no ACL/ownership evidence exists. | NTFS ACL evidence from an installed system. |
| U-11 | "The install-time `sa` password is changed by the customer." | **NOT RECOVERABLE / CONTRADICTED by the shipped state** | The 2019 payload still carries `sa`/`12345678` **and** a log of 10 prior attempts using that exact credential on a real host (`SPRT007-PC`). The CHM's own instruction to change the *maintenance* password (`123`) is a separate secret from the DB credential. | A post-install configuration audit of a deployed system. |
| U-12 | "The PDF/print-stack signing and licence defects are not properties of the V2 product." | **CONTRADICTED — VERIFIED for V2** | The PDF stack, its installers and the BATCH-11 analysis all belong to the shipped V2 payload, so the signing and licensing defects of §7 are properties of the V2 product. | Not applicable — the finding is confirmed for V2. |
| U-13 | "The `admin` account is removed at deployment." | **UNVERIFIED** | The CHM *instructs* it ("ثم قم بإنشاء مستخدمين وإحذف هذا الحساب"); no evidence exists that any shipped or deployed database has no `admin` row. | A row dump of `patients` from a real installation. |
| U-14 | "Branch scoping prevents cross-branch data access." | **UNVERIFIED** | The mechanism is a single character inside the patient id (`SUBSTRING(patientid,9,1)`) plus a `branche` column on the account row. Whether the application enforces it on *every* read is not evidenced — no SQL literal in the v1.605 pool filters by branch. | Statement-level analysis of the query paths; or a branch-isolation test (not performed — no dynamic analysis, ISS-07). |
| U-15 | "Runtime behaviour has been observed." | **UNVERIFIED — explicitly blocked** | No PE was ever executed: no Wine on the analysis host, so all runtime behaviour is inferred from static evidence. | [P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-07] — "dynamic analysis / PE execution is not possible on Linux (no Wine)"; status **محجوب — بانتظار تفويض منفصل** ("blocked — awaiting separate authorisation"). |
| U-16 | "The Access deployment has the same permission model." | **UNVERIFIED** | `useraccounts` and `loger` do **not** exist in the shipped Access `Patients.mdb`; the Access DDL variants (`ADD COLUMN … YESNO`) exist for `grant13..17` only. Whether the Access mode has an equivalent of `useraccounts` is not evidenced. | The Access-mode attach script or a live Access installation. |
| U-17 | "The SMS-gateway credentials `accuntID` / `accuntpw` in `MyLabSetting` are protected, and delivery to third parties is authorised." | **NOT RECOVERABLE** (Stage 2: the credential is **populated in clear text**, so the assumption is contradicted by the evidence) | The two columns exist in the shipped `MyLabSetting` table of the patient database (P12). **Stage 2:** the shipped V2 `Patients.mdb` holds 5 rows (one per branch slot, `LabID` 100–500) and the `LabID`=100 row carries a populated `accuntID` (8 characters) and a populated `accuntpw` (6 characters), both stored as clear `Text (50)`; rows 200–500 carry empty credential columns. No hashing, encryption or obfuscation evidence exists for them, and no authorisation gate is evidenced anywhere on the NATIGH.COM / `SMSSender` delivery path. The database was opened read-only; no live system was contacted. `[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\bin\Patients.mdb | table MyLabSetting, 5 rows, read-only via Microsoft.ACE.OLEDB.12.0]` | A populated row from a real installation showing the stored representation; the `SMSfrmsenderos` form code decompiled to statement level (ISS-23). |

---

## 9. ISS register — security-relevant entries

Source of record: [P11 | 10-Issues/Open-Issues-and-Limitations.md | §1 سجل القيود (ISS)].
Exact wording is reproduced; the "why it matters here" column is mine.

| ID | Exact register wording (Arabic, verbatim) | Nature / Impact | Proposed resolution | Status (verbatim) |
|---|---|---|---|---|
| **ISS-28** | **"اعتماد `sa`/`12345678` نصًّا صريحًا"** في `BASE.ini` و`data_connection1.udl` | **جوهري (تصميم)** / leakage of the credential with every connection (`PersistSecurityInfo=True`) | — (documented, not exploited) | **مُوثَّق** — `07-security-findings.md` F-01 |
| **ISS-36** | **"`DISABLENETWORKPROTOCOLS=0`** في تثبيت SQL Server Express" | **جوهري (أمني)** / the default install listens on the network with a weak password | — (documented; to be fixed in the alternative design) | **مُوثَّق** |
| **ISS-34** | **"جداول `win32_processor` و`loger`"** في SQL 1.605 | **جوهري** / they may be a system query and an event log — behaviour undocumented | analysis of the full `CREATE TABLE` in Stage 4 | **مفتوح** |
| **ISS-21** | **"هوية المورّد (RealLab / ais group) وشروط الترخيص لم تُبحث"** | **نطاق** / generalising to a reference system may have legal impact | Stage-2 note: the official manual is signed for RealLab and shows `http://reallabeg.com` and `Tel: 002 0114 484 8686` inside the executable, and the `admin`/`admin` default account is documented | **مؤجَّل** |
| **ISS-07** | **"تحليل ديناميكي / تنفيذ PE غير ممكن على Linux (لا Wine)"** | **محجوب** / no observation of actual behaviour | requires: explicit authorisation + Wine + an independent safety assessment + an isolated environment | **محجوب — بانتظار تفويض منفصل** |
| **ISS-23** | **"`vb6decompiler procs` لا تستعيد عناوين الإجراءات"** (1,202 مدخلًا بلا عنوان، `unique_entries=0`) | **جوهري** / SQL cannot be bound to a specific procedure | manual reading of `PROJECT`/`ObjectTable` from the VB6 structure inside `.text` | **مفتوح** |
| **ISS-06** | **`Semi-VB-Decompiler` تطبيق Windows فقط** | **جوهري** / no extraction of VB6 control properties (GAP-1) | solved on Linux by `vb6decompiler blob` (117 forms + 9,281 controls + geometry) and `literals`; **detailed properties (Text/Caption) still need COM** | **جزئي — البديل كافٍ للتحليل البنيوي** |
| **ISS-18** | **"`Patients_backup.mdb` لم يُحدَّث مع تغيّر `Patients.mdb`"** | **دلالي** / freshness of the backup copy | partially: the shipped backup holds **2,786 rows** vs **3,123** in `Patients.mdb` — i.e. it is **not** an updated copy | **مفتوح** |
| **ISS-33** | **"ملفات التثبيت المُشار إليها في `Setup*.bat` غير مُدرجة في الجرد"** | ~~جوهري~~ | closed: `SETUP.LST` (39 files) · `MDAC_TYP.EXE` · the CABs · VB6 SP6 · .NET 4 + Bullzip · the three PDF setup scripts — **all install paths documented**; separate note: **5 major Microsoft installers (SQLEXPR · MSXML · .NET FX2 · MSI 3.1 · MySQL ODBC) are not in the shipped tree** | **✅ VERIFIED** |
| **ISS-38** | **"حمولة `RL_SETUP.exe` بصيغة VB6 مخصّصة داخل `.text` — بلا توقيع أرشيف قياسي"** | **جوهري** / the 22.95 MB payload cannot be unpacked without the installer | reverse the compression algorithm, or extract it from the CAB payload (BATCH-10) | **مفتوح** |
| **ISS-30** | **"`patientinfo` فارغة (0 صفوف)"** | **مهم** / no real patient record for validation | possibly a demo-initialised database, or exported before delivery | **مفتوح** |
| **ISS-09** | **`FileVersionInfo` فارغ لـ709 ملفات (84.7%)** | **جوهري** / version attribution depends on the path rule, not on in-file data | internal format inspection in Stage 2 | **مفتوح — يُعالَج في Stage 2** |

### 9.1 Stage-11 issue IDs that are security-relevant (introduced after the P11 register snapshot)

These IDs are defined in the BATCH-11 architecture report rather than in the P11 register — cited with their own marker:

| ID | Title (verbatim from the source table) | Section | Class |
|---|---|---|---|
| **ISS-49** | — 🆕 **رابط هشّ مُثبَّت** ("fragile hard-coded link" — the Bullzip device name + version) | [P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §requirements table] | VERIFIED |
| **ISS-50** | — 🆕 **‹.NET 4.0 RTM› خارج الدعم** | same | VERIFIED |
| **ISS-51** | — 🆕 **3 ملفات بلا توقيع + 2 بـ SHA-1** | same → §7.2 above | VERIFIED |
| **ISS-52** | — 🆕 **امتثال AGPL/GPL/تجاري** | same → §7.2 above | VERIFIED |
| **ISS-53** | — 🆕 **سلسلة تثبيت معطوبة** (broken install chain) | same → §7.2 above | VERIFIED |
| **ISS-46** | the plaintext password log | [P11 \| Stage-9-V-CD-2019-Final-Comprehensive-Report.md \| §7 constraints map, "ISS-46 سجلّ كلمات المرور"] | VERIFIED (= F-09) |

**Count: 6 Stage-11 security-relevant issue IDs** (rows of the table above).

---

## 10. Reproducibility index

Every count and every quoted value in this document comes from one of the following named files (paths relative to the
patch's deliverable tree).

| Claim area | Named source file | Locator used |
|---|---|---|
| V2 binary identity | `analysis/BATCH-04/pe-reports/real lab system.exe.json` | `version_info`, `"pe"."timestamp"` (1595435962 → 2020-07-22 16:39:22 UTC), `pe.imports` (1 DLL / 231 functions), `pe.resources` (12) |
| Account table + grant columns | `analysis/BATCH-07/db/v2019-Patients.mdb.sql` | `CREATE TABLE [patients]` (grant1..grant17, patientad, patientus, patientuscap, patientword, SecWord, branche, startwork/endwork/breakyorn/breaktime), `CREATE TABLE [loggroup]` |
| Embedded DDL (exact types) | `analysis/BATCH-04/schema/ddl-all.txt` | grant13..17 (Bit / YESNO), `useraccounts` HDD1/HDD2/Gtype, `Patients.branche`, `Patients.SecWord` |
| DDL with byte offsets | `analysis/BATCH-04/sql_v1605/ddl-evidence.txt` | lines 35–37, 258–267 |
| SQL statements (no grant read anywhere) | `analysis/BATCH-04/sql_v1605/statements.csv` | 6D6F18, 6D76E8, 6EF0FC, 6EF184, 6EF2AC, 6EF304, 6EF640, 6EFE40, 69119A, 704D98, 70B700, 726A64…, 72ABDC…, 72C568 |
| Table/statement counts (117 tables) | `analysis/BATCH-04/sql_v1605/tables.csv`; `analysis/V-CD-2019/02-schema.md` | rows `patients` (14), `useraccounts` (6), `loger` (5), `loggroup` (7), `win32_processor` (1) |
| Access-vs-SQL-Server split | `analysis/BATCH-07/db/v2019-Patients.mdb.sql` (103 × `CREATE TABLE`; no `useraccounts`); `analysis/V-CD-2019/08-deployment-installer.md` §2.1 (setting tables in `Interface`) | §2.2, §5.2 |
| VB6 objects / controls | `analysis/BATCH-04/vb6/v1605/objects.json`, `forms-blob.txt` | `users` 57/83, `server` 17/27, `login` 13/8, `userspw` 12/15, `logindete` 6/12, `z_labaccount` 18/32 |
| Official CHM text (15 topics) | `analysis/BATCH-04/help_v1605/help-manual-ar.md` (MD5 `00182711966046b5d328741536d68814`) | topics 001, 002, 003, 007, `backup.htm` |
| Official 2017 learning guide | `analysis/BATCH-05/manuals/RLS_Learn.txt` | §1-4, §2-4, §3-4 (attendance; TOC entry 4-3), TOC 3-11 |
| V2 security findings F-01..F-06 | `analysis/V-CD-2019/06-security.md` | F-01..F-06 |
| 2019 payload (credential confirmation, F-09) | `analysis/V-CD-2019/11-deployment-payload-2019.md` | §3 `BASE.ini`, §F-09, §backup |
| Installer / engine / DB layout | `analysis/V-CD-2019/08-deployment-installer.md` | §2, §2.1, §2.2, §3.1, §4, §5 |
| Install media / registry writes | `analysis/V-CD-2019/12-install-media.md` | §2.2 (`$(DLLSelfRegister)` × 24), §7 |
| PDF/print stack, signing, licensing | `pdf-print-stack.md` | §1, §2.1–2.5, §3, §4, §5.1–5.2, §6, §7 |
| PE envelope of the 5 PDF binaries | `analysis/BATCH-11/pe-envelope.md` + `.csv` | §1 Envelope, §2 Imports |
| Stage-9 report (Stage-numbered findings) | `Stage-9-V-CD-2019-Final-Comprehensive-Report.md` | §6 security layer, §7 constraints map |
| ISS register | `10-Issues/Open-Issues-and-Limitations.md` | §1 ISS register entries cited above |
| Evidence provenance | `11-Evidence/Evidence-Register.md` | EV-ANA-018, EV-ANA-035, EV-ANA-038, EV-ANA-050, EV-ANA-060, EV-ANA-061, EV-ANA-064, EV-ANA-065 |

**Counted totals asserted in this document (all reproducible):**

| Count | Value | Counting method / source |
|---|---|---|
| V2 account-table capability flags | **17** (`grant1`..`grant17`) | count of columns named `grant<N>` in `CREATE TABLE [patients]` (`v2019-Patients.mdb.sql`), inclusive of both ends |
| Grant columns issued by the embedded DDL | **5** (`grant13`..`grant17`) | `ddl-all.txt` — 5 columns × 2 dialects = **10** grant-bearing DDL statements, the only `grant` occurrences in the SQL pool |
| Account-table columns created by the embedded DDL | **7** (`branche`, `grant13`..`grant17`, `secword`) | `ddl-all.txt` `ALTER Table Patients` statements + `v2019-Patients.mdb.sql` |
| `useraccounts` columns created by the embedded DDL | **3** (`Gtype`, `HDD1`, `HDD2`) | `ddl-all.txt` |
| Named role terms in the vendor documentation | **4** | rows of the §1.3 table |
| Enumerated roles in the archive | **0** | no role table / privilege matrix / permission dictionary exists (§1.1) |
| Documented authorization rules | **9** (A1–A9) | rows of the §3 table, excluding the quality gate A10 and the absence row A11 (11 rows in total) |
| Protected functions / operations | **13** (P1–P13) | rows of the §4 table |
| Named unverified security assumptions | **17** (U-01…U-17) | rows of the §8 table |
| Tables in the shipped 2019 Access DB | **103** | `v2019-Patients.mdb.sql` (103 × `CREATE TABLE`) |
| SQL statements referencing `useraccounts` | **6** | `sql_v1605/tables.csv` row `useraccounts` |
| SQL statements referencing `loger` | **5** | `sql_v1605/tables.csv` row `loger` |
| SQL statements referencing `loggroup` | **7** | `sql_v1605/tables.csv` row `loggroup` |
| SQL statements referencing the account table `patients` | **14** | `sql_v1605/tables.csv` row `patients` |
| SQL statements reading any `grantN` column | **0** | grep over `sql_v1605/statements.csv` → only the 10 DDL lines |
| Embedded DDL statements in the V2 binary | **268**, of which **27** are `CREATE TABLE` and **241** are `ALTER TABLE` | direct literal count over `analysis/BATCH-04/schema/ddl-all.txt` (27 / 241); `analysis/V-CD-2019/00-baseline-summary.md` §2 states the 268 total only |
| PDF-stack binaries | **5** (3 unsigned · 2 SHA-1) | `pdf-print-stack.md` §4, §7 |
| ActiveX/DLL self-registrations at install | **24** | `analysis/V-CD-2019/12-install-media.md` §2.2 |
| CHM topics | **15** | `analysis/V-CD-2019/03-capabilities.md` |
| Hard-coded `sa`/`12345678` locations | **6** | rows 1–6 of the §6.3 table |
| Stage-11 security-relevant issue IDs | **6** (ISS-46, ISS-49…ISS-53) | rows of the §9.1 table |

---

## Provenance and method

This document was derived from the source findings file `06_permissions_security_findings.md`, which in turn was assembled
from the evidence archive's patch trees: the v1.605 executable analysis (`P04` → `analysis/BATCH-04/**`), the vendor
manuals and the 2017 learning guide (`P05` → `analysis/BATCH-05/**`), the 2019 shipped Access database and deployment
payload (`P07-08` → `analysis/BATCH-07/**`, `analysis/V-CD-2019/**`), and the BATCH-11 PDF/print-stack analysis together
with the V-CD-2019 synthesis, issue register and evidence register (`P11` → `analysis/BATCH-11/**`,
`10-Issues/Open-Issues-and-Limitations.md`, `11-Evidence/Evidence-Register.md`, `pdf-print-stack.md`). Every substantive item
carries one of the five evidence classes — **VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED**,
**NOT RECOVERABLE** — in the form stated in "Evidence base and method" above, and every claim keeps a
`[patch marker | path | anchor]` citation to a named file. The inventory figures quoted in §10 are counted directly from the
row sets of this document's own tables (roles, authorization rules, protected functions, unverified assumptions) or from the
source evidence named in the right-hand column of that table (column counts, statement counts, table counts, DDL and
binary counts); no figure is estimated and no mechanism absent from the archive has been credited to the product.

*End of RefLab V2 — Permissions, Roles & Security. Every claim above is traceable to a named file; nothing was inferred from
conventional practice, and no mechanism absent from the archive has been credited to the product.*
