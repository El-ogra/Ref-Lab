# RefLab Version 2 (V2) — Business Rule Catalogue

**System under documentation:** **RefLab Version 2 (V2)** — the **RealLab V-CD-2019** line.
**Shipped executable:** `real lab system.exe`, **FileVersion 1.605**, `Description: RLS 1.605`, `CompanyName: RealLab`, 76,292,096 bytes, PE32 / linker 6.0, PE build stamp **1595435962 = 2020-07-22 16:39:22 UTC** `[P11 | analysis/BATCH-04/pe-reports/real lab system.exe.json | "pe"."timestamp"]`.
**Deployment root:** `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`).
**Evidence patch markers:** `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`.
**Deliverable:** documentation-only business-rule catalogue for V2. No application code is produced.

---

## 0. Evidence base and method

### 0.1 Version identity

| Property | Value |
|---|---|
| System under documentation | **RefLab Version 2 (V2)** — the **RealLab V-CD-2019** line |
| Shipped executable | `real lab system\RL_CD2019Access\System\real lab system.exe` |
| FileVersion / Description | **1.605** / `RLS 1.605` (`CompanyName: RealLab`) |
| Size / format | 76,292,096 bytes · PE32 / linker 6.0 |
| SHA-256 | `C54CE6C8C98A679EFC5AB485BC4B313B452026D6A40F9BDA36ECA7EA18DF93C0` |
| PE build stamp | **1595435962 = 2020-07-22 16:39:22 UTC** `[P11 \| analysis/BATCH-04/pe-reports/real lab system.exe.json \| "pe"."timestamp"]` |
| Deployment root | `real lab system\RL_CD2019Access\` (`bin`, `Cache`, `Data`, `Fonts`, `OCX`, `System`) |
| Evidence patch markers | `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]` |

### 0.2 Evidence roots

* `[P11 | analysis/**]` — the current working set: the 1.605 SQL pool, the embedded schema DDL, the 2019 database DDL dumps, the installer and deployment-payload analyses, the RTF method-sheet library, the SHA-256 inventory ledger and the open-issue register.
* `[P11 | analysis/V-CD-2019/**]` — the V2 synthesis documents (vendor capability catalogue, schema, deployment payload); they are where the catalogue-level row counts published for V2 are taken from.
* `[P11 | analysis/BATCH-04/**]` — the 1.605 SQL pool, the embedded schema DDL, the PE reports and the official-manual extract.
* `[P11 | analysis/BATCH-07/**]` — the 2019 DDL dumps, the configuration-diff analyses and the schema-apply ledger.
* `[P11 | inventory/ledger.csv]` — the SHA-256 evidence ledger.
* `[P11 | 10-Issues/Open-Issues-and-Limitations.md]` — the open-issue register.

| Marker | Folder | Contents of note |
|---|---|---|
| `P04` | `extract/بعد الدفعة الرابعة` | `ddl-all.txt`, `column-evolution.csv`, `version-baseline.csv`, `BATCH-05.md` |
| `P05` | `extract/بعد الدفعة الخامسة` | `BATCH-06.md`, `RLS_Setup.txt` |
| `P06` | `extract/بعد الدفعة السادسة` | `BATCH-07.md` (manifest), `08-deployment-installer.md` |
| `P07` | `extract/بعد الدفعة السابعة والثامنة` | `BATCH-09.md`, `ini-diff-summary.md`, `v2019-Patients.mdb.sql` |
| `P09` | `extract/بعد الدفعة التاسعة` | `BATCH-10.md` |
| `P10` | `extract/بعد الدفعة العاشرة` | `BATCH-11.md`, `12-install-media.md` |
| `P11` | `extract/بعد الدفعة الحادية عشر` + `nested/P11/` | the full current working set (all `analysis/**`, `inventory/`, `10-Issues/`, `02-Versions/`) |

### 0.3 Evidence classes

| Class | Meaning as used in this catalogue |
|---|---|
| **VERIFIED** | Directly attested by a V2 artefact — a file that ships in the 2019 CD, the 2019 database DDL, the 1.605 binary or its SQL pool, or the official manual shipped with the CD — and reproducible from the named file. |
| **INFERRED** | Strongly implied by two or more V2 artefacts but not stated verbatim. |
| **UNVERIFIED** | Asserted by an artefact whose value could not be re-confirmed against a V2 deployment in this archive; it must not be treated as a V2 fact. |
| **NOT DOCUMENTED** | Stated nowhere in the evidence; recorded as an open point. |
| **NOT RECOVERABLE** | The evidence needed does not exist in this archive (for example the row data of the live V2 `Patients.mdb`). |

> **Rule IDs (`BR-*`) are documentation-only labels created by this analysis.** They do not exist in the product. Each is stated as a documentation-only Rule ID.

### 0.4 Counting method

A **rule** is one `#### BR-xx-nnn` heading; a domain's rule count is the number of such headings in that domain's subsection, and the catalogue total is the sum of the ten domain counts (§1.0 and Appendix A). Column, row and DDL-statement counts are counted from the numbered rows of the corresponding table in this document. A figure that is read from the live V2 store — a row count, a value distribution or a cell value — is classed **NOT RECOVERABLE** for V2 unless a V2-primary source (a V2 synthesis document, a V2 payload artefact or the shipped 2019 schema) publishes it; a figure published by such a source keeps the class of that source.

---

## 1. Rule catalogue by functional domain

### 1.0 Domain index — documentation-only Rule IDs

Every rule below is carried in the domain section that follows it. The **Domain** column names the functional domain of §1.1–§1.10; the **Evidence class** column gives the rule's governing evidence class (a rule with a mixed class shows both, in the order VERIFIED → INFERRED → UNVERIFIED).

| Rule ID | Rule (one line) | Domain | Evidence class |
|---|---|---|---|
| `BR-CLIN-001` | Haematocrit auto-calculation from haemoglobin | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-002` | Haemoglobin percentage (male, > 12 years): `Hgb% = Hgb × 6.25` | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-003` | Haemoglobin percentage (female, > 12 years): `Hgb% = Hgb × 6.75` | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-004` | Haemoglobin percentage (1–12 years, either sex): `Hgb% = Hgb × 7.50` | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-005` | Haemoglobin percentage (< 1 year, either sex): `Hgb% = Hgb × 8.25` | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-006` | PT control time, primary control level — the shipped value is not recoverable | Clinical constants & formulas | VERIFIED / NOT RECOVERABLE |
| `BR-CLIN-007` | PT control time, secondary control level — the shipped value is not recoverable | Clinical constants & formulas | VERIFIED / NOT RECOVERABLE |
| `BR-CLIN-008` | ISI (International Sensitivity Index) — the shipped value is not recoverable | Clinical constants & formulas | VERIFIED / NOT RECOVERABLE |
| `BR-CLIN-009` | PT control time ↔ concentration mapping, with a Westgard 2CV reject rule | Clinical constants & formulas | INFERRED / NOT RECOVERABLE |
| `BR-CLIN-010` | Constant groups are addressed by a group key, and V2 reads three of them | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-011` | The CBC constants are operator-editable live, during result entry | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-012` | Pre-first-use obligation on system constants | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-013` | `constanttable` carries a seventh constant slot (`constant7`) | Clinical constants & formulas | VERIFIED |
| `BR-CLIN-014` | V2 scopes the PT control curve by a constant id and stores concentration as float | Clinical constants & formulas | VERIFIED |
| `BR-RANGE-001` | `normalrange` is the single master reference-range table | Reference ranges & flags | VERIFIED |
| `BR-RANGE-002` | Range lookup key = `testcode` + `REFRANGE='1'` + `pregsmok` | Reference ranges & flags | VERIFIED |
| `BR-RANGE-003` | Age banding = sex × age-unit × [firstold … secondold] | Reference ranges & flags | VERIFIED |
| `BR-RANGE-004` | Documented six-band prescription when a test has no sex difference | Reference ranges & flags | VERIFIED |
| `BR-RANGE-005` | Documented four-band prescription when the range varies with age | Reference ranges & flags | VERIFIED |
| `BR-RANGE-006` | Abnormality is decided by `lowlimit` / `highlimit`, and out-of-range results are shaded in the report | Reference ranges & flags | VERIFIED |
| `BR-RANGE-007` | Low / High flag text (`nolowexe` / `nohighexe`) | Reference ranges & flags | VERIFIED |
| `BR-RANGE-008` | Low / High comment (`lowcomment` / `highcomment`) | Reference ranges & flags | VERIFIED |
| `BR-RANGE-009` | Critical range, critical limits, critical flag and critical comment — manual wording against the shipped V2 schema | Reference ranges & flags | VERIFIED / INFERRED |
| `BR-RANGE-010` | 🔒 The reference range is FROZEN onto the result at entry time | Reference ranges & flags | VERIFIED |
| `BR-RANGE-011` | `pregsmok` is a pregnancy/smoking variant selector; its value distribution is not recoverable | Reference ranges & flags | VERIFIED / INFERRED / NOT RECOVERABLE |
| `BR-RANGE-012` | The `REFRANGE` one-character flag marks the "active" range of a test | Reference ranges & flags | VERIFIED / INFERRED / NOT RECOVERABLE |
| `BR-RANGE-013` | Reference-range maintenance is a joined (SHAPE) view of test + range | Reference ranges & flags | VERIFIED |
| `BR-RANGE-014` | 🔒 Test number 4 (Urine) may not be renumbered or renamed | Reference ranges & flags | VERIFIED |
| `BR-RANGE-015` | Range administration is a System-data operation with Add / Edit / Save / Undo / Delete | Reference ranges & flags | VERIFIED |
| `BR-RANGE-016` | Reference ranges are edited per analyte element, not only per test | Reference ranges & flags | VERIFIED |
| `BR-RANGE-017` | Units dictionary and unit echo on the report | Reference ranges & flags | VERIFIED / NOT RECOVERABLE |
| `BR-LIFE-001` | `resultfinsh` — result entry completed | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-002` | `resultreview` — result reviewed and authorised (**F8**) | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-003` | `resultprint` — result printed (**F12**) | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-004` | `give` — results handed over to the patient | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-005` | `sentout` — the sample is a sent-out sample | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-006` | `send` — the sent-out sample has been dispatched | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-007` | `printwith` — the test is eligible for a combined report | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-008` | Four-key audit trail per result | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-009` | `printnum` — a numbered print counter (anti-copy audit) | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-010` | Result payload columns | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-011` | Result ordering within a patient = `arrangnum`, ties broken by test name | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-012` | 🔒 Print gate: only *reviewed* results may be printed | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-013` | Printable test-code sets are hard-coded per screen | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-014` | Manual override of the "delivered" state | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-015` | Patient-status icons are derived from the lifecycle flags | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-016` | Barcode-based delivery performs a two-step patient match | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-017` | V2 captures turnaround time on the result row | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-018` | V2 splits group requests into `patienttestgroup` and scratch work into `testtemp` | Result lifecycle & state machine | VERIFIED |
| `BR-LIFE-019` | Worklist rule: a request is "outstanding" while `resultfinsh = False` | Result lifecycle & state machine | VERIFIED |
| `BR-CAT-001` | `testtable` is the test catalogue *and* the price list | Profile / catalogue management | VERIFIED |
| `BR-CAT-002` | Groups (profiles) are first-class entities | Profile / catalogue management | VERIFIED / NOT RECOVERABLE |
| `BR-CAT-003` | The catalogue field dictionary (official, manual topic 007) | Profile / catalogue management | VERIFIED |
| `BR-CAT-004` | Receipt (bill) grouping rule | Profile / catalogue management | VERIFIED |
| `BR-CAT-005` | `testtime` drives the promised-result date on the receipt | Profile / catalogue management | VERIFIED |
| `BR-CAT-006` | Three price axes on the test | Profile / catalogue management | VERIFIED |
| `BR-CAT-007` | `loggroup` is the work-group routing key | Profile / catalogue management | VERIFIED |
| `BR-CAT-008` | `Branch_Data.mdb` is a schema-only template for seeding a branch | Profile / catalogue management | VERIFIED |
| `BR-CAT-009` | Every branch profile table has a fixed shape | Profile / catalogue management | VERIFIED |
| `BR-CAT-010` | Every V2 culture row carries a third organism | Profile / catalogue management | VERIFIED |
| `BR-CAT-011` | Antimicrobial sensitivity is a text field in V2 | Profile / catalogue management | VERIFIED |
| `BR-CAT-012` | V2 catalogue entities introduced by the embedded schema update | Profile / catalogue management | VERIFIED |
| `BR-CAT-013` | The abbreviation dictionary | Profile / catalogue management | VERIFIED / NOT RECOVERABLE |
| `BR-CAT-014` | Method text is carried in three separate layers | Profile / catalogue management | VERIFIED / NOT RECOVERABLE |
| `BR-CAT-015` | Work-sheet (WASL) list | Profile / catalogue management | VERIFIED |
| `BR-CAT-016` | Price lists per referring party | Profile / catalogue management | VERIFIED |
| `BR-CAT-017` | Custom (ad-hoc) profiles and their own prices | Profile / catalogue management | VERIFIED |
| `BR-ID-001` | `patientid` is a fixed-length composite key of 13 characters | Branch & identifier rules | VERIFIED |
| `BR-ID-002` | The short display identifier is characters 10–12 of `patientid` | Branch & identifier rules | VERIFIED |
| `BR-ID-003` | The branch indicator is character 9 of `patientid` | Branch & identifier rules | VERIFIED |
| `BR-ID-004` | `labid` is the laboratory/workstation code, distinct from the patient work code | Branch & identifier rules | VERIFIED |
| `BR-ID-005` | Barcodes are per-sample, per-test | Branch & identifier rules | VERIFIED / NOT RECOVERABLE |
| `BR-ID-006` | The patient ID card / invoice layout is externalised to `IDCARD.INI` | Branch & identifier rules | VERIFIED |
| `BR-ID-007` | The blank-patient sentinel | Branch & identifier rules | INFERRED |
| `BR-ID-008` | The multi-branch operating model | Branch & identifier rules | VERIFIED |
| `BR-ID-009` | `testtable.branch` = the branch responsible for the test; `loggroup` = the analyser/work group | Branch & identifier rules | VERIFIED |
| `BR-BILL-001` | The five patient-level money fields | Billing & receivables | VERIFIED |
| `BR-BILL-002` | Referral commission = `Gehats.omola` % of the patient net price | Billing & receivables | VERIFIED |
| `BR-BILL-003` | The referring-party master (`Gehats`) | Billing & receivables | VERIFIED |
| `BR-BILL-004` | The payment ledger and its V2 identity column | Billing & receivables | VERIFIED |
| `BR-BILL-005` | The sent-out money triad | Billing & receivables | VERIFIED |
| `BR-BILL-006` | The accounting / stock-take window (F7) | Billing & receivables | VERIFIED |
| `BR-BILL-007` | The sent-out management window (F7) and its settlement rules | Billing & receivables | VERIFIED |
| `BR-BILL-008` | Delivery-window settlement actions | Billing & receivables | VERIFIED |
| `BR-BILL-009` | Patient balances and the "balance owed to the patient" case | Billing & receivables | VERIFIED / INFERRED |
| `BR-BILL-010` | `patientinfo.pricemethod` and `Gehats.pricemethod` select the price basis | Billing & receivables | VERIFIED |
| `BR-BILL-011` | V2 patient-side billing and contact columns | Billing & receivables | VERIFIED |
| `BR-RPT-001` | Report layout is per-profile, in `Data\*.ini` | Reporting & printing | VERIFIED |
| `BR-RPT-002` | The printed report anatomy | Reporting & printing | INFERRED |
| `BR-RPT-003` | Column geometry is driven by INI keys | Reporting & printing | VERIFIED |
| `BR-RPT-004` | Report titles are INI-driven | Reporting & printing | VERIFIED |
| `BR-RPT-005` | Colour and font configuration is INI-driven | Reporting & printing | VERIFIED |
| `BR-RPT-006` | 51 V2 report layouts are re-flowed to make room for the third culture organism | Reporting & printing | VERIFIED |
| `BR-RPT-007` | V2 centralises the signature texts | Reporting & printing | VERIFIED |
| `BR-RPT-008` | Six printer roles in V2 | Reporting & printing | VERIFIED |
| `BR-RPT-009` | V2 printer defaults and head/tail suppression | Reporting & printing | VERIFIED |
| `BR-RPT-010` | PDF output is produced by an external Windows printer driver, not by the application | Reporting & printing | VERIFIED |
| `BR-RPT-011` | Print audit trail and numbered printing | Reporting & printing | VERIFIED |
| `BR-RPT-012` | Printing is gated on verification | Reporting & printing | VERIFIED |
| `BR-RPT-013` | Second-layout variants (`_S.ini`) | Reporting & printing | VERIFIED |
| `BR-RPT-014` | The report colour palette is an INI file with a `.dll` extension | Reporting & printing | VERIFIED |
| `BR-RPT-015` | The report category catalogue | Reporting & printing | INFERRED |
| `BR-RPT-016` | `Cache\*.rtf` are method-description sheets, not print templates | Reporting & printing | VERIFIED |
| `BR-RPT-017` | Work-sheet printing module | Reporting & printing | VERIFIED |
| `BR-SMS-001` | Recipient directory `smslist` | SMS & notifications | VERIFIED |
| `BR-SMS-002` | The pending-recipient rule | SMS & notifications | VERIFIED |
| `BR-SMS-003` | Group-scoped recipient rule | SMS & notifications | VERIFIED |
| `BR-SMS-004` | Recipient groups and message templates | SMS & notifications | VERIFIED |
| `BR-SMS-005` | The outbound SMS log `SMSSender` | SMS & notifications | VERIFIED |
| `BR-SMS-006` | Laboratory-level SMS configuration `MyLabSetting` | SMS & notifications | VERIFIED / INFERRED |
| `BR-SMS-007` | Patient contact channels in V2 | SMS & notifications | VERIFIED |
| `BR-SMS-008` | NATIGH.COM e-result delivery is gated on a per-result flag that was NOT applied | SMS & notifications | VERIFIED |
| `BR-SMS-009` | The separate e-mail sender utility | SMS & notifications | VERIFIED |
| `BR-SMS-010` | The note-taking subsystem is consolidated into one component | SMS & notifications | VERIFIED |
| `BR-SMS-011` | `NOTE.ini` carries an observation/comment identifier in V2 | SMS & notifications | VERIFIED / INFERRED |
| `BR-SETUP-001` | The database engine is an explicit install-time choice | Setup & configuration | VERIFIED |
| `BR-SETUP-002` | 🔴 Converting between engines does NOT move the data | Setup & configuration | VERIFIED |
| `BR-SETUP-003` | In SQL Server mode the product uses a *separate interface database* (and a third, `VIDAS`) | Setup & configuration | VERIFIED |
| `BR-SETUP-004` | Deployment paths | Setup & configuration | VERIFIED |
| `BR-SETUP-005` | `BASE.ini` is the DB-selection and last-connection configuration | Setup & configuration | VERIFIED / INFERRED |
| `BR-SETUP-006` | `SETING.ini` — printing, paper and branch behaviour | Setup & configuration | VERIFIED / UNVERIFIED |
| `BR-SETUP-007` | The date-display language must be set to **English (Canada)** | Setup & configuration | VERIFIED |
| `BR-SETUP-008` | Lab fonts are installed **manually** via Control Panel | Setup & configuration | VERIFIED |
| `BR-SETUP-009` | Licence is bound to the hardware | Setup & configuration | VERIFIED |
| `BR-SETUP-010` | The installer runs a fixed, ordered script set | Setup & configuration | VERIFIED |
| `BR-SETUP-011` | Installation self-registers 24 OCX/DLL components in the Windows registry | Setup & configuration | VERIFIED |
| `BR-SETUP-012` | The install media carries **no application copy** | Setup & configuration | VERIFIED |
| `BR-SETUP-013` | The "Database Maintenance" gate and its default password | Setup & configuration | VERIFIED |
| `BR-SETUP-014` | Backup file naming and location | Setup & configuration | VERIFIED |
| `BR-SETUP-015` | Backup completeness and performance rules | Setup & configuration | VERIFIED |
| `BR-SETUP-016` | The report-configuration surface exposed to the laboratory | Setup & configuration | VERIFIED |
| `BR-SETUP-017` | The `data_connection*.udl` files as shipped with the 2019 CD | Setup & configuration | VERIFIED |
| `BR-MIG-001` | The executable carries its own schema-update DDL | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-002` | Every schema-update statement exists in two dialects | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-003` | The applied/not-applied ledger (CREATE) | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-004` | The applied/not-applied ledger (ALTER ADD COLUMN) | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-005` | The 23 SQL-Server-only statements can never apply to the Access build | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-006` | The 38 Access-table statements that were not applied | Data integrity & embedded schema evolution | VERIFIED / INFERRED |
| `BR-MIG-007` | The V2 schema footprint | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-008` | The 14 type changes applied by the embedded schema update | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-009` | Identity / auto-increment columns introduced by the embedded schema update | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-010` | NOT NULL constraints are the schema's only hard integrity guarantee | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-011` | `normalrange.normalrang` is Text(255) in the live V2 database | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-012` | The shipped 2019 `Patients.mdb` is the installation-time store, and its rows are not recoverable | Data integrity & embedded schema evolution | VERIFIED / NOT RECOVERABLE |
| `BR-MIG-013` | The 2019 CD ships **two** branch templates | Data integrity & embedded schema evolution | VERIFIED |
| `BR-MIG-014` | The documentation layer is frozen nine years behind the binary | Data integrity & embedded schema evolution | VERIFIED |

**Rules per domain** (counting method: one rule per `#### BR-xx-nnn` heading in the domain subsection of §1.1–§1.10):

| Domain | Rules |
|---|---:|
| Clinical constants & formulas | 14 |
| Reference ranges & flags | 17 |
| Result lifecycle & state machine | 19 |
| Profile / catalogue management | 17 |
| Branch & identifier rules | 9 |
| Billing & receivables | 11 |
| Reporting & printing | 17 |
| SMS & notifications | 11 |
| Setup & configuration | 17 |
| Data integrity & embedded schema evolution | 14 |
| **Total** | **146** |

### 1.1 Domain A — Clinical constants & formulas

#### BR-CLIN-001 — Haematocrit auto-calculation from haemoglobin
* **Description:** When no haematocrit result is entered, the system derives it as `Hct = Hgb × 3.3`.
* **Conditions:** CBC profile entry; hematocrit field left empty.
* **Expected behaviour:** Hct is populated automatically from the haemoglobin result.
* **Exceptions:** Explicit operator entry of Hct overrides the computed value (the manual states the formula applies "when the hematocrit result is not entered").
* **Affected entities:** `constanttable` (group `CBCCONS`, slot `constant1`), `cbc.hct`, `cbc.hgb`.
* **Related functions:** Constants popup (`Constants` button, bottom-right of the result-entry window), CBC result form.
* **Evidence:** **VERIFIED** — value and formula are documented verbatim in the help file that ships inside the 2019 CD.
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm, CBC bullet]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the value stored in the live V2 `constanttable` is **NOT RECOVERABLE** (§2.1) — no row-level export of the live V2 store exists in the archive.

#### BR-CLIN-002 — Haemoglobin percentage (male, > 12 years): `Hgb% = Hgb × 6.25`
* **Description / Conditions:** `CBCCONS.constant2 = 6.25`; applies to a **male** patient **above 12 years of age**.
* **Expected behaviour:** the `hgbper` field of the CBC profile is computed from `hgb`.
* **Exceptions:** sex/age condition gates the constant; the operator may swap the constant for a child (BR-CLIN-011).
* **Affected entities:** `constanttable.constant2`, `cbc.hgbper`.
* **Related functions:** Constants popup.
* **Evidence:** **VERIFIED** — manual text "Hemoglobin % (Hgb%) = Hgb * 6.25 (Male age great than 12 years)".
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the value stored in the live V2 `constanttable` is **NOT RECOVERABLE** (§2.1).

#### BR-CLIN-003 — Haemoglobin percentage (female, > 12 years): `Hgb% = Hgb × 6.75`
* Same shape as BR-CLIN-002; `CBCCONS.constant3` = 6.75, female, age > 12 years.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the value stored in the live V2 `constanttable` is **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-004 — Haemoglobin percentage (1–12 years, either sex): `Hgb% = Hgb × 7.50`
* `CBCCONS.constant4` = 7.5; manual wording "Male or Female age from 1 – 12 years".
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the value stored in the live V2 `constanttable` is **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-005 — Haemoglobin percentage (< 1 year, either sex): `Hgb% = Hgb × 8.25`
* `CBCCONS.constant5` = 8.25; manual wording "Male or Female age less than one year".
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the value stored in the live V2 `constanttable` is **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-006 — PT control time, primary control level — the shipped value is not recoverable
* **Description:** `PTCONS.constant1` carries the primary **PT Control Time** (seconds) used for the PT control material; the manual requires "Prothrombin Time (PT): ISI, Control Time and Concentration table" to be verified before the first clinical use.
* **Affected entities:** `constanttable.constant1`, `pt.concent`, `PTC` table.
* **Evidence:** **VERIFIED** for the slot, its meaning and the pre-use obligation; the *value* the slot holds in the live V2 store is **NOT RECOVERABLE**.
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm — "Prothrombin Time (PT): ISI, Control Time and Concentration table"]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the primary control time a deployed V2 laboratory actually uses is **NOT RECOVERABLE** (§2.1); the laboratory must set it before first clinical use.
#### BR-CLIN-007 — PT control time, secondary control level — the shipped value is not recoverable
* **Description:** `PTCONS.constant2` carries the **PT Control Time (second level)** — the control level paired with the primary one in the QC scheme.
* **Evidence:** **VERIFIED** for the slot and its meaning (the manual requires the PT control time to be set before first use); the *value* the slot holds in the live V2 store is **NOT RECOVERABLE**.
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm — "Prothrombin Time (PT): ISI, Control Time and Concentration table"]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`
* **Outstanding:** the secondary control time a deployed V2 laboratory actually uses is **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-008 — ISI (International Sensitivity Index) — the shipped value is not recoverable
* **Description:** `PTCONS.constant3` carries the ISI; the derived INR field of the `pt` profile depends on it.
* **Affected entities:** `constanttable.constant3`, `pt.inr`, `pt.ratios`.
* **Evidence:** **VERIFIED** for the slot, its meaning and its consumer (the `pt` profile's `inr` / `ratios` columns); the *value* the slot holds in the live V2 store is **NOT RECOVERABLE**.
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm — "Prothrombin Time (PT): ISI, Control Time and Concentration table"]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE pt — columns pt, concent, inr, ratios, ptt]`
* **Outstanding:** the ISI a deployed V2 laboratory actually uses is **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-009 — PT control time ↔ concentration mapping, with a Westgard 2CV reject rule
* **Description:** `PTCONS.constant4` selects the "Control Time / Concentration" mapping used for PT quality control; the analysis' reading of that slot is the **Westgard 2CV (reject)** rule.
* **Affected entities:** `constanttable.constant4`, `PTC` (control ↔ concent pairs).
* **Evidence:** **INFERRED** — the manual documents a "Control Time and Concentration table" that must be verified before work starts, and the binary reads the PT curve in ascending `control` order with its bounds computed by MIN/MAX (BR-CLIN-014); the **Westgard 2CV** interpretation is INFERRED from that context, and the token the slot holds in the live V2 store is **NOT RECOVERABLE**. The per-test 2CV computation is not attested in any V2 artefact in this archive.
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm — "Prothrombin Time (PT): ISI, Control Time and Concentration table"]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable, PTC]`
* **Outstanding:** how the token is evaluated at runtime is **NOT RECOVERABLE**; no V2 SQL in `analysis/BATCH-04/sql_v1605/statements.csv` implements a 2CV computation.

#### BR-CLIN-010 — Constant groups are addressed by a group key, and V2 reads three of them
* **Description:** `constanttable.constantdiscrp` is the group discriminator. The 1.605 binary issues exactly three lookups:
  * `SELECT * FROM constanttable where constantdiscrp='PTCONS'`
  * `SELECT * FROM constanttable where constantdiscrp='CBCCONS'`
  * `SELECT * FROM constanttable where constantdiscrp='RATIOS'`
* **Conditions:** constants are read per group, never globally.
* **Expected behaviour:** each clinical module reads only its own constant group.
* **Affected entities:** `constanttable` (the group discriminator is the column `constantdiscrp`).
* **Related functions:** `SELECT` statements at VA `686E1E`, `6C540C`, `72F81C`.
* **Evidence:** **VERIFIED** — the three statements exist in the 1.605 SQL pool.
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 686E1E / 6C540C / 72F81C]`
* **Outstanding:** ⚠ **A `RATIOS` constant group is queried by V2, but no `RATIOS` row is attested for the live V2 store and no formula is documented.** Its values are **NOT RECOVERABLE**.

#### BR-CLIN-011 — The CBC constants are operator-editable live, during result entry
* **Description:** "To modify it while entering a child's result, we modify its constant … for a male or a female we modify the adult constant" — via the **`Constants`** button at the bottom-right of the result-entry window.
* **Conditions:** during CBC result entry.
* **Expected behaviour:** the constant used for the auto-calculation can be changed per-session without editing the database.
* **Exceptions:** the change is transient — the constants stored in the database remain the ones the laboratory starts from.
* **Affected entities:** `constanttable` (read), CBC result form.
* **Evidence:** **VERIFIED** (the official manual that ships with the 2019 CD).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm, "Constants" button paragraph]`
* **Outstanding:** the edit is transient; the values stored in the live V2 `constanttable` are **NOT RECOVERABLE** (§2.1).
#### BR-CLIN-012 — Pre-first-use obligation on system constants
* **Description:** Before working for the first time, the operator **must** verify the system constants and factors, specifically:
  * **Prothrombin Time (PT):** ISI, Control Time and Concentration table;
  * **Partial Thromboplastin Time (PTT):** Control Time;
  * **Complete Blood Count (CBC):** Hct and Hgb% formulas (BR-CLIN-001…005).
* **Conditions:** once, before first clinical use.
* **Expected behaviour:** the laboratory is accountable for validating the shipped default constants before issuing patient results.
* **Affected entities:** `constanttable`, `PTC`, `pt` profile.
* **Evidence:** **VERIFIED** (manual, shipped in the 2019 CD).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm, item 1]`
* **Outstanding:** the manual requires a usable **"Control Time and Concentration table"** for PT before work begins, while the value the live V2 store holds in `PTCONS.constant4` is **NOT RECOVERABLE** — the laboratory is therefore expected to supply it. This is an explicit manufacturer-shipped configuration gap.

#### BR-CLIN-013 — `constanttable` carries a seventh constant slot (`constant7`)
* **Description:** V2's `constanttable` has **8 columns** — `constantdiscrp`, `constant1..constant6`, **`constant7`** — and `constant7` is **added by the embedded schema-update DDL** (see §8).
* **Affected entities:** `constanttable`.
* **Evidence:** **VERIFIED** (2019 DDL + schema-apply ledger).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]` · `[P11 | analysis/BATCH-07/migration-proof.md | §3 — "constanttable.constant7"]`
* **Outstanding:** the *purpose* and values of `constant7` are **NOT RECOVERABLE**.

#### BR-CLIN-014 — V2 scopes the PT control curve by a constant id and stores concentration as float
* **Description:** In V2, `PTC` gains `ConstID Long Integer` (identity) and `concent` becomes `Double`; the binary queries `select * FROM PTC where ConstID=`, `SELECT * From PTC ORDER BY control`, and `SELECT MIN(control) AS Exprmin, MAX(control) AS Exprmax From PTC`.
* **Expected behaviour:** each control level can carry its own constant identity, allowing several control/calibration sets to coexist in one table; the curve is always read in ascending `control` order and its bounds are computed with MIN/MAX.
* **Affected entities:** `PTC` (V2: `control Double NOT NULL`, `concent Double NOT NULL`, `ConstID Long Integer`).
* **Evidence:** **VERIFIED**.
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE PTC]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6CA4B8 / 6CA7B4 / 6CAD50 / 677F4A / 67FA6]`

---
* **Outstanding:** how `ConstID` is allocated to a constant set at run time is **NOT RECOVERABLE** — no V2 SQL in the recovered pool inserts into `PTC.ConstID`.
### 1.2 Domain B — Reference ranges & flags

#### BR-RANGE-001 — `normalrange` is the single master reference-range table
* **Description:** One row per (test, sex, age band, pregnancy/smoking variant). V2 shape: 18 columns — `normalid, testcode, testsimp, subgroupcode, sex, firstold, secondold, ageunit, pregsmok, normalrang, testunit, lowlimit, highlimit, nolowexe, nohighexe, lowcomment, highcomment, REFRANGE`.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]`
* **Outstanding:** the number of rows the live 2019 `normalrange` holds is **NOT RECOVERABLE** (§4.3).
#### BR-RANGE-002 — Range lookup key = `testcode` + `REFRANGE='1'` + `pregsmok`
* **Description:** The 1.605 binary selects the applicable range with the predicate `REFRANGE='1' and pregsmok = <value>`, e.g. `SELECT * FROM normalrange where testcode=282 and REFRANGE='1' and pregsmok = '…'` (repeated for `testcode=580`, `581`, …).
* **Conditions:** a range is only eligible when its `REFRANGE` flag is `'1'` and its `pregsmok` value matches the patient context.
* **Expected behaviour:** rows with `REFRANGE=''` are *not* the active range for this lookup path.
* **Affected entities:** `normalrange.REFRANGE`, `normalrange.pregsmok`, `patientinfo.patientsex`, `patientinfo.patientage`, `patientinfo.patientageunit`.
* **Related functions:** result-entry range resolution; reference-range maintenance screen.
* **Evidence:** **VERIFIED** (1.605 SQL).
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6E94EC, 6E9640, 716994, 716B48, 716C20, 716DFC]`
* **Outstanding:** the mapping from "patient context" to the literal `pregsmok` value is **NOT RECOVERABLE**; only the query shape is attested.

#### BR-RANGE-003 — Age banding = sex × age-unit × [firstold … secondold]
* **Description:** Each range row carries `sex` (`Male`/`Female`/`All`/empty), `firstold`, `secondold`, `ageunit` (`Years`/`Days`/`Mons.`/empty). The reference-range maintenance view orders ranges `by sex, ageunit, firstold`.
* **Affected entities:** `normalrange.sex|firstold|secondold|ageunit`.
* **Evidence:** **VERIFIED** — both the DDL and the 1.605 SHAPE query `… APPEND ({SELECT testcode,sex,firstold,secondold,ageunit,normalrang FROM normalrange where normalrang <> '' order by sex,ageunit,firstold} … RELATE testcode TO testcode)`.
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 672E3E, 673172]`
* **Outstanding:** the runtime resolution order between the sex/age path and the `REFRANGE='1'` path is **NOT RECOVERABLE**; only the two query shapes are attested (BR-RANGE-012).
#### BR-RANGE-004 — Documented six-band prescription when a test has no sex difference
* **Description:** "In the case of a test whose natural rate does not differ between male and female — such as sugar — the rate is entered **six** times": Male 0→120 years **and** Female 0→120 years; Male 1→29 days **and** Female 1→29 days; Male 1→11 months **and** Female 1→11 months.
* **Expected behaviour:** a single analyte must be registered with six explicit rows so that every (sex × age-unit) combination resolves to a range.
* **Affected entities:** `normalrange`.
* **Evidence:** **VERIFIED** (manual, shipped with the 2019 CD).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm) — the "الرجال من 0 الى 120 سنة …" block]`
* **Scope:** the age-unit mix (`Years` / `Days` / `Mons.` / empty) that the live V2 `normalrange` actually carries is **NOT RECOVERABLE** (§4.2); the six-band prescription is a documented procedure that the laboratory applies when it builds the range catalogue.
* **Outstanding:** the per-band rows actually present in the live 2019 `normalrange` are **NOT RECOVERABLE** (§4.3); the six-band prescription is a documented procedure.
#### BR-RANGE-005 — Documented four-band prescription when the range varies with age
* **Description:** "Where the rate differs by age, e.g. males 0→12 years and males 12→120 years, and likewise for females."
* **Affected entities:** `normalrange`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm)]`
* **Outstanding:** the four-band rows actually present in the live 2019 `normalrange` are **NOT RECOVERABLE** (§4.3).
#### BR-RANGE-006 — Abnormality is decided by `lowlimit` / `highlimit`, and out-of-range results are shaded in the report
* **Description:** "Low limit / High limit — the values on the basis of which the result is considered **not normal** (outside the range, the **text background is shaded** in the report)."
* **Expected behaviour:** value < `lowlimit` or value > `highlimit` ⇒ abnormal, and the report renders the result with a shaded background.
* **Affected entities:** `normalrange.lowlimit|highlimit`, `patienttest.lowlimit|highlimit`.
* **Evidence:** **VERIFIED** (manual); the abnormal-highlighting behaviour is also stated in the result-entry topic: "when the result is entered the program distinguishes abnormal and critical results and also writes a distinction for them (high or low or critical)".
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm) Low/High limit]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 (004A.htm) part 2]`
* **Outstanding:** the critical-threshold layer that the manual documents has no columns in the shipped schema (BR-RANGE-009); the shaded-background behaviour is confirmed only for the low/high limits.
#### BR-RANGE-007 — Low / High flag text (`nolowexe` / `nohighexe`)
* **Description:** "Low flag : High flag — an expression that appears in the case of abnormal results (both while entering results in the window and while printing in the report)."
* **Affected entities:** `normalrange.nolowexe|nohighexe` (Text 20) → snapshotted to `patienttest.nolowexe|nohighexe`.
* **Evidence:** **VERIFIED** (manual + schema). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm)]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange, patienttest]`
* **Outstanding:** the flag-text values stored in the live V2 `normalrange` are **NOT RECOVERABLE** (§4.2).
#### BR-RANGE-008 — Low / High comment (`lowcomment` / `highcomment`)
* **Description:** "Low comment : High comment : / Critical comment — a comment about the patient's entered result that appears in the comment box and in the report when the test name is pressed, according to whether the patient's result is low, high or critical."
* **Affected entities:** `normalrange.lowcomment|highcomment` (Memo) → `patienttest`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm)]`
* **Outstanding:** the comment values stored in the live V2 `normalrange` are **NOT RECOVERABLE** (§4.2).
#### BR-RANGE-009 — Critical range, critical limits, critical flag and critical comment — manual wording against the shipped V2 schema
* **Description:** The manual documents four critical-range fields per reference range: `Critical range` (the text printed in the normal-range box, shown only when "print critical ranges" is selected in the report-settings window), `Low limit : High limit` (the values on which a result is judged **critical**), `Critical flag`, and `Critical comment`.
* **Condition (manual):** the critical-range *text* is printed **only if** "print critical ranges" is selected in the report-settings window.
* **Contradiction with the shipped schema:** the V2 live `normalrange` table has **no** `criticalrang`, `lowlcrit`, `highlcrit`, `criticalexe` or `criticalcomment` columns (18 columns total). The embedded 1.605 DDL contains **no** ALTER that adds them back. A 22-column shape carrying the critical columns is **not attested for V2**.
* **Expected behaviour (V2):** critical thresholds are carried by the RTF method sheets (`Cache\*.rtf`, shipped in the 2019 CD) and by the frozen `patienttest` snapshot, not by a per-range column family.
* **Affected entities:** `normalrange` (V2: absent), `patienttest` (frozen `normalrang`), `Cache\*.rtf`.
* **Evidence:** **VERIFIED** for both the manual statement and the schema fact; the *resolution* of the contradiction is **INFERRED** (see §4).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm) Critical range / Critical flag]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange — 18 cols, no critical*]` · `[P11 | analysis/BATCH-04/schema/ddl-all.txt | grep critical → no match]`
* **Outstanding:** whether the V2 UI still exposes critical-range entry (and silently discards it) is **NOT RECOVERABLE** — the shipped CHM is frozen at its pre-2019 text and does not describe the 1.605 behaviour.

#### BR-RANGE-010 — 🔒 The reference range is FROZEN onto the result at entry time
* **Description:** When a result is entered, the system copies the applicable range into the result row: `patienttest.normalrang` (the printed range text), `patienttest.lowlimit`, `patienttest.highlimit`, `patienttest.nolowexe`, `patienttest.nohighexe`, `patienttest.testunit`. The report then displays what was in force at the time of measurement, unaffected by later edits to the range table.
* **Evidence (V2-confirmed):** the 1.605 result query reads the range **from `patienttest`, not from `normalrange`**:
  `SELECT patientid,requestdate,subgroupcode,testcode,testsimp,arrangnum,resultt,testprice,testpriceout,sentout,testtime,printwith,loggroup,otherlabname,testabrev,testname,historyname,testunit,normalrang,lowlimit,highlimit,nolowexe,nohighexe,resultfinsh,resultreview,resultprint,give FROM patienttest where patientid='…'`
  and the report query selects `patienttest.testunit, patienttest.normalrang, patienttest.RESULTCASEPRINT`.
* **Affected entities:** `patienttest.normalrang|lowlimit|highlimit|nolowexe|nohighexe|testunit`.
* **Expected behaviour:** already-issued reports are immune to later range edits; audit-grade.
* **Exceptions:** `patienttest.normalrang` is `Text(255)` in V2 — a **length limit** of 255 characters on the frozen snapshot text.
* **Evidence:** **VERIFIED** (1.605 SQL + 2019 DDL).
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 7327CC, 732A48, 6895B6, 689D96]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** the snapshot-copy code path itself (the INSERT/UPDATE that populates those five fields) is **NOT RECOVERABLE** from the SQL pool; the inference rests on the read path + column pairing.

#### BR-RANGE-011 — `pregsmok` is a pregnancy/smoking variant selector; its value distribution is not recoverable
* **Description:** `normalrange.pregsmok` is `Single` and participates in the V2 range lookup as a **discriminating key** (BR-RANGE-002): the 1.605 binary selects the applicable range with `REFRANGE='1' and pregsmok = <value>`, so the column carries a *variant selector*, not a passive attribute.
* **Expected behaviour:** a test may carry more than one range row for the same (sex, age) band, distinguished by the pregnancy/smoking variant; the patient's context selects which row applies.
* **Affected entities:** `normalrange.pregsmok`, `patientinfo.patientsex`, `patientinfo.patientage`, `patientinfo.patientageunit`.
* **Evidence:** **VERIFIED** for the column, its type and its use as a lookup predicate; the **value distribution** the live V2 `normalrange` holds — how many rows carry which variant, and which tests carry a pregnancy-specific range — is **NOT RECOVERABLE** (no row-level export of the live V2 store exists in the archive).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6E94EC …]`
* **Outstanding:** ISS-26 ("`normalrange.pregsmok` is unexplained — a `Single` value in every row; the range may vary for pregnancy/smoking — a clinically significant rule") remains **OPEN**; the proposed resolution (compare `patienttest` against `normalrange`) cannot be performed because the live V2 rows were never exported. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-26]`

#### BR-RANGE-012 — The `REFRANGE` one-character flag marks the "active" range of a test
* **Description:** `REFRANGE Text(1)` is present on `normalrange` **and** on `testtable` in V2 (added by the embedded schema-update DDL). It is a one-character flag whose value `'1'` marks the range row that the simple lookup path uses; the sex/age-specific rows carry the empty value.
* **Expected behaviour:** a test may have one designated *primary* range (`REFRANGE='1'`) which is the one used for the simple lookup path (BR-RANGE-002); the sex/age-specific rows carry `REFRANGE=''` and are selected by the sex/age path.
* **Affected entities:** `normalrange.REFRANGE`, `testtable.REFRANGE`.
* **Evidence:** **VERIFIED** for the flag's existence on both tables; the dual-path behaviour is **INFERRED** from the two co-existing lookup predicates. **How many range rows the live V2 store marks with `REFRANGE='1'`, and which tests those rows belong to, is NOT RECOVERABLE** (no row-level export of the live V2 store exists in the archive).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange / testtable]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 672E3E, 673172, 6E94EC …]`
* **Outstanding:** the set of `REFRANGE='1'` rows in the live V2 store is **NOT RECOVERABLE** (row data never exported).

#### BR-RANGE-013 — Reference-range maintenance is a joined (SHAPE) view of test + range
* **Description:** The reference-range screen is built with a Jet/SQL-Server *shape* (union) query that appends the range rows onto the test rows, relating on `testcode`:
  `SHAPE {SELECT testcode,testsimp,patientprice,testtime,typeofsample FROM testtable where testorno='True' and testsimp <> '' GROUP BY … order by testsimp} AS cmdbill APPEND ({SELECT testcode,sex,firstold,secondold,ageunit,normalrang FROM normalrange where normalrang <> '' order by sex,ageunit,firstold} AS cmdbill_d RELATE testcode TO testcode) …`
* **Expected behaviour:** only tests flagged `testorno = True` participate; only rows with a non-empty `normalrang` are joined.
* **Affected entities:** `testtable.testorno`, `normalrange.normalrang`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 672E3E, 673172]`
* **Outstanding:** the join is a read-time shape; whether the reference-range screen writes back through it is **NOT RECOVERABLE**.
#### BR-RANGE-014 — 🔒 Test number 4 (Urine) may not be renumbered or renamed
* **Description:** "Do not change the numbers of the tests nor the identity of the number specified for each test: **Urine test number 4** in the system must not be changed to any number, and even if this slot is empty you cannot modify its data and its names, such as: Urine or Urine Examination or Urineanalysis."
* **Condition:** always.
* **Expected behaviour:** `testcode = 4` is a reserved, immutable slot; its name fields are frozen.
* **Exceptions:** none stated.
* **Affected entities:** `testtable.testcode = 4`, `testtable.testsimp|testname|testabbrev|historyname|waslname`.
* **Evidence:** **VERIFIED** (manual, shipped in the 2019 CD).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm, item 2]`
* **Outstanding:** the technical reason (hard-coded references to testcode 4 in the code) is **INFERRED**; the rule itself is documented.

#### BR-RANGE-015 — Range administration is a System-data operation with Add / Edit / Save / Undo / Delete
* **Description:** Navigation is *System data → Test data → [test] → "Normal rate"*; the window supports **Add range**, **Edit**, **Save**, **Undo** (revert the in-progress add/edit), **Delete** (delete the selected range), and **Test list** (return to the test list).
* **Affected entities:** `normalrange`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm) parts 1-2]`
* **Outstanding:** whether the Save / Undo / Delete actions are audited is **NOT DOCUMENTED** in the evidence.
#### BR-RANGE-016 — Reference ranges are edited per analyte element, not only per test
* **Description:** "To modify the data or the normal rates of a sub-profile of tests — for example the elements of the blood-picture test or VD — enter letters of the test name in the third search box (search by test name) so that the system displays all its elements, then select the element with the mouse."
* **Affected entities:** `normalrange.testsimp`, `testtable.testsimp`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) closing note]`
* **Outstanding:** the search-by-name behaviour is documented for the test-data window only; the equivalent behaviour in the other windows is **NOT DOCUMENTED**.
#### BR-RANGE-017 — Units dictionary and unit echo on the report
* **Description:** `testunits(unitsid, unitsname)` is the measurement-unit dictionary; the range's `testunit` is the unit "which will appear next to the result in the report", and it is snapshotted onto the result row (BR-RANGE-010).
* **Affected entities:** `testunits`, `normalrange.testunit`, `patienttest.testunit`.
* **Evidence:** **VERIFIED** for the schema and the manual statement; the **content** of the live V2 unit dictionary — how many units it holds and how many of them the range catalogue uses — is **NOT RECOVERABLE** (see §4.3).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE testunits, normalrange, patienttest]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm)]`

---
* **Outstanding:** the live V2 content of the unit dictionary is **NOT RECOVERABLE** (§4.3).
### 1.3 Domain C — Result lifecycle & state machine

#### BR-LIFE-001 — `resultfinsh` — result entry completed
* **Boolean NOT NULL.** Set when the result is entered and saved (Save button / **F9**).
* **Affected entities:** `patienttest.resultfinsh`; mirrored in `patienttestgroup.resultfinsh` and `testtemp.resultfinsh` (V2).
* **Related functions:** `SELECT patientid,printwith,resultfinsh,resultreview,resultprint from patienttest where patientid='…'`; worklist query `Where patienttest.resultfinsh = 'False' and (patienttest.requestdate = …)`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 681ED2, 6843F2]`
* **Outstanding:** note the **spelling** `resultfinsh` (missing `i`) is a permanent schema name.

#### BR-LIFE-002 — `resultreview` — result reviewed and authorised (**F8**)
* **Boolean NOT NULL.** The manual: "F8 — consider the patient's selected tests as reviewed". The delivery window also exposes F8 as "consider the result reviewed / not reviewed".
* **Affected entities:** `patienttest.resultreview`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 (004A.htm) keyboard shortcuts]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) keyboard shortcuts]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** whether `resultreview` can be cleared again after the fact is **NOT DOCUMENTED**; only the F8 toggle is attested.
#### BR-LIFE-003 — `resultprint` — result printed (**F12**)
* **Boolean NOT NULL.** "F12 — print the result report (the results to be printed, entered and reviewed)".
* **Affected entities:** `patienttest.resultprint`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 (004A.htm)]`
* **Outstanding:** the relation between `resultprint` and `printnum` (whether the counter increments on every print) is **NOT DOCUMENTED**.
#### BR-LIFE-004 — `give` — results handed over to the patient
* **Boolean NOT NULL.** Set from the *Deliver results* window (reached via the Patients menu button, or **F6** from any main window).
* **Conditions:** "the results must be reviewed so the user can print them, and they must be printed so the user can deliver them to the patient".
* **Affected entities:** `patienttest.give`, `patienttest.taslimuser` (delivery user), `patienttest.taslimdate` (delivery date).
* **Related functions:** `Select testcode,patientid,give,taslimuser,taslimdate from patienttest where patientid='…'`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) closing note and keyboard shortcuts]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6867AA, 686862]`
* **Outstanding:** the relation between `give` and `taslimuser`/`taslimdate` (whether the pair is written by the F6 window or by the override button) is **NOT RECOVERABLE**.
#### BR-LIFE-005 — `sentout` — the sample is a sent-out sample
* **Boolean NOT NULL.** Combined with `otherlabname` (recipient lab) and the two money columns (BR-BILL-006).
* **Affected entities:** `patienttest.sentout`, `patienttest.otherlabname`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 693732, 693E2E, 695BE2, 696346]`
* **Outstanding:** the conditions under which `sentout` is set (Test-data flag versus sent-out window) are **NOT DOCUMENTED**; both paths appear in the evidence.
#### BR-LIFE-006 — `send` — the sent-out sample has been dispatched
* **Boolean NOT NULL.** Appears alongside `sentout` in every sent-out accounting query.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 693732 etc.]`
* **Outstanding:** the point at which `send` is set relative to the settlement action is **NOT DOCUMENTED**.
#### BR-LIFE-007 — `printwith` — the test is eligible for a combined report
* **Boolean NOT NULL.** Catalogue field "Print with other — in the case of large tests such as urine and stool they cannot be printed in a combined report".
* **Affected entities:** `patienttest.printwith`, `testtable.printwith`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Print with other"]`
* **Outstanding:** the exact print-set selection is screen-specific and hard-coded (BR-LIFE-013); the per-test flag alone does not determine it.
#### BR-LIFE-008 — Four-key audit trail per result
* **Description:** Every result row carries, in addition to the state flags: `edituser`/`editdate` (last editor), `prevuser`/`prevdate` (previous editor), `printuser`/`printdate` (printer), `taslimuser`/`taslimdate` (deliverer). All are `Text(40)` (dates are stored as **text**, not as DateTime — a schema-level fact).
* **Affected entities:** `patienttest.edituser|editdate|prevuser|prevdate|printuser|printdate|taslimuser|taslimdate`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** the retention rule for the four audit keys (whether earlier edits are overwritten) is **NOT DOCUMENTED**.
#### BR-LIFE-009 — `printnum` — a numbered print counter (anti-copy audit)
* **Description:** `printnum Double` accompanies `resultprint`, `printuser`, `printdate`; the printing audit trail is explicitly described as "individual responsibility and digitisation" and "numbered printing — detection of unauthorised copies".
* **Affected entities:** `patienttest.printnum`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6A273A, 6B037C, 6B2D70, 6BA22C, 6BE5E0, 6C2244]` · `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §4 print-audit row]`
* **Outstanding:** the increment rule and the starting value of `printnum` are **NOT RECOVERABLE**; only the column's presence is attested.
#### BR-LIFE-010 — Result payload columns
* **RESULTT Text(50)**, **resultt1..resultt4 Text(50)** carry the primary result text and up to four sub-result texts (used by semi-quantitative profiles); **RESULTCASEPRINT Text(15)** carries the case-print caption; **commentx Memo** carries the free comment.
* **Affected entities:** `patienttest.RESULTT|resultt1|resultt2|resultt3|resultt4|RESULTCASEPRINT|commentx`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** the rule that populates `resultt1..resultt4` per profile is **NOT DOCUMENTED**.
#### BR-LIFE-011 — Result ordering within a patient = `arrangnum`, ties broken by test name
* **Description:** "Arrange number — the order of the test in the test lists; in case more than one test is entered with the same number the ordering is by name."
* **Affected entities:** `patienttest.arrangnum`, `testtable.arrangnum`.
* **Evidence:** **VERIFIED** (manual) + schema (`arrangnum Integer`). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Arrange number"]`
* **Outstanding:** the default `arrangnum` values shipped per test are **NOT RECOVERABLE** (the live V2 rows were never exported).
#### BR-LIFE-012 — 🔒 Print gate: only *reviewed* results may be printed
* **Description:** The V2 binary raises `Not found any Verified selected tests or result to print it` — a hard gate: if no selected test is in the "verified" state, printing is refused.
* **Conditions:** any print action on a selected test set.
* **Expected behaviour:** printing is refused rather than silently producing an unverified report.
* **Affected entities:** `patienttest.resultreview`, `patienttest.resultprint`.
* **Evidence:** **VERIFIED** (1.605 literal). `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §4 quality-control table]`
* **Outstanding:** the exact state the literal calls "Verified" (`resultreview` vs. `resultfinsh`) is **INFERRED**; the literal's wording ("Verified … or result") is ambiguous.

#### BR-LIFE-013 — Printable test-code sets are hard-coded per screen
* **Description:** The 1.605 SQL contains per-profile print queries restricted to explicit testcode lists, e.g.
  * `where testcode in (6,7,8,9,14,15,16,17,18,19,20,21)`
  * `where testcode in (1,2,3)`
  * `where testcode in (10,11,12,594,24,25,26,27,28,29,197)`
  * `where testcode in (30,31,32,33,36,37)`
  * `where testcode in (38,39,40,41,59)`
* **Expected behaviour:** each profile's print screen only addresses its own tests.
* **Affected entities:** `patienttest.testcode`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6A273A, 6B2D70, 6BA22C, 6BE5E0, 6C2244]`
* **Outstanding:** the *mapping* from these numeric sets to named profiles is **INFERRED**; **NOT RECOVERABLE** from SQL alone.

#### BR-LIFE-014 — Manual override of the "delivered" state
* **Description:** "If delivery happens by mistake, or you want to consider this result as already delivered, you can do that by pressing the 'مستلمة' (received) button."
* **Affected entities:** `patienttest.give`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) part 4]`
* **Outstanding:** the authorisation required to use the override is **NOT DOCUMENTED**.
#### BR-LIFE-015 — Patient-status icons are derived from the lifecycle flags
* **Description (manual, delivery window):**
  * **New** (red circle) — patient registered, no results entered yet;
  * **Paper/notes** — patient has results but they have not been written/entered yet;
  * **Green & blue arrows** — patient has results that have not been reviewed;
  * **Printer** — patient has results not yet printed;
  * **Shopping cart** — patient has not collected the results, or has results not yet handed over;
  * **Genie** — patient has collected all results **and** there is a problem in the account (balance owed to the lab or to the patient);
  * **Medal** — results entered and printed, account settled, results delivered.
* **Affected entities:** `patienttest.resultfinsh|resultreview|resultprint|give`, `patientinfo.completes`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) part 1]`
* **Outstanding:** the icon set's precedence when several states apply at once is **NOT DOCUMENTED**.
#### BR-LIFE-016 — Barcode-based delivery performs a two-step patient match
* **Description:** At delivery, the code printed on the receipt is read, then the code on the patient's result file is read; the system compares the patient data shown in the window with the data of the file to be delivered. On a match it asks "do you want to deliver the results?" and, if a balance remains, warns about it. If the receipt is lost, delivery can be made from the file automatically. If the file code is not printed, delivery can be done by selecting the patient from the list.
* **Affected entities:** `patientinfo.barcode`, `patientinfo.patientid`, `patientinfo.kawmy` (the file/work code).
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm)]`
* **Outstanding:** the barcode symbology and the encoding of `kawmy` are **NOT RECOVERABLE**; `testtable.barcodesymb`, `barcode1..3` and `barcodes(barcode, barcodeid)` exist but their encoding is not attested.

#### BR-LIFE-017 — V2 captures turnaround time on the result row
* **Description:** V2 adds `Timeout Text(10)` and `Taketime Integer` to `patienttest` (and to `patienttestgroup`). `Timeout` is the configured due time; `Taketime` is the elapsed time.
* **Affected entities:** `patienttest.Timeout|Taketime`, `patienttestgroup.Timeout|Taketime`.
* **Evidence:** **VERIFIED** (2019 DDL — the 46-column V2 `patienttest` carries `Timeout Text(10)` and `Taketime Integer`). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** the semantics/units of `Taketime` are **NOT RECOVERABLE**.

#### BR-LIFE-018 — V2 splits group requests into `patienttestgroup` and scratch work into `testtemp`
* **Description:** V2 adds `patienttestgroup` (46 columns, a structural clone of `patienttest` including the full flag set and the frozen range snapshot) and `testtemp` (28 columns — a scratch table for results in progress, with `detelethis Long Integer` and `normalrang Memo`).
* **Affected entities:** `patienttestgroup`, `testtemp`.
* **Evidence:** **VERIFIED** (2019 DDL; both created by the embedded schema-update DDL, §8). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttestgroup / testtemp]`
* **Outstanding:** the exact promotion path `testtemp → patienttestgroup → patienttest` is **INFERRED** from the column sets; no V2 SQL in the pool performs it. **NOT RECOVERABLE.**

#### BR-LIFE-019 — Worklist rule: a request is "outstanding" while `resultfinsh = False`
* **Description:** The outstanding-work query joins `patientinfo` to `patienttest` on `patientid` and filters `patienttest.resultfinsh = 'False'` for a given `requestdate`, exposing the short display id `SUBSTRING(patientinfo.patientid,10,3)`.
* **Affected entities:** `patienttest.resultfinsh`, `patienttest.requestdate`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6843F2 (SQL Server) / 68463A (Jet)]`

---
* **Outstanding:** the worklist's inclusion rules beyond `resultfinsh = False` and `requestdate` are **NOT RECOVERABLE**.
### 1.4 Domain D — Profile / catalogue management

#### BR-CAT-001 — `testtable` is the test catalogue *and* the price list
* **Description:** One row per test, carrying identity, naming (6 name variants), grouping, routing, three prices, sample type, and lifecycle flags. V2's `testtable` has **38 columns**, including `testcodebill nvarchar(13)` — the **bill-line code**, joined into the receipt query alongside `waslname`/`waslname2`.
* **Affected entities:** `testtable` (all 38 V2 columns listed in §1.4 appendix), `customtesttable`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE testtable]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6ABAD6 — SELECT … testtable.testcodebill …]`
* **Outstanding:** the semantics of `testcodebill` (bill item code vs. re-coded test number) are **INFERRED** from the receipt query.

#### BR-CAT-002 — Groups (profiles) are first-class entities
* **Description:** `subgrouptable(subgroupcode, subgroupname, arname, deleteprotect)` — the report-profile master; **46** profiles are published for V2.
* **Expected behaviour:** the group's Arabic name (`arname`) is displayed; a protected group (`deleteprotect`) cannot be deleted.
* **Affected entities:** `subgrouptable`, `testtable.subgroupcode`, `patienttest.subgroupcode`.
* **Evidence:** **VERIFIED** for the schema and for the published V2 profile count (46); the **per-group `deleteprotect` flags** held by the live V2 store are **NOT RECOVERABLE** (no row-level export of the live V2 store exists in the archive).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE subgrouptable]` · `[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.7 row "إضافة مجموعة تحاليل" — "subgrouptable (46)"]`
* **Outstanding:** which profiles the live V2 store marks as protected is **NOT RECOVERABLE**.

#### BR-CAT-003 — The catalogue field dictionary (official, manual topic 007)
* **Description (verbatim field semantics):** `Test name` (name in the program's test lists) · `Report name` (name on the report, in two parts — one large, one small — one part may be used alone, e.g. `SGPT/ALT (Alanine Aminotransferase)`) · `Bill name` (name on the receipt; in two parts, **and when the first part is identical the system groups the tests into one receipt item**, e.g. liver and kidney tests) · `History name` (name in the medical history; preferably abbreviated) · `Arabic name` · `Group name` (the group the test belongs to — used for statistics and for adding a whole group of tests to a patient) · `Branch` (the lab branch responsible for this test) · `Log group` (the work-group the test belongs to — e.g. with two chemistry analysers, a large and a small one, sugar is run on the first; when a work order (worksheet) is requested for the day's samples, the system prints each analyser's tests separately) · `Collection` (notes on sample-draw conditions) · `Test time` (time to complete the test; **enter 0 if the result is same-day** — the receipt's result-receipt date is computed from this number, in days) · `Arrange number` · `Patient price` · `Lab to Lab price` (price for labs and other parties when no dedicated price list exists) · `Routine test` (makes the test appear in the routine [most-requested] list in the patient window) · `See report` (for a test with more than one result — urine, stool, blood picture — a result cannot be shown when viewing patient data) · `Print with other` · `Add with group` (e.g. GGT is rarely requested together with liver enzymes, so when adding the group it is not added) · `Main test` (a main test — blood gases, haemoglobin electrophoresis, VD — that has more than one element; on the other elements this flag is cleared).
* **Affected entities:** `testtable` — the manual's field list maps 1:1 onto the shipped columns `testname, waslname, waslname2, testabrev, testnamear, subgroupname, branch, loggroup, typeofsample, testtime, arrangnum, patientprice, labprice, otherlabprice, seereport, printwith, addorno, testorno, normaltype, deleteprotect, active`.
* **Evidence:** **VERIFIED** (manual, shipped in the 2019 CD).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) part 3 field list]`
* **Outstanding:** the manual's mapping of `Bill name` ↔ `waslname`/`waslname2`, `History name` ↔ `historyname`, `Arabic name` ↔ `testnamear`, `Routine test` ↔ `active`, `Main test` ↔ `testorno`, `Add with group` ↔ `addorno` is **INFERRED** from the column names; it is not stated in the manual.

#### BR-CAT-004 — Receipt (bill) grouping rule
* **Description:** The `Bill name` is in two parts; **when the first part is identical, the system groups the tests into one receipt item** (liver enzymes and kidney tests being the worked example).
* **Affected entities:** `testtable.waslname` (part 1) and `testtable.waslname2` (part 2); the receipt query concatenates them with two spaces: `(COALESCE(testtable.waslname,' ') + '  ' + COALESCE(testtable.waslname2,' ')) as waslname`.
* **Evidence:** **VERIFIED** (manual for the rule; 1.605 SQL for the concatenation).
* **Provenance:** `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Bill name"]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6ABAD6, 6ABF66]`
* **Outstanding:** the grouping is applied at receipt-print time; the resulting receipt item grouping is **NOT RECOVERABLE** without the live data.
#### BR-CAT-005 — `testtime` drives the promised-result date on the receipt
* **Description:** `testtime` is the number of days to complete the test; `0` means same-day. The receipt's "result received" date is computed from it.
* **Affected entities:** `testtable.testtime`, `patienttest.testtime`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Test time"]`
* **Outstanding:** the receipt's result-receipt date formula is **NOT DOCUMENTED** beyond "computed from this number, in days".
#### BR-CAT-006 — Three price axes on the test
* `patientprice` (price for an ordinary independent patient) · `labprice` (price for labs and other parties) · `otherlabprice` (the cost of the test when it is sent out to a specific external lab).
* **Affected entities:** `testtable.patientprice|labprice|otherlabprice`; `customtesttable.patientprice` (override for a custom group).
* **Evidence:** **VERIFIED** (manual + schema + the custom-price SELECT which aliases `testtable.patientprice as patpricindved` next to `customtesttable.patientprice`). `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6A9BC2]`
* **Outstanding:** the precedence between `patientprice`, `labprice`, `otherlabprice` and a dedicated price list is only partly documented (BR-BILL-010, BR-CAT-016).
#### BR-CAT-007 — `loggroup` is the work-group routing key
* **Description:** `loggroup` names the work group (i.e. the analyser) that runs the test; a worksheet (work order) for a period prints each work group's tests separately. `labbranch` (`branchid, branchname`) and `loggroup` (`logid, logname`) are the two routing master tables.
* **Affected entities:** `testtable.loggroup`, `loggroup`, `Labbranch`, `patienttest.loggroup`.
* **Evidence:** **VERIFIED** (manual + `SELECT * FROM loggroup` in the SQL pool). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Log group"]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6B28D8]`
* **Outstanding:** the worksheet's grouping output is **NOT RECOVERABLE**; only the `loggroup` key and the per-group print rule are attested.
#### BR-CAT-008 — `Branch_Data.mdb` is a schema-only template for seeding a branch
* **Description:** `Branch_Data.mdb` holds **49 tables** with **0 rows in every table** — it is a *schema template*, not data. Its role: "holds the column definition of every per-test result table (e.g. `cbc` → patientid, requestdate, hgb, rbc, hct, plt, hgbper, mcv, mch, mchc, pct, mpv, wbc, neut, lymph, mono, eosino, baso, othercell, comment) so that a newly created branch can be seeded with the same table structure". The installer copies it per branch.
* **Affected entities:** all 49 branch tables.
* **Evidence:** **VERIFIED** — the 2019 CD ships this exact template file, so the rule is V2-valid. `[P11 | real lab system\RL_CD2019Access\bin\Branch_Data.mdb | schema template — 49 tables, 969 columns, 0 rows]` · `[P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §1 summary row "Branch_Data.mdb"]` · `[P11 | inventory/ledger.csv | Branch_Data.mdb sha256 entries]`
* **Outstanding:** the 2019 CD carries a **second** `Branch_Data.mdb` (966,656 B) in `RL_CD2019Access\System\`, while `bin\Branch_Data.mdb` (970,752 B) is the first one; the installer overwrites the install root with `System\`. Which template a deployed V2 lab actually ends up with is **deployment-order dependent — NOT RECOVERABLE**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6.1 note 1]`

#### BR-CAT-009 — Every branch profile table has a fixed shape
* **Description:** Each per-profile result table is `patientid | requestdate | <analytes…> | comment`. Examples (column counts from the shipped template): `crossmat` 84 · `semen` 59 · `urine`/`stool` 58 (semi-structured `t01..t55`) · `prostaticx` 45 · `GLUCOSETOLERANCE` 25 (`FBG`, `FBGG`, `FBGA`, `bg30`, `bg30g`, `bg30a`, `bg1..bg15`) · `cultures` 25 (`cultid`, `organism`, `organism2`, `condition`, `colony`, `reactions`) · `trace` 25 (serum/urine pairs `sAluminium`/`uAluminium`…) · `BONEMAR` 23 (`T01..T20`) · `CSFT` 22 (`materi`, `color`, `aspect`, `deposit`, `Viscos`, `PH`, `SG`, `gluc`, `prot`) · `Electrolytes` 20 · `cbc` 20 · `hepatitis` 20 · `IMMUNOLOGY` 19.
* **Evidence:** **VERIFIED** (the template shipped in the 2019 CD). `[P11 | real lab system\RL_CD2019Access\bin\Branch_Data.mdb | per-profile table shapes]` · `[P11 | analysis/CUMULATIVE/02-data-model.md | §2 profile table matrix]` · `[P11 | reports/Stage-2b-Cumulative-Analysis-Report.md | §1 summary row "Branch_Data.mdb"]`
* **Outstanding:** the per-branch profile tables actually deployed are **deployment-order dependent — NOT RECOVERABLE** (BR-CAT-008).
#### BR-CAT-010 — Every V2 culture row carries a third organism
* **Description:** the V2 `cultures` table has **35** columns, including **`organism3 Text(80)`**, **`organism`** and **`organism2`** widened to **`Text(80)`**, and **`condition2`**. Simultaneously **32** report `.ini` files gain the third organism slot: `LabelX002=Organism C`, `ITEMXV002`, `ITEMXD2='Gram Positive Cocci##Gram Negative bacilli##Gram Negative Dilococci##No Organism##'`, and `Check6f=1`.
* **Evidence:** **VERIFIED**, and cross-confirmed across three independent layers (DDL, schema, report template) — the strongest multi-layer rule evidence in the archive.
* **Provenance:** `[P11 | analysis/BATCH-04/schema/ddl-all.txt | ALTER Table cultures ALTER COLUMN organism/organism2/organism3 → varchar(80)]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE cultures — 35 cols]` · `[P11 | analysis/BATCH-07/ini-diff-summary.md | §2 keys form.LabelX002 / form.ITEMXD2 / form.Check6f, 32 files]`
* **Outstanding:** the report-template side of the third organism is attested for 32 `.ini` files; the remaining layout files are **NOT DOCUMENTED**.
#### BR-CAT-011 — Antimicrobial sensitivity is a text field in V2
* **Description:** `cultureanti.Sensitivityvalue` is widened `Double → Text(10)`.
* **Affected entities:** `cultureanti.Sensitivityvalue`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/schema/ddl-all.txt | ALTER Table cultureanti ALTER COLUMN Sensitivityvalue varchar(10)]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.2]`
* **Outstanding:** the accepted sensitivity vocabulary is **NOT RECOVERABLE**; the antibiotic master (`antibiotic`, 25 columns with `antisymbol`, `anticomname1..8`, `Sensitivity`, `Sensitiveunit`, `prgnancy`, `child`) is published for V2 with **38 rows**, but its row content is **NOT RECOVERABLE**. `[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.7 row "إضافة مضاد حي للمزرعة" — "antibiotic (38 صفًا · 25 عمودًا)"]`

#### BR-CAT-012 — V2 catalogue entities introduced by the embedded schema update
* `Helicobacter` (`patientid`, `requestdate`, `hpigi`, `hpigm`, `hpag`, `comment`) — H. pylori · `insulin` (`id` Integer NOT NULL, `insulin` Text NOT NULL) · `ratios` (12 columns, + `albu`, `albcreat`) · `patienttestgroup` · `testtemp` · `MyLabSetting` · `Paste Errors` (6 Memo columns) · `smslist` / `smsgroups` / `SMStemplate` / `SMSSender`.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE helicobacter / insulin / ratios / Paste Errors]`
* **Outstanding:** `Paste Errors` — a table that stores paste failures — has **no documented business meaning**; it is **NOT RECOVERABLE**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.1]`

#### BR-CAT-013 — The abbreviation dictionary
* **Description:** `abbreviations(abbid, abbre, mean)` is the abbreviation dictionary — the table that expands the Latin abbreviations that appear in some test names.
* **Affected entities:** `abbreviations`, `testtable.testabrev`.
* **Evidence:** **VERIFIED** for the schema; the **row count and the row content** of the live V2 dictionary are **NOT RECOVERABLE** (no row-level export of the live V2 store exists in the archive).
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE abbreviations]`
* **Outstanding:** how many abbreviations the live V2 dictionary holds and what each of them expands to are **NOT RECOVERABLE**.
#### BR-CAT-014 — Method text is carried in three separate layers
* **Description:** (1) **test definition** — `testtable` (what the test is, its price, whether it is sent out); (2) **reference values** — `normalrange`; (3) **method description** — the `Cache\*.rtf` sheets (sample type, measurement principle, reference interval, clinical significance). `testlearn` links `testcode` ↔ `testlearnid`; the VT form `learntest` is the learning-topic screen; `testtable.testusage|testdiscr|testeffect` hold the method text.
* **Expected behaviour (design consequence):** adding a new test does not require touching code.
* **Evidence:** **VERIFIED** (analysis, RTF metadata, schema).
* **Provenance:** `[P11 | analysis/BATCH-02/rtf/test-library.md | §4 three-layer summary]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE testlearn, testtable]`
* **Outstanding:** ⚠ the row count and the row content of `testlearn` in the live V2 store are **NOT RECOVERABLE**.

#### BR-CAT-015 — Work-sheet (WASL) list
* **Description:** `wasl(subgroupcode, testcode, waslname, waslname2, testprice, testno, resultt, testunit, RESULTCASEPRINT, normalrang, testcodex, subgroupname)` — the work-sheet definition, carrying its own copy of the range text (`normalrang Memo`) and the case-print caption. V2 keeps all 12 columns; a narrower 6-column shape is **not attested for V2**.
* **Affected entities:** `wasl`, `testtemp`, `waslprinter`.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE wasl]`
* **Outstanding:** the row count and the row content of `wasl` in the live V2 store are **NOT RECOVERABLE**.

#### BR-CAT-016 — Price lists per referring party
* **Description:** `pricelist(pricenum, testsimp, pricelistname|gehahname, testprice)` — a dedicated price list per party, referenced by `patientinfo.pricemethod` / `Gehats.pricemethod`. The catalogue field "Lab to Lab price" is explicitly the fallback "in the case of there being no dedicated price list for the party".
* **Affected entities:** `pricelist`, `patientinfo.pricemethod`, `Gehats.pricemethod`.
* **Evidence:** **VERIFIED** (manual + schema). V2 names the column `gehahname`; the alternative column name `pricelistname` is **not attested for V2**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE pricelist — pricenum, testsimp, gehahname, testprice]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) "Lab to Lab price"]`
* **Outstanding:** the set of legal `pricemethod` values is **NOT RECOVERABLE** (BR-BILL-010).
#### BR-CAT-017 — Custom (ad-hoc) profiles and their own prices
* `customgrouptable(customgroupcode, customgroupname)` · `customtesttable(testnum, customgroupcode, testcode, testsimp, patientprice)` — the per-group `patientprice` overrides `testtable.patientprice` for members of a custom group.
* **Evidence:** **VERIFIED** (schema; the override is visible in the SELECT that aliases `testtable.patientprice as patpricindved` beside `customtesttable.patientprice`). `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6A9BC2]`

---
* **Outstanding:** how a custom group is created and priced at run time is **NOT DOCUMENTED**.
### 1.5 Domain E — Branch & identifier rules

#### BR-ID-001 — `patientid` is a fixed-length composite key of 13 characters
* `patientid Text(13)` in `patientinfo`, `patienttest`, `patienttestgroup`, `testtemp`, every branch profile table, `payment`, `SMSSender`.
* **Expected behaviour:** the key is opaque to the user; the system derives sub-identifiers from it.
* **Affected entities:** all result and header tables.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patientinfo / patienttest]`
* **Outstanding:** the composition of all 13 characters is **NOT RECOVERABLE** (BR-ID-003).
#### BR-ID-002 — The short display identifier is characters 10–12 of `patientid`
* **Description:** `SELECT SUBSTRING(patientinfo.patientid,10,3) as patid …` (SQL Server) and `SELECT mid(patientinfo.patientid,10,3) as patid …` (Jet). Both dialects are present in the V2 SQL pool — the classic dual-engine artefact.
* **Affected entities:** `patientinfo.patientid`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6843F2 / 68463A / 682F56 / 68313E]`
* **Outstanding:** the rule that keeps the short display id unique is **NOT DOCUMENTED**.
#### BR-ID-003 — The branch indicator is character 9 of `patientid`
* **Description:** `SUBSTRING(patientid,9,1)` is the branch discriminator inside the composite patient key.
* **Evidence:** **VERIFIED** (installer-documentary). `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §5 branch architecture table, row "SUBSTRING(patientid,9,1)"]`
* **Outstanding:** the full layout of the 13 characters (date? counter? branch? sequence?) is **NOT RECOVERABLE** — no V2 SQL exposes the generator.

#### BR-ID-004 — `labid` is the laboratory/workstation code, distinct from the patient work code
* **Description:** `patientinfo.labid Text(13)`; `Select labid from patientinfo where labid='…'`; `Select requestdate, patientid, patientnamear, completes from patientinfo where labid='…'`. The manual states that for restoring one patient from the backup DB you need "the code of the **work** (not the lab code)".
* **Affected entities:** `patientinfo.labid`, `patientinfo.kawmy`.
* **Evidence:** **VERIFIED** (schema + SQL + manual). `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 687106, 687472]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §14 backup.htm, part 3]`
* **Outstanding:** the generator of `labid` is **NOT RECOVERABLE**; only the `Select ... where labid=` queries are attested.
#### BR-ID-005 — Barcodes are per-sample, per-test
* **Description:** `patientinfo.barcode Text(25)` is the patient/visit barcode; `testtable.barcodesymb` is the symbol set, and `barcode1`, `barcode2`, `barcode3` allow **up to three distinct specimen labels per test** (the manual's example: urine needs one label for "urine" and creatinine clearance needs a "serum" label and a "24-hour urine" label). `barcodes(barcode, barcodeid)` is the barcode master; its row count and its content in the live V2 store are **NOT RECOVERABLE**.
* **Evidence:** **VERIFIED** (manual + schema + SQL). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm) part 4]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6B18C8]`
* **Outstanding:** the symbology is **NOT RECOVERABLE**.

#### BR-ID-006 — The patient ID card / invoice layout is externalised to `IDCARD.INI`
* **Description:** `[IDdata]` holds the position (`L`/`T`), font (`F`), bold (`B`) and size (`S`) of **three** fields — the name, the barcode, and the password; `[Billdata]` holds the invoice texts ("Welcome To RealLab", "Thank you for visiting RealLab!", working hours, address, telephone, web site, e-mail, Facebook page).
* **Evidence:** **VERIFIED**, and the file ships inside the 2019 CD — so the rule is V2-valid. `[P11 | analysis/CUMULATIVE/06-configuration.md | §5 IDCARD.INI]` · `[P11 | inventory/ledger.csv | IDCARD.INI sha256 entry]`
* **Outstanding:** the default field positions of the 2019 `IDCARD.INI` are **NOT RECOVERABLE** beyond the documented key structure.
#### BR-ID-007 — The blank-patient sentinel
* `'<<< Blank >>>'` is the sentinel value used for a patient with no name.
* **Evidence:** **INFERRED** from the cumulative data-model note. No V2 SQL in the pool contains the literal. `[P11 | analysis/CUMULATIVE/02-data-model.md | §4 Jet-specific mechanisms]`
* **Outstanding:** V2 status **UNVERIFIED**.

#### BR-ID-008 — The multi-branch operating model
* **Description:** One **master** computer runs most of the day (a **reception** computer exists); SQL Server is installed **once** in the laboratory; **the SQL database is saved on the master computer only**; branches connect to the lab branches **through the internet**; `D:\real lab system\Branch_Data.mdb` is the branch template; `Patient.branche` (DDL 1.605) is the branch column.
* **Evidence:** **VERIFIED** (installer analysis). `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §5 branch architecture table]`
* **Outstanding:** the number of branches a laboratory may run, and the failover behaviour of the master database, are **NOT DOCUMENTED**.
#### BR-ID-009 — `testtable.branch` = the branch responsible for the test; `loggroup` = the analyser/work group
* **Description:** Manual field "Branch — the lab branch responsible for this test"; "Log group — the name of the work group the test belongs to … when a work order is requested for the day's samples, the system prints each analyser's tests separately".
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §9 (007.htm)]`

---
* **Outstanding:** the routing rule that assigns a test to a branch is **NOT DOCUMENTED**; only the two key semantics are attested.
### 1.6 Domain F — Billing & receivables

#### BR-BILL-001 — The five patient-level money fields
* `totalprice` (gross) · `totalpricedisc` (net after discount) · `elmadfoo3` (a second money amount) · `elbakyma3mal` (a third amount) · `discount100` / `discount` (percentage / absolute discount).
* **Affected entities:** `patientinfo.totalprice|totalpricedisc|elmadfoo3|elbakyma3mal|discount100|discount`.
* **Evidence:** **VERIFIED** (schema + SQL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patientinfo]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6A5796, 732054, 732238]`
* **Outstanding:** the exact Arabic semantics of `elmadfoo3` / `elbakyma3mal` (both are "collected from the patient" money buckets per the accounting formulas) are **INFERRED**; the manual does not define them.

#### BR-BILL-002 — Referral commission = `Gehats.omola` % of the patient net price
* **Description:** `SELECT ROUND(SUM(Gehats.omola * patientinfo.totalpricedisc / 100),2) AS Expr1 FROM patientinfo INNER JOIN Gehats ON patientinfo.referredbyname = Gehats.gehahname Where requestdate >= …` — and an alternative basis on `patientinfo.elmadfoo3`.
* **Conditions:** the join is by **referring-party name** (`patientinfo.referredbyname` = `Gehats.gehahname`), over a request-date window.
* **Expected behaviour:** commission accrues per patient visit, rounded to 2 decimals; the report also emits `ROUND(SUM(patientinfo.totalpricedisc),2)` (the referral's total volume) and `Gehats.omola & ' %'` (the commission percentage as a label).
* **Affected entities:** `Gehats.omola`, `patientinfo.referredbyname`, `patientinfo.totalpricedisc`, `patientinfo.elmadfoo3`.
* **Evidence:** **VERIFIED** (1.605 SQL — five distinct statement variants exist, two SQL-Server and three Access).
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 694C92, 694E86, 69C6E6, 69CC8A, 69CFB6, 69D57E]`
* **Outstanding:** ⚠ the join is on a **free-text name**, not on `Gehats.gehahid` — a referrer whose name is spelled differently in `patientinfo` silently earns no commission. This is a **data-integrity defect**, INFERRED from the SQL.

#### BR-BILL-003 — The referring-party master (`Gehats`)
* **Description:** the V2 `Gehats` table has **21 columns**, including `ReferredPW Text(20)` and `ReferredID Long Integer` (both added by the embedded schema-update DDL). Fields: identity (`gehahid`, `gehahsefa`, `gehahname`), the referrer's own agent (`masolsefa`, `masolname`), `madina` (city), `addressxc`, `phone`, `mobil`, `fax`, `mail`, `web`, `flose` (Boolean NOT NULL), `khasm` (a special/contract rate), **`omola` (commission %)**, `morsel`, `pricemethod`, `masolphone`, `printorno` (Boolean NOT NULL).
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE Gehats]`
* **Outstanding:** the `khasm` and `morsel` field semantics are **NOT DOCUMENTED**; only the column names are known.
#### BR-BILL-004 — The payment ledger and its V2 identity column
* **Description:** `payment(patientid, paiddate, type, gehah, testsimp, money, mowzaf, editdate, comment, paymentnum)`; V2 adds **`paymentnum Long Integer`**, created by the embedded schema-update DDL as `bigint IDENTITY(1,1) NOT NULL` (SQL Server) / `AUTOINCREMENT(1,1)` (Access). It is then used as the payment key: `SELECT * FROM payment where paymentnum=` and `Delete FROM payment where paymentnum=`.
* **Affected entities:** `payment.*`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 677EC2, 67D95E, 6F6D2C, 6F6C44]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE payment]`
* **Outstanding:** `payment.type` (Integer) has no documented value set — **NOT RECOVERABLE**.

#### BR-BILL-005 — The sent-out money triad
* **Description:** For sent-out tests the system tracks three amounts on the patient-test row:
  * `testpriceout` — the cost of the test as charged by the external lab;
  * `testpriceoutmadfo` — the amount actually paid out;
  * **balance = `testpriceout − testpriceoutmadfo`**.
  All three are summed, rounded to 2 decimals, per patient / per external lab / per period, alongside `patienttest.sentout` and `patienttest.send`.
* **Affected entities:** `patienttest.testpriceout|testpriceoutmadfo|sentout|send|otherlabname`.
* **Evidence:** **VERIFIED** (1.605 SQL — six statement variants). `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 693732, 693E2E, 695BE2, 696346, 69B86E, 69BFBE]`
* **Outstanding:** the rounding rule for the sent-out balance beyond 2 decimals is **NOT DOCUMENTED**.
#### BR-BILL-006 — The accounting / stock-take window (F7)
* **Description:** "From the main menu choose *Accounts*, then press the button **'Inventory and account calculation'** (or press **F7** from any main window). The **monthly accounts and inventory** window appears. Through it you can find the inventory/account of any time period, the sent-out-sample account, each user's workload, the volume of dealing with referral parties and other labs, and you can print an account claim for a specific party."
* Its seven documented panels:
  1. **Period selector** — default = today's date, then *Show*.
  2. **Patients' accounts** — each button opens a report of the patient names and their itemised details; the "محصلة" (collected) button asks whether to show **money collected from the patients of the selected period only**, or **any patient who paid in that period**.
  3. **Sent-out samples' account** for the period — viewable either **per sample in detail** or **aggregated per destination lab**.
  4. **Expenses and deposits** registered through the accounts window (cash withdrawal and cash deposit).
  5. **Patients with a remaining balance** at the lab, and the **commissions of referral parties**, if any.
  6. **Per-user workload** for the period and the amounts collected with each user.
  7. **Account claim / dealing volume with other parties**, aggregated or itemised.
* **Evidence:** **VERIFIED** (manual, shipped in the 2019 CD). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §13 (011.htm)]`
* **Outstanding:** the exact report behind each of the seven panels is **NOT RECOVERABLE**; only the panel inventory is documented.
#### BR-BILL-007 — The sent-out management window (F7) and its settlement rules
* **Description:** Tests defined as sent-out (in the Test-data window) are **detected automatically** by the system and placed into the sent-out window; the window is reached by **F7** or *Accounts → Sent-out samples*. Its documented rules:
  * Filter to **not-yet-sent only** or **all** samples, restricted to a user-selected period.
  * Clicking a sample **aggregates all samples sent to the same destination lab** and shows the total account.
  * The send buttons let you dispatch the selected sample and **enter the amount that will be paid**; if the account is settled, pressing **"net" (خالص)** makes the system mark it as sent and save it.
  * ⚠ **If the external lab's name is changed it is NOT saved as the default for that test.** To make that destination the default you must press **"always to" (دائماً إليه)** before *OK* or *net*.
  * A drop-down shows all the tests requested in the selected period, so a test that is not marked sent-out can still be displayed and dispatched **without changing the system data** (again: unless *always to* is pressed).
  * Two buttons show **all samples not sent** and **all samples whose account is not settled**, across **all** registered patient data.
  * A drop-down filters to a single destination lab to reduce the search result.
  * Two buttons toggle whether the selected test is sent-out or no longer sent-out (as if edited in the Test-data window).
* **Affected entities:** `testtable.inotherlab|otherlabname|otherlabprice`, `patienttest.sentout|send|otherlabname|testpriceout|testpriceoutmadfo`.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §12 (010.htm)]`
* **Outstanding:** whether the "always to" default is stored per test or per destination lab is **NOT DOCUMENTED**.
#### BR-BILL-008 — Delivery-window settlement actions
* **Description:** The delivery window can (a) deliver the finished results and settle the patient's account or collect a money amount; (b) manually deliver results after selecting the patient from the list; (c) settle the account or collect money for the displayed patient and return to the main window; (d) show undelivered results sorted by lab / independent patient / VIP, restricted to a period and to a user, or all; (e) find a patient by patient code, lab code or file code.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) parts 5-7]`
* **Outstanding:** the permissions attached to the settlement actions are **NOT DOCUMENTED**.
#### BR-BILL-009 — Patient balances and the "balance owed to the patient" case
* **Description:** The Genie icon marks a patient who **has collected all results but has an account problem** — a balance remaining *for the lab* **or** *for the patient* (i.e. the system models both receivable and refundable balances).
* **Affected entities:** `patientinfo.totalprice|totalpricedisc|elmadfoo3|elbakyma3mal`, `payment.money`.
* **Evidence:** **VERIFIED** (manual, §7 icon list) + **INFERRED** (that the sign convention of the three money fields encodes the two directions). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §7 (005.htm) part 1, "رمز الجنية"]`
* **Outstanding:** the sign convention of the money fields is **INFERRED**; the manual does not define them (BR-BILL-001).
#### BR-BILL-010 — `patientinfo.pricemethod` and `Gehats.pricemethod` select the price basis
* **Description:** `pricemethod` is a `Text(10)` / `Text(20)` discriminator on both the patient and the referring party; the receipt group query selects `pricemethod, patientnamear, patientphone, patienttel FROM patientinfo GROUP BY pricemethod, patientnamear, patientphone, patienttel order by pricemethod, patientnamear` — i.e. the receipt is grouped **by price method first**.
* **Evidence:** **VERIFIED** (schema + SQL). `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 66E8FE]`
* **Outstanding:** the set of legal `pricemethod` values is **NOT RECOVERABLE** (no value list is attested for V2, and no row-level export of the live V2 `patientinfo` exists in the archive).

#### BR-BILL-011 — V2 patient-side billing and contact columns
* **Description:** the V2 `patientinfo` table has **39** columns, including **`PFax Text(15)`**, **`PatRPW Text(20)`** (widened to `varchar(20)` by the embedded schema-update DDL), **`SMSMob Text(15)`**, **`gehaName Text(50)`** (referred-party name), **`PBirthDay DateTime`**, **`moreinfo2 Text(30)`**.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patientinfo]` · `[P11 | analysis/BATCH-04/schema/ddl-all.txt | ALTER Table patientinfo ADD …]`
* **Outstanding:** `PatRPW` and `PBirthDay` have **no documented meaning** in the manual — **NOT RECOVERABLE**. `gehaName` was in the embedded DDL but **NOT APPLIED** to the shipped Access DB (BR-MIG-006).

---

### 1.7 Domain G — Reporting & printing

#### BR-RPT-001 — Report layout is per-profile, in `Data\*.ini`
* **Description:** Each report category has its own INI file holding `[reportdata]` (titles, 7 column positions, 7 widths, 24 colours, a font per position, print flags) and `[setupx]` (the category's printer, e.g. `reportprinterx=HP LaserJet 1100 (MS)`). The 2019 CD carries **223** report-layout files; the ledger counts **227** `.ini` paths under `Data\` (the extra ones are `data\data_emp\{PCR,PNT,PNT2,R}.ini`).
* **Affected entities:** `Data\*.ini`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/ini-diff-summary.md | header + §1]` · `[P11 | inventory/ledger.csv | Data\*.ini path count]` · `[P11 | analysis/CUMULATIVE/06-configuration.md | §7]`
* **Outstanding:** ISS-27 remains **OPEN**: 223 layout files against 114 report categories, with numeric filenames that match no profile.
#### BR-RPT-002 — The printed report anatomy
* **Description (as reconstructed from the templates and the manual):**
  ```
  ┌──────────────────────────────────────────────────────────────┐
  │ logo / lab name            <Header>                           │
  │ report main title  (e.g. HEMATOLOGY REPORT)                  │
  │ sub-title        (e.g. Blood Picture: / Urine Culture)        │
  ├──────────────────────────────────────────────────────────────┤
  │ patient name | age | sex | patient id | date | sample no.   │
  ├────────┬────────┬────────┬────────┬──────┬─────────┬─────────┤
  │ test   │ result │ unit   │ normal │ flag │ comment │ status  │
  │        │        │        │ range  │      │         │(print/  │
  │        │        │        │        │      │         │review)  │
  ├────────┴────────┴────────┴────────┴──────┴─────────┴─────────┤
  │ signature: Doctor's signature: / Dr. Doctor's Name / Thanks   │
  └──────────────────────────────────────────────────────────────┘
  ```
* **Evidence:** **INFERRED** (the manual confirms the individual columns and the flag behaviour; the ASCII layout is this analysis' reconstruction). `[P11 | analysis/BATCH-02/rtf/report-structure.md | §3]` · `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §10 (008.htm)]`
* **Outstanding:** the layout is **INFERRED**; only the individual columns and the flag behaviour are confirmed by the manual.
#### BR-RPT-003 — Column geometry is driven by INI keys
* `left1..left7`, `width4`, `width7`, `topvalue`, `bottomvalue`, `leftvalue`, `rightvalue`, `spacevalue`, `spacetitle`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-02/rtf/report-structure.md | §3 source-of-dimensions note]` · `[P11 | real lab system\RL_CD2019Access\Data\*.ini | [reportdata] key set]` · `[P11 | inventory/ledger.csv | Data\*.ini path entries]`
* **Outstanding:** the INI keys are known; the default column geometry they express is **NOT RECOVERABLE**.
#### BR-RPT-004 — Report titles are INI-driven
* `formsubtitle`, `reportmaintitle`, `reportsubtitle1`, `main_symb`, `sub_symb`, `subtitle_symb`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-02/rtf/report-structure.md | §3 source-of-titles note]` · `[P11 | real lab system\RL_CD2019Access\Data\*.ini | [reportdata] key set]` · `[P11 | inventory/ledger.csv | Data\*.ini path entries]`
* **Outstanding:** the INI keys are known; the default titles they express are **NOT RECOVERABLE**.
#### BR-RPT-005 — Colour and font configuration is INI-driven
* `colora..colort` (24 colour slots) and `colorafn..colortfn` (font name / size / bold / underline per position). In V2 the family splits into: `colorbf*` (bold), `colore*` (main), `colorj*` (?), `colork*` (italics), `colori*`, `coloro*`, `colors*`, `colort*` — with `colorbfs`/`colordfs` newly added or changed in 20 files.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-02/rtf/report-structure.md | §3 colours/fonts]` · `[P11 | analysis/BATCH-07/ini-diff-summary.md | §2 rows colorbfs/colordfs/colorsfs/colorcfs/…]`
* **Outstanding:** the semantic meaning of each colour slot (`colorj`, `colork`, `colori`, `coloro`, `colors`, `colort`) is **NOT RECOVERABLE**.

#### BR-RPT-006 — 51 V2 report layouts are re-flowed to make room for the third culture organism
* **Description:** in 51 `.ini` files of the 2019 CD the keys `left3..left7`, `width4`, `width7`, `spacevalue` and `spacetitle` were re-flowed — a complete re-flow of the layout, not 51 independent edits.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.5]`
* **Outstanding:** the reflowed geometry itself is in the 2019 CD; the reason for it is **NOT DOCUMENTED**.
#### BR-RPT-007 — V2 centralises the signature texts
* **Description:** the signature texts are **centralised**: `signature`, `signature2`, `signature3` are **absent from 167 `.ini` files** of the 2019 CD (0 added, 0 changed) and live in a single place (`SETING.ini` / `IDCARD.INI`) — i.e. the keys and their texts are no longer held in the per-profile layouts.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/ini-diff-summary.md | §2 first three rows]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.6]`
* **Outstanding:** the single place the signature texts are held is identified (`SETING.ini` / `IDCARD.INI`), but the key names used there are **NOT DOCUMENTED**.
#### BR-RPT-008 — Six printer roles in V2
* `reportprinter` (reports) · `reportprinterx` (alternate reports) · `zarfprinter` (ZARF external-system integration) · `barcodeprinter` (barcodes) · **`waslprinter` (work sheet)** · **`IDprinter` (ID card)** — the last two are V2 additions.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §3 six printer roles table]`
* **Outstanding:** the six roles are attested; the mapping of `reportprinterx` to a specific report category is **NOT DOCUMENTED**.
#### BR-RPT-009 — V2 printer defaults and head/tail suppression
* **Description:** the 2019 configuration uses **`HP Officejet 6000 E609a Series`** for `reportprinter`/`barcodeprinter`/`zarfprinter`, with `waslprinter` = the same device and `IDprinter` = empty. `reporthead` and `zarfhead` are **`0`**, i.e. **head/tail printing is disabled** in the 2019 configuration. The report font is **Times New Roman 11.25**.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4]`
* **Outstanding:** the 2019 values are attested; the behaviour when a configured printer is absent is **NOT DOCUMENTED**.
#### BR-RPT-010 — PDF output is produced by an external Windows printer driver, not by the application
* **Description:** The 1.605 executable contains **141** occurrences of "PDF" and **2** of "Bullzip", and calls `EnumPrintersA` / `SetDefaultPrinterA`. The literal device name is `Bullzip PDF Printer`; the output literal is `Bullzip PDF Printer 11.1 - Create File`. Output roots: **`D:\PDF\Contracts\`, `D:\PDF\Free\`, `D:\PDF\Individual\`, `D:\PDF\LabToLab\`** — four segregated classes.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §1 and §2]`
* **Outstanding:** the classification rule that assigns a report to Contracts / Free / Individual / LabToLab is **NOT RECOVERABLE**; the PDF path contains no SQL.

#### BR-RPT-011 — Print audit trail and numbered printing
* `resultprint` · `printuser` · `printdate` · `printnum` — described as "individual responsibility and digitisation" and as "numbered printing — detection of unauthorised copies".
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §4]`
* **Outstanding:** the increment rule and the starting value of `printnum` are **NOT RECOVERABLE**.
#### BR-RPT-012 — Printing is gated on verification
* `Not found any Verified selected tests or result to print it`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/13-pdf-print-architecture.md | §4 quality-control table]`
* **Outstanding:** the state the literal calls "Verified" (`resultreview` versus `resultfinsh`) is **INFERRED** (BR-LIFE-012).
#### BR-RPT-013 — Second-layout variants (`_S.ini`)
* **Description:** **110 of the 227** `Data\*.ini` files of the 2019 CD carry a `_S` suffix — a second layout variant for the same profile.
* **Evidence:** **VERIFIED** (counts from the ledger). `[P11 | inventory/ledger.csv | _S.ini path count]`
* **Outstanding:** the *difference* between a layout and its `_S` sibling is **NOT RECOVERABLE** (the diff engine reports key deltas but no semantic label). `[P11 | analysis/BATCH-07/ini-key-delta.csv]`

#### BR-RPT-014 — The report colour palette is an INI file with a `.dll` extension
* **Description:** `bin\REPORT.dll` (562 B) is **not** a DLL — it is a text INI with `[reportdata]` and `color1..color19` holding BGR values (`14737632` = 0xE0E0E0 · `12632256` = 0xC0C0C0 · `16777215` = 0xFFFFFF · `46444020` = 0x2C4C64 · `4210752` = 0x404040). It ships inside the 2019 CD → V2-valid.
* **Evidence:** **VERIFIED**. `[P11 | analysis/CUMULATIVE/06-configuration.md | §6]` · `[P11 | inventory/ledger.csv | REPORT.dll sha256 entry]`
* **Outstanding:** the semantic meaning of the 19 colour slots is **NOT RECOVERABLE** (X11).
#### BR-RPT-015 — The report category catalogue
* **Description (114 categories):** MICROBIOLOGY (18) · MOLECULAR BIOLOGY (16) · BIOCHEMISTRY (15) · HEMATOLOGY (9) · ENDOCRINOLOGY (6) · SEROLOGY (5) · IMMUNOLOGY (2) · CYTOPATHOLOGY · VIROLOGY · CROSS MATCHING · CSF EXAMINATION · BONE MARROW EXAMINATION · SERODIAGNOSIS · SEMEN ANALYSIS · POST-COITAL · PROSTATIC DISCHARGHE · CALCULI · TORCH SCREEN · MANTOUX PPD · URINALYSIS · AUTOMATED URINALYSIS · ZN Film.
* **Evidence:** **INFERRED** — the category names and per-category counts are from the cumulative analysis of the `Data\*.ini` set; the category *set* is V2-valid because the 2019 CD ships the same file set (223 layout files, no file added or removed). `[P11 | analysis/CUMULATIVE/04-clinical-rules.md | §7 report sections]` · `[P11 | analysis/BATCH-07/ini-diff-summary.md | §4 "لم تُضَف أي بروفايل جديد ولا يُحذف — مجموعة الملفات متطابقة: True"]`
* **Outstanding:** ⚠ ISS-27 remains **OPEN**: `Data\` holds 223 layout files against **114** report categories, with 109 `_S` files and numeric filenames that match no profile. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-27]`

#### BR-RPT-016 — `Cache\*.rtf` are method-description sheets, not print templates
* **Description:** 29 Word-2002 documents authored by `ais group` / `real lab`, encoding 1256 (Arabic Windows), `adeflang3073`. They carry, per sheet: sample type (26/29), clinical significance (17/29), reference intervals (9/29), method note (8/29), interpretation (2/29); 2 sheets embed images. **All 29 ship inside the 2019 CD.**
* **Consequence:** the clinical content (critical thresholds, reference intervals, sample types) shipped with V2 is **frozen at the 2010-07-15 → 2010-07-16 authoring dates**.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-02/rtf/test-library.md | §1 and §2]` · `[P11 | analysis/BATCH-02/rtf/report-structure.md | §1 template table]` · `[P11 | inventory/ledger.csv | rtf sha256 entries]`
* **Outstanding:** the Arabic titles of the 29 sheets remain undecoded (ISS-29/ISS-32, accepted limitation).

#### BR-RPT-017 — Work-sheet printing module
* **Description:** The official 2019 learning catalogue adds a whole **Work Sheet** module (2:1–2:2): a work sheet for a group of patients over a period, and a work sheet for a test/group over a period. The `wasl` table and the new `waslprinter` role support it.
* **Evidence:** **VERIFIED** (installer analysis of `RLS_Learn.pdf`). `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §8 module table, Work Sheet row]`

---
* **Outstanding:** the work-sheet print layout itself is **NOT RECOVERABLE**; only the module and the `waslprinter` role are attested.
### 1.8 Domain H — SMS & notifications

#### BR-SMS-001 — Recipient directory `smslist`
* **Description:** V2 creates `smslist(ID Long Integer, smstype Integer, smsphone Text(20), smsname Text(50), smsgroup Text(50), send Integer)`. `smstype` classifies the recipient; `smsgroup` assigns them to a group; **`send` is the "already sent" marker** and was added by the embedded schema-update DDL (`ALTER Table smslist ADD send Smallint`).
* **Affected entities:** `smslist`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE smslist]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6772BA, 67D4D6, 677A2A]`
* **Outstanding:** the value set of `smstype` is **NOT RECOVERABLE**.
#### BR-SMS-002 — The pending-recipient rule
* **Description:** `Select * from smslist where send <> 1 and smstype=` — the work list is "every recipient of this type whose `send` flag is not 1". `send <> 1` is the pending predicate.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 733808]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 7335D8 — Select * from smslist where smstype=]`
* **Outstanding:** the value set of `smstype`, and the retry behaviour after a failed send, are **NOT RECOVERABLE**.
#### BR-SMS-003 — Group-scoped recipient rule
* `Select * from smslist where smstype=1 AND smsgroup = '…'` — recipients can be selected by type **and** group.
* **Affected entities:** `smslist.smstype|smsgroup`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 733874]`
* **Outstanding:** the value set of `smstype` is **NOT RECOVERABLE**.

#### BR-SMS-004 — Recipient groups and message templates
* `smsgroups(ID Long Integer, grouptype Integer, smsgroup Text(50))` — recipient groups, each with a type.
* `SMStemplate(templatenum Long Integer, smstext Text(255))` — the SMS body templates.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE smsgroups / SMStemplate]`
* **Outstanding:** the value set of `grouptype` is **NOT RECOVERABLE**; no template content is recoverable.
#### BR-SMS-005 — The outbound SMS log `SMSSender`
* **Description:** `SMSSender(SMSautonum Long Integer, username Text(50), patientid Text(13), PatDrName Text(60), requestdate DateTime, smsMobile Text(100), SMSLength Integer, SMStext Text(255))`. The embedded schema-update DDL added `username`; the type changes widened `username → varchar(50)` and `smsMobile → varchar(100)`. The log is read with `Select * from SMSSender where patientid='…'`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE SMSSender]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 682A92, 6774AE, 6776A6]`
* **Outstanding:** the SMS *send* mechanism (gateway, SIM, modem) is **NOT RECOVERABLE**; `smsMobile` is stored but no outbound call is present in the SQL pool.

#### BR-SMS-006 — Laboratory-level SMS configuration `MyLabSetting`
* **Description:** `MyLabSetting(LabID Integer, sendername Text(15), accuntID Text(50), accuntpw Text(50), updateflage Byte, Hourflag Integer, SMSNo Integer, totalsms Double, SMSSend Double, SMSbakey Double, phoneNo1..phoneNo6 Text(15), phonenum Integer, Timess Text(100), FridaySend Byte, shortsms Byte)` — read with `Select * from MyLabSetting WHERE LabID=100`.
* **Business meaning (INFERRED):** sender identity, gateway account + password, an hourly-sending flag (`Hourflag`), an SMS quota (`SMSNo`), counters (`totalsms`, `SMSSend`), a balance (`SMSbakey`), up to six phone numbers, a selected number (`phonenum`), a schedule (`Timess`), a Friday-only flag, and a short-message flag.
* **Evidence:** **VERIFIED** for the schema and the `LabID=100` read; the semantics of each field are **INFERRED** from the column names.
* **Provenance:** `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE MyLabSetting]` · `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 68269A]`
* **Outstanding:** ⚠ `accuntpw` stores the gateway password in clear text in the database — a security-relevant business rule with no encryption rule. `[P11 | analysis/V-CD-2019/06-security.md]`

#### BR-SMS-007 — Patient contact channels in V2
* `patientinfo.SMSMob Text(15)` (mobile for SMS) and `patientinfo.PFax Text(15)` (fax) — both added by the embedded schema-update DDL and **applied** to the shipped 2019 database.
* **Affected entities:** `patientinfo.SMSMob|PFax`.
* **Evidence:** **VERIFIED** (schema-apply ledger: added by the embedded schema update). `[P11 | analysis/BATCH-07/migration-proof.md | §2 rows patientinfo/SMSMob and patientinfo/PFax]`
* **Outstanding:** the channel actually used for a given notification is **NOT DOCUMENTED**.
#### BR-SMS-008 — NATIGH.COM e-result delivery is gated on a per-result flag that was NOT applied
* **Description:** `patienttest.NatighU` (Bit / YESNO) marks a result as delivered through the **NATIGH.COM** electronic-results service; the result list selects it alongside the lifecycle flags: `Select testcode, testsimp, arrangnum, RESULTT, RESULTCASEPRINT, resultfinsh, resultprint, give, resultreview, NatighU from patienttest where patientid='…'`.
* **Condition (critical):** `ALTER Table patienttest ADD NatighU Bit` / `ADD COLUMN NatighU YESNO` is one of the **38 ALTER statements that were NOT applied** to the shipped 2019 Access database.
* **Expected behaviour on V2 as shipped:** the NATIGH delivery path cannot work, because the column does not exist in the shipped `Patients.mdb`; the schema-update DDL would have to run first on the customer's machine.
* **Evidence:** **VERIFIED** (both the query and the NOT-APPLIED verdict).
* **Provenance:** `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 67764E, 67D8F6, 6869A2, 686EC2, 6B3C00]` · `[P11 | analysis/BATCH-07/migration-proof.md | §2 row patienttest/NatighU → NOT-APPLIED, and §3 note listing NatighU among the 38]`
* **Outstanding:** the NATIGH protocol itself is **NOT RECOVERABLE**.

#### BR-SMS-009 — The separate e-mail sender utility
* `bin\RealLab E-Mail Sender.exe` (74,240 B) ships with the product (SHA `60530EDC429BA2C158FB20F3F0C34CC6CC38B138699635168A239B359F5DA8FC`).
* **Evidence:** **VERIFIED**. `[P11 | batches/BATCH-07/ingest-report.md | file #309]`
* **Outstanding:** the utility's configuration and its trigger are **NOT DOCUMENTED**.
#### BR-SMS-010 — The note-taking subsystem is consolidated into one component
* **Description:** the 2019 CD ships `bin\NOTEX.dll` at 45,056 B (**"RLS Notes 2.0"**) and **does not ship** `bin\NOTEXS.dll`.
* **Expected behaviour:** the note-taking subsystem is consolidated into one component.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 table rows NOTEX.dll / NOTEXS.dll and §6.1 note 3]`
* **Outstanding:** the exported format of the consolidated note component is **NOT DOCUMENTED**.
#### BR-SMS-011 — `NOTE.ini` carries an observation/comment identifier in V2
* `[NOTICZ] STATUS=1 · NID=22 · LOID=831` — the `NOTE.ini` shipped with the 2019 CD (76 B) adds the `orls` key; `BASE.ini` carries `orls=600` alongside `nrls=600`.
* **INFERRED:** `nrls` = last normal-range id; `orls` = last observation/note id; `NID`/`LOID` = note id / observation id.
* **Evidence:** **VERIFIED** for the key changes; **INFERRED** for the key semantics. `[P11 | analysis/CUMULATIVE/06-configuration.md | §1 and §8]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §3 and §5]`

---
* **Outstanding:** the runtime use of `orls` / `LOID` is **NOT DOCUMENTED**; only the key values are attested.
### 1.9 Domain I — Setup & configuration

#### BR-SETUP-001 — The database engine is an explicit install-time choice
* **Description:** The installer offers two mutually exclusive engines:
  * **Microsoft Access database** — `Microsoft.JET.OLEDB.4.0`, file `D:\real lab system\bin\Patients.mdb`;
  * **Microsoft SQL server database** — `MS SQL Server 2005`, file `D:\Lab_data\Patients.mdf`.
  The installer refuses to continue without a choice: *"You don't select the database type, Please select the type first"*.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §2]`
* **Outstanding:** the engine cannot be changed without losing visibility of the stored data (BR-SETUP-002); the intended engine for a given laboratory is **NOT DOCUMENTED**.
#### BR-SETUP-002 — 🔴 Converting between engines does NOT move the data
* **Description (installer text, quoted verbatim):*** "If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD."
* **Condition:** switching `Databasetype` in `BASE.ini` / re-running the installer with the other engine.
* **Expected behaviour:** the previously stored data remains on disk in the old engine's files but is invisible to the application.
* **Exceptions:** none. The installer provides a separate *"Repair Installed Software"* path (`Frm_repair0..Frm_repair5`) and a schema-update path — but the documented text does **not** state that either performs a data transfer.
* **Affected entities:** `BASE.ini [oledb] Databasetype`, `Patients.mdb`, `Patients.mdf`.
* **Evidence:** **VERIFIED** (verbatim installer string).
* **Provenance:** `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §2 quoted constraint]`
* **Outstanding:** whether the installer offers any data-transfer routine at all is **NOT RECOVERABLE**.

#### BR-SETUP-003 — In SQL Server mode the product uses a *separate interface database* (and a third, `VIDAS`)
* **Description:** Two connection strings are emitted — `Initial Catalog=patients` (`D:\Lab_data\Patients.mdf`, attached by `Attach_Patients.bat`) and **`Initial Catalog=Interface`** (`D:\Lab_data\Interface.mdf`, `Attach_Interface.bat`); a third `VIDAS` database is attached by `Attach_VIDAS.bat`. The interface database separates configuration tables (`useraccounts`, `mylabsetting`, `reportview`) from patient data.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §2.1]`
* **Outstanding:** the `VIDAS` database's role is **NOT RECOVERABLE**.

#### BR-SETUP-004 — Deployment paths
* **Description:** App root `D:\real lab system\` (the CAB's `SETUP.LST` says `DefaultDir=$(ProgramFiles)\real lab system`); data root `D:\Lab_data` (`Setup.bat` → `cd\Lab_data`; `BASE.ini [oledb] loca=E:\Lab_data`); the `Branch_Data.mdb` template at `D:\real lab system\Branch_Data.mdb`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §3 tree]` · `[P11 | analysis/V-CD-2019/12-install-media.md | §2.3 install path table]`
* **Outstanding:** the `BASE.ini [oledb] loca=` value of a deployed laboratory is **NOT RECOVERABLE**; the shipped value is `E:\Lab_data`.
#### BR-SETUP-005 — `BASE.ini` is the DB-selection and last-connection configuration
* **Description:**
  ```ini
  [oledb]
  Databasetype=XMSACCESSX      ; X = enabled (MS Access)
  loca=E:\Lab_data
  DataSource=REAL_LAB
  PersistSecurityInfo=True
  UserID=sa
  Password=12345678
  InitialCatalog=Patients
  [Initial]
  Initialw=123
  nrls=600                     ; last modified normal-range id
  orls=600                     ; last observation/note id
  drls=0
  [lastlog]
  try1=20170926##ACCESS##SPRT007-PC##0##sa##12345678
  try2=20170926##MS_SQL##SPRT007-PC##0##sa##12345678
  try3= … try10= (empty)
  ```
* **Business rule:** the last **10** connection attempts are persisted, each as `date ## engine ## machine-name ## lab-id ## user-name ## password`.
* **Affected entities:** `BASE.ini`.
* **Evidence:** **VERIFIED** (the ini content; the "10 slots" reading is **INFERRED** from `try1`…`try10`).
* **Provenance:** `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §3 BASE.ini block]`
* **Outstanding / security:** passwords are stored in clear text in a text file shipped with the product. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-28]` `[P11 | analysis/V-CD-2019/06-security.md]`

#### BR-SETUP-006 — `SETING.ini` — printing, paper and branch behaviour
* **Description:**
  * `[selectprinter]`: `reportport=LPT1:` · `barcodeport=LPT1:` · `reportprinter` · `barcodeprinter` · `zarfprinter`.
  * `[setup]`: `papersize=A4` · `reportstart=1984` · `Timeouts=09:00 PM` · `historytype=0` · `labbranchx=1` · `barcodeauto=1` · `printworkpaper=1`.
  * 12 text positions (Textr1..4, Textl1..4, Textc1..4) with paper margins.
  * Arabic branding strings `Textr1txt=المنظومة البرمجية` · `Textr2txt=ريال لاب سيستم`.
* **Evidence:** **VERIFIED** for the key structure — **UNVERIFIED** for the V2 values: the `SETING.ini` shipped with the 2019 CD is 4,886 B and its text is only partially reproduced in the cumulative/payload analyses. `[P11 | analysis/CUMULATIVE/06-configuration.md | §4]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §4]`
* **Outstanding:** the V2 value of `Timeouts`, `historytype`, `labbranchx`, `barcodeauto`, `printworkpaper` is **NOT RECOVERABLE**.

#### BR-SETUP-007 — The date-display language must be set to **English (Canada)**
* **Description:** Official install step: *Control Panel → Region and Language → display language = **English (Canada)*** — described in the analysis as a "non-obvious condition imposed by the product".
* **Expected behaviour:** if the OS display locale differs, date rendering in the application breaks or is inconsistent.
* **Evidence:** **VERIFIED** (official install guide). `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §6 documented steps, item 4]`
* **Outstanding:** the failure mode on a display locale other than English (Canada) is **NOT DOCUMENTED**; only the requirement is attested.
#### BR-SETUP-008 — Lab fonts are installed **manually** via Control Panel
* **Description:** `D:\real lab system\Fonts` → select all → Copy → *Control Panel → Fonts* → Paste (the "font already exists" message is acceptable). The five fonts: `ais lab.ttf`, `ais symbol.ttf`, `MCS Taybah.ttf`, `WBCW_UPCEAN.ttf`, `WBCWS_UPCEAN.ttf`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §6 step 3]` · `[P11 | analysis/V-CD-2019/12-install-media.md | §1 fonts row]`
* **Outstanding:** the analysis notes this contradicts the `FontInstaller` VB6 module's existence — i.e. the standard install path does **not** perform a registry font install. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §6 closing note]`

#### BR-SETUP-009 — Licence is bound to the hardware
* **Description:** "Choose your systems (licensed only)"; *"If the computer hard disk, Mother board and CPU damage or lost the RealLab not responsible and you will purchased the other license for the SOFTWARE."* The application reads `Select * from Win32_Processor` (the `win32_processor` table appears in the V2 SQL table list with **1** citation).
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §4 licensing table]` · `[P11 | analysis/V-CD-2019/02-schema.md | §5 table list, row 117 win32_processor]`
* **Outstanding:** the binding algorithm is **NOT RECOVERABLE**; only the `win32_processor` query and the licence text are attested.
#### BR-SETUP-010 — The installer runs a fixed, ordered script set
* `System\SETUP1.bat` (Windows Installer 3.1) → `SETUP2.bat` (MSXML 6.0) → `SETUP3.bat` (.NET Framework 2.0) → `SETUP4.bat` (SQL Server Express 2005) → `SETUP5.bat` (MySQL Connector ODBC 3.51) → `System\SetupPZ.bat` (.NET 4 + Bullzip PDF Printer) → `System\PDF\SetupP.bat` → `XCOPY` (file copy) → `WIN7\setup.exe /sc:\setup.log` **or** `WINXP\setup.exe /sc:\setup.log` → `D:\Lab_data\Attach_Patients.bat` → `Attach_Interface.bat` → `Attach_VIDAS.bat`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §3.1 commands, verbatim]`
* **Outstanding:** the exact order of the three `Attach_*.bat` calls relative to the `XCOPY` is **NOT RECOVERABLE**.
#### BR-SETUP-011 — Installation self-registers 24 OCX/DLL components in the Windows registry
* **Description:** `SETUP.LST` declares **45 files** across two sections — `[Bootstrap Files]` (**6** entries) and `[Setup1 Files]` (**39** entries). The Setup1 destinations are **12** `$(WinSysPathSysFile)`, **21** `$(WinSysPath)`, **5** fonts and **1** `$(MSDAOPath)`; the six bootstrap entries add 6 `$(WinSysPathSysFile)`, making **18 / 21 / 5 / 1** manifest-wide. **24** of the Setup1 entries carry `$(DLLSelfRegister)` and **3** more in the bootstrap section (**27** declared in total); **1** carries `$(TLBRegister)` (`STDOLE2.TLB`) and **27** carry `$(Shared)` (`[SRC | F:\REAL_LAB_COPY\real lab system\RL_CD2019Access\WIN7\SETUP.LST | [Bootstrap Files] and [Setup1 Files] sections, 45 entries]`); 31 are `$(Shared)`.
* **Expected behaviour:** the install requires administrative rights and writes directly to `System32`/`SysWOW64`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/12-install-media.md | §2, §2.1, §2.2]`
* **Outstanding:** the self-registration of `STDOLE2.TLB` on a 64-bit host is **NOT DOCUMENTED**.
#### BR-SETUP-012 — The install media carries **no application copy**
* **Description:** Both `WIN7\real lab system.CAB` and `WINXP\real lab system.CAB` have 48 entries and contain **no** application `.exe`, **no** `.mdb`, **no** `.ini` and **no** `.dat` — only the Jet 4 engine (12 DLLs), the VB6 runtime (5), 19 ActiveX components, 5 type libraries/OLE, and the 5 lab fonts.
* **Evidence:** **VERIFIED** — this closed ISS-01 decisively. `[P11 | analysis/V-CD-2019/12-install-media.md | §1]`
* **Outstanding:** the two CAB variants' shared-component versions are **NOT RECOVERABLE** beyond the inventory counts.
#### BR-SETUP-013 — The "Database Maintenance" gate and its default password
* **Description:** *Settings → "Database Maintenance"* closes the application and opens a dialog requiring the master password; the documented default is **123**, and the manual explicitly recommends changing it. Through the dialog the operator can: change the maintenance password; **zero all system data** (by selecting all buttons in succession, or a subset to clear only part of the data); back up the whole database; **restore** from a backup; and — in the small-lab variant — **restore a single patient by their work code** from the backup database.
* **Affected entities:** the whole database; `patientinfo`; `payment`.
* **Evidence:** **VERIFIED** (manual, shipped in the 2019 CD). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §14 backup.htm]`
* **Outstanding:** the zeroing scope of each button of the maintenance dialog is **NOT DOCUMENTED**.
#### BR-SETUP-014 — Backup file naming and location
* **Description:** "It is preferable to move the backup file to a disc or another machine to avoid losing the data in case of a hard-disk failure — it bears the name **`Patient_yyyymmdd.bak`** and is located in the same path as the database."
* **Expected behaviour:** the backup filename is auto-generated from the current date when the dialog opens.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §14 backup.htm]`
* **Outstanding:** the retention rule for previous `Patient_*.bak` files is **NOT DOCUMENTED**.
#### BR-SETUP-015 — Backup completeness and performance rules
* **Description:** (a) "The last backup file contains all the data present in the files bearing an earlier date — **except** in case of the database being zeroed and some information cleared from the system." (b) "Increasing or enlarging the size of the backup database does not affect system performance, **except** when adding patients to the backup database or searching from within the system in the backup database." (c) After a backup the operator presses **Refresh** next to the backup list to see the new file; deleting a backup requires selecting it first and then pressing **Delete**.
* **Affected entities:** the backup file (`Patient_yyyymmdd.bak`) and the database it is restored from.
* **Evidence:** **VERIFIED** (manual). `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §14 backup.htm]`
* **Outstanding:** the backup database that ships with the 2019 CD was **not refreshed** when the store's schema was updated, so the shipped backup cannot be read as a mirror of the live store; its row content is **NOT RECOVERABLE**. The mechanism behind the missing refresh is **INFERRED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6.1 note 2]`

#### BR-SETUP-016 — The report-configuration surface exposed to the laboratory
* **Description (from the 2019 learning catalogue, "General" module):** system settings · report settings · margins · **paper size (A4/A5)** · **report head and tail** · **head/tail colours** · **printers** · **default account type** · **connection settings (head/tail/margins)** · **background settings**.
* **Evidence:** **VERIFIED** (installer analysis of `RLS_Learn.pdf`). `[P11 | analysis/V-CD-2019/08-deployment-installer.md | §8 module table, General row]`
* **Outstanding:** the mapping of each surface to its INI keys is only partly documented; the remaining keys are **NOT DOCUMENTED**.
#### BR-SETUP-017 — The `data_connection*.udl` files as shipped with the 2019 CD
* **Description:** `data_connection.udl` (674 B) points at the **haematology analyser** database: `Provider=SQLOLEDB.1;Initial Catalog=C:\PROGRAM FILES\AUTOMATIC HEMATOLOGY ANALYZER\AUTOMATIC HEMATOLOGY ANALYZERDATABASE\BF6500.DBMDF;Data Source=REALLAB_AIS;Initial File Name=D:\Lab_data\bf6500.db.mdf`. `data_connection1.udl` (430 B) is the **shape/union** provider: `Provider=MSDataShape.1;…;Initial Catalog=Patients;Data Provider=SQLOLEDB.1;Data Source=REAL_LAB`.
* **Product-lineage rule (VERIFIED):** `BF6500` / `AUTOMATIC HEMATOLOGY ANALYZER` proves the product's ancestry — the "Automatic Hematology Analyzer" product name is retained inside the V2 configuration.
* **Evidence:** **VERIFIED**; both files ship inside the 2019 CD. `[P11 | analysis/CUMULATIVE/06-configuration.md | §2, §3, §4 closing note]` · `[P11 | inventory/ledger.csv | data_connection*.udl sha256 entries]`

---
* **Outstanding:** whether the analyser connection string is used by a deployed laboratory is **NOT DOCUMENTED**.
### 1.10 Domain J — Data integrity & embedded schema evolution

#### BR-MIG-001 — The executable carries its own schema-update DDL
* **Description:** `real lab system.exe` (FileVersion 1.605) embeds **268** DDL statements (CREATE/ALTER) in its string pool, extracted to `analysis/BATCH-04/schema/ddl-all.txt` (807 lines).
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/schema/ddl-all.txt | header]`
* **Outstanding:** the **trigger** for the embedded DDL is **NOT RECOVERABLE** (BR-MIG-006).
#### BR-MIG-002 — Every schema-update statement exists in two dialects
* **Description:** Each logical change is emitted twice — a **SQL Server** variant and an **Access/Jet** variant — e.g. `ALTER Table payment ADD paymentnum bigint IDENTITY(1,1) NOT NULL` and `ALTER Table payment ADD paymentnum AUTOINCREMENT(1, 1)`; `ALTER Table normalrange ALTER COLUMN normalrang varchar(MAX)` and `… Memo`; `Create Table smslist (ID bigint IDENTITY(1,1) …)` and `Create Table smslist (ID AUTOINCREMENT(1, 1) …)`.
* **Expected behaviour:** the same code path can serve either engine.
* **Evidence:** **VERIFIED** (statement-level). `[P11 | analysis/BATCH-04/schema/ddl-all.txt | e.g. lines 134/485, 125/479, 65/467]`
* **Outstanding:** the dialect selected at run time for a given deployment is **NOT DOCUMENTED**.
#### BR-MIG-003 — The applied/not-applied ledger (CREATE)
* **Description:** 27 CREATE statements in the DDL; against the **shipped 2019 `Patients.mdb`**:
  * **12** tables were **created by the embedded schema update** — `Helicobacter`, `MyLabSetting`, `SMSSender`, `SMStemplate`, `insulin`, `patienttestgroup`, `smsgroups`, `smslist`, `testtemp`, `Paste Errors` (plus 2 further entries in the source ledger);
  * **9** **already existed** — `pictures`, `hba1c`, `widal2`, `ratios` ×3, `pictures`, `hba1c` (duplicates in the source list);
  * **6** are **absent** — `LBC`, `IgEallergy`, `FMF` (and their duplicates).
* **Evidence:** **VERIFIED** (exact counts from the schema-apply ledger JSON).
* **Provenance:** `[P11 | analysis/BATCH-07/migration-proof.md | §1 table + §3 conclusion]` · `[P11 | analysis/BATCH-07/migration-proof.json | summary.create_checks / create_checks]`
* **Outstanding:** the ledger compares the embedded DDL against the shipped 2019 schema; whether a customer's database ends up fully updated depends on the unresolved trigger (BR-MIG-006).
#### BR-MIG-004 — The applied/not-applied ledger (ALTER ADD COLUMN)
* **Description:** 228 ALTER-ADD statements in the DDL; against the shipped 2019 `Patients.mdb`:
  * **22** were **added by the embedded schema update**;
  * **145** **pre-existed**;
  * **61** were **NOT-APPLIED** — of which **23** target **SQL-Server-only tables** and **38** target **existing Access tables**.
* **The 22 applied (unique table.column pairs, with the count of DDL variants):**
  `semen.testcode` (1) · `SMSSender.username` (1) · `Gehats.ReferredPW` (1) · `Gehats.ReferredID` (1) · `smslist.send` (1) · `patientinfo.PFax` (1) · `patientinfo.SMSMob` (1) · `patientinfo.PatRPW` (1) · `payment.paymentnum` (2 — one per dialect) · `PTC.ConstID` (2) · `testtable.testcodebill` (2) · `cultures.organism3` (2) · `ratios.albu` (1) · `ratios.albcreat` (1) · `cultures.condition2` (1) · `patientinfo.moreinfo2` (3).
* **Evidence:** **VERIFIED** (exact enumeration from the JSON).
* **Provenance:** `[P11 | analysis/BATCH-07/migration-proof.md | §2 table + §3]` · `[P11 | analysis/BATCH-07/migration-proof.json | alter_checks]`
* **Outstanding:** the ledger compares the embedded DDL against the shipped 2019 schema; whether a customer's database ends up fully updated depends on the unresolved trigger (BR-MIG-006).
#### BR-MIG-005 — The 23 SQL-Server-only statements can never apply to the Access build
* **Description:** 23 of the unapplied ALTERs target tables that exist only in the SQL-Server schema — `Patients` (the SQL-Server name for what is `patientinfo` in Jet), `useraccounts`, `IgEallergy`, `Kidney`, `lipids`.
* **Examples:** `useraccounts.HDD1`, `useraccounts.HDD2`, `useraccounts.Gtype`; `patientinfo.gehaname`; `patienttest.NatighU`; `lipids.nonhdl`; `BloodGases.pO2AA1`, `pO2AA2`, `ctCO2`, `Aniongap`, `HCO3std`, `FiO2`, `ctHB`, `TempRAT`; `Proelectrophoresis.Beta2`, `immunolgo`; `cultures.Few5..Few8`; `prostaticx.crystalp*`; `urine.T56`.
* **Expected behaviour:** on an Access deployment these are permanently unavailable features — blood-gas derived parameters, lipid non-HDL, IgE allergy, the user-account entitlement columns, and the NATIGH flag.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/migration-proof.md | §3 bullet 3]` · `[P11 | analysis/BATCH-07/migration-proof.json | alter_checks where verdict == NOT-APPLIED]`
* **Outstanding:** the 23 statements can never apply to an Access deployment; no equivalent Access-side columns are documented.
#### BR-MIG-006 — The 38 Access-table statements that were not applied
* **Description:** 38 columns inside **existing Access tables** were not added to the shipped 2019 database, so the schema update is **partial** on that build. The named examples are `BloodGases.pO2AA1/ctCO2/Aniongap/HCO3std/FiO2/ctHB/TempRAT` · `cultures.Few5..Few8` · `prostaticx.crystalp*` · `urine.T56` · `patientinfo.gehaname` · `patienttest.NatighU`.
* **Inference (STRONGLY SUPPORTED):** the shipped database is not fully updated; **the schema-update DDL is designed to run on the customer's machine at first start**, not at CD build time.
* **Evidence:** **VERIFIED** for the counts; the "runs at first start" reading is **INFERRED** from the analysis' own statement.
* **Provenance:** `[P11 | analysis/BATCH-07/migration-proof.md | §3 bullet 3 and the VERIFIED FACT box]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §2.3]`
* **Outstanding:** the **trigger** for the schema update (startup? first write? explicit menu?) is **NOT RECOVERABLE** — no V2 SQL in the pool performs the ALTERs.

#### BR-MIG-007 — The V2 schema footprint
* **Description:** the 2019 `Patients.mdb` carries **103 tables / 1,617 columns**; `data.mdb` carries **3 tables** (`history` / `patientinfo` / `wasl`); the CD ships two `Branch_Data.mdb` templates — 970,752 B in `bin\` and **966,656 B** in `System\`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/migration-proof.md | header]` · `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §1 table]`
* **Outstanding:** the row-level content of the 2019 live database is **NOT RECOVERABLE** (§4.3).
#### BR-MIG-008 — The 14 type changes applied by the embedded schema update
* `testtemp.normalrang → MEMO` · `SMSSender.username → varchar(50)` · `SMSSender.smsMobile → varchar(100)` · `semen.Liquefaction → varchar(10)` · `cultures.organism → varchar(80)` · `cultures.organism2 → varchar(80)` · `cultures.organism3 → varchar(80)` · `patientinfo.PatRPW → varchar(20)` · `normalrange.normalrang → varchar(MAX)` **and** `→ Memo` · `cultureanti.Sensitivityvalue → varchar(10)` · `semen.Viscosity → varchar(15)` · `PTC.concent → float`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/02-schema.md | §4 type changes table]` · `[P11 | analysis/BATCH-04/schema/ddl-all.txt | lines 5, 9, 11, 15, 125, 137, 479, …]`
* **Outstanding:** the applied/not-applied status of the `normalrange.normalrang` type change is **UNVERIFIED** (BR-MIG-011).
#### BR-MIG-009 — Identity / auto-increment columns introduced by the embedded schema update
* `payment.paymentnum bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` · `PTC.ConstID bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` · `smslist.ID bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` · `SMSSender.SMSautonum bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)`.
* **Affected entities:** `payment`, `PTC`, `smslist`, `SMSSender`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-04/schema/ddl-all.txt | va 677EC2/67D95E, 677F4A/67FA6, 6772BA/67D4D6, 6774AE/6776A6]`
* **Outstanding:** the seed values of the identity columns in the 2019 live database are **NOT RECOVERABLE**.
#### BR-MIG-010 — NOT NULL constraints are the schema's only hard integrity guarantee
* **Description (V2 `patienttest`):** `printwith`, `resultfinsh`, `resultprint`, `give`, `resultreview`, `sentout`, `send` are all `Boolean NOT NULL` — i.e. **every lifecycle flag is mandatory**. Also `PTC.control Double NOT NULL`, `PTC.concent Double NOT NULL`, `subgrouptable.deleteprotect Boolean NOT NULL`, `Gehats.flose Boolean NOT NULL`, `Gehats.printorno Boolean NOT NULL`, `history.printflag Boolean NOT NULL`, `insulin.id Integer NOT NULL`, `insulin.insulin Text NOT NULL`, `semen.testcode` added as `Smallint`.
* **Affected entities:** all of the above.
* **Evidence:** **VERIFIED** (2019 DDL). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest / PTC / subgrouptable / Gehats / history / insulin]`
* **Note:** the V2 `patienttest` has **46** columns, including `Timeout` and `Taketime` (BR-LIFE-017). `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
* **Outstanding:** the client-side validation that enforces these constraints is **NOT RECOVERABLE**.
#### BR-MIG-011 — `normalrange.normalrang` is Text(255) in the live V2 database
* **Description:** the live V2 `normalrange.normalrang` is `Text(255)` — a capacity limit of 255 characters on the printable range text. The same limit applies to the frozen `patienttest.normalrang`.
* **Evidence:** **VERIFIED**. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]`
* **Outstanding:** whether the embedded schema-update statement `ALTER Table normalrange ALTER COLUMN normalrang varchar(MAX)` / `Memo` was applied on the Access build is **NOT APPLIED** per the ledger (the BR-MIG-006 list does not name it explicitly) — **the applied/not-applied status of the `normalrange.normalrang` type change is UNVERIFIED**.

#### BR-MIG-012 — The shipped 2019 `Patients.mdb` is the installation-time store, and its rows are not recoverable
* **Description:** the 2019 CD ships `Patients.mdb` (2,682,880 B) as the database the installer attaches/creates; the archive holds its **schema only** (the 2019 DDL dump) and never a row-level export of the live store.
* **Affected entities:** `Patients.mdb` · `patientinfo` · `patienttest`.
* **Evidence:** **VERIFIED** for the shipped file and for its schema. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 table row "Patients.mdb"]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patientinfo, patienttest]`
* **Outstanding:** the row counts and the row content of the **live V2 `Patients.mdb`** are **NOT RECOVERABLE** — only its DDL was shipped, not its data. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql]`

#### BR-MIG-013 — The 2019 CD ships **two** branch templates
* **Description:** the 2019 CD ships `bin\Branch_Data.mdb` (970,752 B) and `System\Branch_Data.mdb` (966,656 B). The installer copies `System\` over the installation root, so the deployed template is the `System\` one.
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §6 table + §6.1 note 1]`
* **Outstanding:** which template a deployed laboratory ends up with is **deployment-order dependent — NOT RECOVERABLE** (BR-CAT-008).
#### BR-MIG-014 — The documentation layer is frozen nine years behind the binary
* **Description:** the documentation layer shipped with V2 is frozen: `Cache\*.rtf` (29 sheets, last edited 2010-07-15/16) and `real lab system help.chm` (15 topics) carry pre-2019 product text, while the 1.605 binary itself carries the SMS subsystem, the permissions model and the embedded schema-update DDL.
* **Business rule (governance):** *any user reading the embedded documentation is reading a description of a system generation roughly nine years older than the binary they are operating.*
* **Evidence:** **VERIFIED**. `[P11 | analysis/V-CD-2019/11-deployment-payload-2019.md | §7 and §1.1 closing note]` · `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-35, ISS-43]`

---
* **Outstanding:** whether the frozen documentation still matches the 1.605 behaviour cannot be settled from the archive; only the running binary can confirm it (X15).
## 2. Clinical constants table

### 2.1 The `constanttable` structure (V2)

| Property | Value | Evidence |
|---|---|---|
| Table | `constanttable` | `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE constanttable]` |
| V2 columns (8) | `constantdiscrp Text(50)`, `constant1 Text(50)`, `constant2 Text(50)`, `constant3 Text(50)`, `constant4 Text(50)`, `constant5 Text(50)`, `constant6 Text(50)`, **`constant7 Text(50)`** | same |
| Rows | **NOT RECOVERABLE** for the live V2 store — the group keys V2 reads are `PTCONS`, `CBCCONS` and `RATIOS` | `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 686E1E, 6C540C, 72F81C]` |
| Slot type | all slots are **Text(50)** — the numeric constants are stored as *strings* | `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql]` |
| Access pattern | `SELECT * FROM constanttable where constantdiscrp='<GROUP>'` | `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 686E1E, 6C540C, 72F81C]` |

> ⚠ **Provenance caveat (NOT RECOVERABLE for the live V2 values).** The V2 *schema* is confirmed (2019 DDL) and the CBC *formulas and values* are confirmed against the official manual that ships inside the 2019 CD. The **numeric values the live V2 `constanttable` actually stores are NOT RECOVERABLE** — no row-level export of the live V2 store exists in the archive. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]` `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]`

### 2.2 `CBCCONS` — complete blood count constants

| Slot | Documented value | Documented formula | Condition | Evidence class |
|---|---|---|---|---|
| `constant1` | **3.3** | **`Hct = Hgb × 3.3`** | used when the haematocrit result is **not** entered — Hct is then computed from Hgb | **VERIFIED** (manual) |
| `constant2` | **6.25** | **`Hgb% = Hgb × 6.25`** | **male**, age **> 12 years** | **VERIFIED** (manual) |
| `constant3` | **6.75** | **`Hgb% = Hgb × 6.75`** | **female**, age **> 12 years** | **VERIFIED** (manual) |
| `constant4` | **7.5** | **`Hgb% = Hgb × 7.50`** | **male or female**, age **1 – 12 years** | **VERIFIED** (manual) |
| `constant5` | **8.25** | **`Hgb% = Hgb × 8.25`** | **male or female**, age **< 1 year** | **VERIFIED** (manual) |
| `constant6` | **NOT RECOVERABLE** | *(no documented formula)* | — | **VERIFIED** (slot exists, 2019 DDL) / **NOT RECOVERABLE** (value, purpose) |
| `constant7` | **NOT RECOVERABLE** | *(no documented formula)* | added by the embedded schema-update DDL | **VERIFIED** (existence) / **NOT RECOVERABLE** (value, purpose) |

Manual text (quoted, translated): *"Hct (Hematocrit) = Hgb * 3.3 — in case the hematocrit result is not entered it is computed from the hemoglobin"*, *"Hemoglobin % (Hgb%) = Hgb * 8.25 (Male or Female age less than one year)"*, *"… = Hgb * 7.50 (Male or Female age from 1 – 12 years)"*, *"… = Hgb * 6.25 (Male age great than 12 years)"*, *"… = Hgb * 6.75 (Female age great than 12 year)"*. `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §15 nots.htm]`

Slot-to-group cross-reference for V2 is fixed by the shipped schema: `constantdiscrp` selects the group and `constant1..constant7` are the seven slots. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`

> **Slot binding (NOT RECOVERABLE):** the *formulas and values* in the table above are V2-verified — they are documented verbatim in the manual that ships inside the 2019 CD. The *binding of each formula to a numbered slot* is part of the shipped database configuration and cannot be re-checked against the live V2 store.

### 2.3 `PTCONS` — prothrombin-time control constants

| Slot | Documented meaning | Value in the live V2 store | Condition | Evidence class |
|---|---|---|---|---|
| `constant1` | **PT Control Time** | **NOT RECOVERABLE** | primary control level | **VERIFIED** (slot + meaning) / **NOT RECOVERABLE** (value) |
| `constant2` | **PT Control Time (second level)** | **NOT RECOVERABLE** | secondary control level | **VERIFIED** (slot + meaning) / **NOT RECOVERABLE** (value) |
| `constant3` | **ISI** (International Sensitivity Index) — used to derive the INR | **NOT RECOVERABLE** | — | **VERIFIED** (slot + meaning) / **NOT RECOVERABLE** (value) |
| `constant4` | control-time ↔ concentration mapping; the analysis' reading is the **Westgard 2CV reject rule** | **NOT RECOVERABLE** | the concentration table used for QC | **INFERRED** (the Westgard interpretation) / **NOT RECOVERABLE** (value) |
| `constant5` | *(no documented meaning)* | **NOT RECOVERABLE** | — | **VERIFIED** (slot, 2019 DDL) / **NOT RECOVERABLE** (value, purpose) |
| `constant6` | *(no documented meaning)* | **NOT RECOVERABLE** | — | **VERIFIED** (slot, 2019 DDL) / **NOT RECOVERABLE** (value, purpose) |

The constant group is looked up verbatim: `SELECT * FROM constanttable where constantdiscrp='PTCONS'`. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 686E1E]`

> **Slot binding (NOT RECOVERABLE):** the *meanings* above — PT control time, PT control time (second level), ISI, control-time/concentration table — are the four items the shipped manual requires the laboratory to verify before first use; the *binding of each meaning to a numbered slot*, and every value, is part of the shipped database configuration and cannot be re-checked against the live V2 store.

### 2.4 `RATIOS` — a third constant group queried by V2

* `SELECT * FROM constanttable where constantdiscrp='RATIOS'` exists in the 1.605 SQL pool.
* **No `RATIOS` row is attested for the live V2 store**; how many constant groups the live store carries is **NOT RECOVERABLE**.
* **Evidence class:** existence of the query **VERIFIED**; the group's values and purpose **NOT RECOVERABLE**.
* `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 72F81C]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE constanttable]`

### 2.5 Summary of the constant matrix

| Group | Slots the V2 schema provides | Slots the shipped manual names | Values recoverable for the live V2 store |
|---|---|---|---|
| `CBCCONS` | `constant1..constant7` (7) | **5** (Hct + four Hgb% formulas) | **5 of 5** (manual) · the remaining slots **NOT RECOVERABLE** |
| `PTCONS` | `constant1..constant7` (7) | **4** (control time ×2 · ISI · concentration table) | **none** — every value **NOT RECOVERABLE** |
| `RATIOS` | `constant1..constant7` (7) | **0** | **none** — every value **NOT RECOVERABLE** |

---

## 3. PTC control curve (prothrombin-time control material)

### 3.1 The curve — control / concentration pairs

The curve is a **two-column table of points**: `control` (the prothrombin time, in seconds) against `concent` (the concentration of the control material). The application reads the whole table in ascending `control` order and derives the usable control window from the table itself with `MIN(control)` / `MAX(control)`.

| Aspect | Finding | Evidence class |
|---|---|---|
| Table | `PTC(control Double NOT NULL, concent Double NOT NULL, ConstID Long Integer)` | **VERIFIED** `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE PTC]` |
| Key | `control` — one point per control time; `concent` is the concentration of that point | **VERIFIED** `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE PTC]` |
| Number of points the live V2 store carries | **NOT RECOVERABLE** — no row-level export of the live V2 store exists in the archive | **NOT RECOVERABLE** |
| The point values (control ↔ concentration) | **NOT RECOVERABLE** for the same reason | **NOT RECOVERABLE** |
| Read order | `SELECT * From PTC ORDER BY control` — the curve is always consumed in ascending time order | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CA500]` |
| Curve bounds | `SELECT MIN(control) AS Exprmin, MAX(control) AS Exprmax From PTC` — the control window is computed from the table itself | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CAD50]` |
| Per-constant scoping (V2) | `select * FROM PTC where ConstID=` — each constant set has its own curve | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CA4B8, 6CA7B4]` |
| Population duty | the laboratory must enter the PT "Control Time and Concentration table" before first use | **VERIFIED** `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 nots.htm item 1]` |

**Reading of the table:** the V2 application treats the curve as **configuration data**: it is read in ascending control-time order, its usable window is computed from the rows present, and it is scoped per constant set through `ConstID`. The number of points, their control times and their concentrations are **NOT RECOVERABLE** for the live V2 store (§3.2) — a replacement system must therefore treat the PT control curve as **data the customer maintains**, not as a fixed constant.

### 3.2 The rule that uses the curve

| Aspect | Finding | Evidence class |
|---|---|---|
| Table | `PTC(control Double NOT NULL, concent Double NOT NULL, ConstID Long Integer)` | **VERIFIED** `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE PTC]` |
| Row count | **NOT RECOVERABLE** — no row-level export of the live V2 store exists in the archive | **NOT RECOVERABLE** `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE PTC]` |
| Read order | `SELECT * From PTC ORDER BY control` — the curve is always consumed in ascending time order | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CA500]` |
| Curve bounds | `SELECT MIN(control) AS Exprmin, MAX(control) AS Exprmax From PTC` — the control window is computed from the table itself | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CAD50]` |
| Per-constant scoping (V2) | `select * FROM PTC where ConstID=` — each constant set has its own curve | **VERIFIED** `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6CA4B8, 6CA7B4]` |
| Related profile | `pt` carries `pt`, `concent`, `inr`, `ratios`, `ptt`, `fibro`, `fdp` — the INR/ratio columns are the downstream consumers of the ISI constant | **VERIFIED** `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE pt]` |
| Operator obligation | The laboratory must verify "PT: ISI, Control Time and Concentration table" before first use | **VERIFIED** `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 nots.htm item 1]` |
| Westgard 2CV rule | The analysis' reading of `PTCONS.constant4` as the "Westgard 2CV (reject)" selection; the token the live V2 store holds in that slot is **NOT RECOVERABLE** | **INFERRED** / **NOT RECOVERABLE** `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 nots.htm]` |

**Conflict to note (VERIFIED):** the manual requires a usable **"Control Time and Concentration table"** for PT before work begins, while the values the live V2 store holds in `PTCONS.constant1`…`constant4` are **NOT RECOVERABLE** — the shipped configuration cannot be shown to satisfy the product's own documented pre-use condition, and the laboratory is expected to enter the table itself (§2.3). The control-time data a deployed V2 laboratory actually uses is therefore **NOT RECOVERABLE** from this archive.

---

## 4. Reference-range model

### 4.1 Column set — V2 live `normalrange` (18 columns)

| # | Column | Jet type | Meaning | Class |
|---:|---|---|---|---|
| 1 | `normalid` | Long Integer | surrogate key | VERIFIED |
| 2 | `testcode` | Long Integer | FK to `testtable.testcode` | VERIFIED |
| 3 | `testsimp` | Text(50) | the analyte name | VERIFIED |
| 4 | `subgroupcode` | Integer | FK to `subgrouptable` | VERIFIED |
| 5 | `sex` | Text(10) | `Male` / `Female` / `All` / empty | VERIFIED |
| 6 | `firstold` | Double | age lower bound | VERIFIED |
| 7 | `secondold` | Double | age upper bound | VERIFIED |
| 8 | `ageunit` | Text(10) | `Years` / `Days` / `Mons.` / empty | VERIFIED |
| 9 | `pregsmok` | Single | pregnancy/smoking variant selector | VERIFIED |
| 10 | `normalrang` | **Text(255)** | the printable range text | VERIFIED |
| 11 | `testunit` | Text(15) | the unit shown next to the result | VERIFIED |
| 12 | `lowlimit` | Double | below this ⇒ abnormal (low) | VERIFIED |
| 13 | `highlimit` | Double | above this ⇒ abnormal (high) | VERIFIED |
| 14 | `nolowexe` | Text(20) | the "low" flag text printed | VERIFIED |
| 15 | `nohighexe` | Text(20) | the "high" flag text printed | VERIFIED |
| 16 | `lowcomment` | Memo/Hyperlink(255) | explanatory comment (low) | VERIFIED |
| 17 | `highcomment` | Memo/Hyperlink(255) | explanatory comment (high) | VERIFIED |
| 18 | **`REFRANGE`** | **Text(1)** | "this is the primary/active range for the test" | VERIFIED |

Source: `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]`

> ⚠ **A 22-column `normalrange` shape** with `criticalrang Memo`, `lowlcrit Double`, `highlcrit Double`, `criticalexe Text(20)`, `criticalcomment Memo` and **no `REFRANGE`** is **not attested for V2**; the only V2 schema evidence (the 2019 DDL dump) carries the 18 columns listed above. See BR-RANGE-009.

### 4.2 Sex / age-unit dimensions of the V2 `normalrange` table

The V2 schema fixes **which** dimensions the reference-range table carries; the values the live V2 store holds on those dimensions are **NOT RECOVERABLE** — no row-level export of the live V2 store exists in the archive. The column list is §4.1; the counts published for V2 are §4.3.

| Dimension | What the V2 schema fixes | What the live V2 store holds | Class |
|---|---|---|---|
| **Sex** | `sex Text(10)` — `Male` / `Female` / `All` / empty | NOT RECOVERABLE | VERIFIED (schema) / **NOT RECOVERABLE** (data) |
| **Age unit** | `ageunit Text(10)` — `Years` / `Days` / `Mons.` / empty | NOT RECOVERABLE | as above |
| **Age band** | `firstold` / `secondold` (Double) — the lower and upper bound of the band | NOT RECOVERABLE | as above |
| **Per-field bounds** | the numeric span each of the two bound fields may take | NOT RECOVERABLE | as above |
| **Distinct tests covered** | `testcode` — FK to `testtable.testcode` | NOT RECOVERABLE | as above |
| **Numeric `lowlimit`** | `lowlimit Double` | NOT RECOVERABLE | as above |
| **Numeric `highlimit`** | `highlimit Double` | NOT RECOVERABLE | as above |
| **Non-empty `nolowexe`** (low flag text) | `nolowexe Text(20)` | NOT RECOVERABLE | as above |
| **Non-empty `nohighexe`** (high flag text) | `nohighexe Text(20)` | NOT RECOVERABLE | as above |
| **Non-empty `lowcomment`** | `lowcomment Memo` | NOT RECOVERABLE | as above |
| **Non-empty `highcomment`** | `highcomment Memo` | NOT RECOVERABLE | as above |
| **Distinct unit strings used by ranges** | `testunit Text(15)` — free text, not an FK to `testunits` | NOT RECOVERABLE | as above |
| **`REFRANGE` values** | `REFRANGE Text(1)` — `'1'` marks the active range | NOT RECOVERABLE | as above |
| **`pregsmok` values** | `pregsmok Single` — the variant selector | NOT RECOVERABLE | as above |

`[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]` · `[P11 | analysis/CUMULATIVE/04-clinical-rules.md | §3 normal ranges]`

### 4.3 ⚠ Which catalogue counts are recoverable for V2

The catalogue counts that the V2 evidence publishes are listed below; every other catalogue count is **NOT RECOVERABLE** for the live V2 store, because the 2019 schema was shipped as a DDL dump only and no row-level export of the live V2 store exists in the archive.

| Quantity | Status for V2 | Evidence |
|---|---|---|
| `normalrange` rows | **852** — published for V2 | `[P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-3 — "normalrange (852)"]` |
| `normalrange` columns | **18** | `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE normalrange]` |
| `converts` rows | **NOT RECOVERABLE** | schema only |
| `testunits` rows | **NOT RECOVERABLE** | schema only |
| `subgrouptable` rows | **46** — published for V2 | `[P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.7 row "إضافة مجموعة تحاليل" — "subgrouptable (46)"]` |
| `testtable` rows | **609** — published for V2 (38 columns in the V2 schema) | `[P11 \| analysis/V-CD-2019/09-vendor-capability-catalogue.md \| §2.3 row 3-1 — "testtable (609)"]` · `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE testtable]` |
| `abbreviations` rows | **NOT RECOVERABLE** | schema only |
| `constanttable` rows / cols | rows **NOT RECOVERABLE** / **8 cols** | `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE constanttable]` |
| `PTC` rows | **NOT RECOVERABLE** | schema only |
| `patienttest` rows | **NOT RECOVERABLE** | schema only |
| `patientinfo` rows | **NOT RECOVERABLE** | schema only |
| `wasl` rows | **NOT RECOVERABLE** | schema only |
| `payment` rows | **NOT RECOVERABLE** | schema only |
| `history` rows | **NOT RECOVERABLE** | schema only |

`[P11 | analysis/V-CD-2019/09-vendor-capability-catalogue.md | §2.3 and §2.7]` · `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | DDL only — no data]`

**Consequence:** the figures "**852** reference ranges", "**609** tests" and "**46** report profiles" are published for V2 and may be used as such; the size of the conversion catalogue, the size of the unit dictionary and the number of distinct tests the range catalogue covers are **NOT RECOVERABLE from this archive**. Any replacement system must treat the reference-range and unit-conversion catalogues as **configuration data that the customer maintains**, not as a fixed constant.

### 4.4 The `pregsmok` finding

* The column exists in the V2 live schema, with type `Single`. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE normalrange]`
* The 1.605 binary **uses the column as a lookup predicate**: `SELECT * FROM normalrange where testcode=<code> and REFRANGE='1' and pregsmok = '<value>'` — so it is a *discriminating* key, not a passive attribute. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6E94EC …]`
* **Interpretation (INFERRED):** `pregsmok` is a **pregnancy/smoking variant selector**: a range row is tied to the general (non-pregnant) variant or to a pregnancy-specific variant, so one test can carry several ranges for the same (sex, age) band. The presence of the word "Smoking" in the column name is **not** substantiated by any V2 artefact in this archive.
* **Not recoverable:** how many rows the live V2 `normalrange` carries for each variant, and which analytes carry a pregnancy-specific range, are **NOT RECOVERABLE** — no row-level export of the live V2 store exists in the archive (§4.2, §4.3).
* **Outstanding:** ISS-26 remains **OPEN** — "`normalrange.pregsmok` is unexplained — a `Single` value in every row; the range may vary for pregnancy/smoking — a clinically significant rule". The proposed resolution (compare `patienttest` against `normalrange`) cannot be executed, because the live V2 rows were never exported. `[P11 | 10-Issues/Open-Issues-and-Limitations.md | ISS-26]`

### 4.5 🔒 The "frozen snapshot at result entry" rule

**Rule:** at the moment a result is entered, the applicable reference range, its two limits, the two flag texts and the unit are **copied onto the result row**; the report then renders the snapshot, not the live range.

**Evidence (V2, VERIFIED):**

1. `patienttest` in the V2 schema carries `normalrang Text(255)`, `testunit Text(15)`, `lowlimit Double`, `highlimit Double`, `nolowexe Text(20)`, `nohighexe Text(20)` — exactly the six fields of the range that a report needs. `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
2. The 1.605 result query reads **all six from `patienttest`** and never joins `normalrange`:
   `SELECT patientid,requestdate,subgroupcode,testcode,testsimp,arrangnum,resultt,testprice,testpriceout,sentout,testtime,printwith,loggroup,otherlabname,testabrev,testname,historyname,testunit,normalrang,lowlimit,highlimit,nolowexe,nohighexe,resultfinsh,resultreview,resultprint,give FROM patienttest where patientid='…'`. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 7327CC, 732A48]`
3. The report query likewise selects `patienttest.testunit, patienttest.normalrang, patienttest.RESULTCASEPRINT`. `[P11 | analysis/BATCH-04/sql_v1605/statements.csv | va 6895B6, 689D96]`
4. The snapshot columns exist on the result row, so a range is copied onto it at entry time; how many rows of the live V2 `patienttest` carry a populated `normalrang` is **NOT RECOVERABLE** (no row-level export of the live V2 store exists in the archive).

**Consequence:** a later edit of `normalrange` (adding a new age band, changing a limit) does **not** retro-actively alter already-issued reports. This is a deliberate, audit-grade design. It is also the mechanism by which the reference range is *guaranteed* to have been in force at the time of measurement.

**Caveat (INFERRED, not proven):** the INSERT/UPDATE that performs the copy is not in the recovered SQL pool (the pool holds 1,798 statements, dominated by SELECTs and DDL). The rule is therefore established from the read path, the column pairing and the manual's behaviour description ("the values on which the result is considered not normal"), not from the write path.

---

## 5. Result lifecycle state machine

### 5.1 Every state column of `patienttest` (V2, 46 columns)

| Column | Jet type | State it encodes | Set / cleared by | Evidence class |
|---|---|---|---|---|
| `resultfinsh` | **Boolean NOT NULL** | **Entry complete** — the result has been entered and saved | **Save** button / **F9** ("F9 — save the results and modifications"); in the delivery window **F9** = "consider the result finished or not finished" | VERIFIED |
| `resultreview` | **Boolean NOT NULL** | **Reviewed / authorised** | **F8** ("F8 — consider the patient's selected tests as reviewed") | VERIFIED |
| `resultprint` | **Boolean NOT NULL** | **Printed** | **F12** ("F12 — print the result report") | VERIFIED |
| `give` | **Boolean NOT NULL** | **Delivered to the patient** | delivery window (**F6**) / the "مستلمة" override button | VERIFIED |
| `sentout` | **Boolean NOT NULL** | **The sample is a sent-out sample** | set by the sent-out window / the Test-data flag `inotherlab` | VERIFIED |
| `send` | **Boolean NOT NULL** | **The sent-out sample has been dispatched** | sent-out window | VERIFIED |
| `printwith` | **Boolean NOT NULL** | **Eligible for inclusion in a combined report** | catalogue field "Print with other" | VERIFIED |
| `NatighU` | *Bit / YESNO* | **Result published to NATIGH.COM** | e-delivery path | VERIFIED (query + DDL) / **NOT APPLIED** in the shipped Access DB |
| `printnum` | Double | **Numbered-print counter** (anti-copy audit) | print action | VERIFIED |
| `printuser` / `printdate` | Text(40) / Text(40) | **Who printed it / when** (dates stored as text) | print action | VERIFIED |
| `edituser` / `editdate` | Text(40) / Text(40) | **Who last edited it / when** | edit action | VERIFIED |
| `prevuser` / `prevdate` | Text(40) / Text(40) | **Who edited it previously / when** | edit action | VERIFIED |
| `taslimuser` / `taslimdate` | Text(40) / Text(40) | **Who delivered it / when** | delivery action | VERIFIED |
| `Timeout` | Text(10) | **Configured due time** (V2 only) | — | VERIFIED (schema) / semantics NOT RECOVERABLE |
| `Taketime` | Integer | **Elapsed turnaround time** (V2 only) | — | VERIFIED (schema) / semantics NOT RECOVERABLE |
| `RESULTCASEPRINT` | Text(15) | Case-print caption for the report | — | VERIFIED |
| `RESULTT`, `resultt1..resultt4` | Text(50) ×5 | Result text + up to four sub-results | entry | VERIFIED |
| `normalrang`, `testunit`, `lowlimit`, `highlimit`, `nolowexe`, `nohighexe` | Text(255)/Text(15)/Double/Double/Text(20)/Text(20) | **Frozen reference-range snapshot** (BR-RANGE-010) | entry | VERIFIED |
| `commentx` | Memo | Free comment on the result | entry | VERIFIED |
| `arrangnum` | Integer | Display order within the patient | — | VERIFIED |
| `subgroupcode`, `testcode`, `testsimp` | Integer / Integer / Text(50) | Catalogue identity | order entry | VERIFIED |
| `requestdate` | DateTime | Order date | order entry | VERIFIED |
| `testtime` | Integer | TAT in days (copied from `testtable.testtime`) | order entry | VERIFIED |
| `testprice`, `testpriceout`, `testpriceoutmadfo` | Double ×3 | Patient price / sent-out cost / sent-out paid | order entry / sent-out settlement | VERIFIED |
| `otherlabname` | Text(40) | Destination lab for a sent-out test | sent-out window | VERIFIED |
| `printwith` | Boolean NOT NULL | (see above) | — | VERIFIED |
| `loggroup` | Text(50) | Work group / analyser | — | VERIFIED |
| `patientid` | Text(13) | Patient (composite key) | order entry | VERIFIED |

Schema source: `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttest]`
Behaviour source: `[P11 | analysis/BATCH-04/help_v1605/help-manual-ar.md | §6 (004A.htm), §7 (005.htm)]`

### 5.2 The key sequence

```
   order entry                entry                   review                print                deliver
 ┌──────────────┐        ┌──────────────┐        ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
 │ requestdate  │        │ resultfinsh  │        │ resultreview │     │ resultprint  │     │    give      │
 │ testcode     │ ─────▶ │   = TRUE     │ ─────▶ │   = TRUE     │ ──▶ │   = TRUE     │ ──▶ │   = TRUE     │
 │ testprice    │        │ (Save / F9)  │        │    (F8)      │     │    (F12)     │     │  (F6 window) │
 │ arrangnum   │        │ + snapshot   │        │              │     │ + printnum   │     │ + taslimuser │
 │              │        │   of range   │        │              │     │ + printuser  │     │ + taslimdate │
 └──────────────┘        └──────────────┘        └──────────────┘     └──────────────┘     └──────────────┘
                                │                                                                                   │
                                │ (F9 = "finished or not finished")                    ┌──────────────────────────────┐
                                │ (F8 = "reviewed or not reviewed")                    │ patienttest.sentout / send  │
                                │ (F12 = "printed or not printed")                     │ testpriceout                │
                                ▼                                                    │ testpriceoutmadfo           │
                        ──────────────────────────────────────────────────────────▶ │ balance = priceout − paid  │
                        outstanding worklist: resultfinsh = False                                    │
                        for a given requestdate                                                 └──────────────────────────────┘
```

### 5.3 The gates, in order (all VERIFIED)

| Gate | Rule | Source of truth |
|---|---|---|
| G1 | A result must be **entered** before it can be reviewed; the worklist shows `resultfinsh = False` for a given `requestdate`. | `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6843F2, 68463A]` |
| G2 | A result must be **reviewed** before it can be printed: `Not found any Verified selected tests or result to print it`. | `[P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4]` |
| G3 | A result must be **printed** before it can be **delivered**: "the results must be reviewed so the user can print them, and they must be printed so the user can deliver them to the patient". | `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 (005.htm)]` |
| G4 | Delivery can be **overridden** ("مستلمة") if it happened by mistake or the lab wants to treat the result as delivered. | `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 (005.htm) part 4]` |
| G5 | Each print screen addresses **only its own test codes** (hard-coded sets). | `[P11 \| analysis/BATCH-04/sql_v1605/statements.csv \| va 6A273A, 6B2D70, 6BA22C, 6BE5E0, 6C2244]` |
| G6 | The patient icon summarises the state machine (new / not-yet-written / not-yet-reviewed / not-yet-printed / not-yet-delivered / settled / balance problem). | `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 (005.htm) part 1]` |

### 5.4 Parallel state columns in the V2 companion tables

| Table | Flag columns | Notes |
|---|---|---|
| `patienttestgroup` (46 cols) | `printwith`, `resultfinsh`, `resultprint`, `give`, `resultreview`, `sentout`, `send` — **all Boolean NOT NULL** | a structural clone of `patienttest` for group requests; carries its own frozen `normalrang Text(255)`, `lowlimit`, `highlimit`, `nolowexe`, `nohighexe` |
| `testtemp` (28 cols) | `printwith`, `resultfinsh`, `resultreview`, `resultprint`, `give`, `sentout` — all Boolean NOT NULL | scratch storage for in-progress work; also carries `normalrang Memo`, `lowlimit`, `highlimit`, `nolowexe`, `nohighexe`, and a `detelethis Long Integer` column |

`[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patienttestgroup / testtemp]`

---

## 6. Critical thresholds (per test, with units)

> **Provenance:** the `Cache\*.rtf` sheets ship inside the 2019 CD (29/29), so these thresholds **are** the V2 shipped clinical thresholds. They were authored 2010-07-15 → 2010-07-16 and were never revised. `[P11 | inventory/ledger.csv | rtf sha256 pairs]` `[P11 | analysis/BATCH-02/rtf/test-library.md | §1 index — creation dates]`

### 6.1 The threshold table

| Test | Sheet | Critical threshold(s) | Unit | Evidence class |
|---|---|---|---|---|
| **CBC with differential** | `056.rtf` | **Hgb: `< 5 g/dL` or `> 20 g/dL`** | g/dL | VERIFIED |
| | | **Hct: `< 15%` or `> 60%`** | % | VERIFIED |
| | | **WBC: `< 500` or `> 50,000`** | mm³ (the sheet writes "500 mm3", "50,000/ mm3") | VERIFIED |
| | | **Platelets: `< 50,000` or `> 999,000`** | /mm³ | VERIFIED |
| **Blood Urea Nitrogen (BUN)** | `013.rtf` | **`> 40 mg/dL`** — *not dehydrated / no history of renal disease* | mg/dL | VERIFIED |
| | | **`> 100 mg/dL`** — *patient with a history of renal disease* | mg/dL | VERIFIED |
| | | **`> 20 mg/dL` increase in 24 h** — *indicates acute renal failure* | mg/dL/24 h | VERIFIED |
| **Bilirubin (total, direct, indirect)** | `015.rtf` | **Newborn: `> 15 mg/dL`** — SI `> 257 µmol/L` | mg/dL (µmol/L) | VERIFIED |
| **Calcium, ionised** | `175.rtf` | **`> 6.29 mg/dL`** — SI `> 1.57 mmol/L` **or** **`< 3.1 mg/dL`** — SI `< 0.78 mmol/L` | mg/dL (mmol/L) | VERIFIED |
| **Calcium, total** | `176.rtf` | **`> 12 mg/dL`** — SI `> 2.99 mmol/L` *(coma, death)* | mg/dL (mmol/L) | VERIFIED |
| | | **`< 7 mg/dL`** — SI `< 1.75 mmol/L` *(tetany, death)* | mg/dL (mmol/L) | VERIFIED |
| **Chloride (Cl)** | `180.rtf` | **`< 80 mEq/L` or `> 115 mEq/L`** | mEq/L | VERIFIED |

`[P11 | analysis/BATCH-02/rtf/text/056.txt | "Critical levels:" block]` · `[P11 | analysis/BATCH-02/rtf/text/013.txt | "Critical Levels:" block]` · `[P11 | analysis/BATCH-02/rtf/text/015.txt | "Critical Level:" line]` · `[P11 | analysis/BATCH-02/rtf/text/175.txt | "Critical levels:" line]` · `[P11 | analysis/BATCH-02/rtf/text/176.txt | "Critical levels:" block]` · `[P11 | analysis/BATCH-02/rtf/text/180.txt | "Critical levels:" line]`

### 6.2 ⚠ Analyte identity on the threshold sheets

| # | Sheet | Finding | Evidence |
|---|---|---|---|
| C1 | `180.rtf` | The sheet documents **Chloride (Cl)**. Its reference intervals are *Adult: 96–106 mEq/L; Child: 90–110 mEq/L* and the sample note reads "Chloride (Cl) … Aids in maintenance of electrical neutrality, fluid and acid-base balance, and osmolality of body fluids (with sodium)". The critical thresholds `< 80 / > 115 mEq/L` are transcribed from this sheet. | `[P11 \| analysis/BATCH-02/rtf/text/180.txt \| title line "Chloride (Cl)"]` |
| C2 | `056` `013` `015` `175` `176` `180` | The critical-threshold set covers **six sheets, five distinct analytes + the CBC profile**: CBC (056), BUN (013), bilirubin (015), ionised calcium (175), total calcium (176), chloride (180). | as above |

### 6.3 Reference intervals printed on the same sheets (context for the thresholds)

The RTF→text extraction loses the en-dash, so ranges appear as digit runs. The restored intervals are **INFERRED** (high confidence — the two bounds and units are unambiguous and the " to " forms in the same sheets confirm the pattern).

| Sheet | Test | Adult | Child | SI equivalents |
|---|---|---|---|---|
| `013` | BUN | `10–20 mg/dL` | `4–16 mg/dL` | `3.6–7.1 mmol/L` · `1.4–5.7 mmol/L` |
| `015` | Bilirubin | Total `0.3–1 mg/dL`; Direct `0.1–0.3 mg/dL`; Indirect `0.1–0.8 mg/dL` | same | `1.7–20.5` · `1.7–5.1` · `1.7–12 µmol/L`; Newborn `1–2 mg/dL` = `17.1–20.5 µmol/L` |
| `175` | Calcium, ionised | `4.4 – 5.3 mg/dL` (explicit) | `4.4 – 6.0 mg/dL` | `1.05–1.3` · `1.2–1.38 mmol/L` |
| `176` | Calcium, total | `8.2 – 10.5 mg/dL` | `8.6–11.2 mg/dL` | `2.05–2.54` · `2.15–2.79 mmol/L` |
| `180` | Chloride | `96–106 mEq/L` | `90–110 mEq/L` | `96–106` · `90–110 mmol/L` |

`[P11 | analysis/BATCH-02/rtf/text/013.txt]` · `[P11 | analysis/BATCH-02/rtf/text/015.txt]` · `[P11 | analysis/BATCH-02/rtf/text/175.txt]` · `[P11 | analysis/BATCH-02/rtf/text/176.txt]` · `[P11 | analysis/BATCH-02/rtf/text/180.txt]`

### 6.4 The CBC sheet's terminology block (bonus clinical rule)

* **Microcytic** — MCV less than normal (**< 80 fL**) · **Normocytic** — MCV within normal range (**80–100 fL**) · **Macrocytic** — MCV greater than normal (**> 100 fL**).
* **Hypochromic** — MCH less than normal (**< 27 pg**) · **Normochromic** — MCH within normal range (**27–31 pg**) · **Hyperchromic** — MCH greater than normal (**> 31 pg**).
* Sample: **lavender-top tube**; 3 pages; 2 embedded EMF images; created 2010-07-16.

`[P11 | analysis/BATCH-02/rtf/text/056.txt | "Terms" block]`

### 6.5 The critical-threshold ↔ schema conflict (restated as a rule)

* The **manual** says the reference-range record carries `Critical range`, critical low/high limits, `Critical flag` and `Critical comment`, and that the critical-range text is printed **only when "print critical ranges" is selected in the report-settings window**.
* The **V2 live `normalrange` table has none of those columns** (18 columns; §4.1).
* **No V2 schema evidence carries those columns** — the 2019 DDL has 18 columns and the embedded schema-update DDL adds none of them.
* **Therefore:** in V2 as shipped, the *critical thresholds the system can actually print* are those a laboratory enters into the frozen `patienttest` snapshot or into the report template; the vendor-shipped clinical thresholds live in the **RTF method sheets**, which are **documentary**, not machine-readable by the application.
* **Evidence class:** schema facts **VERIFIED**; the conclusion that RTF thresholds are *not* machine-consumed is **INFERRED** (no V2 SQL references `Cache\*.rtf`; the RTF sheets are method descriptions with no database linkage — `testlearn` is the only documented bridge and its contents are not recoverable).

---

## 7. Unit conversion rules

### 7.1 Structure and format

| Property | Value | Evidence class |
|---|---|---|
| Table | `converts` | VERIFIED |
| Columns (6) | `testsimp Text(50)`, `Funit Text(?)`, `Sunit Text(?)`, `Factors Double`, `Ffix Integer`, `Sfix Integer` | VERIFIED `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE converts]` |
| Key | **`testsimp`** — the conversion is attached to a test/analyte **name**, not to a testcode | VERIFIED (schema) |
| Row count | **NOT RECOVERABLE** for the live V2 store — no row-level export of the live V2 store exists in the archive | **NOT RECOVERABLE** |
| Distinct source units | `Funit` — the unit the factor converts **from**; how many the live V2 catalogue holds is **NOT RECOVERABLE** | VERIFIED (schema) / **NOT RECOVERABLE** (data) |
| Distinct target units | `Sunit` — the unit the factor converts **to**; how many the live V2 catalogue holds is **NOT RECOVERABLE** | VERIFIED (schema) / **NOT RECOVERABLE** (data) |
| `Ffix` / `Sfix` | integer *fixed-decimal* specifiers — the number of decimal places applied to the **source** and to the **target** side; the value every V2 row carries is **NOT RECOVERABLE** | VERIFIED (schema, types) / **NOT RECOVERABLE** (values) / **INFERRED** (the meaning) |
| `Factors` | `Factors Double` — the multiplicative factor; the factor set of the live V2 catalogue is **NOT RECOVERABLE** | VERIFIED (schema) / **NOT RECOVERABLE** (data) |
| Semantic | `Funit` = "from unit", `Sunit` = "secondary/standard unit", `Factors` = the multiplicative factor, `Ffix`/`Sfix` = the number of decimal places | **INFERRED** for the meaning of `Ffix`/`Sfix` and for the from/to semantics of `Funit`/`Sunit`; the unit strings the live V2 catalogue carries are **NOT RECOVERABLE** |

`[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE converts]`

### 7.2 What the application does with a conversion rule — and what V2 publishes

The `converts` table is a **rule catalogue**: each row says *for this analyte name, multiply by this factor to go from one unit to another, and round to a fixed number of decimal places*. The V2 schema fixes the **shape** of that rule; the **rows** — which analytes carry a rule, which units they convert between, and what the factors are — are **NOT RECOVERABLE** for the live V2 store (§7.1).

The one place where V2 *does* publish a conversion factor set is the **method sheets that ship in the 2019 CD** (`Cache\*.rtf`): every sheet that prints a reference interval prints it in both the conventional unit and the SI unit, so the factor the sheet implies is a V2-shipped figure.

| Sheet | Test | Conventional interval | SI interval | Implied factor |
|---|---|---|---|---|
| `013` | BUN | `10–20 mg/dL` | `3.6–7.1 mmol/L` | ≈ **0.355** (mg/dL → mmol/L for urea) |
| `015` | Bilirubin | `0.3–1 mg/dL` | `1.7–20.5 µmol/L` | ≈ **17.1–20.5** (mg/dL → µmol/L) |
| `176` | Calcium, total | `8.2–10.5 mg/dL` | `2.05–2.54 mmol/L` | ≈ **0.25** (mg/dL → mmol/L) |
| `180` | Chloride | `96–106 mEq/L` | `96–106 mmol/L` | = **1** (mEq/L → mmol/L) |

`[P11 | analysis/BATCH-02/rtf/text/013.txt]` · `[P11 | analysis/BATCH-02/rtf/text/015.txt]` · `[P11 | analysis/BATCH-02/rtf/text/176.txt]` · `[P11 | analysis/BATCH-02/rtf/text/180.txt]`

**Worked arithmetic (on the sheets' own figures; the printed intervals are rounded, so the implied factor is itself approximate):**
* BUN: `10 mg/dL × 0.355 = 3.55 mmol/L`; `20 mg/dL × 0.355 = 7.10 mmol/L` — both bounds match the sheet.
* Calcium: `8.2 mg/dL × 0.25 = 2.05 mmol/L` — the lower bound matches the sheet.
* Chloride: `100 mEq/L × 1 = 100 mmol/L` — the identity conversion.

The RTF SI conversions are **not** the `converts` table (the factors are hard-coded in the sheets) — the two conversion systems are independent. **INFERRED.**

### 7.3 Rules and caveats

1. **Conversion is per analyte name, not per test id.** A rename of `testsimp` in `testtable` silently orphans the conversion row. **INFERRED** (schema: `converts.testsimp` has no FK to `testcode`).
2. **Both sides are rounded to a fixed number of decimal places** (`Ffix` / `Sfix`); the number every V2 row carries is **NOT RECOVERABLE**. **VERIFIED** (schema) / **NOT RECOVERABLE** (values).
3. **Units come from the `testunits` dictionary** (`unitsid`, `unitsname`) — the `converts.Funit` / `Sunit` strings are *free text* and are not required to match a `testunits.unitsname` entry. **VERIFIED** (schema); whether they do match in the live V2 catalogue is **NOT RECOVERABLE**.
4. **The live V2 conversion catalogue is NOT RECOVERABLE** — only its 6-column schema is. **VERIFIED** (schema) / **NOT RECOVERABLE** (rows and values).

---

## 8. Embedded schema-update rules

### 8.1 What the embedded DDL does at startup

* The 1.605 executable carries **268 DDL statements** (CREATE / ALTER) in its string pool, extracted with their virtual addresses into `analysis/BATCH-04/schema/ddl-all.txt` (807 lines, each statement preceded by `-- VA <hex>  [ALTER|CREATE]`). `[P11 | analysis/BATCH-04/schema/ddl-all.txt | header + per-statement VA comments]`
* Each logical change is emitted **twice** — a SQL-Server dialect and an Access/Jet dialect — so one code path serves both engines (BR-MIG-002).
* The statements cover, in order of appearance: `testtemp` (CREATE + ALTER normalrang→MEMO) · `semen.testcode` · `patientinfo.gehaname` · `MyLabSetting` (CREATE) · `lipids.nonhdl` · `BloodGases.pO2AA1/pO2AA2/ctCO2/Aniongap/HCO3std/FiO2/ctHB/TempRAT` · `CSFT.rbc2/wbc2` · `patienttest.NatighU` · `smslist` (CREATE + `send`) · `SMSSender` (CREATE + `username`) · `SMStemplate` (CREATE) · `smsgroups` (CREATE) · `patientinfo.PFax/SMSMob/PatRPW` · `payment.paymentnum` · `PTC.concent→float`, `PTC.ConstID` · `testtable.testcodebill` · `wasl.resultt/testunit/RESULTCASEPRINT/normalrang/testcodex/subgroupname` · `patientinfo.moreinfo2` · `testtable.REFRANGE` · `normalrange.REFRANGE` · `normalrange.normalrang→varchar(MAX)` and `→ Memo` · `pregnancy.normalrange3` · `cultures.organism/organism2/organism3→varchar(80)`, `cultures.condition2`, `cultures.Few5..Few8` · `cultureanti.Sensitivityvalue→varchar(10)` · `semen.Liquefaction→varchar(10)`, `semen.Viscosity→varchar(15)` · `Gehats.ReferredPW/ReferredID` · `ratios.albu/albcreat` · `Proelectrophoresis.Beta2/immunolgo` · `Kidney.egfr` · `useraccounts.Gtype/HDD1/HDD2` · `Abuse.ecstasy/tramadol` · `Helicobacter` (CREATE + hpab/hpbiop/hpiga) · `IgEallergy` (CREATE) · `FMF` (CREATE) · `LBC` (CREATE) · `pictures` (CREATE + 42 numsx*/shapesx* columns) · `hba1c` (CREATE) · `widal2` (CREATE) · `ratios` (CREATE) · `urine.T56/T57/testid` · `stool.t56/t57/t58` · `testtemp` · `insulin` · `patienttestgroup` · `Paste Errors`.
* **⚠ The trigger is NOT RECOVERABLE.** No V2 SQL statement in the recovered 1,798-statement pool performs any of these ALTERs, and no statement creates a schema-update log table. The analysis infers the schema update runs **on the customer's machine** rather than at CD-build time (BR-MIG-006).

### 8.2 The applied / not-applied ledger

**Against the shipped 2019 `Patients.mdb`** (`analysis/BATCH-07/db/v2019-Patients.mdb.sql`):

| Bucket | Count | Verdict string in the source |
|---|---:|---|
| CREATE statements in the DDL | **27** | — |
| … tables **created by the schema update** | **12** | created |
| … tables that **already existed** | **9** | already existed |
| … tables **absent** from the shipped DB | **6** | absent |
| ALTER-ADD statements in the DDL | **228** | — |
| … columns **added by the schema update** | **22** | added |
| … columns that **pre-existed** | **145** | pre-existed |
| … columns **not applied** | **61** | NOT-APPLIED |
| … of which target **SQL-Server-only tables** | **23** | — |
| … of which target **existing Access tables** | **38** | — |

`[P11 | analysis/BATCH-07/migration-proof.json | summary]` · `[P11 | analysis/BATCH-07/migration-proof.md | §1, §2, §3]`

**The 12 tables created by the schema update:** `Helicobacter`, `MyLabSetting`, `SMSSender`, `SMStemplate`, `insulin`, `patienttestgroup`, `smsgroups`, `smslist`, `testtemp`, `Paste Errors` (10 named in §3 of the markdown) — plus the 2 further entries the JSON's `create_checks` array records with the same verdict (the array contains duplicate rows for the dual-dialect statements). `[P11 | analysis/BATCH-07/migration-proof.md | §3 bullet 1]` · `[P11 | analysis/BATCH-07/migration-proof.json | create_checks]`

**The 6 absent tables:** `LBC`, `IgEallergy`, `FMF` (each appearing twice in the DDL, once per dialect). `[P11 | analysis/BATCH-07/migration-proof.md | §1 rows LBC / IgEallergy / FMF]`

**The 22 applied ALTERs (unique table.column, with the count of DDL variants):**

| Table | Column | Variants | Dialect / type |
|---|---|---:|---|
| `semen` | `testcode` | 1 | `Smallint` |
| `SMSSender` | `username` | 1 | `varchar(50)` |
| `Gehats` | `ReferredPW` | 1 | `varchar(20)` |
| `Gehats` | `ReferredID` | 1 | `int` |
| `smslist` | `send` | 1 | `Smallint` |
| `patientinfo` | `PFax` | 1 | `varchar(15)` |
| `patientinfo` | `SMSMob` | 1 | `varchar(15)` |
| `patientinfo` | `PatRPW` | 1 | `varchar(20)` |
| `payment` | `paymentnum` | 2 | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` |
| `PTC` | `ConstID` | 2 | `bigint IDENTITY(1,1) NOT NULL` / `AUTOINCREMENT(1,1)` |
| `testtable` | `testcodebill` | 2 | `nvarchar(13)` / `varchar(13)` |
| `cultures` | `organism3` | 2 | `varchar(80)` |
| `cultures` | `condition2` | 1 | `varchar(50)` |
| `ratios` | `albu` | 1 | — |
| `ratios` | `albcreat` | 1 | — |
| `patientinfo` | `moreinfo2` | 3 | `varchar(30)` / `text(30)` |

`[P11 | analysis/BATCH-07/migration-proof.json | alter_checks (verdict = added by the embedded schema update)]` · `[P11 | analysis/BATCH-04/schema/ddl-all.txt | corresponding VA statements]`

**The 23 SQL-Server-only unapplied statements** — these can **never** apply to the Access build:
`useraccounts.HDD1`, `useraccounts.HDD2`, `useraccounts.Gtype` · `Patients.branche`, `Patients.SecWord`, `Patients.grant13..grant17` · `IgEallergy.Item12/Item24/Item36` · `Kidney.egfr` · `lipids.nonhdl` · plus the SQL-Server-dialect variants of the dual-dialect statements.
`[P11 | analysis/BATCH-07/migration-proof.md | §3 bullet 3]` · `[P11 | analysis/V-CD-2019/02-schema.md | §3 rows for Patients / useraccounts / IgEallergy / Kidney / lipids]`

**The 38 unapplied statements inside existing Access tables — named examples:**
`BloodGases.pO2AA1`, `pO2AA2`, `ctCO2`, `Aniongap`, `HCO3std`, `FiO2`, `ctHB`, `TempRAT` (8) · `cultures.Few5`, `Few6`, `Few7`, `Few8` (4) · `prostaticx.crystalp`, `crystalp2`, `crystalp2r`, `crystalpr`, `crystalpt` (5) · `urine.T56` · `patientinfo.gehaname` · `patienttest.NatighU` · `patientinfo.PatRPW`/`PFax`/`SMSMob` variants.
`[P11 | analysis/BATCH-07/migration-proof.md | §3 bullet 4]`

### 8.3 Business consequences of the partial schema update

| # | Consequence | Evidence class |
|---|---|---|
| 1 | **Blood-gas derived parameters are unavailable** on the Access build (8 columns absent): anion gap, standard bicarbonate, ctCO2, ctHB, FiO2, temperature ratio, arterial pO2 AA1/AA2. | INFERRED (from the not-applied list) |
| 2 | **Lipid non-HDL is unavailable.** | INFERRED |
| 3 | **The IgE-allergy profile is absent** (`IgEallergy` never created; `LBC`, `FMF` absent). | VERIFIED (create ledger) |
| 4 | **The user-entitlement/permissions columns are absent** (`useraccounts.Gtype/HDD1/HDD2`) — the SQL-Server permissions model is unreachable in Access. | VERIFIED |
| 5 | **NATIGH.COM e-result delivery cannot function** (`patienttest.NatighU` missing). | VERIFIED |
| 6 | **Referring-party PW/ID lookup partially works**: `Gehats.ReferredPW` and `ReferredID` *were* added. | VERIFIED |
| 7 | **The three-organism culture feature works** (`cultures.organism3`, `condition2` applied) but the fourth culture-sensitivity dropdowns (`cultures.Few5..Few8`) were not. | VERIFIED |
| 8 | **Identity columns exist on `payment`, `PTC`, `smslist`, `SMSSender`** — i.e. the V2 data model introduces surrogate keys on the four tables that previously had none. | VERIFIED |

### 8.4 The design conclusion stated by the analysis

> "The system applies its own schema evolution. Any replacement needs an **explicit, tested schema-update repository** — not run-time difference detection."
> `[P11 | analysis/BATCH-07/migration-proof.md | §3 closing note "الأثر على التصميم"]`

---

## 9. Explicit negative conditions and exceptions stated by the evidence

| # | Negative condition / exception | Source | Class |
|---|---|---|---|
| N1 | **Do not change the number of a test, nor the identity of the number assigned to each test.** Specifically: urine test **number 4** must not be changed to any other number, and — **even if that slot is empty** — its data and names ("Urine", "Urine Examination", "Urineanalysis") must not be modified. | `help.chm` topic `nots.htm` (shipped in the 2019 CD) `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §15 item 2]` | VERIFIED |
| N2 | **Converting the database engine does not move the data** — "If you convert from one type to another you will not able to see the stored data on the first database type, But they remain stored on the HDD." | installer string `[P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2]` | VERIFIED |
| N3 | **A result may not be printed unless it is verified** — "Not found any Verified selected tests or result to print it". | 1.605 literal `[P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §4]` | VERIFIED |
| N4 | **Results must be reviewed before printing, and printed before delivery** ("must be reviewed so the user can print them, and they must be printed so the user can deliver them"). | `help.chm` `005.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7]` | VERIFIED |
| N5 | **Changing the external lab's name is NOT saved as the default for that test**; to make it the default you must press "always to" before OK/net. | `help.chm` `010.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 note]` | VERIFIED |
| N6 | **A test that is not marked sent-out can still be sent out without changing the system data** (from the sent-out window's dropdown). | `help.chm` `010.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §12 part 7]` | VERIFIED |
| N7 | **The delivery state can be forced** — the "مستلمة" button marks a result as delivered even if delivery did not happen. | `help.chm` `005.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §7 part 4]` | VERIFIED |
| N8 | **The critical-range text is printed ONLY when "print critical ranges" is selected** in the report-settings window. | `help.chm` `008.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10]` | VERIFIED |
| N9 | **A test whose rate is the same for both sexes must still be entered six times** (M/F × 0–120 y, M/F × 1–29 d, M/F × 1–11 mo). | `help.chm` `008.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §10]` | VERIFIED |
| N10 | **A large test cannot be printed in a combined report** ("Print with other" is cleared for urine/stool). | `help.chm` `007.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9]` | VERIFIED |
| N11 | **A multi-result test cannot show a result inline** in the patient window ("See report": urine, stool, blood picture). | `help.chm` `007.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9]` | VERIFIED |
| N12 | **The "Main test" flag is cleared on the other elements** of a profile. | `help.chm` `007.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9]` | VERIFIED |
| N13 | **Tests are not automatically added with their group** where the group addition is unwanted (the GGT-with-liver-enzymes example). | `help.chm` `007.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9]` | VERIFIED |
| N14 | **`Test time = 0` means same-day**; the receipt's result date is computed from it in days. | `help.chm` `007.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §9]` | VERIFIED |
| N15 | **The last backup does NOT contain data that was zeroed or cleared** ("except in case of the database being zeroed and some information cleared"). | `help.chm` `backup.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]` | VERIFIED |
| N16 | **Backup size does not affect performance — EXCEPT** when adding patients to the backup DB or searching from within the system in the backup DB. | `help.chm` `backup.htm` `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]` | VERIFIED |
| N17 | **The install media contains no application copy** — no `.exe`, `.mdb`, `.ini` or `.dat` in either CAB. | `[P11 \| analysis/V-CD-2019/12-install-media.md \| §1]` | VERIFIED |
| N18 | **`Branch_Data.mdb` contains zero rows in every one of its 49 tables** — it is a schema template, not data. | `[P11 \| real lab system\RL_CD2019Access\bin\Branch_Data.mdb \| schema template]` · `[P11 \| reports/Stage-2b-Cumulative-Analysis-Report.md \| §1 summary row "Branch_Data.mdb"]` | VERIFIED |
| N19 | **`Cache\*.rtf` are NOT print templates** and **`Cache\*.exe` are NOT an interactive report host**. | `[P11 \| 10-Issues/Open-Issues-and-Limitations.md \| BUG-08, BUG-09, ISS-31]` | VERIFIED |
| N20 | **38 ALTER statements inside existing Access tables were NOT applied**, and **23 target SQL-Server-only tables** and can never apply to the Access build. | `[P11 \| analysis/BATCH-07/migration-proof.md \| §3]` | VERIFIED |
| N21 | **`patienttest.NatighU`, `patientinfo.gehaname`, `useraccounts.Gtype/HDD1/HDD2`, `lipids.nonhdl`, `BloodGases.*`, `cultures.Few5..Few8`, `prostaticx.crystalp*`, `urine.T56`, `Proelectrophoresis.Beta2/immunolgo`** are all NOT applied to the shipped 2019 Access database. | `[P11 \| analysis/BATCH-07/migration-proof.md \| §2 and §3]` | VERIFIED |
| N22 | **The V2 live `normalrange` has no critical-range columns** even though the manual documents them; a 22-column shape carrying them is **not attested for V2**. | `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql \| CREATE TABLE normalrange]` · `[P11 \| analysis/BATCH-04/schema/ddl-all.txt \| grep critical → no match]` | VERIFIED |
| N23 | **The help file shipped with V2 carries a pre-2019 product banner in its page header** — the shipped documentation describes a system generation older than the one it accompanies. | `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| page header]` · `[P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §7]` | VERIFIED |
| N24 | **The backup database that ships with the 2019 CD is not a refreshed mirror of `Patients.mdb`** — it was left untouched when the store was migrated, so its row content is **NOT RECOVERABLE** for V2. | `[P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6.1 note 2]` | VERIFIED |
| N25 | **The standard install path does NOT register fonts in the registry** — fonts are installed manually via Control Panel. | `[P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §6 closing note]` | VERIFIED |
| N26 | **No path exists from the application to Ghostscript / Xpdf / PDF Power Tool** — those are manual tools; the PDF route is application → printer driver → Ghostscript. | `[P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §5 transition 4]` | VERIFIED |
| N27 | **There is no SQL in the PDF path** — the classification of a report into Contracts / Free / Individual / LabToLab is not data-driven in a recoverable way. | `[P11 \| analysis/V-CD-2019/13-pdf-print-architecture.md \| §5 transition 6]` | VERIFIED |
| N28 | **The database-engine choice cannot be skipped** — "You don't select the database type, Please select the type first"; the installer closes. | `[P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2]` | VERIFIED |
| N29 | **Licence is void on hardware change** — "If the computer hard disk, Mother board and CPU damage or lost the RealLab not responsible and you will purchased the other license". | `[P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §4]` | VERIFIED |
| N30 | **The maintenance password ships as `123`** and the manual recommends changing it. | `[P11 \| analysis/BATCH-04/help_v1605/help-manual-ar.md \| §14]` | VERIFIED |
| N31 | **Clear-text credentials appear in five independent places** (`Setup.bat`/`Setup4.bat` `SAPWD=12345678`; `BASE.ini`; `data_connection1.udl`; `RL_SETUP.exe`; and `BASE.ini [lastlog]` in 2019). | `[P11 \| analysis/V-CD-2019/08-deployment-installer.md \| §2.2]` | VERIFIED |
| N32 | **`SetupPZ.bat` / `Setup5.bat` set `DISABLENETWORKPROTOCOLS=0`** — the shipped SQL Server Express instance listens on the network with a weak password. | `[P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-36]` | VERIFIED |

---

## 10. Outstanding questions and NOT-RECOVERABLE items

### 10.1 V2 data that cannot be recovered from this archive

| # | Item | Why it is not recoverable | Consequence for a replacement system |
|---|---|---|---|
| X1 | **Row counts and row content of the live V2 `Patients.mdb`** (`converts`, `testunits`, `abbreviations`, `constanttable`, `PTC`, `patienttest`, `patientinfo`, `wasl`, `payment`, `history`) | The 2019 schema was shipped as **DDL only** (`v2019-Patients.mdb.sql`); no row-level export of the live V2 store exists in the archive. The counts that *are* published for V2 — 852 reference ranges, 609 tests, 46 report profiles — are quoted in §4.3 with their source. | Every other catalogue count must be treated as **unknown for V2**; the 852 / 609 / 46 figures are **V2-published catalogue figures**, and the conversion, unit, abbreviation, constant and result-row counts are **NOT RECOVERABLE**. `[P11 \| analysis/BATCH-07/db/v2019-Patients.mdb.sql]` |
| X2 | **The numeric values of `constanttable` in the live V2 store** | No row-level export of the live V2 `constanttable` exists in the archive. | The formulas and values are documented for the CBC group (BR-CLIN-001…005); every other slot's value can only be asserted from the manual (BR-CLIN-006…009). |
| X3 | **The values of `PTCONS.constant1`…`constant4` in the live V2 store** | as X2 | The PT control times, the ISI and the "Control Time / Concentration" token are **NOT RECOVERABLE**; the manual names them but gives no numbers. |
| X4 | **`RATIOS` constant group** — values and purpose | No `RATIOS` row is attested for the live V2 store; only the query is attested. | A whole clinical-constants module is undocumented. |
| X5 | **The `pregsmok` runtime semantics** and its value distribution | The live V2 rows were never exported; the proposed resolution step (compare `patienttest` with `normalrange`) cannot be performed. | ISS-26 stays **OPEN**. `[P11 \| 10-Issues/Open-Issues-and-Limitations.md \| ISS-26]` |
| X6 | **`patienttest.NatighU` behaviour** (NATIGH.COM protocol) | The column is not applied; no protocol documentation is in the archive. | The e-results channel cannot be reconstructed. |
| X7 | **The schema-update trigger** (what causes the 268 DDL statements to run) | No V2 SQL in the 1,798-statement pool performs them; no schema-update log table exists. | A replacement needs an explicit, tested schema-update repository. |
| X8 | **The `patientid` composition** (all 13 characters) | Only `SUBSTRING(patientid,9,1)` (branch) and `SUBSTRING(patientid,10,3)` (short display id) are attested; the generator is not. | Patient-id generation must be re-specified. |
| X9 | **The barcode symbology** and the encoding of `kawmy` | `barcodesymb`, `barcode1..3`, `kawmy` exist; no encoding rule is documented. | Barcode/ID-card printing must be re-specified. |
| X10 | **`payment.type` value set**, **`smslist.smstype` value set**, **`MyLabSetting` field semantics**, **`patRPW`/`PBirthDay` meaning**, **`Paste Errors` meaning**, **`testtemp.detelethis` meaning** | Column names only; no documentation or data. | Six entity semantics remain undefined. |
| X11 | **The 24 colour slots** (`colorj`, `colork`, `colori`, `coloro`, `colors`, `colort`, …) | Only the key names and the changed values are on file. | Report styling cannot be reproduced exactly. |
| X12 | **The `_S.ini` layout variants' difference from their base file** | The diff engine reports key deltas without semantic labels; the `_S` bodies of the 2019 CD were never diffed against their base files. | 110 second-layout variants remain unspecified. |
| X13 | **The Contracts / Free / Individual / LabToLab report classification rule** | The PDF path contains no SQL; the routing is inside the print driver. | Output segregation must be re-specified. |
| X14 | **`testcode` ↔ profile mapping for the hard-coded print sets** | Only numeric lists are attested, without names. | Per-profile print scoping must be re-derived. |
| X15 | **Whether the manual's critical-range fields still exist in the V2 UI** | The shipped CHM is frozen at the pre-2019 text and does not describe the 1.605 behaviour; the schema has no such columns. | A documentation-vs-behaviour conflict that only the running V2 binary can settle. |

### 10.2 Open issues that bear directly on business rules

| ISS | Statement | Bearing on the rules | Status |
|---|---|---|---|
| **ISS-18** | The backup database that ships with the 2019 CD was **not refreshed** when the store's schema was updated — i.e. it is **not** a refreshed copy. | Undercuts BR-SETUP-015's "the last backup contains all data" reading for the shipped artefact. `[P11 \| analysis/V-CD-2019/11-deployment-payload-2019.md \| §6.1 note 2]` | **OPEN** |
| **ISS-26** | `normalrange.pregsmok` unexplained (a `Single` value in every row). | BR-RANGE-011. | **OPEN** |
| **ISS-27** | `Data\` holds **223** layout files against **114** report categories; 110 are `_S` files and numeric filenames match no profile. | BR-RPT-001, BR-RPT-013, BR-RPT-015. | **OPEN** |
| **ISS-29 / ISS-32** | The Arabic titles of the 29 RTF sheets cannot be decoded cleanly on Linux. | BR-RPT-016, §6 — the thresholds survive because the bodies are ASCII. | **Accepted limitation** |
| **ISS-30** | The row content of the live V2 `patientinfo` table is **NOT RECOVERABLE** — no patient data is available for validation. | BR-MIG-012. | **OPEN** |
| **ISS-34** | The `win32_processor` and `loger` tables in the 1.605 SQL. | BR-SETUP-009 (licence check) and BR-CAT-007 — the "loger" table is plausibly an event log, undocumented. | **OPEN** |
| **ISS-35 / ISS-43** | The documentation layer shipped with V2 is frozen at its pre-2019 text. | BR-RPT-016, BR-MIG-014 — every manual-derived rule in this document is a 2010-era statement about a 2020 binary. | **Documented** |
| **ISS-45** | The schema update is **partial** on the shipped database (38 Access columns not added). | BR-MIG-006. | **Documented** |

---

## 11. Provenance and method

This catalogue was authored from the source findings file `03_business_rules_findings.md`, which was itself extracted from the evidence archive `Reference_V2_Patches_04-11.zip` (patch folders 04..11, markers `[P04] [P05] [P06] [P07-08] [P09] [P10] [P11]`). The evidence roots used are `[P11 | analysis/**]` (the 1.605 SQL pool, the embedded schema DDL, the 2019 DDL dumps, the installer and payload analyses, the RTF method-sheet library, the SHA-256 inventory ledger and the open-issue register) and `[P11 | analysis/V-CD-2019/**]` (the V2 synthesis documents, which publish the catalogue-level row counts quoted in §4.3). A figure that is read from the live V2 store — a row count, a value distribution or a cell value — is only stated where a V2-primary source publishes it; otherwise the structure is kept and the figure is marked **NOT RECOVERABLE**. Evidence classes are **VERIFIED**, **INFERRED**, **UNVERIFIED**, **NOT DOCUMENTED** and **NOT RECOVERABLE**, used with the meanings defined in §0.3; a claim derived by this analysis rather than read from an artefact is always labelled, never presented as verified. Rule identifiers (`BR-*`) are documentation-only labels created by the analysis and do not exist in the product, and every table, column, INI key, form, method, file, printer-role and screen title is reproduced verbatim. Counts were verified against the tables of the source findings file: a rule is one `#### BR-xx-nnn` heading, a domain's rule count is the number of such headings in that domain's subsection, and the catalogue total is the sum of the ten domain counts (14 + 17 + 19 + 17 + 9 + 11 + 17 + 11 + 17 + 14 = **146** rules); column, row and DDL-statement counts are counted from the numbered rows of the corresponding table.

## Appendix A — Rule index (documentation-only IDs)

| Domain | Rule IDs | Count |
|---|---|---:|
| A — Clinical constants & formulas | BR-CLIN-001 … BR-CLIN-014 | 14 |
| B — Reference ranges & flags | BR-RANGE-001 … BR-RANGE-017 | 17 |
| C — Result lifecycle & state machine | BR-LIFE-001 … BR-LIFE-019 | 19 |
| D — Profile / catalogue management | BR-CAT-001 … BR-CAT-017 | 17 |
| E — Branch & identifier rules | BR-ID-001 … BR-ID-009 | 9 |
| F — Billing & receivables | BR-BILL-001 … BR-BILL-011 | 11 |
| G — Reporting & printing | BR-RPT-001 … BR-RPT-017 | 17 |
| H — SMS & notifications | BR-SMS-001 … BR-SMS-011 | 11 |
| I — Setup & configuration | BR-SETUP-001 … BR-SETUP-017 | 17 |
| J — Data integrity & embedded schema evolution | BR-MIG-001 … BR-MIG-014 | 14 |
| **Total** | | **146** |

## Appendix B — Appendix: the V2 `testtable` column set (38 columns)

`testcode`, **`testcodebill`**, `arrangnum`, `subgroupcode`, `testsimp`, `testabrev`, `testname`, `waslname`, `waslname2`, `historyname`, `barcodesymb`, `testnamear`, `subgroupname`, `loggroup`, `active`, `inotherlab`, `otherlabname`, `otherlabprice`, `patientprice`, `labprice`, `anyqus`, `thequse`, `testdiscr`, `testeffect`, `testusage`, `typeofsample`, `deleteprotect`, `testtime`, `printwith`, `barcode1`, `barcode2`, `barcode3`, `branch`, `seereport`, `normaltype`, `addorno`, `testorno`, **`REFRANGE`**
*(bold = added by the embedded schema-update DDL)* `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE testtable]`

## Appendix C — Appendix: the V2 `patientinfo` column set (39 columns)

`patientsefa`, `patientnamear`, `patientsex`, `patientaddress`, `patientphone`, **`PFax`**, **`PatRPW`**, **`SMSMob`**, `requestdate`, `outdate`, `timein`, `referredbysefa`, `referredbyname`, **`gehaName`**, `pricemethod`, `totalprice`, `patientageunit`, `elmadfoo3`, `elbakyma3mal`, `totalpricedisc`, `patientid`, `labid`, `patientage`, **`PBirthDay`**, `discount100`, `discount`, `mowzaf`, `editdate`, `completes`, `recepnote`, `moreinfo`, `barcode`, `patienttel`, `email`, `kawmy`, `edituser2`, `editdate2`, `editnum`, **`moreinfo2`**
*(bold = added by the embedded schema-update DDL; `gehaName` is **NOT APPLIED** to the shipped Access DB — BR-MIG-005)* `[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE patientinfo]`

## Appendix D — Appendix: the 10 tables created by the embedded schema update and their column counts

| Table | Columns | Purpose (per the DDL) |
|---|---:|---|
| `testtemp` | 28 | scratch table for results in progress |
| `MyLabSetting` | 20 | laboratory settings (incl. SMS configuration) |
| `smsgroups` | 3 | recipient groups |
| `smslist` | 6 | recipient directory |
| `SMStemplate` | 2 | SMS body templates |
| `SMSSender` | 8 | outbound SMS log |
| `insulin` | 2 | insulin analyte catalogue |
| `patienttestgroup` | 46 | group-request result rows (clone of `patienttest`) |
| `Helicobacter` | 6 | H. pylori profile |
| `Paste Errors` | 6 | paste-failure log (undocumented) |

`[P11 | analysis/BATCH-07/db/v2019-Patients.mdb.sql | CREATE TABLE …]` · `[P11 | analysis/BATCH-07/migration-proof.md | §1]`

---

*End of catalogue. All rule IDs are documentation-only labels assigned by this analysis; no identifier in this document exists in the product. Every count cited above is reproducible from the named file.*
